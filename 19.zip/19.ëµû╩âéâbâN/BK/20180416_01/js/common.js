function change-open-close(){
  var status = $('#test-div1').css("display");

  if(status == "none"){
    $('#test-div1').css("display", "block");
  } else {
    $('#test-div1').css("display", "none");
  }
}
