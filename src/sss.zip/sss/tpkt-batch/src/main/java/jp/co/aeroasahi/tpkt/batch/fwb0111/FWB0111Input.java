package jp.co.aeroasahi.tpkt.batch.fwb0111;

import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】SAP仕入先マスタ＞のInputBean。
 */
@Setter
@Getter
public class FWB0111Input {

    /** 処理区分 */
    private String KBN;

    /** 共通転記ブロック */
    private String SPERR;

    /** 仕入先または債権者の勘定コード */
    private String LIFNR;

    /** 会社コード */
    private String BUKRS;

    /** 勘定グループ */
    private String KTOKK;

    /** 名称１ */
    private String NAME1;

    /** 名称２ */
    private String NAME2;

    /** 名称３ */
    private String NAME3;

    /** 名称４ */
    private String NAME4;

    /** 検索用語1 */
    private String SORT1;

    /** 検索用語2 */
    private String SORT2;

    /** 地域（都道府県） */
    private String REGION;

    /** 地名 */
    private String STREET;

    /** 市区町村の郵便番号 */
    private String POST_CODE1;

    /** 市区町村 */
    private String CITY1;

    /** 所在地 */
    private String CITY2;

    /** 地名２ */
    private String STR_SUPPL1;

    /** 地名３ */
    private String STR_SUPPL2;

    /** 国コード */
    private String COUNTRY;

    /** 電話番号: コード + 番号をダイアル */
    private String TEL_NUMBER;

    /** 電話番号: 内線 */
    private String TEL_EXTENS;

    /** FAX 番号: 局番 + 番号 */
    private String FAX_NUMBER;

    /** 電子メールアドレス */
    private String SMTP_ADDR;

    /** 通信方法 (キー) (ビジネスアドレスサービス) */
    private String DEFLT_COMM;

    /** 住所注記 */
    private String REMARK;

    /** 名称１ */
    private String NAME1_B;

    /** 名称２ */
    private String NAME2_B;

    /** 名称３ */
    private String NAME3_B;

    /** 名称４ */
    private String NAME4_B;

    /** 検索語句 1 */
    private String SORT1_B;

    /** 検索語句 2 */
    private String SORT2_B;

    /** 地域（都道府県） */
    private String REGION_B;

    /** 地名 */
    private String STREET_B;

    /** 市区町村 */
    private String CITY1_B;

    /** 所在地 */
    private String CITY2_B;

    /** 地名２ */
    private String STR_SUPPL1_B;

    /** 地名３ */
    private String STR_SUPPL2_B;

    /** 部屋/アパート番号 */
    private String ROOMNUMBER_B;

    /** 住所注記 */
    private String REMARK_B;

    /** 名称１ */
    private String NAME1_C;

    /** 名称２ */
    private String NAME2_C;

    /** 名称３ */
    private String NAME3_C;

    /** 名称４ */
    private String NAME4_C;

    /** 検索語句 1 */
    private String SORT1_C;

    /** 検索語句 2 */
    private String SORT2_C;

    /** 地域（都道府県） */
    private String REGION_C;

    /** 地名 */
    private String STREET_C;

    /** 市区町村 */
    private String CITY1_C;

    /** 所在地 */
    private String CITY2_C;

    /** 地名２ */
    private String STR_SUPPL1_C;

    /** 地名３ */
    private String STR_SUPPL2_C;

    /** 部屋/アパート番号 */
    private String ROOMNUMBER_C;

    /** 住所注記 */
    private String REMARK_C;

    /** 得意先コード */
    private String KUNNR;

    /** 取引先の会社 ID */
    private String VBUND;

    /** グループキー */
    private String KONZS;

    /** 標準キャリアコード */
    private String SCACD;

    /** 源泉徴収税対象者の出生地 */
    private String GBORT;

    /** 銀行国コード */
    private String BANKS;

    /** 銀行コード */
    private String BANKL;

    /** 口座番号 */
    private String BANKN;

    /** 口座名義人名 */
    private String KOINH;

    /** 預金種別 */
    private String BKONT;

    /** 銀行手数料負担コード */
    private String DTAWS;

    /** 総勘定元帳の統制勘定 */
    private String AKONT;

    /** 本店勘定コード */
    private String LNRZE;

    /** 計画グループ */
    private String FDGRV;

    /** 旧マスタレコードのコード */
    private String ALTKN;

    /** 少数コード */
    private String MINDK;

    /** 従業員番号 */
    private String PERNR;

    /** 支払条件キー */
    private String ZTERM;

    /** 考慮される支払方法一覧 */
    private String ZWELS;

    /** フラグ: 得意先と仕入先間の相殺決済 */
    private String XVERR;

    /** 下請法対象候補区分 */
    private String MGRUP;

    /** 記帳担当者 */
    private String BUSAB;

    /** 関係会社担当者のインターネットアドレス */
    private String INTAD;

    /** コメント */
    private String KVERM;

    /** 源泉徴収税国コード */
    private String QLAND;

    /** 源泉徴収税タイプコード */
    private String WITHT;

    /** 源泉徴収税コード */
    private String WT_WITHCD;

    /** フラグ:源泉税課税対象 */
    private String WT_SUBJCT;

    /** 処理ステータス */
    private String STATUS;

    /** メッセージテキスト */
    private String MSG_TEXT;

    /** 作成日 */
    private String INS_DT;

    /** 更新日 */
    private String UPD_DT;

}
