package jp.co.aeroasahi.tpkt.batch.mdb0901;

import org.apache.ibatis.annotations.Param;

/**
 * キューブの自動デプロイのリポジトリ
 */
public interface MDB0901Repository {

    /**
     * キューブ自動デプロイのプロシージャを実行する
     *
     * @return
     */
    void automaticCompilation(@Param("folderName") String folderName, @Param("projectName") String projectName, @Param("packageName") String packageName);
}
