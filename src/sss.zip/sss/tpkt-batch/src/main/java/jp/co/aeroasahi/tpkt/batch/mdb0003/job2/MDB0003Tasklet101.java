package jp.co.aeroasahi.tpkt.batch.mdb0003.job2;

import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.mdb0003.BatchDataHolder;
import jp.co.aeroasahi.tpkt.batch.mdb0003.BatchJobRequestInput;
import jp.co.aeroasahi.tpkt.batch.mdb0003.MDB0003Repository;

/**
 * 外注情報取込を実行するTasklet
 */
@Component
@Scope("step")
public class MDB0003Tasklet101 implements Tasklet {

    /** メインバッチジョブID */
    private static final String JOB_ID = "mdb0003Job";

    /** 外注情報取込ジョブ名 */
    private static final String OUTSOURCING_JOB_NAME = "mdb0402Job";

    @Inject
    MDB0003Repository mdb0003Repository;

    @Autowired
    private BatchDataHolder batchDataHolder;

    /**
     *
     * マインバッチ処理
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return 一括で各ジョブを実行した状態
     */
    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

        BatchJobRequestInput input = new BatchJobRequestInput();

        String jobStartDateTime = batchDataHolder.getJobStartDateTime();

        input.setJobName(OUTSOURCING_JOB_NAME);
        input.setJobParameter(getJobParameter(jobStartDateTime));
        input.setPriority(1);
        input.setPollingStatus("INIT");
        input.setCreateDate(jobStartDateTime);

        mdb0003Repository.create(input);

        return RepeatStatus.FINISHED;
    }

    private String getJobParameter(String systemDateTimeStr) {
        List<String> params = new ArrayList<>();
        params.add("systemDateTime=" + systemDateTimeStr);
        params.add("jobId=" + JOB_ID);
        return String.join(",", params);
    }
}
