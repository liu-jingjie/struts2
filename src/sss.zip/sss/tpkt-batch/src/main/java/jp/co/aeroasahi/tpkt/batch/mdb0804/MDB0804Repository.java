package jp.co.aeroasahi.tpkt.batch.mdb0804;

import java.util.List;

/**
 * テーブルに操作
 */
public interface MDB0804Repository {

    /**
     * 日次の場合、条件によって、テーブル＜工数金額＞＜プロジェクト＞＜部門マスタ＞＜部門別稼働人数＞＜部門表示順マスタ＞の情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0804PerformanceInput> findAllByDayPerformance(MDB0804PerformanceInput input);

    /**
     * 月次の場合、条件によって、テーブル＜工数金額＞＜プロジェクト＞＜部門マスタ＞＜部門別稼働人数＞＜部門表示順マスタ＞の情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0804PerformanceInput> findAllByMonthPerformance(MDB0804PerformanceInput input);

    /**
     * 条件によって、テーブル＜部門計画工数マスタ＞＜部門マスタ＞＜部門表示順マスタ＞の情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0804PlanInput> findAllByPlan(MDB0804PlanInput input);

    /**
     * 条件によって、テーブル＜積算月別展開データ＞＜プロジェクト＞＜部門マスタ＞＜部門表示順マスタ＞の情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0804EstimateInput> findAllByEstimate(MDB0804EstimateInput input);

    /**
     * 条件によって、テーブル＜操業度管理＞の情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0804Output> findAllByKey();

    /**
     * テーブル＜操業度管理＞に登録する。
     *
     * @param output MDB0804Output
     * @return
     */
    void create(MDB0804Output output);

    /**
     * テーブル＜操業度管理＞に更新する。
     *
     * @param output MDB0804Output
     * @return
     */
    void update(MDB0804Output output);
}