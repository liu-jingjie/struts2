package jp.co.aeroasahi.tpkt.batch.util;

import java.io.File;
import java.io.IOException;
import org.apache.commons.io.FileUtils;

/**
 * 共通のユーティリティー
 */
public class CommonUtils {

    /**
     * ファイルを指定フォルダに移動する
     *
     * @param preFilePath 移動前のファイルの絶対パス
     * @param afterFilePath 移動後のファイルの絶対パス
     *
     * @return 移動する結果(true:正常、false:異常)
     * @throws IOException ファイル移動に失敗した場合
     */
    public static void fileMove(String preFilePath, String afterFilePath) throws IOException {

        fileCopy(preFilePath, afterFilePath);

        deleteFile(preFilePath);
    }

    private static void fileCopy(String preFilePath, String afterFilePath) throws IOException {

        File source = new File(preFilePath);
        File target = new File(afterFilePath);

        FileUtils.copyFile(source, target);
    }

    private static boolean deleteFile(String preFilePath) {

        boolean rtn = false;

        File target = new File(preFilePath);
        rtn = FileUtils.deleteQuietly(target);

        return rtn;
    }
}
