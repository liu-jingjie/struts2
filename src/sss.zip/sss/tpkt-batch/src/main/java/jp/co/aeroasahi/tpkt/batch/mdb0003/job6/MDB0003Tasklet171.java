package jp.co.aeroasahi.tpkt.batch.mdb0003.job6;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.mdb0003.BatchDataHolder;
import jp.co.aeroasahi.tpkt.batch.mdb0003.BatchJobRequestInput;
import jp.co.aeroasahi.tpkt.batch.mdb0003.MDB0003Repository;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

/**
 * 積算実績登録の実行要求をするTasklet
 */
@Component
@Scope("step")
public class MDB0003Tasklet171 implements Tasklet {

    /** メインバッチジョブID */
    private static final String JOB_ID = "mdb0003Job";

    /** 積算実績登録ジョブ名 */
    private static final String SEKISAN_ACT_REGISTER_JOB_NAME = "sbb0201Job";

    @Inject
    DateFactory dateFactory;

    @Inject
    MDB0003Repository mdb0003Repository;

    @Autowired
    private BatchDataHolder batchDataHolder;

    // 日次処理の場合は「D」、月次確定処理の場合は「M」
    @Value("#{jobParameters['shorikbn']}")
    public String shorikbn;

    // 処理年月：日次処理の場合は空白を設定、バッチ実行画面の指定した月次確定対象年月を「YYYYMM」形式
    @Value("#{jobParameters['ym']}")
    public String ym;

    /** DateTimeFormatterのパターン uuuu-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.SSS");

    /**
     *
     * 積算実績登録の実行要求をする
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return ステータス
     */
    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

        // ジョブ番号単位でシステム日時を取得
        String jobStartDateTime = dateFactory.newDateTime().format(dtf);
        batchDataHolder.setJobStartDateTime(jobStartDateTime);

        BatchJobRequestInput input = new BatchJobRequestInput();

        input.setJobName(SEKISAN_ACT_REGISTER_JOB_NAME);
        input.setJobParameter(getParameter(jobStartDateTime));
        input.setPriority(1);
        input.setPollingStatus("INIT");
        input.setCreateDate(jobStartDateTime);

        // 実行要求
        mdb0003Repository.create(input);

        return RepeatStatus.FINISHED;
    }


    private String getParameter(String systemDateTime) {

        String tempYyyyMm = shorikbn.equals("D") ? "" : ym;

        List<String> params = new ArrayList<>();
        params.add("jobKbn=" + shorikbn);
        params.add("jobYm=" + tempYyyyMm);
        params.add("sysDate=" + systemDateTime);
        params.add("systemDateTime=" + systemDateTime);
        params.add("JOB_ID=" + JOB_ID);

        return String.join(",", params);
    }
}
