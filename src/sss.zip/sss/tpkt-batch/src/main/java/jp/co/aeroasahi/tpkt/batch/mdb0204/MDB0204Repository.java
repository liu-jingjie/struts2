package jp.co.aeroasahi.tpkt.batch.mdb0204;

import java.util.List;

/**
 * テーブル＜【TEMP】顧客マスタ＞とテーブル＜SAP得意先マスタ＞に操作
 */
public interface MDB0204Repository {

    /**
     * 全てのSAP得意先マスタ情報を取得する。
     *
     * @return SAP得意先マスタ情報
     */
    List<MDB0204Input> findAll();

    /**
     * テーブル＜【TEMP】顧客マスタ＞に登録する。
     *
     * @param output MDB0204Output
     * @return
     */
    void create(MDB0204Output output);

    /**
     * テーブル＜【TEMP】顧客マスタ＞に削除する。
     *
     * @return
     */
    void delete();
}
