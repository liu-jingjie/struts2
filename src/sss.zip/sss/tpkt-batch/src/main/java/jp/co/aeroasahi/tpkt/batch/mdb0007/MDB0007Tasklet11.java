package jp.co.aeroasahi.tpkt.batch.mdb0007;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import jp.co.aeroasahi.tpkt.batch.util.CommonUtils;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

/**
 * 各ジョブを実行するTasklet
 */
@Component
@Scope("step")
public class MDB0007Tasklet11 implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0007Tasklet11.class);

    @Inject
    DateFactory dateFactory;

    @Inject
    MDB0007Repository mdb0007Repository;

    /** ファイル連携先 */
    @Value("${sap.input.dirpath}")
    String inputDirPath;

    /** ファイルバックアップ先（取込が正常に行われた場合） */
    @Value("${sap.output.dirpath}")
    String outputDirPath;

    /** ファイルバックアップ先（取込で異常が発生した場合） */
    @Value("${sap.error.dirpath}")
    String errorDirPath;

    /** TEMPファイルバックアップ先（一時ファイルの場所） */
    @Value("${sap.temp.dirpath}")
    String tempDirPath;

    private final static String EMPTY = "";

    /** DateTimeFormatterのパターン uuuuMMdd */
    private static final DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("uuuuMMdd");

    /** DateTimeFormatterのパターン uuuu-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf4 = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.SSS");

    /** 得意先マスタのパス */
    private static final String CUSTOMER = "Customer\\";

    /** 仕入先マスタのパス */
    private static final String VENDOR = "Vendor\\";

    /** プロジェクト属性のパス */
    private static final String PROJECTATTRIBUTE = "ProjectAttribute\\";

    /** プロジェクト個別のパス */
    private static final String PROJECT = "Project\\";

    /** 勘定明細のパス */
    private static final String ACCOUNTDETAIL = "AccountDetail\\";

    /** 勘定残高のパス */
    private static final String ACCOUNTBALANCE = "AccountBalance\\";

    /** 仕掛原価のパス */
    private static final String INPROCESSCOST = "InProcessCost\\";

    /** 受注のパス */
    private static final String RECEIVEORDER = "ReceiveOrder\\";

    /** 発注番号のパス */
    private static final String ORDERNO = "OrderNo\\";

    /** 得意先マスタのファイル */
    private static final String SATP0001 = "SATP0001.txt";

    /** 仕入先マスタのファイル */
    private static final String SATP0002 = "SATP0002.txt";

    /** プロジェクト属性のファイル */
    private static final String SATP0003 = "SATP0003.txt";

    /** プロジェクト個別のファイル */
    private static final String SATP0004 = "SATP0004.txt";

    /** 勘定明細のファイル */
    private static final String SATP0005 = "SATP0005.txt";

    /** 勘定残高のファイル */
    private static final String SATP0007 = "SATP0007.txt";

    /** 仕掛原価のファイル */
    private static final String SATP0008 = "SATP0008.txt";

    /** 受注のファイル */
    private static final String SATP0009 = "SATP0009.txt";

    /** 発注番号のファイル */
    private static final String SATP0010 = "SATP0010.txt";

    @Autowired
    private BatchDataHolder batchDataHolder;

    private boolean isError;

    /**
     *
     * マインバッチ処理
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return 一括で各ジョブを実行した状態
     */
    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        LocalDateTime systemDateTime = dateFactory.newDateTime();

        String systemDateTimeStr = systemDateTime.format(dtf4);
        String systemYMD = systemDateTime.format(dtf2);
        // 実施時間
        batchDataHolder.setStartDateTime(systemDateTime);


        // 当日NGファイル存在チェック
        isError = isExistFiles(getFileName(errorDirPath), systemYMD, EMPTY);

        if (isError) {
            // ログ出力(NGファイルが存在するため、SAPファイル取込処理を終了します。
            logger.error("NGファイルが存在するため、SAPファイル取込処理を終了します。");
            throw new RuntimeException("mdb0007メインバッチ（SAP取込）処理実行に異常が発生しました。");
        } else {

            // f2：ファイル存在チェック/バッチリクエスト
            // 得意先マスタ
            executeCheck(inputDirPath + CUSTOMER, SATP0001, systemDateTimeStr);
            // 仕入先マスタ
            executeCheck(inputDirPath + VENDOR, SATP0002, systemDateTimeStr);
            // プロジェクト属性
            executeCheck(inputDirPath + PROJECTATTRIBUTE, SATP0003, systemDateTimeStr);
            // プロジェクト
            executeCheck(inputDirPath + PROJECT, SATP0004, systemDateTimeStr);
            // 勘定明細
            executeCheck(inputDirPath + ACCOUNTDETAIL, SATP0005, systemDateTimeStr);
            // 勘定残高
            executeCheck(inputDirPath + ACCOUNTBALANCE, SATP0007, systemDateTimeStr);
            // 仕掛原価
            executeCheck(inputDirPath + INPROCESSCOST, SATP0008, systemDateTimeStr);
            // 受注
            executeCheck(inputDirPath + RECEIVEORDER, SATP0009, systemDateTimeStr);
            // 発注番号
            executeCheck(inputDirPath + ORDERNO, SATP0010, systemDateTimeStr);
        }

        return RepeatStatus.FINISHED;
    }

    private void executeCheck(String inputDirPath, String fileName, String systemDateTime) throws Exception {

        // フォルダ「INPUTフォルダ」 にパラメータ:ファイル名と等しいファイルが存在する
        if (isfileExist(inputDirPath, fileName)) {
            String systemYMD = systemDateTime.substring(0, 10).replaceAll("-", "");
            // TEMPファイル存在チェック(ファイル取込中)
            boolean isCheckFiles = isExistFiles(getFileName(tempDirPath), systemYMD, fileName);

            // 存在しない場合
            if (!isCheckFiles) {
                try {
                    // ファイルをTEMPフォルダに移動する。
                    CommonUtils.fileMove(inputDirPath + fileName, tempDirPath + fileName);
                } catch (IOException e) {
                    isError = true;
                    logger.error(fileName + "をTEMPフォルダに移動するときに、異常が発生しました。");
                    return;
                }

                logger.info("取込ファイルを移動しました。;ファイル名={};移動先フォルダ={}", fileName, tempDirPath);

                // BATCH_JOB_REQUEST にINSERT
                switch (fileName) {
                    case SATP0001:
                        executeJob("fwb0101Job",
                                "inputFile=" + tempDirPath + fileName + ",systemDateTime=" + systemDateTime);
                        break;
                    case SATP0002:
                        executeJob("fwb0102Job",
                                "inputFile=" + tempDirPath + fileName + ",systemDateTime=" + systemDateTime);
                        break;
                    case SATP0003:
                        executeJob("fwb0103Job",
                                "inputFile=" + tempDirPath + fileName + ",systemDateTime=" + systemDateTime);
                        break;
                    case SATP0004:
                        executeJob("fwb0104Job",
                                "inputFile=" + tempDirPath + fileName + ",systemDateTime=" + systemDateTime);
                        break;
                    case SATP0005:
                        executeJob("fwb0105Job",
                                "inputFile=" + tempDirPath + fileName + ",systemDateTime=" + systemDateTime);
                        break;
                    case SATP0007:
                        executeJob("fwb0106Job",
                                "inputFile=" + tempDirPath + fileName + ",systemDateTime=" + systemDateTime);
                        break;
                    case SATP0008:
                        executeJob("fwb0107Job",
                                "inputFile=" + tempDirPath + fileName + ",systemDateTime=" + systemDateTime);
                        break;
                    case SATP0009:
                        executeJob("fwb0108Job",
                                "inputFile=" + tempDirPath + fileName + ",systemDateTime=" + systemDateTime);
                        break;
                    case SATP0010:
                        executeJob("fwb0109Job",
                                "inputFile=" + tempDirPath + fileName + ",systemDateTime=" + systemDateTime);
                        break;
                }
                return;
            } else {
                logger.info("ファイル取込中のため処理をスキップしました。;ファイル名={};処理={}", fileName, "メインバッチ（SAP取込）");
                return;
            }
        }
        logger.info("取込ファイルが存在しないため処理をスキップしました。;ファイル名={};処理={}", fileName, "メインバッチ（SAP取込）");
    }

    /**
     * ジョブ実行処理
     */
    private void executeJob(String jobName, String jobParameter) throws Exception {

        BatchJobRequestInput input = new BatchJobRequestInput();

        input.setJobName(jobName);
        input.setJobParameter(jobParameter);
        input.setPriority(1);
        input.setPollingStatus("INIT");

        mdb0007Repository.create(input);
    }

    private String[] getFileName(String path) {
        File file = new File(path);
        String[] fileName = file.list();
        return fileName;
    }

    private boolean isExistFiles(String[] fileNames, String systemYMD, String checkStr) {

        // false:ファイルが無い、true：ファイルが有る
        boolean rtn = false;

        if (fileNames == null) {
            return false;
        }

        for (String name : fileNames) {

            if (name.length() >= 12 && name.substring(0, 8).equals(systemYMD)) {

                if (checkStr.equals(EMPTY)) {
                    rtn = true;
                } else {
                    rtn = name.indexOf(checkStr) != -1 ? true : false;
                }
            }
        }

        return rtn;
    }

    private boolean isfileExist(String path, String fileName) {

        File source = new File(path + fileName);

        return source.exists();

    }

}
