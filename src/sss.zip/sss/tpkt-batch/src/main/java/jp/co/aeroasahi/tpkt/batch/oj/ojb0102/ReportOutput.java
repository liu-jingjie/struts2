package jp.co.aeroasahi.tpkt.batch.oj.ojb0102;

import lombok.Getter;
import lombok.Setter;


/**
 * 帳票のOutputBean.
 * <p>
 * 帳票のOutputBean.
 * </p>
 */

@Getter
@Setter
public class ReportOutput {
    /**
     * 応受援帳票種別.
     */
    private String ojuenDocType;
    /**
     * 応受援帳票名称.
     */
    private String ojuenDocName;
    /**
     * 申請番号.
     */
    private String applyNum;
    /**
     * 委託先枝番.
     */
    private int entrustBranchNum;
    /**
     * 発注番号.
     */
    private String orderNum;
    /**
     * 算定注文番号.
     */
    private String calculatedNum;
}
