package jp.co.aeroasahi.tpkt.batch.mdb0801;

import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜外注情報＞＜プロジェクト＞＜プロジェクト属性＞＜委託先マスタ＞＜応受援基本情報＞＜応受援委託先枝番情報＞
 * ＜金額＞＜社員＞＜部門マスタ＞＜部門表示順マスタ＞＜受注＞のInputBean。
 */
@Setter
@Getter
public class MDB0801Input {

    /** 売上年度 */
    private String soldFiscalYear;

    /** プロジェクトID */
    private String pjId;

    /** プロジェクト名称 */
    private String pjName;

    /** 初回売上日 */
    private String soldOn;

    /** 売上予定日 */
    private String planedSellingOn;

    /** 物件区分 */
    private String pjKbn;

    /** 名義会社 */
    private String meigiCorpCd;

    /** 顧客名称 */
    private String customerName;

    /** BU */
    private String bu;

    /** プロジェクト属性ID */
    private String pjAttId;

    /** 枝番 */
    private String branchNum;

    /** 契約件名 */
    private String contractName;

    /** 契約工期(FROM) */
    private String contractFrom;

    /** 契約工期(TO) */
    private String contractTo;

    /** 取引種別 */
    private String dealType;

    /** 案件情報 */
    private String pjInfo;

    /** 分野コード */
    private String fieldCd;

    /** 分野コード名称 */
    private String fieldName;

    /** 業務コード */
    private String businessCd;

    /** 業務コード名称 */
    private String businessName;

    /** 顧客種別 */
    private String customerCategoryCd;

    /** 物件管理責任者部門支社ＣＤ */
    private String pjManageRespDeptBranchCd;

    /** 物件管理責任者部門支社名称 */
    private String pjManageRespDeptBranchName;

    /** 物件管理責任者部門部ＣＤ */
    private String pjManageRespMDeptCd;

    /** 物件管理責任者部門部名称 */
    private String pjManageRespMDeptName;

    /** 物件管理責任者部門部署ＣＤ */
    private String pjManageRespDeptCd;

    /** 物件管理責任者部門部署名称 */
    private String pjManageRespDeptName;

    /** 物件管理責任者ＣＤ */
    private String pjManageRespEmpCd;

    /** 物件管理責任者名 */
    private String pjManageRespEmpName;

    /** 生産主管部門支社ＣＤ */
    private String productMainDeptBranchCd;

    /** 生産主管部門支社名称 */
    private String productMainDeptBranchName;

    /** 生産主管部門部ＣＤ */
    private String productMainMDeptCd;

    /** 生産主管部門部名称 */
    private String productMainMDeptName;

    /** 生産主管部門ＣＤ */
    private String productMainDeptCd;

    /** 生産主管部門名称 */
    private String productMainDeptName;

    /** 生産プロデューサーＣＤ */
    private String productProducerEmpCd;

    /** 生産プロデューサー名 */
    private String productProducerName;

    /** 営業主管部門支社ＣＤ */
    private String salesMainDeptBranchCd;

    /** 営業主管部門支社名称 */
    private String salesMainDeptBranchName;

    /** 営業主管部門部ＣＤ */
    private String salesMainMDeptCd;

    /** 営業主管部門部名称 */
    private String salesMainMDeptName;

    /** 営業主管部門ＣＤ */
    private String salesMainDeptCd;

    /** 営業主管部門名称 */
    private String salesMainDeptName;

    /** 営業担当者ＣＤ */
    private String salesEmpCd;

    /** 営業担当者名 */
    private String salesEmpName;

    /** 生産担当部門支社ＣＤ */
    private String productDeptBranchCd;

    /** 生産担当部門支社名称 */
    private String productDeptBranchName;

    /** 生産担当部門部ＣＤ */
    private String productMDeptCd;

    /** 生産担当部門部名称 */
    private String productMDeptName;

    /** 生産担当部門ＣＤ */
    private String productDeptCd;

    /** 生産担当部門名称 */
    private String productDeptName;

    /** 生産担当者ＣＤ */
    private String productEmpCd;

    /** 生産担当者名 */
    private String productEmpName;

    /** 受注区分 */
    private String receiveKbn;

    /** 受注日 */
    private String receivedOn;

    /** 受注額 */
    private BigDecimal receivedMoney;

    /** 受注原価率 */
    private BigDecimal receivedCostRate;

    /** 売上種別 */
    private String salesType;

    /** 当該年度売上予定日 */
    private String thisFiscalYearPlanedSellingOn;

    /** 当該年度売上日 */
    private String thisFiscalYearSoldOn;

    /** 最終売上予定日 */
    private String lastPlanedSellingOn;

    /** 最終売上完了日 */
    private String lastSoldOn;

    /** 完了フラグ */
    private String pjEnded;

    /** ステータス */
    private String pjStatus;

    /** 売上種別区分 */
    private String salesTypeKbn;

    /** 高原価・政策受注フラグ */
    private String highCostReceive;

    /** 応札時積算額 */
    private BigDecimal osatsuPlanedAmount;

    /** 応札時積算率 */
    private BigDecimal osatsuPlanedRate;

    /** 生産高 */
    private BigDecimal seisandaka;

    /** 一般売上 */
    private BigDecimal outsideSoldAmount;

    /** 関係会社売上額 */
    private BigDecimal groupSoldAmount;

    /** 売上物件原価率 */
    private BigDecimal soldPjCostRate;

    /** 期首仕掛原価 */
    private BigDecimal kisyuWorkingCost;

    /** 期首仕掛品原価差異 */
    private BigDecimal kisyuWorkingCostDifference;

    /** 社員工数 */
    private BigDecimal empKosu;

    /** 積算社員工数 */
    private BigDecimal planedEmpKosu;

    /** 人件費（直・間接合計） */
    private BigDecimal laborCost;

    /** 積算人件費（直・間接合計 */
    private BigDecimal planedLaborCost;

    /** 人件費（直接） */
    private BigDecimal directLaborCost;

    /** 積算人件費（直接） */
    private BigDecimal planedDirectLaborCost;

    /** 臨時時間 */
    private BigDecimal tempEmpKosu;

    /** 積算臨時時間 */
    private BigDecimal planedTempEmpKosu;

    /** 臨時人件費 */
    private BigDecimal tempLaborCost;

    /** 積算臨時人件費 */
    private BigDecimal planedTempLaborCost;

    /** 外注費（一般）発注ベース */
    private BigDecimal outsideOrderedCost;

    /** 積算外注費（一般）発注ベース */
    private BigDecimal planedOutsideOrderingCost;

    /** 外注費（一般）支払ベース */
    private BigDecimal outsidePaidCost;

    /** 積算外注費（一般）支払ベース */
    private BigDecimal planedOutsidePayingCost;

    /** 外注費（関係）発注ベース */
    private BigDecimal groupOrderedCost;

    /** 積算外注費（関係）発注ベース */
    private BigDecimal planedGroupOrderingCost;

    /** 外注費（関係）支払ベース */
    private BigDecimal groupPaidCost;

    /** 積算外注費（関係）支払ベース */
    private BigDecimal planedGroupPayingCost;

    /** 業務委託費発注ベース */
    private BigDecimal entrustOrderedCost;

    /** 積算業務委託費 */
    private BigDecimal planedEntrustCost;

    /** 業務委託費支払ベース */
    private BigDecimal entrustPaidCost;

    /** 未発注外注費（一般）支払ベース */
    private BigDecimal nonOrderedOutsidePaidCost;

    /** 未発注外注費（関係）支払ベース */
    private BigDecimal nonOrderedGroupPaidCost;

    /** 材料費 */
    private BigDecimal materialCost;

    /** 積算材料費 */
    private BigDecimal planedMaterialCost;

    /** 印刷製本費 */
    private BigDecimal printingBindingCost;

    /** 積算印刷製本費 */
    private BigDecimal planedPrintingBindingCost;

    /** 旅費交通費 */
    private BigDecimal travelingCarfareCost;

    /** 積算旅費交通費 */
    private BigDecimal planedTravelingCarfareCost;

    /** 車両費 */
    private BigDecimal carCost;

    /** 積算車両費 */
    private BigDecimal planedCarCost;

    /** 大型機材 */
    private BigDecimal largeMachine;

    /** 積算大型機材 */
    private BigDecimal planedLargeMachine;

    /** 直接作業経費 */
    private BigDecimal directWorkCost;

    /** 積算直接作業経費 */
    private BigDecimal planedDirectWorkCost;

    /** 直接費合計 */
    private BigDecimal directCost;

    /** 積算直接費合計 */
    private BigDecimal planedDirectCost;

    /** 大型機材間接費 */
    private BigDecimal largeMachineIndirectCost;

    /** 間接費 */
    private BigDecimal indirectCost;

    /** 積算間接費 */
    private BigDecimal planedIndirectCost;

    /** その他事業部間取引 */
    private BigDecimal otherCost;

    /** 積算その他事業部間取引 */
    private BigDecimal planedOtherCost;

    /** 総原価 */
    private BigDecimal sogenka;

    /** 積算総原価 */
    private BigDecimal planedSogenka;

    /** 他勘定振替 */
    private BigDecimal accountTransaction;

    /** 今期発生原価 */
    private BigDecimal thisFiscalYearCost;

    /** 今期原価差異 */
    private BigDecimal thisFiscalYearCostDifference;

    /** 原価合計 */
    private BigDecimal genkagokei;

    /** 積算原価合計 */
    private BigDecimal planedGenkagokei;

    /** 追加原価 */
    private BigDecimal addCost;

    /** 売上原価 */
    private BigDecimal salesCost;

    /** 期末仕掛原価 */
    private BigDecimal kimatsuWorkingCost;

    /** 進捗率 */
    private BigDecimal progressRate;

    /** 初回積算日 */
    private String firstPlanedOn;

    /** 当該年度初回積算額 */
    private BigDecimal thisFiscalYearFirstPlanedAmount;

    /** 当該年度初回積算原価率 */
    private BigDecimal thisFiscalYearFirstPlanedCostRate;

    /** 全年度初回積算額 */
    private BigDecimal firstPlanedAmount;

    /** 全年度初回積算原価率 */
    private BigDecimal firstPlanedAmountRate;

    /** 更新積算日 */
    private String updatePlanedOn;

    /** 当該年度積算額 */
    private BigDecimal thisFiscalYearPlanedAmount;

    /** 当該年度積算原価率 */
    private BigDecimal thisFiscalYearPlanedCostRate;

    /** 全年度積算額 */
    private BigDecimal planedAmount;

    /** 全年度積算原価率 */
    private BigDecimal planedAmountRate;

    /** 見込み原価 */
    private BigDecimal planedCost;

    /** 見込み原価率 */
    private BigDecimal planedCostRate;

    /** 並び順_物件管理責任者部門 */
    private BigDecimal sortNumPjManageRespDept;

    /** 並び順_生産主管部門 */
    private BigDecimal sortNumProductMainDept;

    /** 並び順_営業主管部門 */
    private BigDecimal sortNumSalesMainDept;

    /** 並び順_生産担当部門 */
    private BigDecimal sortNumProductDept;

    /** 年度 金額用 */
    private BigDecimal nendo;

    /** 実績積算区分 金額用 */
    private String resultPlanedKbn;

    /** 今回年度期の年 検索用 */
    private String fiscalYear;

    /** 指定年月或は今の年月 検索用 */
    private String ym;

    /** 今年度期首月 検索用 */
    private String ym1;

    /** 今年度期末月 検索用 */
    private String ym2;

    /** 年月 */
    private String ymAmount;

    /** 日付（FROM) チェック用 */
    private String dateFrom;

    /** 日付（TO） チェック用 */
    private String dateTo;

    /** himoku_01 */
    private BigDecimal himoku01;

    /** himoku_02 */
    private BigDecimal himoku02;

    /** himoku_03 */
    private BigDecimal himoku03;

    /** himoku_32 */
    private BigDecimal himoku32;

    /** himoku_10 */
    private BigDecimal himoku10;

    /** himoku_05 */
    private BigDecimal himoku05;

    /** himoku_06 */
    private BigDecimal himoku06;

    /** himoku_04 */
    private BigDecimal himoku04;

    /** himoku_07 */
    private BigDecimal himoku07;

    /** himoku_08 */
    private BigDecimal himoku08;

    /** himoku_09 */
    private BigDecimal himoku09;

    /** himoku_11 */
    private BigDecimal himoku11;

    /** himoku_12 */
    private BigDecimal himoku12;

    /** himoku_15 */
    private BigDecimal himoku15;

    /** himoku_18 */
    private BigDecimal himoku18;

    /** himoku_20 */
    private BigDecimal himoku20;

    /** himoku_31 */
    private BigDecimal himoku31;

    /** himoku_33 */
    private BigDecimal himoku33;

    /** himoku_34 */
    private BigDecimal himoku34;

    /** himoku_35 */
    private BigDecimal himoku35;

    /** himoku_51 */
    private BigDecimal himoku51;

    /** himoku_52 */
    private BigDecimal himoku52;

    /** BU+プロジェクト属性ID */
    private String buPjAttId;

    /** 積算（全年度の積算⑩＋全年度の積算⑪）或は ⑩直接費合計の外注費以外＋⑪間接費＋⑫その他事業部間取引 */
    private BigDecimal KINGAKU;

    /** ★外注情報（未発注外注費（一般）支払ベース、未発注外注費（関係）支払ベースは除く） */
    /** 外注費（一般）支払ベース＋外注費（関係）支払ベース＋業務委託費支払ベース */
    private BigDecimal GICHUSB;

    /** ★外注情報（未発注外注費（一般）支払ベース、未発注外注費（関係）支払ベースは除く） */
    /** 外注費（一般）発注ベース＋外注費（関係）発注ベース＋業務委託費発注ベース */
    private BigDecimal GICHUHB;

    /** ★外注情報（未発注外注費（一般）支払ベース、未発注外注費（関係）支払ベースのみ） */
    /** 外注費（一般）支払ベース＋外注費（関係）支払ベース */
    private BigDecimal GICHUSBM;

    /** ★SAP仕掛原価 */
    /** ⑬期首仕掛品原価差異 */
    private BigDecimal SIKAKARI;

    /** 追加原価（外注費）の外注費（一般）発生ベース＋外注費（関係）発注ベース＋業務委託費発注ベース */
    private BigDecimal ADDKINGAKU;

    /** 期首仕掛原価差異金額 */
    private BigDecimal inprocessCostBalance;

    /** 今期原価差異金額 */
    private BigDecimal currentCostBalance;

    /** 支払い未外注費の加算用 外注費（一般）発生ベースと外注費（関係）発注ベースの合計値 */
    private BigDecimal orderedCost;

    /**
     * プロジェクトIDと売上年度を結合する
     *
     * @return
     */
    public String concat() {
        return pjId + soldFiscalYear;
    }

    /**
     * プロジェクトIDと金額．年月を結合する
     *
     * @return
     */
    public String concat2() {
        return pjId + ymAmount;
    }

    /**
     * BU+プロジェクト属性IDと金額．年月を結合する
     *
     * @return
     */
    public String concat3() {
        return buPjAttId + ymAmount;
    }
}
