package jp.co.aeroasahi.tpkt.batch.mdb0101;

import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜工数データ＞＜工数振替＞＜社員＞＜費目･リソースマスタ＞＜部門マスタ＞のInputBean。
 */
@Setter
@Getter
public class MDB0101KosuCostInput {

    /** プロジェクトID */
    private String pjId;

    /** 年月 */
    private String ym;

    /** 部門CD */
    private String deptCd;

    /** 工程CD */
    private String koteiCd;

    /** 費目CD */
    private String himokuCd;

    /** 実績積算区分 */
    private String resultPlanedKbn;

    /** 給与等級 */
    private String tokyu;

    /** 代表リソースCD */
    private String distResourceCd;

    /** リソースCD */
    private String resourceCd;

    /** 単価 */
    private BigDecimal unitCost;

    /** 直接単価 */
    private BigDecimal directUnitCost;

    /** 直接部門間接単価 */
    private BigDecimal directDeptIndirectUnitCost;

    /** 間接部門間接単価 */
    private BigDecimal indirectDeptIndirectUnitCost;

    /** 製造間接単価 */
    private BigDecimal indirectUnitCost;

    /** 大型機材単価 */
    private BigDecimal largeMachineIndirectCost;

    /** 工数 */
    private BigDecimal kosu;

    /** 作成日 */
    private String createdAt;

    /** 更新日 */
    private String updatedAt;

    /** 年月 検索用(当月)*/
    private String ym1;

    /** 年月 検索用(前月或は指定した月)*/
    private String ym2;

    /**
     * プロジェクトIDと年月と工程CDと部門CDと費目CDと実績積算区分を結合する
     * @return
     */
    public String concat() {
        return pjId + "," + ym + "," + koteiCd + "," + deptCd + "," + himokuCd + "," + resultPlanedKbn;
    }
}
