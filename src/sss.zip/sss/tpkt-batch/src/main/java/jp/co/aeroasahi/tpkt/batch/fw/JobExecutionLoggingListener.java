package jp.co.aeroasahi.tpkt.batch.fw;

import java.util.Locale;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

@Component
public class JobExecutionLoggingListener implements JobExecutionListener {
    private static final Logger logger =
            LoggerFactory.getLogger(JobExecutionLoggingListener.class);

    @Inject
    MessageSource messageSource;

    @Override
    public void beforeJob(JobExecution jobExecution) {
        String jobName = getJobNameByParams(jobExecution);

        // メインバッチの時はjobNameがnull
        if (jobName == null) {
            MDC.put("jobName", getJobNameByInstance(jobExecution));
        } else {
            MDC.put("jobName", getJobNameByParams(jobExecution));
            MDC.put("stepName", getJobNameByInstance(jobExecution));
        }

        Object[] params = {getJobId(jobExecution), getJobNameByInstance(jobExecution)};
        logger.info(messageSource.getMessage("i.bat.fw.001", params, Locale.getDefault()));
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        Object[] params = {getJobId(jobExecution), getJobNameByInstance(jobExecution)};
        logger.info(messageSource.getMessage("i.bat.fw.002", params, Locale.getDefault()));

        MDC.remove("jobName");
        MDC.remove("stepName");
    }

    private String getJobId(JobExecution jobExecution) {
        return jobExecution.getJobInstance().getJobName();
    }

    private String getJobNameByInstance(JobExecution jobExecution) {
        return messageSource.getMessage(jobExecution.getJobInstance().getJobName(), null, Locale.getDefault());
    }

    private String getJobNameByParams(JobExecution jobExecution) {
        String jobId = jobExecution.getJobParameters().getString("jobId");
        return jobId == null ? null : messageSource.getMessage(jobId, null, Locale.getDefault());
    }
}
