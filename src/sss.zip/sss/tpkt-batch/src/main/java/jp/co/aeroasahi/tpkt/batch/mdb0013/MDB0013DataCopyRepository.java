package jp.co.aeroasahi.tpkt.batch.mdb0013;

import org.apache.ibatis.annotations.Param;

/**
 * 一時テーブルから本体テーブルにデータを登録する
 */
public interface MDB0013DataCopyRepository {

    /**
     * テーブル＜工数金額＞に登録する。
     *
     * @param currentYm システム日付に紐づく年月
     * @param targetYm バッチパラメータに紐づく年月
     * @return
     */
    void dataCopyMdKosuCost(@Param("currentYm") String currentYm, @Param("targetYm") String targetYm);

    /**
     * テーブル＜部門別社員工数＞に登録する。
     *
     * @param
     * @return
     */
    void dataCopyMdDeptPersonalKosu(@Param("currentYm") String currentYm, @Param("targetYm") String targetYm);


    /**
     * テーブル＜受注＞に登録する。
     *
     * @param
     * @return
     */
    void dataCopyMdReceive();

    /**
     * テーブル＜売上＞に登録する。
     *
     * @param
     * @return
     */
    void dataCopyMdSoldAmount(@Param("currentYm") String currentYm, @Param("targetYm") String targetYm);

    /**
     * テーブル＜部門別経費＞に登録する。
     *
     * @param
     * @return
     */
    void dataCopyMdDeptCost(@Param("currentFiscalYear") String currentFiscalYear,
            @Param("currentFiscalMonth") String currentFiscalMonth, @Param("targetFiscalYear") String targetFiscalYear,
            @Param("targetFiscalMonth") String targetFiscalMonth);

    /**
     * テーブル＜金額＞に登録する。
     *
     * @param
     * @return
     */
    void dataCopyMdCost(@Param("currentYm") String currentYm, @Param("targetYm") String targetYm);

    /**
     * テーブル＜部門経費管理＞に登録する。
     *
     * @param
     * @return
     */
    void dataCopyMdDispDeptCost();

    /**
     * テーブル＜操業度管理＞に登録する。
     *
     * @param
     * @return
     */
    void dataCopyMdDispOperation(@Param("currentFiscalYear") String currentFiscalYear,
            @Param("currentFiscalMonth") String currentFiscalMonth, @Param("targetFiscalYear") String targetFiscalYear,
            @Param("targetFiscalMonth") String targetFiscalMonth);
}
