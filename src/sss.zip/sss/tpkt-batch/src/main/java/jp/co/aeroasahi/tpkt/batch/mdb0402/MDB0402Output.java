package jp.co.aeroasahi.tpkt.batch.mdb0402;

import java.math.BigDecimal;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Size;
import org.springframework.batch.item.ItemCountAware;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】外注情報＞のOutputBean。
 */
@Setter
@Getter
public class MDB0402Output implements ItemCountAware {

    private int count;

    /** プロジェクト属性ID */
    @Size(min = 0, max = 8)
    private String pjAttId;

    /** プロジェクトID */
    @Size(min = 0, max = 12)
    private String pjId;

    /** 業者CD */
    @Size(min = 0, max = 10)
    private String vendorCd;

    /** 発注書No */
    @Size(min = 0, max = 10)
    private String orderNum;

    /** 注文日 */
    @Size(min = 0, max = 10)
    private String orderedOn;

    /** 納品予定日 */
    @Size(min = 0, max = 10)
    private String planedDeliveringOn;

    /** 実績積算区分 */
    @Size(min = 0, max = 1)
    private String resultPlanedKbn;

    /** 外注費（一般）発生ベース */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal outsideOrderedCost;

    /** 外注費（関係）発注ベース */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal groupOrderedCost;

    /** 外注費（一般）支払ベース */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal outsidePaidCost;

    /** 外注費（関係）支払ベース */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal groupPaidCost;

    /** 業務委託費発注ベース */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal workOutsourcingOrderedCost;

    /** 業務委託費支払ベース */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal workOutsourcingPaidCost;

    /** 作業着手日 */
    @Size(min = 0, max = 10)
    private String workFrom;

    /** 作業終了日 */
    @Size(min = 0, max = 10)
    private String workTo;

    /** 支払日 */
    @Size(min = 0, max = 10)
    private String paidOn;

    /** 支払処理日 */
    @Size(min = 0, max = 10)
    private String paymentProcessedOn;

    /** 作成日 */
    @Size(min = 23, max = 23)
    private String createdAt;

    /** 更新日 */
    @Size(min = 23, max = 23)
    private String updatedAt;

    /** 登録・更新のチェック区分 */
    private String insertOrUpdateCheckKbn;

    @Override
    public void setItemCount(int count) {
        this.count = count;
    }
}
