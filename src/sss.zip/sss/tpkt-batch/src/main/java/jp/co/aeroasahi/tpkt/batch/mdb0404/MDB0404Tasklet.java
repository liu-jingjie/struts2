package jp.co.aeroasahi.tpkt.batch.mdb0404;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.validator.ValidationException;
import org.springframework.batch.item.validator.Validator;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.fw.CommonLog;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

@Component
@Scope("step")
public class MDB0404Tasklet implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0404Tasklet.class);

    @Inject
    MDB0404Repository mdb0404Repository;

    @Inject
    DateFactory dateFactory;

    @Inject
    Validator<MDB0404Output> validator;

    @Value("#{jobParameters['kbn']}")
    public String kbn;

    @Value("#{jobParameters['yyyymm']}")
    public String yyyymm;

    boolean isErrFlag = false;

    /** DateTimeFormatterのパターン yyyy-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    /** DateTimeFormatterのパターン uuuuMM */
    private static final DateTimeFormatter dtfUUUUMM = DateTimeFormatter.ofPattern("uuuuMM");

    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        LocalDateTime systemDateTime = dateFactory.newDateTime();
        String systemYearMonth = dateFactory.newDateTime().format(dtf);

        // 年(当月の年)
        String year1 = getCurrentMonth(systemDateTime).substring(0, 4);

        // 月(当月)
        String month1 = getCurrentMonth(systemDateTime).substring(4, 6);

        // 年(前月或は指定した月の年)
        String year2 = "";

        // 月(前月或は指定した月)
        String month2 = "";

        // 日次処理の場合
        if (kbn.equals("D")) {
            year2 = getPreviousMonth(systemDateTime).substring(0, 4);
            month2 = getPreviousMonth(systemDateTime).substring(4, 6);

        // 月次確定処理の場合
        } else if (kbn.equals("M")) {
            LocalDateTime yyyymmP = LocalDateTime.of(Integer.parseInt(yyyymm.substring(0, 4)), Integer.parseInt(yyyymm.substring(4, 6)), 1, 1, 1);
            year2 = getCurrentMonth(yyyymmP).substring(0, 4);
            month2 = getCurrentMonth(yyyymmP).substring(4, 6);
        }

        List<MDB0404Output> outItems = setItemOutput(year1, month1, year2, month2, systemYearMonth);

        if (!isErrFlag) {
            for (int i = 0; i < outItems.size(); i++) {
                try {
                    validator.validate(outItems.get(i));
                } catch (ValidationException e) {
                    isErrFlag = true;
                    CommonLog.setFromDbErrorLog(logger, e, "【TEMP】部門別経費(temp_md_dept_cost)");
                }
            }

            if (!isErrFlag) {

                if(outItems.size() > 0) {

                    // データを削除
                    MDB0404Output itemOutput = new MDB0404Output();
                    itemOutput.setGJAHR1(year1);
                    itemOutput.setMONAT1(month1);
                    itemOutput.setGJAHR2(year2);
                    itemOutput.setMONAT2(month2);

                    if(kbn.equals("D")) {
                        mdb0404Repository.deleteDay(itemOutput);
                    }else if(kbn.equals("M")) {
                        mdb0404Repository.deleteMonth(itemOutput);
                    }

                    // データを登録
                    for (MDB0404Output output : outItems) {
                        mdb0404Repository.create(output);
                    }
                }
                CommonLog.setInsertRecordeCountLog(logger, "【TEMP】部門別経費(temp_md_dept_cost)", outItems.size());

            } else {
                logger.error("登録データでエラーが発生しました。");
            }
            outItems.clear();
        }

        if (isErrFlag) {
            throw new RuntimeException("mdb0404部門別経費取込処理実行に異常が発生しました。");
        }

        return RepeatStatus.FINISHED;
    }

    private List<MDB0404Output> setItemOutput(String year1, String month1, String year2, String month2, String systemYearMonth) {

        List<MDB0404Output> outputItems = new ArrayList<>();
        MDB0404Output itemOutput = null;

        MDB0404Input itemInput = new MDB0404Input();
        itemInput.setGJAHR1(year1);
        itemInput.setMONAT1(month1);
        itemInput.setGJAHR2(year2);
        itemInput.setMONAT2(month2);

        // SAP勘定明細
        List<MDB0404Input> detailList = new ArrayList<MDB0404Input>();

        if(kbn.equals("D")) {
            detailList = mdb0404Repository.findAllDetailDay(itemInput);
        }else if(kbn.equals("M")) {
            detailList = mdb0404Repository.findAllDetailMonth(itemInput);
        }

        for (MDB0404Input mdb0404Input : detailList) {

            itemOutput = new MDB0404Output();

            // 部門CD
            itemOutput.setDeptCd(mdb0404Input.getPRCTR());

            // 勘定科目CD
            itemOutput.setKamokuCd(mdb0404Input.getHKONT());

            // 会計年度
            itemOutput.setFiscalYear(new BigDecimal(mdb0404Input.getGJAHR()));

            // 会計期間
            itemOutput.setFiscalMonth(new BigDecimal(mdb0404Input.getMONAT()));

            // 実績積算区分
            itemOutput.setResultPlanedKbn("1");

            // 原価
            itemOutput.setCost(null == mdb0404Input.getDMBTR() || mdb0404Input.getDMBTR().equals("") ? BigDecimal.ZERO :  new BigDecimal(mdb0404Input.getDMBTR()));

            // 作成日
            itemOutput.setCreatedAt(systemYearMonth);

            // 更新日
            itemOutput.setUpdatedAt(systemYearMonth);

            outputItems.add(itemOutput);
        }

        // SAP勘定残高（実績）
        List<MDB0404Input> balanceAchievementList = new ArrayList<MDB0404Input>();

        if(kbn.equals("D")) {
            balanceAchievementList = mdb0404Repository.findAllBalanceAchievementDay(itemInput);
        }else if(kbn.equals("M")) {
            balanceAchievementList = mdb0404Repository.findAllBalanceAchievementMonth(itemInput);
        }

        for (MDB0404Input mdb0404Input : balanceAchievementList) {

            itemOutput = new MDB0404Output();

            // 部門CD
            itemOutput.setDeptCd(mdb0404Input.getPRCTR());

            // 勘定科目CD
            itemOutput.setKamokuCd(mdb0404Input.getRACCT());

            // 会計年度
            itemOutput.setFiscalYear(new BigDecimal(mdb0404Input.getGJAHR()));

            // 会計期間
            itemOutput.setFiscalMonth(new BigDecimal(mdb0404Input.getMONAT()));

            // 実績積算区分
            itemOutput.setResultPlanedKbn("1");

            // 原価
            itemOutput.setCost(null == mdb0404Input.getHSLXX() || mdb0404Input.getHSLXX().equals("") ? BigDecimal.ZERO : new BigDecimal(mdb0404Input.getHSLXX()));

            // 作成日
            itemOutput.setCreatedAt(systemYearMonth);

            // 更新日
            itemOutput.setUpdatedAt(systemYearMonth);

            outputItems.add(itemOutput);
        }

        // SAP勘定残高（積算）
        List<MDB0404Input> balanceEstimateList = new ArrayList<MDB0404Input>();

        if(kbn.equals("D")) {
            balanceEstimateList = mdb0404Repository.findAllBalanceEstimateDay(itemInput);
        }else if(kbn.equals("M")) {
            balanceEstimateList = mdb0404Repository.findAllBalanceEstimateMonth(itemInput);
        }

        for (MDB0404Input mdb0404Input : balanceEstimateList) {

            itemOutput = new MDB0404Output();

            // 部門CD
            itemOutput.setDeptCd(mdb0404Input.getPRCTR());

            // 勘定科目CD
            itemOutput.setKamokuCd(mdb0404Input.getRACCT());

            // 会計年度
            itemOutput.setFiscalYear(new BigDecimal(mdb0404Input.getGJAHR()));

            // 会計期間
            itemOutput.setFiscalMonth(new BigDecimal(mdb0404Input.getMONAT()));

            // 実績積算区分
            itemOutput.setResultPlanedKbn("2");

            // 原価
            itemOutput.setCost(null == mdb0404Input.getHSLXX() || mdb0404Input.getHSLXX().equals("") ? BigDecimal.ZERO : new BigDecimal(mdb0404Input.getHSLXX()));

            // 作成日
            itemOutput.setCreatedAt(systemYearMonth);

            // 更新日
            itemOutput.setUpdatedAt(systemYearMonth);

            outputItems.add(itemOutput);
        }

        return outputItems;
    }

    private String getCurrentMonth(LocalDateTime systemDateTime) {

        return systemDateTime.plusMonths(-3).format(dtfUUUUMM);
    }

    private String getPreviousMonth(LocalDateTime systemDateTime) {

        return systemDateTime.plusMonths(-4).format(dtfUUUUMM);
    }

}
