package jp.co.aeroasahi.tpkt.batch.mdb0205;

import java.util.List;

/**
 * テーブル＜SAP得意先マスタ＞とテーブル＜【TEMP】委託先マスタ＞に操作
 */
public interface MDB0205Repository {

    /**
     * SAP仕入先マスタ情報を取得する。
     *
     * @return SAP得意先マスタ情報
     */
    List<MDB0205Input> findAllBySAPVendor();

    /**
     * 【TEMP】委託先マスタ情報を取得する。
     *
     * @return 【TEMP】委託先マスタ情報
     */
    List<MDB0205Output> findAllByOjMaVendor();

    /**
     * テーブル＜【TEMP】委託先マスタ＞に登録する。
     *
     * @param output MDB0204Output
     * @return
     */
    void create(MDB0205Output output);

    /**
     * テーブル＜【TEMP】委託先マスタ＞に更新する。
     *
     * @param output MDB0204Output
     * @return
     */
    void update(MDB0205Output output);
}
