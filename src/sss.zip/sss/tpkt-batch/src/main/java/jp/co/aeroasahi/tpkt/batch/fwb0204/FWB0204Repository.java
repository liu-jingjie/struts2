package jp.co.aeroasahi.tpkt.batch.fwb0204;

import java.util.List;

public interface FWB0204Repository {

    /**
     * 日次閉塞情報取得
     */
    List<ClosePeriod> findAllIsDaily();
}
