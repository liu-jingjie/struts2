package jp.co.aeroasahi.tpkt.batch.cm.mail.fbfw001;

import java.nio.charset.StandardCharsets;
import java.util.Locale;
import javax.inject.Inject;
import javax.mail.internet.MimeMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Scope;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.common.model.fw.MailManagement;
import jp.co.aeroasahi.tpkt.common.repository.fw.MailManagementRepository;
import jp.co.aeroasahi.tpkt.common.util.CommonUtils;

/**
 *
 * 添付ファイル無しのメール送信タスクレット
 * TERASOLUNABatchの方針に従って、アプリケーション側から受け取る値の検証はしないこととする
 * (バッチパラメータの連番と、連番を用いたメール情報の取得についてのチェック処理は実装しない)
 *
 */
@Component
@Transactional
@Scope("step")
public class FBFW001Tasklet implements Tasklet {

    /** ジョブID */
    private static final String JOB_ID ="fbfw001";

    /** ロガー */
    private static final Logger logger = LoggerFactory.getLogger(FBFW001Tasklet.class);

    /** 送信元メールアドレス */
    @Value("${address.from}")
    String addressFrom;

    /** メール連番 */
    @Value("#{jobParameters['sequence']}")
    public String sequence;

    @Inject
    JavaMailSender mailSender;

    @Inject
    MailManagementRepository mailManagementRepository;

    @Inject
    MessageSource messageSource;

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
        Object[] messages = CommonUtils.getMessageArgs(JOB_ID, sequence);

        logger.info(messageSource.getMessage("i.bat.cm.001", messages, Locale.getDefault()));

        MailManagement mailManagement = mailManagementRepository.findOneByPk(sequence);

        try {
            // メール送信
            register(mailManagement);
        } catch (Exception e) {
            // メールの送信に失敗した場合は、例外をスローし、終了する(監視ログに出力する)
            // 1時間に1回ログ監視バッチで結果を確認し、失敗したものは手動で再送バッチを起動し、再送される
            logger.error(messageSource.getMessage("e.bat.fw.001", messages, Locale.getDefault()));
            throw new RuntimeException(e);
        }

        logger.info(messageSource.getMessage("i.bat.cm.002", messages, Locale.getDefault()));

        return RepeatStatus.FINISHED;
    }


    private void register(MailManagement mailManagement) {

        mailSender.send(new MimeMessagePreparator() {

            @Override
            public void prepare(MimeMessage mimeMessage) throws Exception {
                MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, StandardCharsets.UTF_8.name());
                // TODO メアドFromはサーバー毎に変える必要があるのか？(現状はDBサーバー固定にしている)
                helper.setFrom(addressFrom);
                helper.setTo(mailManagement.getMailAddressTo().split(","));

                // CCが不要な場合(null or空文字が渡された場合)は、設定しない
                String addressCc = mailManagement.getMailAddressCc();
                if(addressCc != null && addressCc.length() > 0) {
                    helper.setCc(mailManagement.getMailAddressCc().split(","));
                }
                helper.setSubject(mailManagement.getSubject());
                helper.setText(mailManagement.getBody(), true);
            }
        });
    }

}
