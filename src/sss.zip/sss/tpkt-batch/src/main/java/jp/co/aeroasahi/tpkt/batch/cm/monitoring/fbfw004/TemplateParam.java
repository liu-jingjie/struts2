package jp.co.aeroasahi.tpkt.batch.cm.monitoring.fbfw004;

import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TemplateParam {

    /** バッチ開始時間 */
    private String fromHour;

    /** エラー件数 */
    private String errorCount;

    /** エラーリスト */
    private List<String> errorList;
}
