package jp.co.aeroasahi.tpkt.batch.ckb0101;

import org.springframework.batch.item.ItemCountAware;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜BU+PJ属性別帳票登録状況＞のOutputBean。
 */
@Setter
@Getter
public class CKB0101RegStsBuPjOutput implements ItemCountAware {

    private int count;

    /** BU+プロジェクト属性ID */
    private String buPjAttId;

    /** 帳票種別 */
    private String docType;

    /** 帳票登録状況 */
    private String docRegStatus;

    /** 原本有無フラグ */
    private boolean originalReged;

    /** 作成日 */
    private String createdAt;

    @Override
    public void setItemCount(int count) {
        this.count = count;
    }
}
