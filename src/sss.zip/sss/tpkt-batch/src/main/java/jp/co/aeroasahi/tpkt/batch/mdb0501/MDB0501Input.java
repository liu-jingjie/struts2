package jp.co.aeroasahi.tpkt.batch.mdb0501;

import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】工数金額＞のInputBean。
 */
@Setter
@Getter
public class MDB0501Input {

    /** プロジェクトID */
    private String pjId;

    /** 年月 */
    private String ym;

    /** 工程CD */
    private String koteiCd;

    /** 費目CD */
    private String himokuCd;

    /** 実績積算区分 */
    private String resultPlanedKbn;

    /** 代表リソースCD */
    private String distResourceCd;

    /** 単価 */
    private BigDecimal unitCost;

    /** 直接単価 */
    private BigDecimal directUnitCost;

    /** 直接部門間接単価 */
    private BigDecimal directDeptIndirectUnitCost;

    /** 間接部門間接単価 */
    private BigDecimal indirectDeptIndirectUnitCost;

    /** 製造間接単価 */
    private BigDecimal indirectUnitCost;

    /** 大型機材単価 */
    private BigDecimal largeMachineIndirectCost;

    /** 工数 */
    private BigDecimal kosu;

    /** 年月 検索用(当月)*/
    private String ym1;

    /** 年月 検索用(前月或は指定した月)*/
    private String ym2;

    /** 年月 検索用（積算）(前月或は指定した月)*/
    private String ym3;
}
