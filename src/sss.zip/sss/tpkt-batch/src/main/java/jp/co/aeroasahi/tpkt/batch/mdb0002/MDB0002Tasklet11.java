package jp.co.aeroasahi.tpkt.batch.mdb0002;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import jp.co.aeroasahi.tpkt.batch.util.CommonUtils;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

/**
 * 差分連携処理の実行を要求するTasklet
 */
@Component
@Scope("step")
public class MDB0002Tasklet11 implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0002Tasklet11.class);

    /** DateTimeFormatterのパターン uuuu-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.SSS");

    /** 仕入先マスタのディレクトリパス */
    private static final String VENDOR_PATH = "Vendor/";
    /** プロジェクトのディレクトリパス */
    private static final String PROJECT_ATTRIBUTE_PATH = "ProjectAttribute/";
    /** プロジェクト属性のディレクトリパス */
    private static final String PROJECT_PATH = "Project/";

    /** 仕入先マスタのパス */
    private static final String VENDOR_FILE_NAME = "SATP0012";
    /** プロジェクトのパス */
    private static final String PROJECT_ATTRIBUTE_FILE_NAME = "SATP0013";
    /** プロジェクト属性のパス */
    private static final String PROJECT_FILE_NAME = "SATP0014";
    /** ファイル名の拡張子 */
    private static final String EXTENSION_NAME = ".txt";

    private final static String EMPTY = "";

    /** ファイル連携先 */
    @Value("${sap.input.dirpath}")
    String inputDirPath;

    /** TEMPファイルバックアップ先（一時ファイルの場所） */
    @Value("${sap.temp.dirpath}")
    String tempDirPath;

    @Inject
    DateFactory dateFactory;

    @Inject
    MDB0002Repository mdb0002Repository;

    @Autowired
    private BatchDataHolder batchDataHolder;

    /**
     * 差分連携処理呼び出し
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return 一括で各ジョブを実行した状態
     */
    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

        try {
            LocalDateTime startDateTime = dateFactory.newDateTime();
            String jobStartDateTimeStr = startDateTime.format(dtf2);

            // 実施時間
            batchDataHolder.setSystemDateTime(jobStartDateTimeStr);
            // 実施した結果
            batchDataHolder.setCheckResult(true);

            // 仕入先マスタ
            executeCheck(inputDirPath + VENDOR_PATH, VENDOR_FILE_NAME, jobStartDateTimeStr);
            // プロジェクト属性
            executeCheck(inputDirPath + PROJECT_ATTRIBUTE_PATH, PROJECT_ATTRIBUTE_FILE_NAME, jobStartDateTimeStr);
            // プロジェクト
            executeCheck(inputDirPath + PROJECT_PATH, PROJECT_FILE_NAME, jobStartDateTimeStr);

        } catch (Exception e) {
            logger.error("システムエラーが発生しました。");
            logger.error("stackTrace：", e);
            batchDataHolder.setCheckResult(false);
        }
        return RepeatStatus.FINISHED;
    }

    private void executeCheck(String dirPath, String fileName, String jobStartDateTimeStr) throws Exception {

        // フォルダ「INPUTフォルダ」 にパラメータ:ファイル名と等しいファイルが存在する
        if (isfileExist(dirPath, fileName)) {
            String systemYMD = jobStartDateTimeStr.substring(0, 10).replaceAll("-", "");

            // TEMPファイル存在チェック(ファイル取込中)
            boolean isCheckFiles = isExistFiles(getFileName(tempDirPath), systemYMD, fileName);
            if (!isCheckFiles) {
                try {
                    // ファイルをTEMPフォルダに移動する。
                    CommonUtils.fileMove(dirPath + fileName + EXTENSION_NAME, tempDirPath + fileName + EXTENSION_NAME);
                } catch (IOException e) {
                    logger.error(fileName + "をTEMPフォルダに移動するときに、異常が発生しました。");
                    logger.error("stackTrace：", e);
                    batchDataHolder.setCheckResult(false);
                    return;
                }
                logger.info("取込ファイルを移動しました。;ファイル名={};移動先フォルダ={}", fileName + EXTENSION_NAME, tempDirPath);
                // BATCH_JOB_REQUEST にINSERT
                switch (fileName) {
                    case VENDOR_FILE_NAME:
                        executeJob("fwb0111Job", "inputFile=" + tempDirPath + fileName + EXTENSION_NAME
                                + ",systemDateTime=" + jobStartDateTimeStr, jobStartDateTimeStr);
                        break;
                    case PROJECT_ATTRIBUTE_FILE_NAME:
                        executeJob("fwb0112Job", "inputFile=" + tempDirPath + fileName + EXTENSION_NAME
                                + ",systemDateTime=" + jobStartDateTimeStr, jobStartDateTimeStr);
                        break;
                    case PROJECT_FILE_NAME:
                        executeJob("fwb0113Job", "inputFile=" + tempDirPath + fileName + EXTENSION_NAME
                                + ",systemDateTime=" + jobStartDateTimeStr, jobStartDateTimeStr);
                        break;
                }
                return;
            } else {
                logger.info("{}がTEMPフォルダに存在するため、取込処理をスキップしました", fileName + EXTENSION_NAME);
                return;
            }
        }
        logger.info("{}は対象のパスに存在しないため、取込処理をスキップしました", fileName + EXTENSION_NAME);
        return;
    }

    /**
     * ジョブ実行処理
     *
     * @return 無し
     */
    private void executeJob(String jobName, String jobParameter, String jobStartDateTimeStr) throws Exception {

        BatchJobRequestInput input = new BatchJobRequestInput();

        input.setJobName(jobName);
        input.setJobParameter(jobParameter);
        input.setPriority(1);
        input.setPollingStatus("INIT");
        input.setJobStartDateTimeStr(jobStartDateTimeStr);

        mdb0002Repository.create(input);
    }

    private String[] getFileName(String path) {
        File file = new File(path);
        String[] fileName = file.list();
        return fileName;
    }


    private boolean isExistFiles(String[] fileNames, String systemYMD, String checkStr) {

        // false:ファイルが無い、true：ファイルが有る
        boolean rtn = false;

        if (fileNames == null) {
            return false;
        }

        for (String name : fileNames) {

            if (name.length() >= 12 && name.substring(0, 8).equals(systemYMD)) {

                if (checkStr.equals(EMPTY)) {
                    rtn = true;
                } else {
                    rtn = name.indexOf(checkStr) != -1 ? true : false;
                }
            }
        }

        return rtn;
    }

    private boolean isfileExist(String path, String fileName) {
        File source = new File(path + fileName + EXTENSION_NAME);
        return source.exists();
    }
}
