package jp.co.aeroasahi.tpkt.batch.mdb0501;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.validator.ValidationException;
import org.springframework.batch.item.validator.Validator;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.fw.CommonLog;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

@Component
@Scope("step")
public class MDB0501Tasklet implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0501Tasklet.class);

    @Inject
    MDB0501Repository mdb0501Repository;

    @Inject
    DateFactory dateFactory;

    @Inject
    Validator<MDB0501Output> validator;

    @Value("#{jobParameters['kbn']}")
    public String kbn;

    @Value("#{jobParameters['yyyymm']}")
    public String yyyymm;

    boolean isErrFlag = false;

    /** DateTimeFormatterのパターン yyyy-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    /** DateTimeFormatterのパターン uuuuMM */
    private static final DateTimeFormatter dtfUUUUMM = DateTimeFormatter.ofPattern("uuuuMM");

    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        LocalDateTime systemDateTime = dateFactory.newDateTime();
        String systemYearMonth = systemDateTime.format(dtf);

        // 当月の年月
        String ym1 = getCurrentMonth(systemDateTime);

        // 前月或は指定した月の年月
        String ym2 = "";

        // 日次処理の場合
        if (kbn.equals("D")) {
            ym2 = getPreviousMonth(systemDateTime);

        // 月次確定処理の場合
        } else if (kbn.equals("M")) {
            LocalDateTime yyyymmP = LocalDateTime.of(Integer.parseInt(yyyymm.substring(0, 4)), Integer.parseInt(yyyymm.substring(4, 6)), 1, 1, 1);
            ym2 = getCurrentMonth(yyyymmP);
        }

        // 検索条件を設定する
        MDB0501Input itemInput = new MDB0501Input();
        itemInput.setYm1(ym1);
        itemInput.setYm2(ym2);

        List<MDB0501Output> outItems = getEditedList(setItemOutput(ym1, ym2, systemYearMonth,systemDateTime));

        if (!isErrFlag) {
            for (int i = 0; i < outItems.size(); i++) {
                try {
                    validator.validate(outItems.get(i));
                } catch (ValidationException e) {
                    isErrFlag = true;
                    CommonLog.setFromDbErrorLog(logger, e, "【TEMP】金額(temp_md_cost)");
                }
            }

            if (!isErrFlag) {

                // 実績データ削除
                mdb0501Repository.deletePerformance(itemInput);

                itemInput = new MDB0501Input();
                itemInput.setYm1(ym1);
                itemInput.setYm2(getPreviousMonth(systemDateTime));

                // 積算データ削除
                mdb0501Repository.deleteIntegration(itemInput);

                // 初回積算データ削除
                mdb0501Repository.deleteInitialIntegration(itemInput);

                // 【TEMP】金額の既存データを取得する
                List<MDB0501Output> checkList = mdb0501Repository.findAllByKey();
                Map<String, MDB0501Output> checkListMap =
                        checkList.stream().collect(Collectors.toMap(MDB0501Output::concat, Function.identity()));

                List<MDB0501Output> insertRecordList = new ArrayList<MDB0501Output>();
                List<MDB0501Output> updateRecordList = new ArrayList<MDB0501Output>();
                for (MDB0501Output mdb0501Output : outItems) {

                    // 更新
                    if (checkListMap.containsKey(mdb0501Output.concat())) {
                        updateRecordList.add(mdb0501Output);
                        // 登録
                    } else {

                        insertRecordList.add(mdb0501Output);
                    }
                }

                // 【TEMP】金額のデータを更新する
                if (updateRecordList.size() > 0) {
                    for (MDB0501Output output : updateRecordList) {
                        mdb0501Repository.update(output);
                    }
                }

                // 【TEMP】金額のデータを登録する
                if (insertRecordList.size() > 0) {
                    for (MDB0501Output output : insertRecordList) {
                        mdb0501Repository.create(output);
                    }
                }
                CommonLog.setInsertRecordeCountLog(logger, "【TEMP】金額(temp_md_cost)", insertRecordList.size());
                CommonLog.setUpdateRecordeCountLog(logger, "【TEMP】金額(temp_md_cost)", updateRecordList.size());
            } else {
                logger.error("登録データでエラーが発生しました。");
            }
            outItems.clear();
        }

        if (isErrFlag) {
            throw new RuntimeException("mdb0501人件費取込処理実行に異常が発生しました。");
        }

        return RepeatStatus.FINISHED;
    }

    private List<MDB0501Output> setItemOutput(String ym1, String ym2, String systemYearMonth, LocalDateTime systemDateTime) throws CloneNotSupportedException {

        List<MDB0501Output> outputItems = new ArrayList<MDB0501Output>();
        MDB0501Output itemOutput = new MDB0501Output();
        BigDecimal zero = new BigDecimal("0");

        // 検索条件を設定する
        MDB0501Input itemInput = new MDB0501Input();
        itemInput.setYm1(ym1);
        itemInput.setYm2(ym2);
        itemInput.setYm3(getPreviousMonth(systemDateTime));

        // 直接人件費
        BigDecimal priceTotal1 = new BigDecimal("0");
        // 間接人件費
        BigDecimal priceTotal2 = new BigDecimal("0");
        // 臨時人件費
        BigDecimal priceTotal3 = new BigDecimal("0");

        List<MDB0501Input> dataList = new ArrayList<MDB0501Input>();

        // 日次処理の場合
        if (kbn.equals("D")) {

            // 実施する年月の前月の会計年度と会計期間を取得する
            String fiscalYearMonth = getFiscalYearPreviousMonth(systemDateTime);

            // 前月の会計年度
            String fiscalYear = fiscalYearMonth.substring(0, 4);

            // 前月の会計期間
            String fiscalMonth = fiscalYearMonth.substring(4, 6);

            // ［SAP勘定残高］に、勘定科目「52130001」（人件費（直接）の勘定コード）の前月の実績データが1件以上存在する場合
            if(mdb0501Repository.findCountBySAPAccountBalance(fiscalYear, fiscalMonth) > 0) {

                // ［【TEMP】工数金額］から当月のみのデータを抽出し、［【TEMP】金額］に登録する
                dataList = mdb0501Repository.findAllCurrentMonthOnly(itemInput);

            //［SAP勘定残高］に、勘定科目「52130001」（人件費（直接）の勘定コード）の前月の実績データが1件も存在しない場合
            } else {

                // ［【TEMP】工数金額］から当月または前月のデータを抽出し、［【TEMP】金額］に登録する
                dataList = mdb0501Repository.findAll(itemInput);
            }

        } else if (kbn.equals("M")) {

            LocalDateTime yyyymmP = LocalDateTime.of(Integer.parseInt(yyyymm.substring(0, 4)), Integer.parseInt(yyyymm.substring(4, 6)), 1, 1, 1);
            // 指定月の会計年度と会計期間を取得する
            String fiscalYearMonth = getFiscalYear(yyyymmP);

            // 前月の会計年度
            String fiscalYear = fiscalYearMonth.substring(0, 4);

            // 前月の会計期間
            String fiscalMonth = fiscalYearMonth.substring(4, 6);

            // ［SAP勘定残高］に、勘定科目「52130001」（人件費（直接）の勘定コード）の［パラメータ．処理年月］（処理年月を会計年度と会計期間に変換して使用）の実績データが1件以上存在する場合、
            if(mdb0501Repository.findCountBySAPAccountBalance(fiscalYear, fiscalMonth) > 0) {

                // ［【TEMP】工数金額］から当月のみのデータを抽出し、［【TEMP】金額］に登録する
                dataList = mdb0501Repository.findAllCurrentMonthOnly(itemInput);

            //［SAP勘定残高］に、勘定科目「52130001」（人件費（直接）の勘定コード）の［パラメータ．処理年月］（処理年月を会計年度と会計期間に変換して使用）の実績データが1件も存在しない場合、
            } else {

                // ［【TEMP】工数金額］から当月または［パラメータ．処理年月］のデータを抽出し、［【TEMP】金額］に登録する
                dataList = mdb0501Repository.findAll(itemInput);
            }
        }

        for (int i = 0; i < dataList.size(); i++) {

            MDB0501Input mdb0501Input = dataList.get(i);

            itemOutput = new MDB0501Output();

            // プロジェクト属性ID
            itemOutput.setPjAttId(mdb0501Input.getPjId().substring(2, 10));

            // プロジェクトID
            itemOutput.setPjId(mdb0501Input.getPjId());

            // 年月
            itemOutput.setYm(mdb0501Input.getYm());

            // 実績積算区分
            itemOutput.setResultPlanedKbn(mdb0501Input.getResultPlanedKbn());

            // 代表リソースCD
            itemOutput.setDistResourceCd(mdb0501Input.getDistResourceCd());

            // 工程CD
            itemOutput.setKoteiCd(mdb0501Input.getKoteiCd());

            // 作成日
            itemOutput.setCreatedAt(systemYearMonth);

            // 更新日
            itemOutput.setUpdatedAt(systemYearMonth);

            if (mdb0501Input.getHimokuCd().equals("02")) {

                // 臨時人件費の場合
                itemOutput.setHimokuCd(mdb0501Input.getHimokuCd());

                // 金額
                //［【TEMP】工数金額．工数］×［【TEMP】工数金額．単価］
                priceTotal3 = multiplyBD(mdb0501Input.getKosu(), mdb0501Input.getUnitCost());
                itemOutput.setPrice(null == priceTotal3? BigDecimal.ZERO : priceTotal3);

                outputItems.add(itemOutput);
            } else {
                // 直接人件費の場合

                // 費目CD
                itemOutput.setHimokuCd("01");

                // 金額
                //［【TEMP】工数金額．工数］×［【TEMP】工数金額．直接単価］
                priceTotal1 = multiplyBD(mdb0501Input.getKosu(), mdb0501Input.getDirectUnitCost());

                // 大型機材間接費 ［【TEMP】工数金額．工数］×［【TEMP】工数金額．大型機材単価］
                priceTotal1 = addBD(priceTotal1, multiplyBD(mdb0501Input.getKosu(), mdb0501Input.getLargeMachineIndirectCost()));

                itemOutput.setPrice(null == priceTotal1 ? BigDecimal.ZERO : priceTotal1);

                outputItems.add(itemOutput);

                // 間接人件費の場合
                MDB0501Output itemOutput1 = (MDB0501Output)itemOutput.clone();

                // 費目CD
                itemOutput1.setHimokuCd("11");

                // 金額
                // 直接部門間接費 ［【TEMP】工数金額．工数］×［【TEMP】工数金額．直接部門間接単価］
                priceTotal2 = addBD(zero, multiplyBD(mdb0501Input.getKosu(), mdb0501Input.getDirectDeptIndirectUnitCost()));

                // 間接部門間接費 ［【TEMP】工数金額．工数］×［【TEMP】工数金額．間接部門間接単価］
                priceTotal2 = addBD(priceTotal2, multiplyBD(mdb0501Input.getKosu(), mdb0501Input.getIndirectDeptIndirectUnitCost()));

                // 製造間接費   ［【TEMP】工数金額．工数］×［【TEMP】工数金額．製造間接単価］
                priceTotal2 = addBD(priceTotal2, multiplyBD(mdb0501Input.getKosu(), mdb0501Input.getIndirectUnitCost()));

                itemOutput1.setPrice(null == priceTotal2 ? BigDecimal.ZERO : priceTotal2 );

                outputItems.add(itemOutput1);

                // 人件費（直・間接合計）の場合
                MDB0501Output itemOutput2 = (MDB0501Output)itemOutput.clone();

                // 費目CD
                itemOutput2.setHimokuCd("20");

                // 金額
                // 直接人件費＋間接人件費
                itemOutput2.setPrice(addBD(priceTotal1, priceTotal2));

                outputItems.add(itemOutput2);
            }
        }

        return outputItems;
    }

    private String getCurrentMonth(LocalDateTime systemDateTime) {

        return systemDateTime.format(dtfUUUUMM);
    }

    private String getPreviousMonth(LocalDateTime systemDateTime) {

        return systemDateTime.minusMonths(1).format(dtfUUUUMM);
    }

    private String getFiscalYearPreviousMonth(LocalDateTime systemDateTime) {

        return systemDateTime.minusMonths(4).format(dtfUUUUMM);
    }

    private String getFiscalYear(LocalDateTime systemDateTime) {

        return systemDateTime.minusMonths(3).format(dtfUUUUMM);
    }

    private BigDecimal addBD(BigDecimal input1, BigDecimal input2) {

        BigDecimal rtn = new BigDecimal(0);

        if (input1 != null && input2 != null) {
            rtn = input1.add(input2);
        } else {

            if (input1 == null && input2 == null) {
                rtn = new BigDecimal(0);
            } else if (input1 == null) {
                rtn = input2;
            } else {
                rtn = input1;
            }
        }

        return rtn;
    }

    private BigDecimal multiplyBD(BigDecimal input1, BigDecimal input2) {

        BigDecimal rtn = new BigDecimal(0);

        if (input1 != null && input2 != null) {
            rtn = input1.multiply(input2);
        }

        return rtn;
    }

    private List<MDB0501Output> getEditedList(List<MDB0501Output> outItems) {

        Map<String, MDB0501Output> checkMap = new HashMap<String, MDB0501Output>();

        MDB0501Output item = null;
        String checkKey = "";
        MDB0501Output mdb0501Output = new MDB0501Output();

        for (int i = 0; i < outItems.size(); i++) {

            mdb0501Output = outItems.get(i);

            checkKey = mdb0501Output.concat();

            if (checkMap.containsKey(checkKey)) {
                item = checkMap.get(checkKey);

                // 金額
                item.setPrice(addBD(item.getPrice(), mdb0501Output.getPrice()));

            } else {
                item = new MDB0501Output();

                // プロジェクト属性ID
                item.setPjAttId(mdb0501Output.getPjAttId());

                // プロジェクトID
                item.setPjId(mdb0501Output.getPjId());

                // 年月
                item.setYm(mdb0501Output.getYm());

                // 費目CD
                item.setHimokuCd(mdb0501Output.getHimokuCd());

                // 実績積算区分
                item.setResultPlanedKbn(mdb0501Output.getResultPlanedKbn());

                // 工程CD
                item.setKoteiCd(mdb0501Output.getKoteiCd());

                // 代表リソースCD
                item.setDistResourceCd(mdb0501Output.getDistResourceCd());

                // 金額
                item.setPrice(mdb0501Output.getPrice());

                // 作成日
                item.setCreatedAt(mdb0501Output.getCreatedAt());

                // 更新日
                item.setUpdatedAt(mdb0501Output.getUpdatedAt());

                checkMap.put(checkKey, item);
                item = null;
            }

            // 最後のSumした結果を追加する
            if (i == outItems.size() - 1 && null != item) {
                checkMap.put(checkKey, item);
            }
        }

        return new ArrayList<MDB0501Output>(checkMap.values());
    }

}
