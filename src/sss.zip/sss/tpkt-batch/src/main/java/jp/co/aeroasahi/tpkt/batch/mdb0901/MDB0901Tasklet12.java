package jp.co.aeroasahi.tpkt.batch.mdb0901;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.fw.CommonLog;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

/**
 * キューブの自動デプロイを実行する
 */
@Component
@Scope("step")
public class MDB0901Tasklet12 implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0901Tasklet12.class);

    @Inject
    MDB0901Repository mdb0901Repository;

    @Inject
    DateFactory dateFactory;

    @Autowired
    private BatchDataHolder batchDataHolder;

    /** キューブを実施したログのパス */
    @Value("${cube.log.path}")
    String cubeLogPath;

    /** 部門経費管理のログファイル */
    private static final String LOG_DCM = "_log_dept_cost_management.log";

    /** 部門経費管理（人件費有）のログファイル */
    private static final String LOG_DCMM = "_log_dept_cost_management_master.log";

    /** 操業度管理のログファイル */
    private static final String LOG_SI = "_log_sogyodo_infos.log";

    /** DateTimeFormatterのパターン uuuu/MM/dd H:m:s */
    private static final DateTimeFormatter DTF = DateTimeFormatter.ofPattern("uuuu/MM/dd H:m:s");

    /** DateTimeFormatterのパターン uuuuMMdd */
    private static final DateTimeFormatter DTF1 = DateTimeFormatter.ofPattern("uuuuMMdd");

    private static final String END_STR = "PackageEnd";
    private static final String ERROR_STR = "OnError";
    private static final String LOG_CHARACTOR_CODE = "UTF-16";

    private static final String LOG_HEADER_STR =
            "#Fields: event,computer,operator,source,sourceid,executionid,starttime,endtime,datacode,databytes,message";

    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        LocalDateTime startDateTime = batchDataHolder.getStartDateTime();
        LocalDateTime jobStartDTPlus1h = startDateTime.plusMinutes(30);
        String fileDatePrefix = startDateTime.format(DTF1);

        // 部門経費管理のデプロイログをチェックする
        isErrLog(cubeLogPath, fileDatePrefix + LOG_DCM, startDateTime, jobStartDTPlus1h);

        // 部門経費管理（人件費有）のデプロイログをチェックする
        isErrLog(cubeLogPath, fileDatePrefix + LOG_DCMM, startDateTime, jobStartDTPlus1h);

        // 操業度管理のデプロイログをチェックする
        isErrLog(cubeLogPath, fileDatePrefix + LOG_SI, startDateTime, jobStartDTPlus1h);

        CommonLog.setNormalLog(logger);

        return RepeatStatus.FINISHED;
    }

    private void isErrLog(String path, String file, LocalDateTime startDateTime, LocalDateTime jobStartDTPlus1h)
            throws IOException, InterruptedException {

        boolean checkFlag = false;

        File logFile = new File(path + file);
        List<String> content = new ArrayList<String>();
        boolean checkDoneFlag = false;

        while (true) {

            Thread.sleep(2000);

            if (logFile.exists()) {

                content = FileUtils.readLines(logFile, LOG_CHARACTOR_CODE);

                for (String lineStr : content) {

                    if (!lineStr.equals("") && !lineStr.equals(LOG_HEADER_STR)) {

                        String[] lineStrArray = lineStr.split(",");
                        if (lineStrArray.length > 6) {
                            String dateTimeStr = lineStr.split(",")[6];
                            String statusStr = lineStr.split(",")[0];
                            LocalDateTime logDateTime = LocalDateTime.parse(dateTimeStr, DTF);

                            if ((startDateTime.isBefore(logDateTime) || startDateTime.equals(logDateTime))
                                    && statusStr.equals(END_STR)) {
                                checkDoneFlag = true;
                            }
                        }
                    }
                }

                if (checkDoneFlag) {

                    for (String lineStr : content) {

                        if (!lineStr.equals("") && !lineStr.equals(LOG_HEADER_STR)) {

                            String[] lineStrArray = lineStr.split(",");
                            if (lineStrArray.length > 6) {
                                String dateTimeStr = lineStr.split(",")[6];
                                String statusStr = lineStr.split(",")[0];
                                LocalDateTime logDateTime = LocalDateTime.parse(dateTimeStr, DTF);

                                if ((startDateTime.isBefore(logDateTime) || startDateTime.equals(logDateTime))) {
                                    if (statusStr.equals(ERROR_STR)) {
                                        checkFlag = true;
                                        logger.error("{} {}処理の実行でエラーが発生しました。ログファイルを確認してください。;ログ出力パス={};ログファイル名={}","mdb0901","キューブデプロイ", path, file);
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    break;
                }
            }
            LocalDateTime systemDateTime = dateFactory.newDateTime();
            if (systemDateTime.isAfter(jobStartDTPlus1h)) {
                // 現在日時がこのjobの起動から30分以上経過している場合はエラーとする
                checkFlag = true;
                logger.error("{} {}処理でタイムアウトエラーが発生しました。ログファイルの出力状態を確認してください。;ログ出力パス={};ログファイル名={}","mdb0901","キューブデプロイ", path, file);
                break;
            }
        }

        if (checkFlag) {
            CommonLog.setFaultLog(logger);
            throw new RuntimeException("mdb0901キューブデプロイ処理実行に異常が発生しました。");
        }
    }

}
