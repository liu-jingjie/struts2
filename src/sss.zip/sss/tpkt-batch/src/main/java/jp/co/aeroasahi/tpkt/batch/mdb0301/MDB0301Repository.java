package jp.co.aeroasahi.tpkt.batch.mdb0301;

/**
 * テーブル＜【TEMP】金額＞に操作
 */
public interface MDB0301Repository {

    /**
     * テーブル＜【TEMP】金額＞に削除する。
     *
     * @param output MDB0301Output
     * @return
     */
    void delete(MDB0301Output output);

    /**
     * テーブル＜【TEMP】金額＞に削除する。
     *
     * @param output MDB0301Output
     * @return
     */
    void deletePerformance(MDB0301Output output);
}