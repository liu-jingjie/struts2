package jp.co.aeroasahi.tpkt.batch.cm.mail.fbfw003;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;
import jp.co.aeroasahi.tpkt.common.fw.message.MessageSharedService;
import jp.co.aeroasahi.tpkt.common.model.fw.BatchJobRequest;
import jp.co.aeroasahi.tpkt.common.repository.fw.BatchJobRequestRepository;
import jp.co.aeroasahi.tpkt.common.repository.fw.MailManagementRepository;

/**
 *
 * 添付ファイル無しのメール送信タスクレット
 * TERASOLUNABatchの方針に従って、アプリケーション側から受け取る値の検証はしないこととする
 * (バッチパラメータの連番と、連番を用いたメール情報の取得についてのチェック処理は実装しない)
 *
 */
@Component
@Scope("step")
public class FBFW003Tasklet implements Tasklet {

    /** ジョブID */
    private static final String JOB_ID = "fbfw003";

    /** パラメータのプレフィックス */
    private static final String PARAMATER_PREFIX = "sequence=";

    /** ロガー */
    private static final Logger logger = LoggerFactory.getLogger(FBFW003Tasklet.class);

    @Inject
    DateFactory dateFactory;

    @Inject
    MailManagementRepository mailManagementRepository;

    @Inject
    ReSendMailRepository reSendMailRepository;

    @Inject
    BatchJobRequestRepository batchJobRequestRepository;

    @Inject
    MessageSharedService messageService;

    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        // DBから送信に失敗したメールの一覧を取得
        List<BatchJobRequest> reSendMailList = reSendMailRepository.findAllReSendmail();

        // 件数が0件の場合、以降の処理は不要なため、ログを出力して終了
        if (reSendMailList.size() == 0) {
            logger.info(messageService.getMessage("i.bat.cm.010", JOB_ID));
            return RepeatStatus.FINISHED;
        }

        // 再送信要求対象のsequenceの一覧
        List<Long> sequences = new ArrayList<>();

        try {
            // 作成日をセットし、パラメータにプレフィックスを付与
            LocalDateTime date = dateFactory.newDateTime();

            for (BatchJobRequest each : reSendMailList) {
                // パラメータから連番を取得
                String sequence = each.getJobParameter();
                each.setCreateDate(date);
                each.setJobParameter(PARAMATER_PREFIX + sequence);

                // 再送要求
                batchJobRequestRepository.create(each);

                sequences.add(Long.valueOf(sequence));

                logger.info(messageService.getMessage("i.bat.cm.009", JOB_ID, sequence));
            }

        } catch (Exception e) {
            logger.error(messageService.getMessage("e.bat.fw.002", JOB_ID, "メール情報"));
            throw new RuntimeException(e);
        } finally {
            // 再送フラグの更新要求
            // 再送済みフラグ更新
            mailManagementRepository.updateSentByPk(sequences);
        }
        return RepeatStatus.FINISHED;
    }

}
