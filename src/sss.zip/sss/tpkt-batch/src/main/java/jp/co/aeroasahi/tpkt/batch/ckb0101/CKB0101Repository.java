package jp.co.aeroasahi.tpkt.batch.ckb0101;

import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 *
 * 帳票登録状況一覧の作成に関するDB操作
 * 品質記録管理帳票マスタTBL
 * 帳票登録情報TBL
 * 帳票登録日情報TBL
 * PJID別帳票登録状況TBL
 * BU+PJ属性別帳票登録状況TBL
 * プロジェクトTBL
 * 未登録状況TBL
 *
 */
public interface CKB0101Repository {

    /**
     * テーブル＜品質記録管理帳票マスタ＞を取得する。
     *
     * @return list <CKB0101QualityRecordDocInput>
     */
    List<CKB0101QualityRecordDocInput> findQualityRecordDoc();

    /**
    * 指定されたテーブルをtruncate
    *
    * @param tableName
    * @return
    */
    int truncateTable(@Param("tableName") String tableName);

    /**
     * テーブル＜帳票登録情報＞を登録する。
     *
     * @param output CKB0101RegInfoOutput
     *
     */
    void createRegInfo(CKB0101RegInfoOutput output);


    /**
     * テーブル＜帳票登録日情報＞を検索する。
     *
     * @return list List<CKB0101RegDateInfoOutput>
     */
    List<CKB0101RegDateInfoOutput> findRegDateInfo();

    /**
     * テーブル＜帳票登録情報＞を登録する。
     *
     * @param output CKB0101RegDateInfoOutput
     *
     */
    void createRegDateInfo(CKB0101RegDateInfoOutput output);

    /**
     * テーブル＜PJID別登録状況＞を削除する。
     *
     *
     */
    void deleteRegStsPj();

    /**
     * テーブル＜PJID別登録状況＞を登録する。
     *
     *
     */
    void createRegStsPj(@Param("sysdatetime") String sysdatetime);

    /**
     * テーブル＜PJID別登録状況＞を更新する。
     *
     * @param sysdatetime String
     *
     */
    void updateRegStsPj(@Param("sysdatetime") String sysdatetime);

    /**
     * テーブル＜BU+PJ属性別帳票登録状況＞を削除する。
     *
     *
     */
    void deleteRegStsBuPj();

    /**
     * テーブル＜BU+PJ属性別帳票登録状況＞に登録する。
     *
     *
     */
    void createBuPjRegStatusInfo(CKB0101RegStsBuPjOutput output);

    /**
     * 登録対象のレコードを取得する。
     *
     */
    List<CKB0101RegStsBuPjInput> findAllInsertTarget();

    /**
     * 各テーブルから＜未登録状況＞を取得する。
     *
     * @return list List<CKB0101UnregStatusInput>
     */
    List<CKB0101UnregStatusInput> findUnregStatus();

    /**
     * テーブル＜未登録状況＞を登録する。
     *
     * @param output CKB0101RegStsPjBuOutput
     *
     */
    void createUnregStatus(CKB0101UnregStatusOutput output);

    /**
     * PjIdより対象外の帳票登録情報を削除。
     *
     *
     */
    void deleteDocRegInfoByPjid();

    /**
     * Excelファイル格納パスなどの情報を取得。
     *
     * @return list List<CKB0101ExcelInput>
     */
    List<CKB0101ExcelInput> findExcelInfos();

    /**
     * Excelファイルのデータを更新。
     *
     * @param excelOutput CKB0101ExcelOutput
     *
     */
    void updateProjectById(CKB0101ExcelOutput excelOutput);
}