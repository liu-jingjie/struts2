package jp.co.aeroasahi.tpkt.batch.mdb0201;

import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜SAP勘定明細＞とテーブル＜ビジネスユニットコード変換＞のInputBean。
 */
@Setter
@Getter
public class MDB0201SaleInput {

    /** ビジネスユニットコード変換のビジネスユニット */
    private String bu;

    /** SAP勘定明細の請求書伝票番号*/
    private String RBUKRS;

    /** SAP勘定明細のプロジェクトID*/
    private String PROJK;

    /** SAP勘定明細の勘定コード*/
    private String HKONT;

    /** SAP勘定明細の会計年度 */
    private String GJAHR;

    /** SAP勘定明細の会計期間 */
    private String MONAT;

    /** SAP勘定明細の転記日付*/
    private String BUDAT;

    /** SAP勘定明細の金額*/
    private BigDecimal DMBTR;

    /** SAP勘定明細の部門*/
    private String PRCTR;

    /** 会計年度 検索用(当月)*/
    private String GJAHR1;

    /** 会計期間 検索用(当月)*/
    private String MONAT1;

    /** 会計年度 検索用(前月或は指定した月)*/
    private String GJAHR2;

    /** 会計期間 検索用(前月或は指定した月)*/
    private String MONAT2;
}
