package jp.co.aeroasahi.tpkt.batch.sbb0202;

import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

/**
 * 単価の年度更新Bean。
 */
@Setter
@Getter
public class SBB0202TankaUpdate {

    /** リソースCD */
    private String resourceCd;

    /** 単価CD */
    private String unitCd;

    /** 単価 */
    private BigDecimal unitCost;

    /** プロジェクトID */
    private String pjId;

    /** 工程CD */
    private String koteiCd;

    /** 枝番 */
    private String branchNum;

    /** 実績積算区分 */
    private String resultPlanedKbn;

    /** 原価 */
    private BigDecimal cost;

    /** 作業年月 */
    private String workYm;

    /** 費目コード */
    private String himokuCd;

}
