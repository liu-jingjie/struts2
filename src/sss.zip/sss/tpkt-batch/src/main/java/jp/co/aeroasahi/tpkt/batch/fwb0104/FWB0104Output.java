package jp.co.aeroasahi.tpkt.batch.fwb0104;

import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.batch.item.ItemCountAware;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】SAPプロジェクト＞のOutputBean。
 */
@Setter
@Getter
public class FWB0104Output implements ItemCountAware {

    private int count;

    /** プロジェクトID */
    @NotBlank
    @Size(min = 1, max = 12)
    private String PSPNR;

    /** プロジェクト名称 */
    @Size(min = 0, max = 80)
    private String ZPSPNAME;

    /** 生産・営業担当部門 */
    @Size(min = 0, max = 6)
    private String PRCTR;

    /** 生産・営業担当者 */
    @Size(min = 0, max = 5)
    private String ZSEISANEIGYOTANTOSHA;

    /** プロジェクトID ステータス */
    @Size(min = 0, max = 4)
    private String STAT;

    /** プロジェクト登録日 */
    @Size(min = 0, max = 23)
    private String ZCMCREADT;

    /** プロジェクト属性ID */
    @Size(min = 0, max = 8)
    private String ZPSPID;

    /** 取引種別 */
    @Size(min = 0, max = 1)
    private String ZTORISYUBETU;

    /** 作成日 */
    @Size(min = 23, max = 23)
    private String INS_DT;

    /** 更新日 */
    @Size(min = 23, max = 23)
    private String UPD_DT;

    @Override
    public void setItemCount(int count) {
        this.count = count;
    }
}
