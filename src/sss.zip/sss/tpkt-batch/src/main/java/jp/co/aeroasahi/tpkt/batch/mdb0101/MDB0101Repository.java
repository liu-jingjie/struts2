package jp.co.aeroasahi.tpkt.batch.mdb0101;

import java.util.List;

/**
 * テーブルに操作
 */
public interface MDB0101Repository {

    /**
     * 条件によって、テーブル＜工数データ＞＜社員＞＜費目･リソースマスタ＞＜部門マスタ＞の情報を取得する。
     *
     * @param input MDB0101KosuCostInput
     * @return データ情報
     */
    List<MDB0101KosuCostInput> findAllByDirectlyNormal(MDB0101KosuCostInput input);

    /**
     * 条件によって、テーブル＜工数データ＞＜社員＞＜費目･リソースマスタ＞＜部門マスタ＞の情報を取得する。
     *
     * @param input MDB0101KosuCostInput
     * @return データ情報
     */
    List<MDB0101KosuCostInput> findAllByDirectlyFormer(MDB0101KosuCostInput input);

    /**
     * 条件によって、テーブル＜工数データ＞＜社員＞＜費目･リソースマスタ＞＜部門マスタ＞の情報を取得する。
     *
     * @param input MDB0101KosuCostInput
     * @return データ情報
     */
    List<MDB0101KosuCostInput> findAllByDirectlyAhead(MDB0101KosuCostInput input);

    /**
     * 条件によって、テーブル＜積算基本情報＞＜積算月別展開データ＞＜費目･リソースマスタ＞＜プロジェクト＞の情報を取得する。
     *
     * @param input MDB0101KosuCostInput
     * @return データ情報
     */
    List<MDB0101KosuCostInput> findAllByDirectlyEstimate(MDB0101KosuCostInput input);

    /**
     * 条件によって、テーブル＜工数データ＞＜社員＞＜部門マスタ＞の情報を取得する。
     *
     * @param input MDB0101KosuCostInput
     * @return データ情報
     */
    List<MDB0101KosuCostInput> findAllByIndirectNormal(MDB0101KosuCostInput input);

    /**
     * 条件によって、テーブル＜工数データ＞＜社員＞＜部門マスタ＞の情報を取得する。
     *
     * @param input MDB0101KosuCostInput
     * @return データ情報
     */
    List<MDB0101KosuCostInput> findAllByIndirectFormer(MDB0101KosuCostInput input);

    /**
     * 条件によって、テーブル＜工数データ＞＜社員＞＜部門マスタ＞の情報を取得する。
     *
     * @param input MDB0101KosuCostInput
     * @return データ情報
     */
    List<MDB0101KosuCostInput> findAllByIndirectAhead(MDB0101KosuCostInput input);

    /**
     * 条件によって、テーブル＜工数データ＞＜社員＞＜部門マスタ＞の情報を取得する。
     *
     * @param input MDB0101KosuCostInput
     * @return データ情報
     */
    List<MDB0101KosuCostInput> findAllByDirectlyFirstTime(MDB0101KosuCostInput input);

    /**
     * 条件によって、テーブル＜工数データ＞＜社員＞＜部門マスタ＞の情報を取得する。
     *
     * @param input MDB0101DeptPersonalKosuInput
     * @return データ情報
     */
    List<MDB0101DeptPersonalKosuInput> findAllByDeptPersonalKosuNormal(MDB0101DeptPersonalKosuInput input);

    /**
     * 条件によって、テーブル＜工数振替＞＜社員＞＜部門マスタ＞の情報を取得する。
     *
     * @param input MDB0101DeptPersonalKosuInput
     * @return データ情報
     */
    List<MDB0101DeptPersonalKosuInput> findAllByDeptPersonalKosuFormer(MDB0101DeptPersonalKosuInput input);

    /**
     * 条件によって、テーブル＜工数振替＞＜社員＞＜部門マスタ＞の情報を取得する。
     *
     * @param input MDB0101DeptPersonalKosuInput
     * @return データ情報
     */
    List<MDB0101DeptPersonalKosuInput> findAllByDeptPersonalKosuAhead(MDB0101DeptPersonalKosuInput input);

    /**
     * テーブル＜【TEMP】工数金額＞に登録する。
     *
     * @param output MDB0101KosuCostOutput
     * @return
     */
    void createKosuCost(MDB0101KosuCostOutput output);

    /**
     * テーブル＜【TEMP】部門別社員工数＞に登録する。
     *
     * @param output MDB0101DeptPersonalKosuOutput
     * @return
     */
    void createDeptPersonalKosu(MDB0101DeptPersonalKosuOutput output);

    /**
     * テーブル＜【TEMP】工数金額＞に削除する。
     *
     * @param output MDB0101KosuCostInput
     * @return
     */
    void deleteKosuCost(MDB0101KosuCostInput output);

    /**
     * テーブル＜【TEMP】工数金額＞に削除する。
     *
     * @param output MDB0101KosuCostInput
     * @return
     */
    void deleteKosuCostPerformance(MDB0101KosuCostInput output);

    /**
     * テーブル＜【TEMP】工数金額＞に削除する。
     *
     * @param output MDB0101KosuCostInput
     * @return
     */
    void deleteKosuCostPerformanceFirstTime(MDB0101KosuCostInput output);

    /**
     * テーブル＜【TEMP】部門別社員工数＞に削除する。
     *
     * @param output MDB0101DeptPersonalKosuInput
     * @return
     */
    void deleteDeptPersonalKosu(MDB0101DeptPersonalKosuInput output);


}