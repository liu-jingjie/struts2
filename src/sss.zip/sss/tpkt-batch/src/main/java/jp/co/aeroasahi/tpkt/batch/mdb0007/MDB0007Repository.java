package jp.co.aeroasahi.tpkt.batch.mdb0007;

import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 * ジョブについてテーブルに操作
 */
public interface MDB0007Repository {

    /**
     * テーブル＜ジョブ要求テーブル＞に登録する。
     *
     * @param input BatchJobRequestInput
     * @return
     */
    void create(BatchJobRequestInput batchJobRequestInput);

    /**
     * ジョブ名を指定し、1時間以内に更新されておりまだ終了していないjobの件数を取得する
     *
     * @param jobNames 検索対象のジョブ名のリスト
     * @param jobStartDateTimeStr システム時間
     *
     * @return ジョブ要求リスト
     */
    int countAllNotExecuted(@Param("jobNames") List<String> jobNames, @Param("jobStartDateTimeStr") String jobStartDateTimeStr);

    /**
     * 条件によって、テーブル＜ジョブ異常テーブル＞の情報を取得する
     *
     * @param executionIds ジョブ実行開始ID
     *
     * @return ジョブ異常リスト
     */
     List<BatchJobExecutionOutput> findByExecutionIds(@Param("executionIds") List<Integer> executionIds);

     /**
     * 条件によって、テーブルの情報を取得する
     *
     * @param executionIds ジョブ実行開始ID
      *
      * @return ジョブ要求リスト
      */
     List<BatchJobRequestOutput> findByJobNames(@Param("executionIds") List<Integer> executionIds);
}
