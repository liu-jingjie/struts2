package jp.co.aeroasahi.tpkt.batch.mdb0006;

import org.springframework.stereotype.Component;
import lombok.Getter;
import lombok.Setter;

@Component
@Setter
@Getter
public class BatchDataHolder {

    private boolean checkResult;

    private String systemDateTime;

    private int checkCount;

}
