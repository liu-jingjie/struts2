package jp.co.aeroasahi.tpkt.batch.mdb0402;

import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.validator.ValidationException;
import org.springframework.batch.item.validator.Validator;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.fw.CommonLog;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

@Component
@Scope("step")
public class MDB0402Tasklet implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0402Tasklet.class);

    @Inject
    MDB0402Repository mdb0402Repository;

    @Inject
    DateFactory dateFactory;

    @Inject
    Validator<MDB0402Output> validator;

    boolean isErrFlag = false;

    /** DateTimeFormatterのパターン yyyy-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    int insertCount = 0;
    int updateCount = 0;

    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        String systemDateTime = dateFactory.newDateTime().format(dtf);

        // ■発注データを設定
        List<MDB0402Output> outOrderDataItems = setOrderData(systemDateTime);

        // ■支払データ
        List<MDB0402Output> outPaymentDataItems = setPaymentData(systemDateTime);

        // ■未発注支払データ
        List<MDB0402Output> outUnorderPaymentDataItems = setUnorderPaymentData(systemDateTime);

        if (!isErrFlag) {

            if(outOrderDataItems.size() > 0 || outPaymentDataItems.size() >0 || outUnorderPaymentDataItems.size() >0) {
                mdb0402Repository.delete();
            }

            // ■発注データを登録
            isErrFlag = insertOrUpdateData(outOrderDataItems, true);

            // ■支払データ
            if (!isErrFlag) {
                isErrFlag = insertOrUpdateData(outPaymentDataItems, false);
            }

            // ■未発注支払データ
            if (!isErrFlag) {
                isErrFlag = insertOrUpdateData(outUnorderPaymentDataItems, true);
            }
        }

        if (isErrFlag) {
            throw new RuntimeException("mdb0402外注情報取込処理実行に異常が発生しました。");
        } else {
            CommonLog.setInsertRecordeCountLog(logger, "【TEMP】外注情報(temp_md_outsourcing)", insertCount);
            CommonLog.setUpdateRecordeCountLog(logger, "【TEMP】外注情報(temp_md_outsourcing)", updateCount);
        }

        return RepeatStatus.FINISHED;
    }

    private boolean insertOrUpdateData(List<MDB0402Output> outItems, boolean insertFlag) {

        boolean isErrFlag = false;

        for (int i = 0; i < outItems.size(); i++) {
            try {
                validator.validate(outItems.get(i));
            } catch (ValidationException e) {
                isErrFlag = true;
                CommonLog.setFromDbErrorLog(logger, e, "【TEMP】外注情報(temp_md_outsourcing)");
            }
        }

        if (!isErrFlag) {

            List<MDB0402Output> insertRecordList = new ArrayList<MDB0402Output>();
            List<MDB0402Output> updateRecordList = new ArrayList<MDB0402Output>();

            for (MDB0402Output mdb0402Output : outItems) {

                // 更新
                if (!insertFlag) {
                    updateRecordList.add(mdb0402Output);
                    updateCount ++;
                    // 登録
                } else {
                    insertRecordList.add(mdb0402Output);
                    insertCount ++;
                }
            }

            // 【TEMP】外注情報のデータを更新する
            if (updateRecordList.size() > 0) {
                for (MDB0402Output output : updateRecordList) {
                    mdb0402Repository.update(output);
                }
            }

            // 【TEMP】外注情報のデータを登録する
            if (insertRecordList.size() > 0) {
                for (MDB0402Output output : insertRecordList) {
                    mdb0402Repository.create(output);
                }
            }

        } else {
            logger.error("登録データでエラーが発生しました。");
        }

        return isErrFlag;
    }

    private List<MDB0402Output> setPaymentData(String systemDateTime) {

        List<MDB0402Output> detailList = mdb0402Repository.findAllByPayment();

        for (MDB0402Output mdb0402Output : detailList) {

            /** 外注費（一般）支払ベース */
            mdb0402Output.setOutsidePaidCost(getBD(mdb0402Output.getOutsidePaidCost()));

            /** 外注費（関係）支払ベース */
            mdb0402Output.setGroupPaidCost(getBD(mdb0402Output.getGroupPaidCost()));

            /** 業務委託費支払ベース */
            mdb0402Output.setWorkOutsourcingPaidCost(getBD(mdb0402Output.getWorkOutsourcingPaidCost()));

            /** 更新日 */
            mdb0402Output.setUpdatedAt(systemDateTime);
        }

        return detailList;
    }

    private List<MDB0402Output> setOrderData(String systemDateTime) {

        List<MDB0402Output> detailList = mdb0402Repository.findAllByOrder();

        for (MDB0402Output mdb0402Output : detailList) {

            /** 外注費（一般）発生ベース */
            mdb0402Output.setOutsideOrderedCost(getBD(mdb0402Output.getOutsideOrderedCost()));

            /** 外注費（関係）発注ベース */
            mdb0402Output.setGroupOrderedCost(getBD(mdb0402Output.getGroupOrderedCost()));

            /** 外注費（一般）支払ベース */
            mdb0402Output.setOutsidePaidCost(getBD(mdb0402Output.getOutsidePaidCost()));

            /** 外注費（関係）支払ベース */
            mdb0402Output.setGroupPaidCost(getBD(mdb0402Output.getGroupPaidCost()));

            /** 業務委託費発注ベース */
            mdb0402Output.setWorkOutsourcingOrderedCost(getBD(mdb0402Output.getWorkOutsourcingOrderedCost()));

            /** 業務委託費支払ベース */
            mdb0402Output.setWorkOutsourcingPaidCost(getBD(mdb0402Output.getWorkOutsourcingPaidCost()));

            /** 作成日 */
            mdb0402Output.setCreatedAt(systemDateTime);

            /** 更新日 */
            mdb0402Output.setUpdatedAt(systemDateTime);
        }

        return detailList;
    }

    private List<MDB0402Output> setUnorderPaymentData(String systemDateTime) {

        List<MDB0402Output> detailList = mdb0402Repository.findAllByUnorderPayment();

        for (MDB0402Output mdb0402Output : detailList) {

            /** 外注費（一般）発生ベース */
            mdb0402Output.setOutsideOrderedCost(getBD(mdb0402Output.getOutsideOrderedCost()));

            /** 外注費（関係）発注ベース */
            mdb0402Output.setGroupOrderedCost(getBD(mdb0402Output.getGroupOrderedCost()));

            /** 外注費（一般）支払ベース */
            mdb0402Output.setOutsidePaidCost(getBD(mdb0402Output.getOutsidePaidCost()));

            /** 外注費（関係）支払ベース */
            mdb0402Output.setGroupPaidCost(getBD(mdb0402Output.getGroupPaidCost()));

            /** 業務委託費発注ベース */
            mdb0402Output.setWorkOutsourcingOrderedCost(getBD(mdb0402Output.getWorkOutsourcingOrderedCost()));

            /** 業務委託費支払ベース */
            mdb0402Output.setWorkOutsourcingPaidCost(getBD(mdb0402Output.getWorkOutsourcingPaidCost()));

            /** 作成日 */
            mdb0402Output.setCreatedAt(systemDateTime);

            /** 更新日 */
            mdb0402Output.setUpdatedAt(systemDateTime);
        }

        return detailList;
    }

    private BigDecimal getBD(BigDecimal input) {
        return null == input?new BigDecimal("0"):input;
    }

}
