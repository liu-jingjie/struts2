package jp.co.aeroasahi.tpkt.batch.mdb0203;

import java.util.List;

/**
 * テーブル＜テーブル＜SAPプロジェクト属性＞＜SAP受注＞＜汎用マスタ＞＜ビジネスユニットコード変換＞に操作
 */
public interface MDB0203Repository {

    /**
     * 全てのテーブル＜SAPプロジェクト＞＜汎用マスタ＞＜【TEMP】受注＞＜【TEMP】売上＞情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0203Input> findAll();

    /**
     * 条件によって、テーブル＜【TEMP】受注＞情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0203Input> findAllReceive();

    /**
     * 条件によって、テーブル＜【TEMP】売上＞情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0203Input> findAllSoldAmount();

    /**
     * 【TEMP】プロジェクト情報を取得する。
     *
     * @return 【TEMP】プロジェクト情報
     */
    List<MDB0203Output> findAllByTempProject();

    /**
     * 年度によって、【TEMP】プロジェクト情報を取得する。
     *
     * @return 【TEMP】プロジェクト情報
     */
    List<MDB0203Output> findAllByTempProjectFiscal(MDB0203Output input);

    /**
     * テーブル＜【TEMP】プロジェクト＞に登録する。
     *
     * @param output MDB0203Output
     * @return
     */
    void create(MDB0203Output output);

    /**
     * テーブル＜【TEMP】プロジェクト＞に更新する。
     *
     * @param output MDB0203Output
     * @return
     */
    void update(MDB0203Output output);

    /**
     * 年度によって、テーブル＜【TEMP】プロジェクト＞に売上予定日を更新する。
     *
     * @param output MDB0203Output
     * @return
     */
    void updateTempProjectFiscal(MDB0203Output output);



}
