package jp.co.aeroasahi.tpkt.batch.mdb0004;

import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜ジョブ要求テーブル＞のOutputBean。
 */
@Setter
@Getter
public class BatchJobRequestOutput {

    /** ジョブ実行ID */
    private int jobExecutionId;

    /** ポーリング状態 */
    private String pollingStatus;

}
