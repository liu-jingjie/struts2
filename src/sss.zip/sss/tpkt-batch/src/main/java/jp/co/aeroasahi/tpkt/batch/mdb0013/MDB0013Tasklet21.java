package jp.co.aeroasahi.tpkt.batch.mdb0013;

import java.time.format.DateTimeFormatter;
import javax.inject.Inject;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

/**
 * 各ジョブを実行するTasklet
 */
@Component
@Scope("step")
public class MDB0013Tasklet21 implements Tasklet {

    @Inject
    DateFactory dateFactory;

    @Inject
    MDB0013Repository mdb0013Repository;

    @Autowired
    private BatchDataHolder batchDataHolder;

    /** ■対象年月 */
    @Value("#{jobParameters['ym']}")
    String ym;

    /** DateTimeFormatterのパターン uuuu-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.SSS");

    /**
     *
     * マインバッチ処理
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return 一括で各ジョブを実行した状態
     */
    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

        String systemDateTime = dateFactory.newDateTime().format(dtf);

        // 実施時間
        batchDataHolder.setJobStartDateTime(systemDateTime);

        // 人件費取込
        executeJob("mdb0501Job", systemDateTime);

        return RepeatStatus.FINISHED;
    }

    /**
     * ジョブ実行処理
     *
     * @return 無し
     */
    private void executeJob(String jobName, String systemDateTime) {

        BatchJobRequestInput input = new BatchJobRequestInput();

        input.setJobName(jobName);
        input.setJobParameter(getParameter(systemDateTime));
        input.setPriority(1);
        input.setPollingStatus("INIT");
        input.setCreateDate(systemDateTime);

        mdb0013Repository.create(input);
    }

    private String getParameter(String systemDateTime) {
        return "jobId=mdb0013Job,kbn=M,yyyymm=" + ym + ",systemDateTime=" + systemDateTime;
    }
}
