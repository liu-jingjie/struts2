package jp.co.aeroasahi.tpkt.batch.mdb0013;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Locale;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

@Service
public class MDB0013SharedServiceImpl {

    private static final Logger logger = LoggerFactory.getLogger(MDB0013SharedServiceImpl.class);

    @Inject
    DateFactory dateFactory;

    @Inject
    MessageSource messageSource;

    @Inject
    MDB0013Repository mdb0013Repository;

    /** タイムアウト_分 */
    @Value("${main.timeout.minute}")
    long timeoutMinute;

    /**
     * 実行結果確認
     * <p>
     * ジョブバッチ開始以降に実行された指定したジョブの結果を確認する
     * 異常があった場合は例外をスローし、メインバッチを異常終了させる
     * </p>
     *
     * @param targetJobId チェック対象のジョブID(テーブル定義的にはjobName)
     * @param jobStartDateTimeStr ジョブの実行開始日時
     * @param jobNum ジョブ番号
     * @throws InterruptedException スレッドスリープの際に異常があった場合(基本的に発生しないはず)
     */
    public void checkExecuteResult(String targetJobId, String jobStartDateTimeStr)
            throws InterruptedException {

        LocalDateTime stepStartDateTime = dateFactory.newDateTime();
        String[] params = {targetJobId, getJobName(targetJobId)};

        while (true) {

            // 5秒待機
            Thread.sleep(5000);

            // メインjobの起動時間を条件に検索し、まだ終了していないjob件数を取得する
            int notExecutedJobCount = mdb0013Repository.countNotExecuted(targetJobId, jobStartDateTimeStr);

            // countが0 = 終了
            if (notExecutedJobCount == 0) {
                // 結果が完了以外のジョブの件数を取得
                int notCompletedJobCount = mdb0013Repository.countNotCompleted(targetJobId, jobStartDateTimeStr);

                // countが0 = ステータスが完了 = 異常なし
                if (notCompletedJobCount == 0) {
                    return;
                } else {
                    // 異常があった場合は例外をスローする(fwが本体からtempへの書き込みを実行するtaskletを呼び出す)
                    logger.error(messageSource.getMessage("e.bat.fw.004", params, Locale.getDefault()));
                    throw new RuntimeException();
                }
            }

            LocalDateTime systemDateTime = dateFactory.newDateTime();
            if (systemDateTime.isAfter(stepStartDateTime.plusMinutes(timeoutMinute))) {
                // このjobの起動から指定時間を経過している場合はエラーとする
                logger.error(messageSource.getMessage("e.bat.fw.005", params, Locale.getDefault()));
                throw new RuntimeException();
            }
        }
    }


    private String getJobName(String jobId) {
        return messageSource.getMessage(jobId, null, Locale.getDefault());
    }

    /**
     * 実行結果確認
     * <p>
     * ジョブ開始以降に実行された指定したジョブの結果を確認する
     * 異常があった場合は例外をスローし、メインバッチを異常終了させる
     * </p>
     *
     * @param targetJobIds チェック対象のジョブID(テーブル定義的にはjobName)
     * @param jobStartDateTimeStr ジョブの実行開始日時
     * @param jobNum ジョブ番号
     * @throws InterruptedException スレッドスリープの際に異常があった場合(基本的に発生しないはず)
     */
    public void checkAllExecuteResult(List<String> targetJobIds, String jobStartDateTimeStr)
            throws InterruptedException {

        LocalDateTime stepStartDateTime = dateFactory.newDateTime();

        while (true) {

            // 5秒待機
            Thread.sleep(5000);

            // jobの起動時間を条件に検索し、まだ終了していない処理の件数を取得する
            int notExecutedJobCount = mdb0013Repository.countAllNotExecuted(targetJobIds, jobStartDateTimeStr);

            // countが0 = 終了
            if (notExecutedJobCount == 0) {
                // 結果が完了以外の処理の件数を取得
                int notCompletedJobCount = mdb0013Repository.countNotAllCompleted(targetJobIds, jobStartDateTimeStr);

                // countが0 = 全てのステータスが完了 = 異常なし
                if (notCompletedJobCount == 0) {
                    return;
                } else {
                    // 異常があった場合は例外をスローする
                    logger.error(messageSource.getMessage("e.bat.fw.006", null, Locale.getDefault()));
                    throw new RuntimeException();
                }
            }

            LocalDateTime systemDateTime = dateFactory.newDateTime();
            if (systemDateTime.isAfter(stepStartDateTime.plusMinutes(timeoutMinute))) {
                // このjobの起動から指定時間を経過している場合はエラーとする
                logger.error(messageSource.getMessage("e.bat.fw.007", null, Locale.getDefault()));
                throw new RuntimeException();
            }
        }
    }
}
