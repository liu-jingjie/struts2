package jp.co.aeroasahi.tpkt.batch.fwb0103;

/**
 * テーブル＜【TEMP】SAPプロジェクト属性＞に操作
 */
public interface FWB0103Repository {

    /**
     * テーブル＜SAPプロジェクト属性＞に登録する。
     *
     * @param output FWB0103Output
     * @return
     */
    void create(FWB0103Output output);

    /**
     * テーブル＜SAPプロジェクト属性＞に削除する。
     *
     * @param output FWB0103Output
     * @return
     */
    void delete(FWB0103Output output);
}
