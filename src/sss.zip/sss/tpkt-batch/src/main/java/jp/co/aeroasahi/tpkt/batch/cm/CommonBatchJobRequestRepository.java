package jp.co.aeroasahi.tpkt.batch.cm;

import org.terasoluna.batch.async.db.repository.BatchJobRequestRepository;

public interface CommonBatchJobRequestRepository extends BatchJobRequestRepository {
}
