package jp.co.aeroasahi.tpkt.batch.mdb0003.job2;

import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.mdb0003.BatchDataHolder;
import jp.co.aeroasahi.tpkt.batch.mdb0003.BatchJobRequestInput;
import jp.co.aeroasahi.tpkt.batch.mdb0003.MDB0003Repository;

/**
 * 人件費取込の実行を要求するTasklet
 */
@Component
@Scope("step")
public class MDB0003Tasklet121 implements Tasklet {

    /** メインバッチジョブID */
    private static final String JOB_ID = "mdb0003Job";

    /** 人件費取込ジョブ名 */
    private static final String MAN_HOUR_JOB_NAME = "mdb0501Job";

    @Inject
    MDB0003Repository mdb0003Repository;

    @Autowired
    private BatchDataHolder batchDataHolder;

    // 日次処理の場合は「D」、月次確定処理の場合は「M」
    @Value("#{jobParameters['shorikbn']}")
    public String shorikbn;

    // 処理年月：日次処理の場合は空白を設定、バッチ実行画面の指定した月次確定対象年月を「YYYYMM」形式
    @Value("#{jobParameters['ym']}")
    public String ym;

    /**
     *
     * 人件費取込の実行を要求する
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return ステータス
     */
    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

        String jobStartDateTime = batchDataHolder.getJobStartDateTime();

        BatchJobRequestInput input = new BatchJobRequestInput();

        input.setJobName(MAN_HOUR_JOB_NAME);
        input.setJobParameter(getParameter(jobStartDateTime));
        input.setPriority(1);
        input.setPollingStatus("INIT");
        input.setCreateDate(jobStartDateTime);

        mdb0003Repository.create(input);

        return RepeatStatus.FINISHED;
    }

    private String getParameter(String systemDateTime) {

        String tempYyyyMm = shorikbn.equals("D") ? "" : ym;

        List<String> params = new ArrayList<>();
        params.add("kbn=" + shorikbn);
        params.add("yyyymm=" + tempYyyyMm);
        params.add("systemDateTime=" + systemDateTime);
        params.add("jobId=" + JOB_ID);

        return String.join(",", params);
    }
}
