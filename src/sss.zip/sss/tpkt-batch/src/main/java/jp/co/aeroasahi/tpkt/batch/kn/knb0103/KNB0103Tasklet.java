package jp.co.aeroasahi.tpkt.batch.kn.knb0103;

import java.io.File;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import javax.inject.Inject;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

/**
 *
 * 勤怠データ削除バッチ
 * <p>
 * 過去に取り込んだ勤怠情報ファイルおよびログファイルのうち、保存日数期間を超える日付のファイルを削除する
 * </p>
 *
 */
@Component
@Transactional
@Scope("step")
public class KNB0103Tasklet implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(KNB0103Tasklet.class);

    @Inject
    DateFactory dateFactory;

    /** DateTimeFormatterのパターン yyyyMMdd */
    private static final DateTimeFormatter dtfYyyyMMdd = DateTimeFormatter.ofPattern("yyyyMMdd");

    /** DateTimeFormatterのパターン yyyyMMddHHmmss */
    private static final DateTimeFormatter dtfYyyyMMddHHmmss = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

    /** コピー先フォルダ CSV */
    @Value("${local.destination.csv.path}")
    String destinationFolderCSV;

    /** コピー先フォルダ LOG */
    @Value("${local.destination.log.path}")
    String destinationFolderLOG;

    @Value("${file.save.period.day}")
    int fileSavePeriodDay;

    /** 想定ファイルサフィックス */
    private static final String CSV = "csv";

    /** 想定ファイルサフィックス */
    private static final String LOG = "log";

    // 各処理の実行結果（true：正常、false：異常）
    boolean processCheckFlag = true;

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        LocalDateTime systemDateTime = dateFactory.newDateTime();
        String systemYMD = systemDateTime.format(dtfYyyyMMdd);
        String systemTime = systemDateTime.format(dtfYyyyMMddHHmmss);


        ArrayList<String> logFiles = getFileList(systemYMD, systemTime, LOG);

        for (String file : logFiles) {
            processCheckFlag = deleteFile(destinationFolderLOG, file);

            if(processCheckFlag) {
                logger.info("ファイル削除完了;ファイル名={}", file);
            }else {
                logger.error("ファイル削除失敗しました。;ファイル名={}", file);
                break;
            }
        }

        if(processCheckFlag) {

            ArrayList<String> csvFiles = getFileList(systemYMD, systemTime, CSV);
            for (String file : csvFiles) {

                processCheckFlag = deleteFile(destinationFolderCSV, file);

                if(processCheckFlag) {
                    logger.info("ファイル削除完了;ファイル名={}", file);
                }else {
                    logger.error("ファイル削除失敗しました。;ファイル名={}", file);
                    break;
                }
            }
        }

        if (processCheckFlag) {

            logger.info("処理結果:正常終了");
        } else {

            logger.error("処理結果:異常終了");
        }

        return RepeatStatus.FINISHED;
    }

    private String getYMD(String input) {

        String rtn = "";
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMdd");
        int year = Integer.parseInt(input.substring(0, 4));
        int month = Integer.parseInt(input.substring(4, 6));
        int day = Integer.parseInt(input.substring(6, 8));

        LocalDate ld = LocalDate.of(year, month, day);
        rtn = ld.minusDays(fileSavePeriodDay).format(dtf);
        return rtn;
    }

    private long getYMDTime(String input) {

        String rtn = "";
        rtn = getYMD(input.substring(0, 8)) + input.substring(8, 14);
        return  Long.parseLong(rtn);
    }

    private ArrayList<String> getFileList(String systemYMD, String systemTime, String type) {

        ArrayList<String> rtn = new ArrayList<String>();

        String[] fileNames = {};

        int checkSystemYMD = Integer.parseInt(getYMD(systemYMD));

        long checkSystemYMDTime = getYMDTime(systemTime);

        if (type.equals(CSV)) {
            fileNames =  getFileName(destinationFolderCSV);
        }else if (type.equals(LOG)) {
            fileNames =  getFileName(destinationFolderLOG);
        }

        for (String name : fileNames) {

            if (type.equals(CSV)) {
                if (name.length() >= 15 && name.substring(name.length() - 3, name.length()).equals(CSV) && Integer.parseInt(name.substring(0,8)) <= checkSystemYMD) {
                    rtn.add(name);
                }
            }else if (type.equals(LOG)){
                if (name.length() == 21 && name.substring(name.length() - 3, name.length()).equals(LOG) && Long.parseLong(name.substring(0,14)) <= checkSystemYMDTime) {
                    rtn.add(name);
                }
            }
        }

        return rtn;
    }

    private String[] getFileName(String path) {
        File file = new File(path);
        String[] fileName = file.list();
        return fileName;
    }

    private boolean deleteFile(String path, String fileName) {

        boolean rtn = false;

        File target = new File(path + fileName);

        rtn = FileUtils.deleteQuietly(target);

        return rtn;
    }
}
