package jp.co.aeroasahi.tpkt.batch.mdb0005;

import org.springframework.stereotype.Component;
import lombok.Getter;
import lombok.Setter;

@Component
@Setter
@Getter
public class BatchDataHolder {

    private boolean checkResult1;

    private boolean checkResult2;

    private boolean checkResult3;

    private boolean checkSkip1;

    private boolean checkSkip2;

    private String systemDateTime;

}
