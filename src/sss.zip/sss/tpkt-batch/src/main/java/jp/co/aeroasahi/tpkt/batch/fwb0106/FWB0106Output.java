package jp.co.aeroasahi.tpkt.batch.fwb0106;

import java.math.BigDecimal;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.batch.item.ItemCountAware;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】SAP勘定残高＞のOutputBean。
 */
@Setter
@Getter
public class FWB0106Output implements ItemCountAware {

    private int count;

    /** 予算フラグ */
    @NotBlank
    @Size(min = 1, max = 1)
    private String RRCTY;

    /** 予算種別 */
    @NotBlank
    @Size(min = 1, max = 3)
    private String RVERS;

    /** 会計年度 */
    @NotBlank
    @Size(min = 1, max = 4)
    private String GJAHR;

    /** 会計期間 */
    @NotBlank
    @Size(min = 1, max = 2)
    private String MONAT;

    /** 勘定コード */
    @NotBlank
    @Size(min = 1, max = 8)
    private String RACCT;

    /** 会社コード */
    @NotBlank
    @Size(min = 1, max = 2)
    private String RBUKRS;

    /** 部門 */
    @NotBlank
    @Size(min = 1, max = 6)
    private String PRCTR;

    /** プロジェクトID */
    @NotBlank
    @Size(min = 1, max = 12)
    private String PROJK;

    /** 商品 */
    @NotBlank
    @Size(min = 1, max = 2)
    private String PRODUCT;

    /** 空情工程CD */
    @NotBlank
    @Size(min = 1, max = 5)
    private String PROGRESSCD;

    /** 金額 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal HSLXX;

    /** 作成日 */
    @Size(min = 23, max = 23)
    private String INS_DT;

    /** 更新日 */
    @Size(min = 23, max = 23)
    private String UPD_DT;

    @Override
    public void setItemCount(int count) {
        this.count = count;
    }

    /**
     * 予算フラグと予算種別と会計年度と会計期間と勘定コードと会社コードと部門とプロジェクトIDと商品と空情工程CDを結合する
     * @return
     */
    public String concat() {
        return RRCTY + "," + RVERS + "," + GJAHR + "," + MONAT + "," + RACCT + "," + RBUKRS + "," + PRCTR + "," + PROJK + "," + PRODUCT + "," + PROGRESSCD;
    }
}
