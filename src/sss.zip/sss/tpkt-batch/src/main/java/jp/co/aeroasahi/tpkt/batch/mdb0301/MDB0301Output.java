package jp.co.aeroasahi.tpkt.batch.mdb0301;

import javax.validation.constraints.Size;
import org.springframework.batch.item.ItemCountAware;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】金額＞のOutputBean。
 */
@Setter
@Getter
public class MDB0301Output implements ItemCountAware {

    private int count;

    /** 年月 当月*/
    @Size(min = 6, max = 6)
    private String ym1;

    /** 年月 前月或は指定した月次確定対象年月*/
    @Size(min = 6, max = 6)
    private String ym2;

    @Override
    public void setItemCount(int count) {
        this.count = count;
    }
}
