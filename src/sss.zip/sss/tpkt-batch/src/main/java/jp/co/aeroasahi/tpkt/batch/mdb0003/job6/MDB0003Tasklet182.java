package jp.co.aeroasahi.tpkt.batch.mdb0003.job6;

import java.util.Locale;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import jp.co.aeroasahi.tpkt.batch.mdb0003.BatchDataHolder;
import jp.co.aeroasahi.tpkt.batch.mdb0003.MDB0003SharedServiceImpl;

/**
 * 支払処理日反映の実行結果を確認するTasklet
 */
@Component
@Scope("step")
public class MDB0003Tasklet182 implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0003Tasklet182.class);

    /** 支払処理日反映ジョブ名 */
    private static final String PREPARE_JOB_NAME = "ojb0301Job";

    /** ジョブ番号 */
    private static final int TARGET_JOB_NUMBER = 6;

    @Autowired
    private BatchDataHolder batchDataHolder;

    @Inject
    MDB0003SharedServiceImpl mdb0003SharedService;

    @Inject
    MessageSource messageSource;

    /**
     *
     * 支払処理日反映の実行結果を確認する
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return ステータス
     * @throws InterruptedException スレッドスリープの際に異常があった場合(基本的に発生しないはず)
     */
    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws InterruptedException {

        String jobStartDateTime = batchDataHolder.getJobStartDateTime();

        // 処理の終了まで待つ (規定時間を待っても終わらない or 異常終了していた場合は例外をスロー)
        mdb0003SharedService.checkExecuteResult(PREPARE_JOB_NAME, jobStartDateTime, TARGET_JOB_NUMBER);

        logger.info(messageSource.getMessage("i.bat.fw.003", null, Locale.getDefault()));

        return RepeatStatus.FINISHED;
    }
}
