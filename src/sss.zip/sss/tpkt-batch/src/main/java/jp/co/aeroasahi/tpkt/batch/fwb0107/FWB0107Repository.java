package jp.co.aeroasahi.tpkt.batch.fwb0107;

/**
 * テーブル＜【TEMP】SAP仕掛原価＞に操作
 */
public interface FWB0107Repository {

    /**
     * テーブル＜【TEMP】SAP仕掛原価＞に登録する。
     *
     * @param output FWB0107Output
     * @return
     */
    void create(FWB0107Output output);

    /**
     * テーブル＜【TEMP】SAP仕掛原価＞に更新する。
     *
     * @param output FWB0107Output
     * @return
     */
    void delete(FWB0107Output output);
}
