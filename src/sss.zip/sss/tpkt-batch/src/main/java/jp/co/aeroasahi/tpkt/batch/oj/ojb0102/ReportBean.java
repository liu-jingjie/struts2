package jp.co.aeroasahi.tpkt.batch.oj.ojb0102;

import lombok.Getter;
import lombok.Setter;


/**
 * 帳票のOutputBean.
 * <p>
 * 帳票のOutputBean.
 * </p>
 */

@Getter
@Setter
public class ReportBean {
    /**
     * 応受援帳票種別.
     */
    private String ojuenDocType;
    /**
     * 応受援帳票名称.
     */
    private String ojuenDocName;
}
