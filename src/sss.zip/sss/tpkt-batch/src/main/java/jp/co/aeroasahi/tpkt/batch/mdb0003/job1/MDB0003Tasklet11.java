package jp.co.aeroasahi.tpkt.batch.mdb0003.job1;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import javax.inject.Inject;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.mdb0003.BatchDataHolder;
import jp.co.aeroasahi.tpkt.batch.mdb0003.BatchJobRequestInput;
import jp.co.aeroasahi.tpkt.batch.mdb0003.MDB0003Repository;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

/**
 * 日次、月次バッチ起動可能チェック処理、発注書番号取込起動要求をするTasklet
 */
@Component
@Scope("step")
public class MDB0003Tasklet11 implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0003Tasklet11.class);

    private static final int MAX_JOB_NUM = 6;

    /** メインバッチジョブID */
    private static final String JOB_ID = "mdb0003Job";

    // SAP取込
    private static final String SAP_CUSTMER_JOB_NAME = "fwb0101Job";
    private static final String SAP_VENDOR_JOB_NAME = "fwb0102Job";
    private static final String SAP_PROJECT_ATTRIBUTE_JOB_NAME = "fwb0103Job";
    private static final String SAP_PROJECT_JOB_NAME = "fwb0104Job";
    private static final String SAP_ACCOUNT_DETAIL_JOB_NAME = "fwb0105Job";
    private static final String SAP_ACCOUNT_BALANCE_JOB_NAME = "fwb0106Job";
    private static final String SAP_INPROCESS_COST_JOB_NAME = "fwb0107Job";
    private static final String SAP_RECEIVE_ORDER_JOB_NAME = "fwb0108Job";
    private static final String SAP_ORDER_NO_JOB_NAME = "fwb0109Job";

    // 発注書番号取込
    private static final String ORDER_NUM_JOB_NAME = "ojb0201Job";

    // 中間操作
    private static final String KOSU_JOB_NAME = "mdb0101Job";
    private static final String RECIEVE_AND_SOLD_JOB_NAME = "mdb0201Job";
    private static final String PJ_ATTRIBUTE_JOB_NAME = "mdb0202Job";
    private static final String PJ_JOB_NAME = "mdb0203Job";
    private static final String CUSTOMER_JOB_NAME = "mdb0204Job";
    private static final String VENDOR_JOB_NAME = "mdb0205Job";
    private static final String ORDER_JOB_NAME = "mdb0401Job";
    private static final String OUTSOURCING_JOB_NAME = "mdb0402Job";
    private static final String DEPT_COST_JOB_NAME = "mdb0404Job";
    private static final String MAN_HOUR_JOB_NAME = "mdb0501Job";
    private static final String COST_JOB_NAME = "mdb0601Job";

    // 表示用テーブル
    private static final String DISP_PROPERTY_JOB_NAME = "mdb0801Job";
    private static final String DISP_OUTSOURCING_JOB_NAME = "mdb0802Job";
    private static final String DISP_DEPT_COST_JOB_NAME = "mdb0803Job";
    private static final String DISP_OPERATION_JOB_NAME = "mdb0804Job";

    // キューブデプロイ
    private static final String CUBE_DEPLOY_JOB_NAME = "mdb0901Job";

    // 実績反映
    private static final String SEKISAN_ACT_REGISTER_JOB_NAME = "sbb0201Job";
    private static final String PREPARE_JOB_NAME = "ojb0301Job";
    private static final String APPROVE_REMIND_JOB_NAME = "ojb0101Job";

    @Inject
    DateFactory dateFactory;

    @Inject
    MDB0003Repository mdb0003Repository;

    @Inject
    MessageSource messageSource;

    @Autowired
    private BatchDataHolder batchDataHolder;

    /** タイムアウト_分 */
    @Value("${sap.timeout.minute}")
    long sapTimeoutMinute;

    /** タイムアウト_分 */
    @Value("${daily.timeout.minute}")
    long timeoutMinute;

    @Value("#{jobParameters['jobNum']}")
    public String jobNum;

    // 日次処理の場合は「D」、月次確定処理の場合は「M」
    @Value("#{jobParameters['shorikbn']}")
    public String shorikbn;

    // 処理年月：日次処理の場合は空白を設定、バッチ実行画面の指定した月次確定対象年月を「YYYYMM」形式
    @Value("#{jobParameters['ym']}")
    public String ym;

    /** DateTimeFormatterのパターン uuuu-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.SSS");

    /**
     *
     * 日次、月次バッチ起動可能チェック処理、発注書番号取込起動処理
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return バッチ終了ステータス
     */
    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

        logger.info("起動パラメータ;処理区分={};処理年月={};リランジョブ番号={}", shorikbn, ym, jobNum);

        LocalDateTime systemDateTime = dateFactory.newDateTime();

        String systemDateTimeStr = systemDateTime.format(dtf);

        if (isAlreadyExecute(systemDateTime)) {
            // 既にメインバッチ（日次、月次確定）が起動している場合は例外をスローし、後続処理を実行しないようにする
            throw new RuntimeException("既にメインバッチ（日次、月次確定）が起動しているので、メインバッチ（日次、月次確定）処理を終了します。");
        }

        // jobNumが2以上の場合は、jobNum2の処理までスキップする
        if (isSkip()) {
            logger.info("リランジョブ番号が2以上であるため、発注書番号取込処理をスキップします。");
            contribution.setExitStatus(new ExitStatus("SKIP"));
            return RepeatStatus.FINISHED;
        }

        // メインバッチ（SAP取込）の処理が完了していない場合は、メインバッチ（SAP取込）処理が完了するまで待つ
        waitSAPEnd(systemDateTime);


        // 実施時間
        batchDataHolder.setJobStartDateTime(systemDateTimeStr);

        // 2以上のリランのjobNum指定が無い場合、応受援テーブル更新
        if (jobNum.equals("") || jobNum.equals("1")) {

            BatchJobRequestInput input = new BatchJobRequestInput();

            input.setJobName(ORDER_NUM_JOB_NAME);
            input.setJobParameter(getJobParameter(systemDateTimeStr));
            input.setPriority(1);
            input.setPollingStatus("INIT");
            input.setCreateDate(systemDateTimeStr);

            // 発注書番号取込実行要求
            mdb0003Repository.create(input);
        }

        return RepeatStatus.FINISHED;

    }

    // jobNumが2以上の場合はSAP取込をスキップする
    private boolean isSkip() {
        if (StringUtils.isNoneEmpty(jobNum)) {
            if (isExistJobNum()) {
                if (Integer.parseInt(jobNum) > 1) {
                    return true;
                }
            } else {
                Integer[] param = {Integer.parseInt(jobNum)};
                throw new RuntimeException(messageSource.getMessage("e.bat.fw.008", param, Locale.getDefault()));
            }
        }
        return false;
    }

    /**
     * 既にMDB0003が起動しているかをチェックする
     *
     * <p>
     * 対象のjobが3時間以内に更新し、かつ、終了していない処理がないかをチェックする
     * </p>
     *
     * @param systemDateTime タスク実行時間
     *
     * @return true:既に起動しているjobが存在する、false:全て実行完了している
     */
    private boolean isAlreadyExecute(LocalDateTime systemDateTime) {

        String targetDateTimeStr = systemDateTime.minusMinutes(timeoutMinute).format(dtf);
        List<String> jobNames = setJobNames();

        int notExecutedJobCount = mdb0003Repository.countAllNotExecuted(jobNames, targetDateTimeStr);
        if (notExecutedJobCount == 0) {
            return false;
        }
        return true;
    }

    private void waitSAPEnd(LocalDateTime systemDateTime) {

        LocalDateTime endDateTime = systemDateTime.plusMinutes(sapTimeoutMinute);
        String targetDateTimeStr = systemDateTime.minusMinutes(timeoutMinute).format(dtf);
        List<String> sapJobNames = setSAPJobNames();

        while (true) {
            try {
                Thread.sleep(10000);
            } catch (InterruptedException e) {
                logger.error("stackTrace：", e);
            }

            if (dateFactory.newDateTime().isAfter(endDateTime)) {
                // 例外をスローし、後続処理を実行しないようにする
                throw new RuntimeException("SAP取込処理が1時間待機しても終了しないため、本バッチを終了します。");
            }

            int notExecutedJobCount = mdb0003Repository.countAllNotExecuted(sapJobNames, targetDateTimeStr);
            if (notExecutedJobCount == 0) {
                return;

            }
            logger.info("まだSAP連携取込処理が終了していないため、10秒間待機します。");
        }

    }

    private List<String> setSAPJobNames() {
        List<String> resultList = new ArrayList<>();

        resultList.add(SAP_CUSTMER_JOB_NAME);
        resultList.add(SAP_VENDOR_JOB_NAME);
        resultList.add(SAP_PROJECT_ATTRIBUTE_JOB_NAME);
        resultList.add(SAP_PROJECT_JOB_NAME);
        resultList.add(SAP_ACCOUNT_DETAIL_JOB_NAME);
        resultList.add(SAP_ACCOUNT_BALANCE_JOB_NAME);
        resultList.add(SAP_INPROCESS_COST_JOB_NAME);
        resultList.add(SAP_RECEIVE_ORDER_JOB_NAME);
        resultList.add(SAP_ORDER_NO_JOB_NAME);

        return resultList;
    }

    private List<String> setJobNames() {
        List<String> resultList = new ArrayList<>();

        resultList.add(ORDER_NUM_JOB_NAME);
        resultList.add(KOSU_JOB_NAME);
        resultList.add(RECIEVE_AND_SOLD_JOB_NAME);
        resultList.add(PJ_ATTRIBUTE_JOB_NAME);
        resultList.add(PJ_JOB_NAME);
        resultList.add(CUSTOMER_JOB_NAME);
        resultList.add(VENDOR_JOB_NAME);
        resultList.add(ORDER_JOB_NAME);
        resultList.add(OUTSOURCING_JOB_NAME);
        resultList.add(DEPT_COST_JOB_NAME);
        resultList.add(MAN_HOUR_JOB_NAME);
        resultList.add(COST_JOB_NAME);

        resultList.add(DISP_PROPERTY_JOB_NAME);
        resultList.add(DISP_OUTSOURCING_JOB_NAME);
        resultList.add(DISP_DEPT_COST_JOB_NAME);
        resultList.add(DISP_OPERATION_JOB_NAME);

        resultList.add(CUBE_DEPLOY_JOB_NAME);

        resultList.add(SEKISAN_ACT_REGISTER_JOB_NAME);
        resultList.add(PREPARE_JOB_NAME);
        resultList.add(APPROVE_REMIND_JOB_NAME);

        return resultList;
    }

    private boolean isExistJobNum() {
        int target = Integer.parseInt(jobNum);
        // 引数が1～最大値の間である場合、true
        if (0 < target && target <= MAX_JOB_NUM) {
            return true;
        }
        return false;
    }

    private String getJobParameter(String systemDateTimeStr) {
        List<String> params = new ArrayList<>();
        params.add("systemDateTime=" + systemDateTimeStr);
        params.add("jobId=" + JOB_ID);
        return String.join(",", params);
    }
}

