package jp.co.aeroasahi.tpkt.batch.mdb0003;

import org.apache.ibatis.annotations.Param;

/**
 * 一時テーブルから本体テーブルにデータを登録する
 */
public interface MDB0003DataCopyRepository {

    int dataCopy(@Param("fromTable") String fromTable, @Param("toTable") String toTable);

    void dataCopy3(@Param("fromTable") String fromTable, @Param("toTable") String toTable, @Param("ym") String ym, @Param("specifiedMonth") String specifiedMonth);

    int dataCopy4(@Param("fromTable") String fromTable, @Param("toTable") String toTable);

    int dataCopy5(@Param("fromTable") String fromTable, @Param("toTable") String toTable);

    int dataCopy6(@Param("fromTable") String fromTable, @Param("toTable") String toTable, @Param("ym") String ym, @Param("ym1") String ym1, @Param("ym2") String ym2, @Param("specifiedMonth") String specifiedMonth);

    /**
     * テーブル＜部門別社員工数＞に登録する。
     *
     * @param
     * @return
     */
    void dataCopyMdDeptPersonalKosu();


    /**
     * テーブル＜受注＞に登録する。
     *
     * @param
     * @return
     */
    void dataCopyMdReceive();

    /**
     * テーブル＜売上＞に登録する。
     *
     * @param
     * @return
     */
    void dataCopyMdSoldAmount();

    /**
     * テーブル＜プロジェクト属性＞に登録する。
     *
     * @param
     * @return
     */
    void dataCopyProjectAttribute();

    /**
     * テーブル＜プロジェクト＞に登録する。
     *
     * @param
     * @return
     */
    void dataCopyProject();

    /**
     * テーブル＜顧客マスタ＞に登録する。
     *
     * @param
     * @return
     */
    void dataCopyMdMaCustomer();

    /**
     * テーブル＜委託先マスタ＞に登録する。
     *
     * @param
     * @return
     */
    void dataCopyOjMaVendor();

    /**
     * テーブル＜部門別経費＞に登録する。
     *
     * @param
     * @return
     */
    void dataCopyMdDeptCost(@Param("ym") String ym);

    /**
     * (指定月より)テーブル＜部門別経費＞に登録する。
     *
     * @param
     * @return
     */
    void dataCopyMdDeptCostBySpecifiedMonth(@Param("ym") String ym, @Param("specifiedMonth") String specifiedMonth);

    /**
     * テーブル＜【TEMP】部門別社員工数＞に登録する。
     *
     * @param
     * @return
     */
    void dataReverseCopyMdDeptPersonalKosu();


    /**
     * テーブル＜【TEMP】受注＞に登録する。
     *
     * @param
     * @return
     */
    void dataReverseCopyMdReceive();

    /**
     * テーブル＜【TEMP】売上＞に登録する。
     *
     * @param
     * @return
     */
    void dataReverseCopyMdSoldAmount();

    /**
     * テーブル＜【TEMP】プロジェクト属性＞に登録する。
     *
     * @param
     * @return
     */
    void dataReverseCopyProjectAttribute();

    /**
     * テーブル＜【TEMP】プロジェクト＞に登録する。
     *
     * @param
     * @return
     */
    void dataReverseCopyProject();

    /**
     * テーブル＜【TEMP】顧客マスタ＞に登録する。
     *
     * @param
     * @return
     */
    void dataReverseCopyMdMaCustomer();

    /**
     * テーブル＜【TEMP】委託先マスタ＞に登録する。
     *
     * @param
     * @return
     */
    void dataReverseCopyOjMaVendor();

    /**
     * テーブル＜【TEMP】部門別経費＞に登録する。
     *
     * @param
     * @return
     */
    void dataReverseCopyMdDeptCost(@Param("ym") String ym);

    /**
     * (指定月より)テーブル＜【TEMP】部門別経費＞に登録する。
     *
     * @param
     * @return
     */
    void dataReverseCopyMdDeptCostBySpecifiedMonth(@Param("ym") String ym, @Param("specifiedMonth") String specifiedMonth);

}
