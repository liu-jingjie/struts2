package jp.co.aeroasahi.tpkt.batch.mdb0003.job5;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.mdb0003.BatchDataHolder;
import jp.co.aeroasahi.tpkt.batch.mdb0003.BatchJobRequestInput;
import jp.co.aeroasahi.tpkt.batch.mdb0003.MDB0003Repository;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

/**
 * キューブデプロイの実行要求をするTasklet
 */
@Component
@Scope("step")
public class MDB0003Tasklet161 implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0003Tasklet161.class);

    /** メインバッチジョブID */
    private static final String JOB_ID = "mdb0003Job";

    /** キューブデプロイジョブ名 */
    private static final String CUBE_DEPLOY_JOB_NAME = "mdb0901Job";

    @Inject
    DateFactory dateFactory;

    @Inject
    MDB0003Repository mdb0003Repository;

    @Autowired
    private BatchDataHolder batchDataHolder;

    @Value("#{jobParameters['jobNum']}")
    public String jobNum;

    /** DateTimeFormatterのパターン uuuu-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.SSS");

    /**
     *
     * キューブデプロイの実行要求をする
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return ジョブステータス
     */
    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

        // jobNumが6以上の場合は、jobNum6の1ステップ目へスキップする
        if (isSkip()) {
            logger.info("リランジョブ番号が6以上であるため、キューブデプロイ処理をスキップします。");
            contribution.setExitStatus(new ExitStatus("SKIP"));
            return RepeatStatus.FINISHED;
        }

        // ジョブ番号単位でシステム日時を取得
        String jobStartDateTime = dateFactory.newDateTime().format(dtf);
        batchDataHolder.setJobStartDateTime(jobStartDateTime);

        BatchJobRequestInput input = new BatchJobRequestInput();

        input.setJobName(CUBE_DEPLOY_JOB_NAME);
        input.setJobParameter(getJobParameter(jobStartDateTime));
        input.setPriority(1);
        input.setPollingStatus("INIT");
        input.setCreateDate(jobStartDateTime);

        // バッチ実行要求
        mdb0003Repository.create(input);

        return RepeatStatus.FINISHED;
    }

    private boolean isSkip() {
        // jobNumが6以上の場合はスキップする
        if (StringUtils.isNoneEmpty(jobNum)) {
            if (Integer.parseInt(jobNum) > 5) {
                return true;
            }
        }
        return false;
    }

    private String getJobParameter(String systemDateTimeStr) {
        List<String> params = new ArrayList<>();
        params.add("systemDateTime=" + systemDateTimeStr);
        params.add("jobId=" + JOB_ID);
        return String.join(",", params);
    }
}
