package jp.co.aeroasahi.tpkt.batch.cm.monitoring.fbfw004;

import java.io.IOException;
import java.util.List;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.common.fw.mail.MailRequestSharedService;
import jp.co.aeroasahi.tpkt.common.fw.message.MessageSharedService;
import jp.co.aeroasahi.tpkt.common.fw.template.TemplateService;
import jp.co.aeroasahi.tpkt.common.model.fw.MailManagement;
import jp.co.aeroasahi.tpkt.common.repository.fw.BatchCompleteInfoRepository;
import jp.co.aeroasahi.tpkt.common.repository.fw.BatchJobRequestRepository;
import jp.co.aeroasahi.tpkt.common.util.DateUtil;

/**
 *
 * 監視処理
 *
 */
@Component
@Transactional
@Scope("step")
public class FBFW004Tasklet implements Tasklet {

    /** ロガー */
    private static final Logger logger = LoggerFactory.getLogger(FBFW004Tasklet.class);

    /** ジョブID */
    private static final String jobId = "fbfw004";

    /** メール件名 */
    private static final String MAIL_SUBJECT = "システムエラーが検出されました";

    /** テンプレートID */
    private static final String TEMPLATE_ID = "t_fw_001";

    /** 定時バッチから渡されるシステム日時 */
    @Value("#{jobParameters['dateTime']}")
    public String dateTime;

    /** web監視ログファイルパス */
    @Value("${monitoring.web.filepath}")
    String webLogFilepath;

    /** bat監視ログファイルパス */
    @Value("${monitoring.bat.filepath}")
    String batLogFilepath;

    /** 送信先メールアドレス(AACメーリス) */
    @Value("${address.mailinglist.aac}")
    String aacMailinglistAddress;

    // TODO メールアドレスの確定
    /** 送信先メールアドレス(USE保守チーム) */
    @Value("${address.use}")
    String useAddress;

    @Inject
    JavaMailSender mailSender;

    @Inject
    TemplateService templateService;

    @Inject
    BatchJobRequestRepository batchJobRequestRepository;

    @Inject
    MailRequestSharedService mailRequestSharedService;

    @Inject
    BatchCompleteInfoRepository batchCompleteInfoRepository;

    @Inject
    MessageSharedService messageService;

    /**
     * fbfw004
     * 監視処理
     * <p>
     * バッチ完了情報テーブルの完了日時以降に出力された監視ログの情報をメール本文に抽出し、メール送信する
     * </p>
     */
    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {
        String fromHour = Integer.toString(DateUtil.parseDateTime(dateTime).getHour());
        logger.info(messageService.getMessage("i.bat.cm.003", jobId, fromHour));

        // バッチ完了情報テーブルから最終完了日時を取得する
        String lastCompleteDateTime = batchCompleteInfoRepository.findMonitoringComplete();

        if (lastCompleteDateTime == null) {
            throw new RuntimeException("バッチ完了情報テーブルにレコードが存在しません。");
        }

        // ログ監視処理
        Monitor monitor = new Monitor(webLogFilepath, batLogFilepath);
        try {
            List<String> monitoringResult =
                    monitor.monitor(DateUtil.parseDateTime(lastCompleteDateTime.substring(0, 19)));

            // 監視結果が0件でない場合、メールを送信する
            if (monitoringResult.size() != 0) {
                // メールパラメータをDBに登録し、登録結果の連番を取得
                MailManagement mailManagement = createMailManagement(fromHour, monitoringResult);
                mailRequestSharedService.requestNoAttachmentMail(mailManagement);
            }

            // バッチ完了情報テーブルを更新する
            batchCompleteInfoRepository.updateMonitoringComplete(DateUtil.parseDateTime(dateTime));

            logger.info(messageService.getMessage("i.bat.cm.004", jobId, fromHour, monitoringResult.size()));
        } catch (IOException e) {
            // ファイルパスの誤り等の場合にcatchする想定
            logger.error(messageService.getMessage("e.bat.fw.003", jobId));
            throw new RuntimeException(e);
        }

        return RepeatStatus.FINISHED;
    }


    private MailManagement createMailManagement(String fromHour, List<String> errorList) {
        // メール管理情報を設定
        MailManagement mailManagement = new MailManagement();

        mailManagement.setMailAddressTo(aacMailinglistAddress);
        mailManagement.setMailAddressCc(useAddress);
        mailManagement.setSubject(MAIL_SUBJECT);
        mailManagement.setCreatedAt(dateTime);

        TemplateParam templateParam = createTemplateParam(fromHour, errorList);

        // メール本文をテンプレートを用いて作成する
        String body = templateService.create(TEMPLATE_ID, templateParam);
        mailManagement.setBody(body);

        return mailManagement;
    }

    private TemplateParam createTemplateParam(String fromHour, List<String> errorList) {
        // テンプレートに渡すパラメータを設定
        TemplateParam templateParam = new TemplateParam();

        templateParam.setFromHour(fromHour);
        templateParam.setErrorCount(Integer.toString(errorList.size()));
        templateParam.setErrorList(errorList);

        return templateParam;
    }
}
