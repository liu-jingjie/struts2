package jp.co.aeroasahi.tpkt.batch.mdb0201;

import java.math.BigDecimal;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.batch.item.ItemCountAware;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】売上＞のOutputBean。
 */
@Setter
@Getter
public class MDB0201SaleOutput implements ItemCountAware {

    private int count;

    /** ビジネスユニット */
    @Size(min = 0, max = 5)
    private String bu;

    /** 請求書伝票番号 */
    @NotBlank
    @Size(min = 1, max = 16)
    private String voucherNum;

    /** プロジェクト属性ID */
    @Size(min = 1, max = 8)
    private String pjAttId;

    /** プロジェクトID */
    @NotBlank
    @Size(min = 1, max = 12)
    private String pjId;

    /** 費目CD */
    @Size(min = 1, max = 2)
    private String himokuCd;

    /** 年月 */
    @NotBlank
    @Size(min = 1, max = 6)
    private String ym;

    /** 売上日 */
    @Size(min = 0, max = 10)
    private String soldOn;

    /** 売上額 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal soldAmount;

    /** 部門CD */
    @Size(min = 0, max = 6)
    private String deptCd;

    /** キャンセルフラグ */
    @Size(min = 1, max = 1)
    private String canceled;

    /** 作成日 */
    @Size(min = 0, max = 23)
    private String createdAt;

    /** 更新日 */
    @Size(min = 0, max = 23)
    private String updatedAt;

    /** 比較チェック用 */
    private String deleteFlag;

    @Override
    public void setItemCount(int count) {
        this.count = count;
    }
}
