package jp.co.aeroasahi.tpkt.batch.sbb0201;

import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

/**
 * 工数金額抽出Bean。
 */
@Setter
@Getter
public class SBB0201KosuCost {

    /** プロジェクトID */
    private String pjId;

    /** 工程CD */
    private String koteiCd;

    /** 費目CD */
    private String himokuCd;

    /** 代表リソースCD */
    private String distResourceCd;

    /** 実績積算区分 */
    private String resultPlanedKbn;

    /** 枝番 */
    private String branchNum;

    /** 並び順 */
    private Integer sortNum;

    /** 作業期間FROM */
    private String workFrom;

    /** 作業期間TO */
    private String workTo;

    /** 存在フラグ */
    private Integer isExists;

    /** 金額 */
    private BigDecimal price;

    /** 工数 */
    private BigDecimal kosu;

    /** 単位CD */
    private String unitCd;

}
