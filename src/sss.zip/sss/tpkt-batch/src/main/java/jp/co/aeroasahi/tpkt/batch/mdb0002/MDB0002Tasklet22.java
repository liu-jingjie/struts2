package jp.co.aeroasahi.tpkt.batch.mdb0002;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

/**
 * 滞留監視の実行結果を確認するTasklet
 */
@Component
@Scope("step")
public class MDB0002Tasklet22 implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0002Tasklet22.class);

    /** 滞留監視jobのジョブ名 ojb0403Job */
    private static final String RETENTION_JOB_NAME = "ojb0403Job";

    @Inject
    DateFactory dateFactory;

    @Inject
    MDB0002Repository mdb0002Repository;

    @Autowired
    private BatchDataHolder batchDataHolder;


    /**
     *
     * 滞留監視の実行結果を確認する
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return 一括で各ジョブを実行した状態
     */
    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        try {
            String jobStartDateTimeStr = batchDataHolder.getSystemDateTime();

            // ジョブが完了している場合
            if (checkJobCompleted(jobStartDateTimeStr)) {
                return RepeatStatus.FINISHED;
            }

        } catch (Exception e) {
            logger.error("処理結果:{}({})の実行時に、異常が発生しました。", "ojb0403Job", "滞留監視");
            logger.error("stackTrace：", e);
        }
        batchDataHolder.setCheckResult(false);
        return RepeatStatus.FINISHED;
    }

    /**
     * 各ジョブ実行結果をチェックする
     *
     * @param number ジョブ件数
     * @param systemDateTime タスク実行時間
     *
     * @return 各ジョブ実行結果をチェックする結果
     * @throws InterruptedException スレッドで割込みが発生した場合
     */
    private boolean checkJobCompleted(String jobStartDateTimeStr) throws InterruptedException {
        List<String> jobIds = new ArrayList<>();
        jobIds.add(RETENTION_JOB_NAME);
        LocalDateTime stepStartDateTime = dateFactory.newDateTime();
        while (true) {

            Thread.sleep(5000);

            // 滞留監視処理のjobの終了確認のために、メインjobの起動時間を条件に検索し、まだ終了していないjob件数を取得する
            int notExecutedJobCount = mdb0002Repository.countAllNotExecuted(jobIds, jobStartDateTimeStr);

            // countが0だった場合は全て終了したとみなす
            if (notExecutedJobCount == 0) {
                // 完了していないジョブの件数を取得し、0件だった場合は完了だったとみなす
                int notCompletedJobCount = mdb0002Repository.countAllNotCompleted(jobIds, jobStartDateTimeStr);
                if (notCompletedJobCount == 0) {
                    return true;
                }
                logger.info("滞留監視処理に異常がありました。");
                return false;
            }

            LocalDateTime systemDateTime = dateFactory.newDateTime();
            if (systemDateTime.isAfter(stepStartDateTime.plusMinutes(10))) {
                // 現在日時がこのstepの起動から10分以上経過している場合はエラーとする
                logger.info("滞留監視処理が10分経過しても終了しないため、待機を解除します。");
                return false;
            }
            // 現在日時がこのjobの起動から10分経過していない場合は5秒待機し、再度取込処理の終了確認を実施する
            logger.info("まだ滞留監視処理が終了していないため、5秒間待機します。");
        }
    }
}
