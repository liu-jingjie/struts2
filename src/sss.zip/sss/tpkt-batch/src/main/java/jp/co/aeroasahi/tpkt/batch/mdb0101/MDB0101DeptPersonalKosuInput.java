package jp.co.aeroasahi.tpkt.batch.mdb0101;

import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜工数データ＞＜工数振替＞＜社員＞＜部門マスタ＞のInputBean。
 */
@Setter
@Getter
public class MDB0101DeptPersonalKosuInput {

    /** 部門CD */
    private String deptCd;

    /** 年月 */
    private String ym;

    /** 社員区分 */
    private String empKbn;

    /** 社員CD */
    private String empCd;

    /** 合計工数 */
    private BigDecimal totalKosu;

    /** 作成日 */
    private String createdAt;

    /** 更新日 */
    private String updatedAt;

    /** 年月 検索用(当月)*/
    private String ym1;

    /** 年月 検索用(前月或は指定した月)*/
    private String ym2;

    /**
     * 部門CDと年月と社員区分と社員CDを結合する
     * @return
     */
    public String concat() {
        return deptCd + "," + ym + "," + empKbn + "," + empCd;
    }

}
