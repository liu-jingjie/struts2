package jp.co.aeroasahi.tpkt.batch.mdb0005;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

/**
 * 各ジョブを実行するTasklet
 */
@Component
@Scope("step")
public class MDB0005Tasklet21 implements Tasklet {

    @Inject
    DateFactory dateFactory;

    @Inject
    MDB0005Repository mdb0005Repository;

    @Autowired
    private BatchDataHolder batchDataHolder;

    /** DateTimeFormatterのパターン uuuu-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.SSS");

    /** ファイル連携時フォルダ */
    @Value("${sap.input.dirpath}")
    String sapInputDirpath;

    /** 発注番号のパス */
    private static final String ORDERNO = "OrderNo\\\\";

    /** ファイル連携時のファイル名 */
    private static final String SATP0010 = "SATP0010.txt";

    private static final Logger logger = LoggerFactory.getLogger(MDB0005Tasklet21.class);

    /**
     *
     * マインバッチ処理
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return 一括で各ジョブを実行した状態
     */
    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        LocalDateTime systemDateTime = dateFactory.newDateTime();
        String systemDateTimeStr = systemDateTime.format(dtf);

        batchDataHolder.setSystemDateTime(systemDateTimeStr);

        // SAPから連携された発注番号ファイルが存在しない場合
        if(!isExistFile(getFileName(sapInputDirpath + ORDERNO), SATP0010)) {

            // 後続処理は行わず、処理終了（正常終了）
            batchDataHolder.setCheckSkip2(true);
            logger.info("取込ファイルがないため処理をスキップしました。;ファイル名={};処理={}",SATP0010, sapInputDirpath + ORDERNO);

        // SAPから連携された発注番号ファイルが存在する場合
        }else {

            batchDataHolder.setCheckSkip2(false);

            // ファイル取込処理を実行する
            // 発注番号データ取込
            executeJob("fwb0109Job", "inputFile=" + sapInputDirpath + ORDERNO + SATP0010 + ",systemDateTime=" + systemDateTimeStr);
        }

        return RepeatStatus.FINISHED;
    }

    /**
     * ジョブ実行処理
     *
     * @return 無し
     */
    private void executeJob(String jobName, String jobParameter) throws Exception {

        BatchJobRequestInput input = new BatchJobRequestInput();

        input.setJobName(jobName);
        input.setJobParameter(jobParameter);
        input.setPriority(1);
        input.setPollingStatus("INIT");

        mdb0005Repository.create(input);
    }

    private String[] getFileName(String path) {
        File file = new File(path);
        String[] fileName = file.list();
        return fileName;
    }

    private boolean isExistFile(String[] fileNames, String checkStr) {

        // false:ファイルが無い、true：ファイルが有る
        boolean rtn = false;

        if (fileNames == null) {
            return false;
        }

        for (String name : fileNames) {

            if (name.length() >= 12 && name.substring(name.length() - 12, name.length()).equals(checkStr)) {
                rtn = true;
            }
        }

        return rtn;
    }
}
