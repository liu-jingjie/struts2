package jp.co.aeroasahi.tpkt.batch.mdb0003.job4;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.mdb0003.BatchDataHolder;
import jp.co.aeroasahi.tpkt.batch.mdb0003.BatchJobRequestInput;
import jp.co.aeroasahi.tpkt.batch.mdb0003.MDB0003Repository;
import jp.co.aeroasahi.tpkt.batch.mdb0003.job3.MDB0003Tasklet141;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

/**
 * 表示用テーブル更新の実行を要求するTasklet
 */
@Component
@Scope("step")
public class MDB0003Tasklet151 implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0003Tasklet141.class);

    /** メインバッチジョブID */
    private static final String JOB_ID = "mdb0003Job";

    /** 【表示用】物件管理更新ジョブ名 */
    private static final String DISP_PROPERTY_JOB_NAME = "mdb0801Job";
    /** 【表示用】外注管理更新ジョブ名 */
    private static final String DISP_OUTSOURCING_JOB_NAME = "mdb0802Job";
    /** 【表示用】部門経費管理更新ジョブ名 */
    private static final String DISP_DEPT_COST_JOB_NAME = "mdb0803Job";
    /** 【表示用】操業度管理更新ジョブ名 */
    private static final String DISP_OPERATION_JOB_NAME = "mdb0804Job";

    /** DateTimeFormatterのパターン uuuu-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.SSS");

    @Inject
    DateFactory dateFactory;

    @Inject
    MDB0003Repository mdb0003Repository;

    @Autowired
    private BatchDataHolder batchDataHolder;

    @Value("#{jobParameters['jobNum']}")
    public String jobNum;

    // 日次処理の場合は「D」、月次確定処理の場合は「M」
    @Value("#{jobParameters['shorikbn']}")
    public String shorikbn;

    // 処理年月：日次処理の場合は空白を設定、バッチ実行画面の指定した月次確定対象年月を「YYYYMM」形式
    @Value("#{jobParameters['ym']}")
    public String ym;

    /**
     *
     * 表示用テーブル更新の実行を要求する
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return ステータス
     */
    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

        // jobNumが5以上の場合は、jobNum5の1ステップ目へスキップする
        if (isSkip()) {
            logger.info("リランジョブ番号が5以上であるため、表示用テーブル更新処理をスキップします。");
            contribution.setExitStatus(new ExitStatus("SKIP"));
            return RepeatStatus.FINISHED;
        }

        // ジョブ番号単位でシステム日時を取得
        String jobStartDateTime = dateFactory.newDateTime().format(dtf);
        batchDataHolder.setJobStartDateTime(jobStartDateTime);

        // 【表示用】物件管理更新
        mdb0003Repository.create(createBatchJobRequestBean(DISP_PROPERTY_JOB_NAME, jobStartDateTime));
        // 【表示用】外注管理更新
        mdb0003Repository.create(createBatchJobRequestBean(DISP_OUTSOURCING_JOB_NAME, jobStartDateTime));
        // 【表示用】部門経費管理更新
        mdb0003Repository.create(createBatchJobRequestBean(DISP_DEPT_COST_JOB_NAME, jobStartDateTime));
        // 【表示用】操業度管理更新
        mdb0003Repository.create(createBatchJobRequestBean(DISP_OPERATION_JOB_NAME, jobStartDateTime));

        return RepeatStatus.FINISHED;
    }

    private BatchJobRequestInput createBatchJobRequestBean(String jobName, String jobStartDateTime) {

        BatchJobRequestInput input = new BatchJobRequestInput();

        input.setJobName(jobName);
        input.setJobParameter(getParameter(jobStartDateTime, jobName));
        input.setPriority(1);
        input.setPollingStatus("INIT");
        input.setCreateDate(jobStartDateTime);

        return input;
    }

    private String getParameter(String systemDateTime, String jobName) {

        List<String> params = new ArrayList<>();

        params.add("systemDateTime=" + systemDateTime);
        params.add("jobId=" + JOB_ID);

        // ジョブ4の物件管理更新と外注管理更新では、日次処理のパラメータを渡す
        if (jobName.equals(DISP_PROPERTY_JOB_NAME) || jobName.equals(DISP_OUTSOURCING_JOB_NAME)) {
            params.add("kbn=" + "D");
            params.add("yyyymm=");
        } else {
            params.add("kbn=" + shorikbn);
            String tempYyyyMm = shorikbn.equals("D") ? "" : ym;
            params.add("yyyymm=" + tempYyyyMm);
        }
        return String.join(",", params);
    }

    private boolean isSkip() {
        // jobNumが5以上の場合はスキップする
        if (StringUtils.isNoneEmpty(jobNum)) {
            if (Integer.parseInt(jobNum) > 4) {
                return true;
            }
        }
        return false;
    }
}
