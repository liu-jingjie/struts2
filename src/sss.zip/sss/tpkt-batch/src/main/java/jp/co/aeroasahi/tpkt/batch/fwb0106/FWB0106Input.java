package jp.co.aeroasahi.tpkt.batch.fwb0106;

import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】SAP勘定残高＞のInputBean。
 */
@Setter
@Getter
public class FWB0106Input {

    /** 予算フラグ */
    private String RRCTY;

    /** 予算種別 */
    private String RVERS;

    /** 会計年度 */
    private String GJAHR;

    /** 会計期間 */
    private String MONAT;

    /** 勘定コード */
    private String RACCT;

    /** 会社コード */
    private String RBUKRS;

    /** 部門 */
    private String PRCTR;

    /** プロジェクトID */
    private String PROJK;

    /** 商品 */
    private String PRODUCT;

    /** 空情工程CD */
    private String PROGRESSCD;

    /** 金額 */
    private String HSLXX;

    /** 作成日 */
    private String INS_DT;

    /** 更新日 */
    private String UPD_DT;

}
