package jp.co.aeroasahi.tpkt.batch.sbb0201;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;

/**
 * 月別原価Bean。
 */
@Setter
@Getter
public class SBB0201MonthKosuCost {

    /** プロジェクトID */
    private String pjId;

    /** 工程CD */
    private String koteiCd;

    /** 費目CD */
    private String himokuCd;

    /** 代表リソースCD */
    private String distResourceCd;

    /** 実績積算区分 */
    private String resultPlanedKbn;

    /** 枝番 */
    private String branchNum;

    /** 年月 */
    private String workYm;

    /** 金額 */
    private BigDecimal cost;

    /** 支払額 */
    private BigDecimal paidAmount;

    /** 工数 */
    private BigDecimal kosu;

    /** 作成者 */
    private String createdBy;

    /** 作成日時 */
    private LocalDateTime createdAt;

    /** 更新者 */
    private String updatedBy;

    /** 更新日時 */
    private LocalDateTime updatedAt;

}
