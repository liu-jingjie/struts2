package jp.co.aeroasahi.tpkt.batch.mdb0401;

import java.util.List;

/**
 * テーブル＜応受援委託先枝番情報＞＜応受援工程情報＞＜応受援基本情報＞に操作
 */
public interface MDB0401Repository {

    /**
     * 条件によって、テーブル＜SAP勘定明細＞の情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0401Input> findAll(MDB0401Input input);

    /**
     * テーブル＜【TEMP】部門別経費＞に登録する。
     *
     * @param output MDB0401Output
     * @return
     */
    void create(MDB0401Output output);

    /**
     * テーブル＜【TEMP】部門別経費＞に削除する。
     *
     * @param input MDB0401Input
     * @return
     */
    void delete(MDB0401Input input);
}