package jp.co.aeroasahi.tpkt.batch.mdb0401;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.validator.ValidationException;
import org.springframework.batch.item.validator.Validator;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.fw.CommonLog;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

@Component
@Scope("step")
public class MDB0401Tasklet implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0401Tasklet.class);

    @Inject
    MDB0401Repository mdb0401Repository;

    @Inject
    DateFactory dateFactory;

    @Inject
    Validator<MDB0401Output> validator;

    @Value("#{jobParameters['kbn']}")
    public String kbn;

    @Value("#{jobParameters['yyyymm']}")
    public String yyyymm;

    boolean isErrFlag = false;

    /** DateTimeFormatterのパターン yyyy-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    /** DateTimeFormatterのパターン uuuuMM */
    private static final DateTimeFormatter dtfUUUUMM = DateTimeFormatter.ofPattern("uuuuMM");

    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        LocalDateTime systemDateTime = dateFactory.newDateTime();
        String systemYearMonth = systemDateTime.format(dtf);

        // 年月(当月)
        String ym1 = getCurrentMonth(systemDateTime);

        // 年月(前月或は指定した月の年月)
        String ym2 = "";

        // 日次処理の場合
        if (kbn.equals("D")) {
            ym2 = getPreviousMonth(systemDateTime);

        // 月次確定処理の場合
        } else if (kbn.equals("M")) {
            LocalDateTime yyyymmP = LocalDateTime.of(Integer.parseInt(yyyymm.substring(0, 4)), Integer.parseInt(yyyymm.substring(4, 6)), 1, 1, 1);
            ym2 = getCurrentMonth(yyyymmP);
        }

        List<MDB0401Output> outItems = setItemOutput(ym1, ym2, systemYearMonth);

        if (!isErrFlag) {
            for (int i = 0; i < outItems.size(); i++) {
                try {
                    validator.validate(outItems.get(i));
                } catch (ValidationException e) {
                    isErrFlag = true;
                    CommonLog.setFromDbErrorLog(logger, e, "【TEMP】金額(temp_md_cost)");
                }
            }

            if (!isErrFlag) {

                MDB0401Input itemInput = new MDB0401Input();
                itemInput.setYm1(ym1);
                itemInput.setYm2(ym2);

                // 【TEMP】金額(temp_md_cost)のデータを削除する
                mdb0401Repository.delete(itemInput);

                if(outItems.size() > 0) {

                    // データを登録
                    for (MDB0401Output output : outItems) {
                        mdb0401Repository.create(output);
                    }
                }
                CommonLog.setInsertRecordeCountLog(logger, "【TEMP】金額(temp_md_cost)", outItems.size());

            } else {
                logger.error("登録データでエラーが発生しました。");
            }
            outItems.clear();
        }

        if (isErrFlag) {
            throw new RuntimeException("mdb0401発注費取込実行に異常が発生しました。");
        }

        return RepeatStatus.FINISHED;
    }

    private List<MDB0401Output> setItemOutput(String ym1, String ym2, String systemYearMonth) {

        List<MDB0401Output> outputItems = new ArrayList<>();
        MDB0401Output itemOutput = null;

        MDB0401Input itemInput = new MDB0401Input();
        itemInput.setYm1(ym1);
        itemInput.setYm2(ym2);

        // ［応受援委託先枝番情報］、［応受援工程情報］、［応受援基本情報］からデータを抽出し、［【TEMP】金額］にデータを設定する
        List<MDB0401Input> detailList = mdb0401Repository.findAll(itemInput);
        for (MDB0401Input mdb0401Input : detailList) {

            itemOutput = new MDB0401Output();

            //プロジェクト属性ID
            itemOutput.setPjAttAd(mdb0401Input.getPjAttAd());

            //プロジェクトID
            itemOutput.setPjId(mdb0401Input.getPjId());

            //年月
            itemOutput.setYm(mdb0401Input.getYm());

            //費目CD
            itemOutput.setHimokuCd(mdb0401Input.getHimokuCd());

            //実績積算区分
            itemOutput.setResultPlanedKbn(mdb0401Input.getResultPlanedKbn());

            //工程CD
            itemOutput.setKoteiCd(mdb0401Input.getKoteiCd());

            //代表リソースCD
            itemOutput.setDistResourceCd(mdb0401Input.getDistResourceCd());

            //金額
            itemOutput.setPrice(null == mdb0401Input.getPrice() ? BigDecimal.ZERO : mdb0401Input.getPrice());

            // 作成日
            itemOutput.setCreatedAt(systemYearMonth);

            // 更新日
            itemOutput.setUpdatedAt(systemYearMonth);

            outputItems.add(itemOutput);
        }

        return outputItems;
    }

    private String getCurrentMonth(LocalDateTime systemDateTime) {

        return systemDateTime.format(dtfUUUUMM);
    }

    private String getPreviousMonth(LocalDateTime systemDateTime) {

        return systemDateTime.plusMonths(-1).format(dtfUUUUMM);
    }

}
