package jp.co.aeroasahi.tpkt.batch.mdb0002;

import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 * ジョブについてテーブルに操作
 */
public interface MDB0002Repository {

    /**
     * テーブル＜ジョブ要求テーブル＞に登録する。
     *
     * @param input BatchJobRequestInput
     * @return
     */
    void create(BatchJobRequestInput batchJobRequestInput);

    /**
     * ジョブ名を指定し、作製日時がメインジョブの開始時間であり、ジョブが終了していないjobの件数を取得する
     *
     * @param jobNames 検索対象のジョブ名のリスト
     * @param jobStartDateTimeStr システム時間
     *
     * @return ジョブ要求リスト
     */
    int countAllNotExecuted(@Param("jobNames") List<String> jobNames,
            @Param("jobStartDateTimeStr") String jobStartDateTimeStr);

    /**
     * ジョブ名を指定し、作製日時がメインジョブの開始時間であり、ジョブが完了していないjobの件数を取得する
     * (ジョブが全て終了していることが前提)
     *
     * @param jobNames 検索対象のジョブ名のリスト
     * @param jobStartDateTimeStr システム時間
     *
     * @return ジョブ要求リスト
     */
    int countAllNotCompleted(@Param("jobNames") List<String> jobNames,
            @Param("jobStartDateTimeStr") String jobStartDateTimeStr);

    /**
     * 条件によって、テーブル＜ジョブ要求テーブル＞の情報を取得する
     *
     * @param number 検索件数
     * @param systemDateTime システム時間
     *
     * @return ジョブ要求リスト
     */
    List<BatchJobRequestOutput> findByTopNum(@Param("number") int number,
            @Param("systemDateTime") String systemDateTime);

    /**
     * 条件によって、テーブル＜ジョブ異常テーブル＞の情報を取得する
     *
     * @param executionIds ジョブ実行開始ID
     *
     * @return ジョブ異常リスト
     */
    List<BatchJobExecutionOutput> findByExecutionIds(@Param("executionIds") List<Integer> executionIds);

    /**
     * 条件によって、テーブルの情報を取得する
     *
     * @param executionIds ジョブ実行開始ID
     *
     * @return ジョブ要求リスト
     */
    List<BatchJobRequestOutput> findByJobNames(@Param("executionIds") List<Integer> executionIds);
}
