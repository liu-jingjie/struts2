package jp.co.aeroasahi.tpkt.batch.kn.knb0101;

import java.time.LocalDate;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import jp.co.aeroasahi.tpkt.common.kn.check.CheckTargetPesonal;
import jp.co.aeroasahi.tpkt.common.model.kn.CheckList;

/**
 * 工数チェックバッチのリポジトリ
 */
public interface KNB0101Repository {


    /**
     * 工数確定から確定年月リストを取得
     *
     * @param targetYmList 対象年月リスト
     * @return 確定年月リスト
     */
    List<String> findConfirmedYmByTargetYm(@Param("targetYmList") List<String> targetYmList);

    /**
     * 日付の範囲を指定し、日付単位にチェック対象の社員情報を取得する
     *
     * @param startDate チェック対象開始日
     * @param lastDate チェック対象終了日
     * @return 日付単位の社員情報
     */
    List<CheckTargetPesonal> findAllByDateRangeAndDeptCd(@Param("startDate") LocalDate startDate,
            @Param("lastDate") LocalDate lastDate, @Param("deptCd") String deptCd);

    /**
     * 日付の範囲を指定し、該当するチェック結果を削除する
     *
     * @param startDate 削除対象開始日
     * @param lastDate 削除対象終了日
     * @param isManual 手動フラグ
     */
    void deleteCheckListByDateRange(@Param("startDate") LocalDate startDate, @Param("lastDate") LocalDate lastDate,
            @Param("isManual") boolean isManual, @Param("deptCd") String deptCd);

    /**
     * チェック一覧テーブルにエラー情報を登録する
     *
     * @param errorList 登録対象のエラー情報
     */
    void createCheckList(CheckList errorList);
}
