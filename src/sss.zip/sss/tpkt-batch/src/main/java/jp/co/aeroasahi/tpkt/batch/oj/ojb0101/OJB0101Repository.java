package jp.co.aeroasahi.tpkt.batch.oj.ojb0101;

import java.util.List;

import org.apache.ibatis.annotations.Param;

/**
 *承認リマインドのデータ取得
 *
 */
public interface OJB0101Repository {


    /**
     * 承認リマインドのデータを収集。
     *
     * @param systemDate システム日付
     * @return 承認リマインド情報
     */
    List<OJB0101AdmitRemindInfor> findAdmitInfor(@Param("systemDate") String systemDate);

}
