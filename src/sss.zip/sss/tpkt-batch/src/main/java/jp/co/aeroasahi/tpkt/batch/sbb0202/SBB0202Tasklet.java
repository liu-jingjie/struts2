package jp.co.aeroasahi.tpkt.batch.sbb0202;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.fw.CommonLog;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

@Component
@Scope("step")
public class SBB0202Tasklet implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(SBB0202Tasklet.class);

    /** DateTimeFormatterのパターン uuuu/MM/dd */
    DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("uuuu/MM/dd");

    /** 処理年度（YYYY形式） */
    @Value("#{jobParameters['jobYear']}")
    public String jobYear;

    @Inject
    SBB0202Repository sbb0202Repository;

    @Inject
    DateFactory dateFactory;

    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        // 入力チェック
        if (!inputCheck()) {
            logger.error("{} {}処理実行に異常が発生しました。", "sbb0202", "単価の年度更新");
            return RepeatStatus.FINISHED;
        }


        // 会計年月を取得
        String yearM = jobYear + "04";

        // システム日時を取得
        LocalDateTime systemDateTime = dateFactory.newDateTime();

        // 単価の年度更新
        try {
            updateSekisanData(yearM, systemDateTime);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("{} {}処理実行に異常が発生しました。", "sbb0202", "単価の年度更新");
        }

        return RepeatStatus.FINISHED;
    }

    /**
     * 入力チェック
     *
     * @return チェック結果（true:エラーなし、false:エラーあり）
     */
    private Boolean inputCheck() {
        Boolean ret = true;
        // 処理年度（YYYY形式）をチェック
        if (jobYear != null && !jobYear.equals("")) {
            // フォーマットをチェック
            try {
                LocalDate.parse(jobYear + "/04/01", dateFormatter);
            } catch (DateTimeException e) {
                ret = false;
            }
        }
        return ret;
    }


    /**
     * 単価の年度更新
     */
    private void updateSekisanData(String yearM, LocalDateTime systemDateTime) {

        // 積算データリストを取得
        List<SBB0202TankaUpdate> sekisanDataList = sbb0202Repository.getSekisanData(yearM, systemDateTime.toLocalDate());

        if (sekisanDataList != null && sekisanDataList.size() > 0) {

            for(SBB0202TankaUpdate entry : sekisanDataList) {
                // 積算月別展開データの更新
                sbb0202Repository.updateSbMonthData(entry, systemDateTime);
            }
            CommonLog.setUpdateRecordeCountLog(logger, "積算月別展開データ", sekisanDataList.size());

            // 単価と数量を乗算した値を加算するデータ
            List<SBB0202TankaUpdate> kingakuData = sbb0202Repository.getKingaku(yearM, systemDateTime.toLocalDate());
            if (kingakuData != null && kingakuData.size() > 0) {
                for (SBB0202TankaUpdate entry : kingakuData) {
                    // 積算データの更新
                    sbb0202Repository.updateSbData(entry);
                }
                CommonLog.setUpdateRecordeCountLog(logger, "積算データ", kingakuData.size());
            }
        }
    }
}
