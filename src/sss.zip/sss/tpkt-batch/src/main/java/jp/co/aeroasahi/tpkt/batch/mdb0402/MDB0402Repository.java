package jp.co.aeroasahi.tpkt.batch.mdb0402;

import java.util.List;

/**
 * テーブルに操作
 */
public interface MDB0402Repository {

    /**
     * 条件によって、テーブル＜応受援委託先枝番情報＞＜応受援工程情報＞＜応受援基本情報＞＜委託先マスタ＞の情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0402Output> findAllByOrder();

    /**
     * 条件によって、テーブル＜SAP勘定明細＞の情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0402Output> findAllByUnorderPayment();

    /**
     * 条件によって、テーブル＜SAP勘定明細＞の情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0402Output> findAllByPayment();
    /**
     * テーブル＜【TEMP】外注情報＞に削除する。
     *
     * @return
     */
    void delete();

    /**
     * テーブル＜【TEMP】外注情報＞に登録する。
     *
     * @param output MDB0804Output
     * @return
     */
    void create(MDB0402Output output);

    /**
     * テーブル＜【TEMP】外注情報＞に更新する。
     *
     * @param output MDB0804Output
     * @return
     */
    void update(MDB0402Output output);
}