package jp.co.aeroasahi.tpkt.batch.mdb0804;

import java.math.BigDecimal;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.batch.item.ItemCountAware;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜操業度管理＞のOutputBean。
 */
@Setter
@Getter
public class MDB0804Output implements ItemCountAware {

    private int count;

    /** 部門ＣＤ */
    @NotBlank
    @Size(min = 1, max = 6)
    private String deptCd;

    /** 部門名称 */
    @Size(min = 0, max = 30)
    private String deptName;

    /** 会社名称 */
    @Size(min = 0, max = 30)
    private String corpName;

    /** 生産担当部門支社ＣＤ */
    @Size(min = 0, max = 6)
    private String productDeptBranchCd;

    /** 生産担当部門支社名称 */
    @Size(min = 0, max = 30)
    private String productDeptBranchName;

    /** 生産担当部門部ＣＤ */
    @Size(min = 0, max = 6)
    private String productMDeptCd;

    /** 生産担当部門部名称 */
    @Size(min = 0, max = 30)
    private String productMDeptName;

    /** 生産担当部門小部門ＣＤ */
    @Size(min = 0, max = 6)
    private String productSDeptCd;

    /** 生産担当部門小部門名称 */
    @Size(min = 0, max = 30)
    private String productSDeptName;

    /** 経費種類 */
    @Size(min = 0, max = 1)
    private String costKind;

    /** 会計年度 */
    @NotNull
    @DecimalMin("1")
    @DecimalMax("9999")
    private BigDecimal fiscalYear;

    /** 会計期間 */
    @NotNull
    @DecimalMin("1")
    @DecimalMax("12")
    private BigDecimal fiscalMonth;

    /** 社員区分 */
    @NotBlank
    @Size(min = 1, max = 1)
    private String empKbn;

    /** 稼働人数 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal activePeople;

    /** 直接時間 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal directTime;

    /** 直接の内【間機】時間 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal directMachineTime;

    /** 有休時間 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal paidHolidayTime;

    /** 販売時間 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal saleTime;

    /** 他間接時間 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal otherIndirectTime;

    /** 他間接時間内訳（社内会議） */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal otherIndirectTimeZca10;

    /** 他間接時間内訳（社外活動） */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal otherIndirectTimeZca20;

    /** 他間接時間内訳（ISO9001） */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal otherIndirectTimeZca30;

    /** 他間接時間内訳（ISO14001） */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal otherIndirectTimeZca40;

    /** 他間接時間内訳（QDC活動） */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal otherIndirectTimeZca50;

    /** 他間接時間内訳（Pマーク） */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal otherIndirectTimeZca60;

    /** 他間接時間内訳（ISO27001） */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal otherIndirectTimeZca70;

    /** 他間接時間内訳（本部からの依頼） */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal otherIndirectTimeZca80;

    /** 他間接時間内訳（講習会、研修会） */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal otherIndirectTimeZcc10;

    /** 他間接時間内訳（業務管理） */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal otherIndirectTimeZcc20;

    /** 他間接時間内訳（2Wayｺﾐｭﾆｹｰｼｮﾝ） */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal otherIndirectTimeZcc40;

    /** 他間接時間内訳（その他） */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal otherIndirectTimeZcc50;

    /** 積算値 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal planedKosu;

    /** 計画稼働人数 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal planActivePeople;

    /** 計画直接時間 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal planDirectTime;

    /** 計画直接の内【間機】時間 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal planDirectMachineTime;

    /** 計画有休時間 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal planPaidHolidayTime;

    /** 計画販売時間 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal planSaleTime;

    /** 計画他間接時間 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal planOtherIndirectTime;

    /** 並び順_部門 */
    @DecimalMin("0")
    @DecimalMax("922337203685477")
    private BigDecimal sortNumDept;

    /** 実績データ、計画データ、積算データのチェック区分 */
    private String dataCheckKbn;

    /**
     * 部門ＣＤと会計年度と会計期間と社員区分を結合する
     * @return
     */
    public String concat() {
        return deptCd + "," + fiscalYear + "," + fiscalMonth + "," + empKbn;
    }

    @Override
    public void setItemCount(int count) {
        this.count = count;
    }
}
