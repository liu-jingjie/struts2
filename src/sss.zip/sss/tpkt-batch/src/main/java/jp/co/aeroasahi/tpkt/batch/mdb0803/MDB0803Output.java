package jp.co.aeroasahi.tpkt.batch.mdb0803;

import java.math.BigDecimal;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.batch.item.ItemCountAware;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】部門経費管理＞のOutputBean。
 */
@Setter
@Getter
public class MDB0803Output implements ItemCountAware {

    private int count;

    /** 部門ＣＤ */
    @NotBlank
    @Size(min = 1, max = 6)
    private String deptCd;

    /** 部門名称 */
    @Size(min = 0, max = 30)
    private String deptName;

    /** 費目ＣＤ */
    @Size(min = 0, max = 2)
    private String himokuCd;

    /** 費目名 */
    @Size(min = 0, max = 50)
    private String himokuName;

    /** 勘定科目ＣＤ */
    @NotBlank
    @Size(min = 1, max = 8)
    private String kamokuCd;

    /** 勘定科目名称 */
    @Size(min = 0, max = 40)
    private String kamokuName;

    /** 部門支社ＣＤ */
    @Size(min = 0, max = 6)
    private String deptBranchCd;

    /** 部門支社名称 */
    @Size(min = 0, max = 30)
    private String deptBranchName;

    /** 部門部ＣＤ */
    @Size(min = 0, max = 6)
    private String mDeptCd;

    /** 部門部名称 */
    @Size(min = 0, max = 30)
    private String mDeptName;

    /** 部門小部門ＣＤ */
    @Size(min = 0, max = 6)
    private String sDeptCd;

    /** 部門小部門名称 */
    @Size(min = 0, max = 30)
    private String sDeptName;

    /** 経費種類 */
    @Size(min = 0, max = 1)
    private String costKind;

    /** 会計年度 */
    @NotNull
    @DecimalMin("1")
    @DecimalMax("9999")
    private BigDecimal fiscalYear;

    /** 会計期間 */
    @NotNull
    @DecimalMin("1")
    @DecimalMax("12")
    private BigDecimal fiscalMonth;

    /** 実績積算区分 */
    @NotBlank
    @Size(min = 0, max = 1)
    private String resultPlanedKbn;

    /** 原価 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal cost;

    /** 並び順_部門 */
    @DecimalMin("0")
    @DecimalMax("922337203685477")
    private BigDecimal sortNumDept;

    @Override
    public void setItemCount(int count) {
        this.count = count;
    }
}
