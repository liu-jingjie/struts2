package jp.co.aeroasahi.tpkt.batch.oj.ojb0102;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import org.springframework.util.StringUtils;

/**
 * ファイル処理クラス.
* <p>
* ファイルの処理。
* </p>
 */
public class FileUtils {

    /**
     * 指定したパスよりファイルを取得
     * @param filePath
     * @return
     * @throws IOException
     */
    public static List<File> getServerFileList(String filePath, String fileFilter) throws IOException {

        // Defaultの「rootパス」と「拡張子Filter」を設定
        String rootFilePath = "";

        // 帳票のRootPathを取得
        if (!StringUtils.isEmpty(filePath)) {
            rootFilePath = filePath;
        }
        Path configFilePath = Paths.get(rootFilePath);

        String[] extensions;
        // 帳票の拡張子Filterを取得
        if (!StringUtils.isEmpty(fileFilter)) {
            extensions = fileFilter.split(",");
            // 取得できない場合、""を設定
        } else {
            extensions = new String[] {""};
        }

        // ファイルリストを作成する
        try (Stream<Path> pathStream = Files.walk(configFilePath)) {

            List<File> fileList = new ArrayList<>();
            pathStream.map(path -> path.toFile())
                    // ファイルのみ取得
                    .filter(file -> !file.isDirectory())
                    .filter(file -> {
                        boolean checkFlg = true;
                        if (extensions.length > 0) {
                            for (String extension : extensions) {
                                // 拡張子リストで設定された拡張子は対象外
                                if (file.getName().toLowerCase().endsWith(extension)) {
                                    checkFlg = false;
                                    break;
                                }
                            }
                        }
                        return checkFlg;
                    })
                    .forEach(fileList::add);

            return fileList;
        } catch (IOException e) {
            throw new IOException(e);
        }
    }
}
