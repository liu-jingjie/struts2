package jp.co.aeroasahi.tpkt.batch.fwb0113;

import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】プロジェクト＞のOutputBean。
 */
@Setter
@Getter
public class FWB0113TpktOutput {

    /** プロジェクトID */
    private String pjId;

    /** BU+プロジェクト属性ID */
    private String buPjAttId;

    /** プロジェクト属性ID */
    private String pjAttId;

    /** プロジェクト種別 */
    private String pjType;

    /** プロジェクト名称 */
    private String pjName;

    /** 生産・営業担当部門CD */
    private String proSalesDeptCd;

    /** 生産・営業担当者CD */
    private String proSalesEmpCd;

    /** プロジェクト完了フラグ */
    private String pjEnded;

    /** PJステータス */
    private String pjStatus;

    /** 取引種別 */
    private String dealType;

    /** 作成日 */
    private String createdAt;

    /** 更新日 */
    private String updatedAt;

}
