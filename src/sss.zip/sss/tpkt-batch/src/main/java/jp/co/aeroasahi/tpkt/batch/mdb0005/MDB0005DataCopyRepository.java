package jp.co.aeroasahi.tpkt.batch.mdb0005;

import org.apache.ibatis.annotations.Param;

/**
 * 一時テーブルから本体テーブルにデータを登録する
 */
public interface MDB0005DataCopyRepository {

    int dataCopy(@Param("fromTable") String fromTable, @Param("toTable") String toTable);
}
