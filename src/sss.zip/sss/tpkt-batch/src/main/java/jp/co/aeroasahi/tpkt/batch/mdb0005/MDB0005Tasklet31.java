package jp.co.aeroasahi.tpkt.batch.mdb0005;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.inject.Inject;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

/**
 * 各ジョブを実行するTasklet
 */
@Component
@Scope("step")
public class MDB0005Tasklet31 implements Tasklet {

    @Inject
    DateFactory dateFactory;

    @Inject
    MDB0005Repository mdb0005Repository;

    @Autowired
    private BatchDataHolder batchDataHolder;

    /** DateTimeFormatterのパターン uuuu-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.SSS");

    /**
     *
     * マインバッチ処理
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return 一括で各ジョブを実行した状態
     */
    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        LocalDateTime systemDateTime = dateFactory.newDateTime();
        String systemDateTimeStr = systemDateTime.format(dtf);

        batchDataHolder.setSystemDateTime(systemDateTimeStr);

        if(!batchDataHolder.isCheckSkip2() && batchDataHolder.isCheckResult2()) {

            // 発注書番号取込
            executeJob("ojb0201Job", "systemDateTime=" + systemDateTimeStr);

        }

        return RepeatStatus.FINISHED;
    }

    /**
     * ジョブ実行処理
     *
     * @return 無し
     */
    private void executeJob(String jobName, String jobParameter) throws Exception {

        BatchJobRequestInput input = new BatchJobRequestInput();

        input.setJobName(jobName);
        input.setJobParameter(jobParameter);
        input.setPriority(1);
        input.setPollingStatus("INIT");

        mdb0005Repository.create(input);
    }

}
