package jp.co.aeroasahi.tpkt.batch.mdb0901;

import java.time.LocalDateTime;
import javax.inject.Inject;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

/**
 * キューブの自動デプロイを実行する
 */
@Component
@Scope("step")
public class MDB0901Tasklet implements Tasklet {

    @Inject
    MDB0901Repository mdb0901Repository;

    @Inject
    DateFactory dateFactory;

    @Autowired
    private BatchDataHolder batchDataHolder;

    private static final String SSIS_FOLDER_NAME = "Si-MOS";
    private static final String DEPLOY_PROJECT_NAME = "CubeDeploy";

    private static final String DEPT_COST_MANAGEMENT = "dept_cost_management.dtsx";
    private static final String DEPT_COST_MANAGEMENT_MASTER = "dept_cost_management_master.dtsx";
    private static final String SOGYODO_INFOS = "sogyodo_infos.dtsx";

    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        LocalDateTime systemDateTime = dateFactory.newDateTime();
        batchDataHolder.setStartDateTime(systemDateTime);

        // 部門経費管理のキューブをデプロイする
        mdb0901Repository.automaticCompilation(SSIS_FOLDER_NAME, DEPLOY_PROJECT_NAME, DEPT_COST_MANAGEMENT);

        // 部門経費管理（人件費有）のキューブをデプロイする
        mdb0901Repository.automaticCompilation(SSIS_FOLDER_NAME, DEPLOY_PROJECT_NAME, DEPT_COST_MANAGEMENT_MASTER);

        // 操業度管理のキューブをデプロイする
        mdb0901Repository.automaticCompilation(SSIS_FOLDER_NAME, DEPLOY_PROJECT_NAME, SOGYODO_INFOS);

        return RepeatStatus.FINISHED;
    }
}
