package jp.co.aeroasahi.tpkt.batch.oj.ojb0102;

import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;

/**
 *応受援帳票登録状況一覧の作成
 *
 */
public interface OJB0102Repository {


    /**
    * 指定されたテーブルをtruncate
    *
    * @param tableName
    * @return
    */
    int truncateTable(@Param("tableName") String tableName);
    /**
     * 帳票名を取得
     * @return
     */
    List<ReportBean> findReportName () ;

    /**
     * 帳票詳細を取得
     * @return
     */
    List<ReportDetailBean> findReportDetailInfo () ;

    /**
     * テーブル＜応受援帳票登録情報＞を登録する。
     *
     * @param output OjDocRegInfoOutput
     *
     */
    void createOjDocRegInfo(OjDocRegInfoOutput output);

    /**
     * テーブル＜応受援帳票登録日情報＞を登録する。
     *
     * @param output OjDocRegDateOutPut
     *
     */
    void createOjDocRegDateInfo(OjDocRegDateOutPut output);

    /**
     * ファイルの名称よりテーブル＜応受援帳票登録日情報＞を検索する。
     *
     * @param fileName String
     *
     * @return
     */
    Map<String, Integer> findOjDocRegDateInfoByFileName(@Param("fileName") String fileName);

    /**
     * テーブル＜応受援帳票基本情報＞を登録する。
     *
     * @param output OjDocRegDateOutPut
      * @return
     */
    void createOjDocBaseInfo(@Param("date") String date);

    /**
     * テーブル＜委託履歴＞を検索する。
     *
     * @param output OjEntrustHistoryOutput
     *
     */
    Map<String ,Integer> findOjEntrustHistory(OjEntrustHistoryOutput output);

    /**
     * テーブル＜委託履歴＞を登録する。
     *
     * @param output OjEntrustHistoryOutput
     *
     */
    void createOjEntrustHistory(OjEntrustHistoryOutput output);

    /**
     * テーブル＜委託履歴＞を更新する。
     *
     * @param output OjEntrustHistoryOutput
     *
     */
    void updateOjEntrustHistory(OjEntrustHistoryOutput output);
}
