package jp.co.aeroasahi.tpkt.batch.fwb0103;

import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.batch.item.ItemCountAware;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】SAPプロジェクト属性＞のOutputBean。
 */
@Setter
@Getter
public class FWB0103Output implements ItemCountAware {

    private int count;

    /** プロジェクト属性ID */
    @NotBlank
    @Size(min = 1, max = 8)
    private String ZPSPID;

    /** プロジェクト属性名称 */
    @Size(min = 0, max = 80)
    private String ZPSPNAME;

    /** 営業主管部門 */
    @Size(min = 0, max = 6)
    private String ZEIGYOSHUKANBUMON;

    /** 営業主管担当者 */
    @Size(min = 0, max = 5)
    private String ZEIGYOTANTO;

    /** 生産主管部門 */
    @Size(min = 0, max = 6)
    private String ZSEISANSHUKANBUMON;

    /** 生産プロデューサー */
    @Size(min = 0, max = 5)
    private String ZPRODUCER;

    /** 物件管理責任者部門 */
    @Size(min = 0, max = 6)
    private String ZBUKKENTANTO;

    /** 物件管理責任者 */
    @Size(min = 0, max = 5)
    private String ZBUKKENTANTOBUMON;

    /** 顧客 */
    @Size(min = 0, max = 10)
    private String ZTOKUISAKI;

    /** 分野コード */
    @Size(min = 0, max = 2)
    private String ZBUNYACD;

    /** 業務コード */
    @Size(min = 0, max = 3)
    private String ZGYOUMUCD;

    /** 属性 */
    @Size(min = 0, max = 4)
    private String STAT;

    /** 今期仕掛中フラグ */
    @Size(min = 0, max = 1)
    private String DATEFLG;

    /** 賃貸PJ区分 */
    @Size(min = 0, max = 1)
    private String ZLEASEFLAG;

    /** 契約件名 */
    @Size(min = 0, max = 80)
    private String ZKEIYAKUMEI;

    /** 名義会社 */
    @Size(min = 0, max = 2)
    private String ZMEIGIKAISHA;

    /** 契約工期（FROM） */
    @Size(min = 0, max = 23)
    private String ZKEYAKUKOKIB;

    /** 契約工期(TO） */
    @Size(min = 0, max = 23)
    private String ZKEYAKUKOKIE;

    /** 作成日 */
    @Size(min = 23, max = 23)
    private String INS_DT;

    /** 更新日 */
    @Size(min = 23, max = 23)
    private String UPD_DT;

    @Override
    public void setItemCount(int count) {
        this.count = count;
    }

}
