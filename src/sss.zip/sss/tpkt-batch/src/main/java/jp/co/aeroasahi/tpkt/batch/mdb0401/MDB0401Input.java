package jp.co.aeroasahi.tpkt.batch.mdb0401;

import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜応受援委託先枝番情報＞とテーブル＜応受援工程情報＞とテーブル＜応受援基本情報＞のInputBean。
 */
@Setter
@Getter
public class MDB0401Input {

    /** プロジェクト属性ID */
    private String pjAttAd;

    /** プロジェクトID */
    private String pjId;

    /** 年月 */
    private String ym;

    /** 費目CD */
    private String himokuCd;

    /** 実績積算区分 */
    private String resultPlanedKbn;

    /** 工程CD */
    private String koteiCd;

    /** 代表リソースCD */
    private String distResourceCd;

    /** 金額 */
    private BigDecimal price;

    /** 作成日 */
    private String createdAt;

    /** 更新日 */
    private String updatedAt;

    /** 会計年月 検索用(当月)*/
    private String ym1;

    /** 会計年月 検索用(前月或は指定した月)*/
    private String ym2;

}
