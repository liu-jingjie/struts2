package jp.co.aeroasahi.tpkt.batch.mdb0002;

import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * 滞留監視処理の実行要求をするTasklet
 */
@Component
@Scope("step")
public class MDB0002Tasklet21 implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0002Tasklet21.class);

    @Inject
    MDB0002Repository mdb0002Repository;

    @Autowired
    private BatchDataHolder batchDataHolder;

    /**
     *
     * 滞留監視処理の実行要求をする
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return 一括で各ジョブを実行した状態
     */
    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

        try {
            String jobStartDateTime = batchDataHolder.getSystemDateTime();

            // 滞留監視
            executeJob("ojb0403Job", "systemDateTime=" + jobStartDateTime, jobStartDateTime);

        } catch (Exception e) {
            logger.error("システムエラーが発生しました。");
            logger.error("stackTrace：", e);
            batchDataHolder.setCheckResult(false);
        }
        return RepeatStatus.FINISHED;
    }

    /**
     * ジョブ実行処理
     *
     * @return 無し
     */
    private void executeJob(String jobName, String jobParameter, String jobStartDateTimeStr) {

        BatchJobRequestInput input = new BatchJobRequestInput();

        input.setJobName(jobName);
        input.setJobParameter(jobParameter);
        input.setPriority(1);
        input.setPollingStatus("INIT");
        input.setJobStartDateTimeStr(jobStartDateTimeStr);

        mdb0002Repository.create(input);
    }
}
