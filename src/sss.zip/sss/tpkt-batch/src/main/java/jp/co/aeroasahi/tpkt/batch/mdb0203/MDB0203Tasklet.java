package jp.co.aeroasahi.tpkt.batch.mdb0203;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.fw.CommonLog;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

@Component
@Scope("step")
public class MDB0203Tasklet implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0203Tasklet.class);

    @Inject
    MDB0203Repository mdb0203Repository;

    @Inject
    DateFactory dateFactory;

    /** DateTimeFormatterのパターン yyyy-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    /** DateTimeFormatterのパターン yyyyMM */
    private static final DateTimeFormatter dtfYYYYMM = DateTimeFormatter.ofPattern("yyyyMM");

    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        LocalDateTime systemDateTime = dateFactory.newDateTime();
        String systemDateTimeStr = systemDateTime.format(dtf);

        String systemDateTimeYearMonthStr = systemDateTime.format(dtfYYYYMM);

        // テーブル＜SAPプロジェクト＞＜汎用マスタ＞＜【TEMP】受注＞＜【TEMP】売上＞情報を取得する。
        List<MDB0203Input> inputList = mdb0203Repository.findAll();

        // テーブル＜【TEMP】受注＞情報を取得する。
        List<MDB0203Input> inpuReceivetList = mdb0203Repository.findAllReceive();
        Map<String, MDB0203Input> inpuReceivetMap =
                inpuReceivetList.stream().collect(Collectors.toMap(MDB0203Input::getPjIdReceive, Function.identity()));

        // テーブル＜【TEMP】売上＞情報を取得する。
        List<MDB0203Input> inpuSoldAmountList = mdb0203Repository.findAllSoldAmount();
        Map<String, MDB0203Input> inpuSoldAmountMap =
                inpuSoldAmountList.stream()
                        .collect(Collectors.toMap(MDB0203Input::getPjIdSoldAmount, Function.identity()));

        // 【TEMP】プロジェクトの既存データを取得する
        List<MDB0203Output> checkList = mdb0203Repository.findAllByTempProject();
        Map<String, MDB0203Output> checkListMap =
                checkList.stream().collect(Collectors.toMap(MDB0203Output::getPjId, Function.identity()));

        // 【TEMP】プロジェクトに登録する前に、データを編集する。
        List<MDB0203Output> outItems = setItemOutput(inputList, inpuReceivetMap, inpuSoldAmountMap, systemDateTimeStr);

        List<MDB0203Output> insertRecordList = new ArrayList<MDB0203Output>();
        List<MDB0203Output> updateRecordList = new ArrayList<MDB0203Output>();

        for (MDB0203Output mdb0203Output : outItems) {

            // 更新
            if (checkListMap.containsKey(mdb0203Output.getPjId())) {

                updateRecordList.add(mdb0203Output);
                // 登録
            } else {

                insertRecordList.add(mdb0203Output);
            }

        }

        // 【TEMP】プロジェクトのデータを更新する
        if (updateRecordList.size() > 0) {
            for (MDB0203Output output : updateRecordList) {
                mdb0203Repository.update(output);
            }
        }


        // 【TEMP】プロジェクトのデータを登録する
        if (insertRecordList.size() > 0) {
            for (MDB0203Output output : insertRecordList) {
                mdb0203Repository.create(output);
            }
        }

        CommonLog.setInsertRecordeCountLog(logger, "【TEMP】プロジェクト(temp_project)", insertRecordList.size());
        CommonLog.setUpdateRecordeCountLog(logger, "【TEMP】プロジェクト(temp_project)", updateRecordList.size());
        outItems.clear();

        // テーブル＜【TEMP】プロジェクト＞情報を取得する。
        MDB0203Output inputKey = new MDB0203Output();
        inputKey.setBeginOfFiscalYearMonth(yearMonthToBeginOfFiscalYearMonth(systemDateTimeYearMonthStr));
        inputKey.setEndOfFiscalYearMonth(yearMonthToEndOfFiscalYearMonth(systemDateTimeYearMonthStr));

        List<MDB0203Output> inpuTempProjectFiscalList = mdb0203Repository.findAllByTempProjectFiscal(inputKey);

        // 【TEMP】プロジェクトに更新する前に、データを編集する。
        for (MDB0203Output mdb0203Output : inpuTempProjectFiscalList) {

            mdb0203Output.setUpdatedAt(systemDateTimeStr);
        }

        // 【TEMP】プロジェクトのデータを更新する
        if (inpuTempProjectFiscalList.size() > 0) {
            for (MDB0203Output output : inpuTempProjectFiscalList) {
                mdb0203Repository.updateTempProjectFiscal(output);
            }
        }

        return RepeatStatus.FINISHED;
    }

    private List<MDB0203Output> setItemOutput(List<MDB0203Input> inputList, Map<String, MDB0203Input> inpuReceivetMap,
            Map<String, MDB0203Input> inpuSoldAmountMap, String systemDateTimeStr) {

        List<MDB0203Output> outputItems = new ArrayList<>();

        MDB0203Output item = new MDB0203Output();

        BigDecimal zero = new BigDecimal(0);

        for (MDB0203Input mdb0203Input : inputList) {
            item = new MDB0203Output();

            /** プロジェクトID */
            item.setPjId(mdb0203Input.getPSPNR());

            /** BU+プロジェクト属性ID */
            item.setBuPjAttId(mdb0203Input.getPSPNR().substring(0, 10));

            /** プロジェクト属性ID */
            item.setPjAttId(mdb0203Input.getZPSPID());

            /** プロジェクト種別 */
            item.setPjType(mdb0203Input.getPSPNR().substring(2, 3));

            /** プロジェクト名称 */
            item.setPjName(mdb0203Input.getZPSPNAME());

            /** 生産・営業担当部門CD */
            item.setProSalesDeptCd(mdb0203Input.getPRCTR());

            /** 生産・営業担当者CD */
            item.setProSalesEmpCd(mdb0203Input.getZSEISANEIGYOTANTOSHA());

            /** プロジェクト完了フラグ */
            item.setPjEnded(null == mdb0203Input.getVALUE29() ? "" : mdb0203Input.getVALUE29());

            /** PJステータス */
            item.setPjStatus(null == mdb0203Input.getVALUE30() ? "" : mdb0203Input.getVALUE30());

            /** 応札積算額 */
            if (mdb0203Input.getPSPNR().substring(10, 12).equals("01")) {
                BigDecimal totalOsatsuPlanedAmount = (null == inpuReceivetMap.get(mdb0203Input.getPSPNR().substring(0, 10) + "01"))?BigDecimal.ZERO:inpuReceivetMap.get(mdb0203Input.getPSPNR().substring(0, 10) + "01").getTotalOsatsuPlanedAmount();
                item.setOsatsuPlanedAmount(totalOsatsuPlanedAmount);
            } else {
                item.setOsatsuPlanedAmount(zero);
            }

            /** 受注金額 */
            BigDecimal totalReceivedAmount =
                    (null == inpuReceivetMap.get(mdb0203Input.getPSPNR().substring(0, 10) + "01"))?BigDecimal.ZERO:inpuReceivetMap.get(mdb0203Input.getPSPNR().substring(0, 10) + "01").getTotalReceivedAmount();
            if (mdb0203Input.getPSPNR().substring(10, 12).equals("01")) {
                item.setReceivedAmount(totalReceivedAmount);
            } else {
                item.setReceivedAmount(zero);
            }

            /** 受注日 */
            Date minReceivedOn =
                    (null == inpuReceivetMap.get(mdb0203Input.getPSPNR().substring(0, 10) + "01"))?null:inpuReceivetMap.get(mdb0203Input.getPSPNR().substring(0, 10) + "01").getMinReceivedOn();
            item.setReceivedOn(minReceivedOn);

            /** 売上予定日 */
            item.setPlanedSellingOn(null);

            /** 最終売上完了日 */
            // 【TEMP】売上．売上額］の合計
            BigDecimal totalSoldAmount =
                    (null == inpuSoldAmountMap.get(mdb0203Input.getPSPNR().substring(0, 10) + "01"))?BigDecimal.ZERO:inpuSoldAmountMap.get(mdb0203Input.getPSPNR().substring(0, 10) + "01").getTotalSoldAmount();

            if (totalReceivedAmount.compareTo(zero) != 0 && totalSoldAmount.compareTo(zero) != 0
                    && totalReceivedAmount.compareTo(totalSoldAmount) == 0) {

                // 一番新しい日付を格納
                Date maxSoldOn = inpuSoldAmountMap.get(mdb0203Input.getPSPNR().substring(0, 10) + "01").getMaxSoldOn();
                item.setLastSoldOn(maxSoldOn);
            } else {

                // NULLを格納
                item.setLastSoldOn(null);
            }

            /** 最終売上予定日 */
            item.setLastPlannedSalesOn(null);

            /** 初回売上日 */
            Date minSoldOn = (null == inpuSoldAmountMap.get(mdb0203Input.getPSPNR().substring(0, 10) + "01"))?null:inpuSoldAmountMap.get(mdb0203Input.getPSPNR().substring(0, 10) + "01").getMinSoldOn();
            item.setSoldOn(minSoldOn);

            /** 取引種別 */
            item.setDealType(mdb0203Input.getZTORISYUBETU());

            /** 作成日 */
            item.setCreatedAt(systemDateTimeStr);

            /** 更新日 */
            item.setUpdatedAt(systemDateTimeStr);

            outputItems.add(item);
        }

        return outputItems;
    }

    private String yearMonthToBeginOfFiscalYearMonth(String yearMonth) {

        int year = Integer.parseInt(yearMonth.substring(0, 4));
        int month = Integer.parseInt(yearMonth.substring(4, 6));

        if (month < 4) {
            year--;
        }

        return String.valueOf(year + "04");

    }

    private String yearMonthToEndOfFiscalYearMonth(String yearMonth) {

        int year = Integer.parseInt(yearMonth.substring(0, 4));
        int month = Integer.parseInt(yearMonth.substring(4, 6));

        if (month < 4) {
            year--;
        }

        return String.valueOf(year + 1 + "03");

    }

}
