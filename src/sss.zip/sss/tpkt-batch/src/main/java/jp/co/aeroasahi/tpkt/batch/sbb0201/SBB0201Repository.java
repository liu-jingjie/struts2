package jp.co.aeroasahi.tpkt.batch.sbb0201;

import java.time.LocalDateTime;
import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 * 積算実績登録
 */
public interface SBB0201Repository {

    /**
     * 実績原価リストを取得する。
     *
     * @param list 処理年月リスト
     * @return 実績原価工数リスト
     */
    List<SBB0201KosuCost> findCostByYm(@Param("list") List<String> list);

    /**
     * 月別実績原価リストを取得する。
     *
     * @param list 処理年月リスト
     * @return 月別実績原価リスト
     */
    List<SBB0201MonthKosuCost> findMonthCostByYm(@Param("list") List<String> list);

    /**
     * MAX並び順を取得する。
     *
     * @return MAX並び順リスト
     */
    List<SbDataMaxSort> findMaxSortNum(@Param("ckFlg") int ckFlg);

    /**
     * MAX枝番を取得する。
     *
     * @return MAX枝番リスト
     */
    List<SbDataMaxBranch> findMaxBranchNum(@Param("ckFlg") int ckFlg);

    /**
     * 積算予算データをインサート
     *
     * @param item 積算データ
     */
    void insertSBDataBudget(@Param("item") SBB0201KosuCost item);

    /**
     * 積算実績データを更新
     *
     * @param item 積算データ
     */
    void updateSBDataResult(@Param("item") SBB0201KosuCost item);

    /**
     * 積算月別実績データを更新
     *
     * @param item 積算月別データ
     * @param today システム日時
     */
    void updateSBMonthDataResult(@Param("item") SBB0201MonthKosuCost item, @Param("today") LocalDateTime today);


    /**
     * 実績工数リストを取得する。
     *
     * @param list 処理年月リスト
     * @return 実績工数リスト
     */
    List<SBB0201KosuCost> findKosuByYm(@Param("list") List<String> list);

    /**
     * 月別実績工数リストを取得する。
     *
     * @param list 処理年月リスト
     * @return 月別実績工数リスト
     */
    List<SBB0201MonthKosuCost> findMonthKosuByYm(@Param("list") List<String> list);


    /**
     * 発生原価を取得する。
     *
     * @param list 処理年月リスト
     * @return 発生原価リスト
     */
    List<SBB0201SapCost> findSAPCostByYm(@Param("list") List<String> list);


    /**
     * 積算基本情報を更新
     *
     * @param item 発生原価情報
     * @param today システム日時
     */
    void updateSBBaseInfo(@Param("item") SBB0201SapCost item, @Param("today") LocalDateTime today);

}
