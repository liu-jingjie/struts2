package jp.co.aeroasahi.tpkt.batch.kn.knb0102;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.inject.Inject;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.validator.ValidationException;
import org.springframework.batch.item.validator.Validator;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import com.csvreader.CsvReader;
import jp.co.aeroasahi.tpkt.batch.fw.CommonLog;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

/**
 *
 * 勤怠データ取込バッチ
 * <p>
 * パラメータで取得したシステム日付（yyyyMMdd）の勤怠情報ファイルのデータを読み込み、［勤怠データ］に登録する
 * </p>
 *
 */
@Component
@Transactional
@Scope("step")
public class KNB0102Tasklet implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(KNB0102Tasklet.class);

    @Inject
    DateFactory dateFactory;

    @Inject
    Validator<KNB0102Output> validator;

    @Inject
    KNB0102Repository repository;

    @Value("#{jobParameters['type']}")
    public String type;

    /** 工数チェックのジョブ名 */
    private static final String KOSU_CHECK_JOB_NAME = "knb0101Job";

    /** 年月 */
    @Value("#{jobParameters['yearMonth']}")
    public String yearMonth;

    /** 部門CD */
    @Value("#{jobParameters['deptCd']}")
    public String deptCd;

    /** DateTimeFormatterのパターン yyyyMMdd */
    private static final DateTimeFormatter dtfYyyyMMdd = DateTimeFormatter.ofPattern("yyyyMMdd");

    /** DateTimeFormatterのパターン yyyy-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    /** ファイルのコピー元フォルダ */
    @Value("${local.source.path}")
    String sourceFolder;

    /** コピー先フォルダ CSV */
    @Value("${local.destination.csv.path}")
    String destinationFolderCSV;

    /** コピー先フォルダ LOG */
    @Value("${local.destination.log.path}")
    String destinationFolderLOG;

    /** 想定CSVファイルサフィックス */
    private static final String fileExtensionCSV = "arj.csv";

    /** 想定LOGファイルサフィックス */
    private static final String fileExtensionLog = "arj.log";

    /** 想定ファイルサフィックス */
    private static final String fileExtension_C = "arj_C.csv";

    /** 想定ファイルサフィックス */
    private static final String fileExtensionFrontHalf = "arj_E_";

    /** 想定ファイルサフィックス */
    private static final String fileExtensionFrontBackHalf = ".csv";

    /** 正常終了文字列 */
    private static final String checkStr = "メイン処理 ... 正常終了";

    // 各処理の実行結果（true：正常、false：異常）
    boolean processCheckFlag = false;

    // 各処理の実行結果（true：正常、false：異常）
    boolean processManualCheckFlag = true;

    private final String EMPTY = "";

    private final String COMPY = "COMPY";

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        LocalDateTime systemDateTime = dateFactory.newDateTime();
        String systemYMD = systemDateTime.format(dtfYyyyMMdd);
        String systemTime = systemDateTime.format(dtf);
        String logFile = EMPTY;
        String csvFile = EMPTY;

        try {
            if (null != type && type.equals("0")) {

                // ファイルのコピー元フォルダの中に、想定ファイルがあるかどうか
                processCheckFlag = isfileExist(sourceFolder, systemYMD + fileExtensionCSV);

                // ■ファイルコピーとリネーム
                if (processCheckFlag) {

                    // ファイルのコピー先フォルダの中に、想定ファイルがあるかどうか
                    processCheckFlag = isfileExist(destinationFolderCSV, systemYMD + fileExtensionCSV);

                    if (processCheckFlag) {
                        processCheckFlag = deleteFile(destinationFolderCSV, systemYMD + fileExtensionCSV);
                    }

                    // ファイルをコピー先フォルダにコピーする
                    processCheckFlag = fileCopy(sourceFolder, systemYMD + fileExtensionCSV, destinationFolderCSV,
                            systemYMD + fileExtensionCSV);

                    // ファイルのコピー先フォルダの中に、リネームしたいファイルがあるかどうか
                    csvFile = systemYMD + fileExtension_C;
                    processCheckFlag = isfileExist(destinationFolderCSV, csvFile);

                    if (processCheckFlag) {
                        processCheckFlag = deleteFile(destinationFolderCSV, csvFile);
                    }

                    // ファイルをリネームする
                    processCheckFlag = fileRename(destinationFolderCSV, systemYMD + fileExtensionCSV, csvFile);

                    // コピーしたいログファイル名を取得する
                    logFile = getLatestFile(getFileName(sourceFolder), systemYMD);

                    if (!logFile.isEmpty()) {
                        // ファイルをコピー先フォルダにコピーする
                        processCheckFlag = fileCopy(sourceFolder, logFile, destinationFolderLOG, logFile);

                        if (processCheckFlag) {
                            logger.info("ファイルコピー完了;勤怠情報ファイル名={};勤怠ログファイル名={}", systemYMD + fileExtensionCSV, logFile);
                            logger.info("ファイル名変更完了;勤怠情報ファイル名={}", systemYMD + fileExtension_C);
                        }
                    } else {
                        processCheckFlag = false;
                        // 正常のログファイルが見つかりません
                        logger.error("確認対象のログファイルが存在しません。");
                    }
                } else {
                    logger.error("取込対象のCSVファイルが存在しません。");
                }

            } else if (null != type && type.equals("1")) {

                processCheckFlag = true;

                // 既存のCSVファイル名を取得する
                csvFile = getManualLatestFile(getFileName(destinationFolderCSV), "csv");

                if (csvFile.isEmpty()) {

                    processManualCheckFlag = false;
                    logger.info("取込対象のCSVファイルが存在しないため処理をスキップしました。;処理={}", "勤怠データ取込");
                } else {

                    if (processCheckFlag) {
                        // 既存のログファイル名を取得する
                        logFile = getManualLatestFile(getFileName(destinationFolderLOG), "log");
                        if (logFile.isEmpty()) {
                            processManualCheckFlag = false;
                        }
                    }
                }
            }

            // ■ファイル取込
            if (processCheckFlag && processManualCheckFlag) {

                // LOGファイル取り込む結果
                processCheckFlag = checkLogStr(destinationFolderLOG, logFile, checkStr);

                if (processCheckFlag) {

                    // CSVファイル取り込む結果
                    ArrayList<String[]> csvDataList = getCSVDataList(destinationFolderCSV, csvFile);

                    // 登録データを設定する。
                    List<KNB0102Output> outItems = setItemData(csvDataList, systemTime);

                    String[] tableItemKeys =
                            new String[] {"empCd", "date", "deptCd", "kinmuKbn", "kintaiCd", "openingTime",
                                    "endingTime",
                                    "inputTime", "offTime", "cikokuSoutaiTime", "insEmpCd", "insDt", "updEmpCd",
                                    "updDt"};
                    String[] tableItemNames = new String[] {"社員CD", "日付", "就労所属CD", "勤務種別CD", "勤怠CD", "始業時刻", "終業時刻",
                            "勤怠稼動時間", "休憩時間", "遅刻早退時間", "作成者", "作成日", "更新者", "更新日"};
                    Map<String, String> tableItemInfo = new HashMap<String, String>();
                    for (int i = 0; i < tableItemKeys.length; i++) {
                        tableItemInfo.put(tableItemKeys[i], tableItemNames[i]);
                    }

                    boolean isErrFlag = false;

                    for (int i = 0; i < outItems.size(); i++) {
                        try {
                            validator.validate(outItems.get(i));
                        } catch (ValidationException e) {
                            isErrFlag = true;
                            CommonLog.setFromFileErrorLog(logger, e, tableItemInfo, systemYMD + fileExtensionCSV, i);
                        }
                    }

                    if (!isErrFlag) {
                        try {
                            if (outItems.size() > 0) {
                                for (KNB0102Output output : outItems) {
                                    repository.delete(output);
                                }
                            }

                            if (outItems.size() > 0) {
                                for (KNB0102Output output : outItems) {
                                    repository.create(output);
                                }
                            }
                            CommonLog.setInsertRecordeCountLog(logger, "勤怠データ(kn_company_data)", outItems.size());
                        } catch (Exception e) {
                            logger.error("stackTrace：", e);
                            processCheckFlag = false;
                            throw new RuntimeException("knb0102勤怠データ取込実行に異常が発生しました。");
                        }
                    } else {
                        processCheckFlag = false;
                        logger.error("入力データでエラーが発生しました。");
                    }
                } else {
                    logger.error("対象ファイルに正常終了の文字が存在しません。");
                }
            }

            // ■ファイル取込後、CSVファイルをリネームする
            if (processCheckFlag && processManualCheckFlag) {

                // ファイルのコピー先フォルダの中に、今日の日付のCSVファイル数を取得する
                int filesCount =
                        getFilesCount(destinationFolderCSV, systemYMD + fileExtensionFrontHalf,
                                fileExtensionFrontBackHalf);

                String fileName = systemYMD + fileExtensionFrontHalf + (filesCount + 1) + fileExtensionFrontBackHalf;

                // ファイルのコピー先フォルダの中に、想定ファイルがあるかどうか
                processCheckFlag = isfileExist(destinationFolderCSV, fileName);

                if (processCheckFlag) {
                    processCheckFlag = deleteFile(destinationFolderCSV, fileName);
                }

                // ファイルをリネームする
                processCheckFlag = fileRename(destinationFolderCSV, csvFile, fileName);

                if (processCheckFlag) {
                    logger.info("ファイル名変更完了;勤怠情報ファイル名={}", fileName);
                }
            }

            if (processCheckFlag) {
                if (type != null && type.equals("1")) {
                    // 工数チェックのジョブを呼び出し
                    executeJob(KOSU_CHECK_JOB_NAME, getParameter(deptCd, yearMonth));
                }
                logger.info("処理結果:正常終了");
            } else {
                throw new RuntimeException("knb0102勤怠データ取込処理実行に異常が発生しました。");
            }
        } catch (Exception e) {
            logger.error("stackTrace：", e);
            logger.info("処理結果:異常終了");

            if (type != null && type.equals("1")) {

                logger.error("knb0102勤怠データ取込処理実行に異常が発生しました。");
                // 工数チェックのジョブを呼び出し
                executeJob(KOSU_CHECK_JOB_NAME, getParameter(deptCd, yearMonth));
            }
        }

        return RepeatStatus.FINISHED;
    }

    private List<KNB0102Output> setItemData(ArrayList<String[]> csvDataList, String systemTime) {

        List<KNB0102Output> rtn = new ArrayList<KNB0102Output>();
        KNB0102Output output = new KNB0102Output();

        for (int row = 0; row < csvDataList.size(); row++) {

            output = new KNB0102Output();

            /** 社員CD */
            output.setEmpCd(csvDataList.get(row)[0]);

            /** 日付 */
            output.setDate(csvDataList.get(row)[1].replaceAll("/", "-"));

            /** 就労所属CD */
            output.setDeptCd(csvDataList.get(row)[2]);

            /** 勤務種別CD */
            output.setKinmuKbn(csvDataList.get(row)[3]);

            /** 勤怠CD */
            output.setKintaiCd(csvDataList.get(row)[4]);

            /** 始業時刻 */
            output.setOpeningTime(csvDataList.get(row)[5]);

            /** 終業時刻 */
            output.setEndingTime(csvDataList.get(row)[6]);

            /** 勤怠稼動時間 */
            output.setInputTime(getBigDecimalValue(csvDataList.get(row)[7]));

            /** 休憩時間 */
            output.setOffTime(getBigDecimalValue(csvDataList.get(row)[8]));

            /** 遅刻早退時間 */
            output.setCikokuSoutaiTime(getBigDecimalValue(csvDataList.get(row)[9]));

            /** 作成者 */
            output.setInsEmpCd(COMPY);

            /** 作成日 */
            output.setInsDt(systemTime);

            /** 更新者 */
            output.setUpdEmpCd(COMPY);

            /** 更新日 */
            output.setUpdDt(systemTime);

            rtn.add(output);
        }

        return rtn;
    }

    private boolean checkLogStr(String path, String file, String checkStr) {

        boolean rtn = false;

        File logFile = new File(path + file);
        List<String> content = new ArrayList<String>();

        try {
            content = FileUtils.readLines(logFile, "SJIS");

            for (String string : content) {

                if (string.indexOf(checkStr) > -1) {
                    rtn = true;
                    break;
                }
            }
        } catch (IOException e) {
            rtn = false;
        }

        return rtn;
    }

    private int getFilesCount(String path, String fileExtensionFrontHalf, String fileExtensionFrontBackHalf) {

        int rtn = 0;

        String[] fileNames = getFileName(path);

        for (String fileName : fileNames) {

            if (fileName.substring(0, 14).equals(fileExtensionFrontHalf) && fileName
                    .substring(fileName.length() - 4, fileName.length()).equals(fileExtensionFrontBackHalf)) {
                rtn = rtn + 1;
            }
        }

        return rtn;
    }

    private ArrayList<String[]> getCSVDataList(String path, String file) {

        ArrayList<String[]> csvFileList = new ArrayList<String[]>();

        String csvFilePath = path + file;

        try {
            CsvReader reader = new CsvReader(csvFilePath, ',', Charset.forName("UTF-8"));

            reader.readHeaders();
            while (reader.readRecord()) {
                csvFileList.add(reader.getValues());
            }
            reader.close();

        } catch (FileNotFoundException e) {
            processCheckFlag = false;
        } catch (IOException e) {
            processCheckFlag = false;
        }

        return csvFileList;
    }

    private String getManualLatestFile(String[] fileNames, String type) {

        String rtn = EMPTY;
        String tempFileName = EMPTY;
        long tempFileNameNum = 0;
        long maxFileNameNum = 0;


        if (type.equals("csv")) {

            if (null != fileNames) {
                for (String name : fileNames) {

                    if (name.length() == 17 && name.substring(name.length() - 9, name.length()).equals(fileExtension_C)) {

                        tempFileName = name;
                        break;
                    }
                }
            }
            rtn = tempFileName;

        } else if (type.equals("log")) {

            for (String name : fileNames) {

                if (name.length() >= 15 && name.substring(name.length() - 7, name.length()).equals(fileExtensionLog)) {

                    tempFileName = name.replaceAll(fileExtensionLog, EMPTY);

                    try {
                        tempFileNameNum = Long.valueOf(tempFileName);
                    } catch (NumberFormatException e) {
                        maxFileNameNum = 0;
                        break;
                    }

                    maxFileNameNum = maxFileNameNum < tempFileNameNum ? tempFileNameNum : maxFileNameNum;

                }
            }
            rtn = maxFileNameNum != 0 ? maxFileNameNum + fileExtensionLog : EMPTY;
        }

        return rtn;
    }

    private String getLatestFile(String[] fileNames, String systemYMD) {

        String rtn = EMPTY;
        String tempFileName = EMPTY;
        long tempFileNameNum = 0;
        long maxFileNameNum = 0;


        for (String name : fileNames) {

            if (name.length() >= 15 && name.substring(name.length() - 7, name.length()).equals(fileExtensionLog)
                    && name.substring(0, 8).equals(systemYMD)) {

                tempFileName = name.replaceAll(fileExtensionLog, EMPTY);

                try {
                    tempFileNameNum = Long.valueOf(tempFileName);
                } catch (NumberFormatException e) {
                    maxFileNameNum = 0;
                    break;
                }

                maxFileNameNum = maxFileNameNum < tempFileNameNum ? tempFileNameNum : maxFileNameNum;

            }
        }

        rtn = maxFileNameNum != 0 ? maxFileNameNum + fileExtensionLog : EMPTY;
        return rtn;
    }

    private String[] getFileName(String path) {
        File file = new File(path);
        String[] fileName = file.list();
        return fileName;
    }

    private boolean fileCopy(String prePath, String preFilename, String afterPath, String afterFilename) {

        boolean rtn = true;

        File source = new File(prePath + preFilename);
        File target = new File(afterPath + afterFilename);

        try {
            FileUtils.copyFile(source, target);
        } catch (IOException e) {
            rtn = false;
        }

        return rtn;
    }

    private boolean deleteFile(String path, String fileName) {

        boolean rtn = false;

        File target = new File(path + fileName);

        rtn = FileUtils.deleteQuietly(target);

        return rtn;
    }

    private boolean fileRename(String path, String preFilename, String afterFilename) {

        boolean rtn = false;

        File source = new File(path + preFilename);

        File target = new File(path + afterFilename);

        rtn = source.renameTo(target);

        return rtn;
    }

    private boolean isfileExist(String path, String fileName) {

        boolean rtn = false;

        File source = new File(path + fileName);

        rtn = source.exists();

        return rtn;
    }

    private BigDecimal getBigDecimalValue(String input1) {
        return (null == input1 || input1.equals(EMPTY)) ? null : new BigDecimal(input1);
    }

    /**
     * ジョブ実行処理
     *
     * @return 無し
     */
    private void executeJob(String jobName, String jobParameter) throws Exception {

        BatchJobRequestInput input = new BatchJobRequestInput();

        input.setJobName(jobName);
        input.setJobParameter(jobParameter);
        input.setPriority(1);
        input.setPollingStatus("INIT");

        repository.jobInsert(input);
    }

    private String getParameter(String deptCd, String yearMonth) {
        List<String> resultList = new ArrayList<>();
        resultList.add("isManual=1");
        resultList.add("isRetry=0");
        resultList.add("yearMonth=" + yearMonth);
        if (deptCd != null) {
            resultList.add("deptCd=" + deptCd);
        }
        return String.join(",", resultList);
    }

}
