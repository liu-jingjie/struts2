package jp.co.aeroasahi.tpkt.batch.cm.mail.fbfw003;

import java.util.List;
import jp.co.aeroasahi.tpkt.common.model.fw.BatchJobRequest;

public interface ReSendMailRepository {

    /**
     * バッチ実行ステータスが"FAILED"であるバッチを全て取得する
     *
     * @return 再送信が必要なバッチ情報
     */
    List<BatchJobRequest> findAllReSendmail();

}
