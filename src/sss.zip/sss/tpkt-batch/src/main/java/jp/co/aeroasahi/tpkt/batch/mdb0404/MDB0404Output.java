package jp.co.aeroasahi.tpkt.batch.mdb0404;

import java.math.BigDecimal;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.batch.item.ItemCountAware;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】部門経費管理＞のOutputBean。
 */
@Setter
@Getter
public class MDB0404Output implements ItemCountAware {

    private int count;

    /** 部門CD */
    @NotBlank
    @Size(min = 1, max = 6)
    private String deptCd;

    /** 勘定科目CD */
    @NotBlank
    @Size(min = 1, max = 8)
    private String kamokuCd;

    /** 会計年度 */
    @NotNull
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal fiscalYear;

    /** 会計期間 */
    @NotNull
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal fiscalMonth;

    /** 実績積算区分 */
    @NotBlank
    @Size(min = 1, max = 1)
    private String resultPlanedKbn;

    /** 原価 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal cost;

    /** 作成日 */
    @Size(min = 0, max = 23)
    private String createdAt;

    /** 更新日 */
    @Size(min = 0, max = 23)
    private String updatedAt;

    /** 会計年度 削除用(当月)*/
    private String GJAHR1;

    /** 会計期間 削除用(当月)*/
    private String MONAT1;

    /** 会計年度 削除用(前月或は指定した月)*/
    private String GJAHR2;

    /** 会計期間 削除用(前月或は指定した月)*/
    private String MONAT2;

    @Override
    public void setItemCount(int count) {
        this.count = count;
    }
}
