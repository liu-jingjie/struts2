package jp.co.aeroasahi.tpkt.batch.oj.ojb0201;

import java.util.Date;
import org.springframework.batch.item.ItemCountAware;
import lombok.Getter;
import lombok.Setter;


@Setter
@Getter
public class OjuenEntrustBranchInfoOutInfor implements ItemCountAware{
    private int count;
    /** 申請番号 */
    private String applyNum;
    /** 委託先枝番 */
    private String entrustBranchNum;
    /** 発注番号 */
    private String orderNum;
    /** 注文日 */
    private Date orderedOn;

    /** ステータス */
    private String status;
    /** プロジェクトID */
    private String projectId;



    @Override
    public void setItemCount(int count) {
        this.count = count;
    }
}
