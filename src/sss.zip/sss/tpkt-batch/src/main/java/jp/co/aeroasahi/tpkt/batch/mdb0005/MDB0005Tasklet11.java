package jp.co.aeroasahi.tpkt.batch.mdb0005;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

/**
 * スケジュールされたタイミングで、応受援帳票登録状況一覧および帳票登録状況一覧の作成処理を実行する
 */
@Component
@Scope("step")
public class MDB0005Tasklet11 implements Tasklet {

    @Inject
    DateFactory dateFactory;

    @Inject
    MDB0005Repository mdb0005Repository;

    @Autowired
    private BatchDataHolder batchDataHolder;

    /** DateTimeFormatterのパターン uuuu-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.SSS");

    /** ファイルの移動元フォルダ */
    @Value("${local.pool.path}")
    String localPoolPath;

    /** ファイルの転送元フォルダ */
    @Value("${local.send.path}")
    String localSendPath;

    /** 移動元フォルダでのファイル名 */
    private static final String TPSA0001 = "TPSA0001.txt";

    /** 転送元フォルダでのファイル名 */
    private static final String TSAP0001 = "TSAP0001.TXT";

    private static final Logger logger = LoggerFactory.getLogger(MDB0005Tasklet11.class);

    /**
     *
     * メインバッチ（帳票登録）
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return バッチ終了ステータス
     */
    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        LocalDateTime systemDateTime = dateFactory.newDateTime();
        String systemDateTimeStr = systemDateTime.format(dtf);

        // 実施時間
        batchDataHolder.setSystemDateTime(systemDateTimeStr);

        // 移動元フォルダ内および転送元フォルダ内にファイルが存在しない場合
        if(!isExistFile(getFileName(localPoolPath), TPSA0001) && !isExistFile(getFileName(localSendPath), TSAP0001)) {

            // 発注転送処理をスキップし、発注番号取込処理へ進む
            batchDataHolder.setCheckSkip1(true);
            logger.info("取込ファイルがないため処理をスキップしました。;ファイル名={};処理={}",TPSA0001, localPoolPath);
            logger.info("取込ファイルがないため処理をスキップしました。;ファイル名={};処理={}",TSAP0001, localSendPath);

        // 移動元フォルダ内または転送元フォルダ内にファイルが存在する場合
        }else {

            // 発注転送処理を実行する
            batchDataHolder.setCheckSkip1(false);

            // 発注転送
            executeJob("ojb0401Job", "systemDateTime=" + systemDateTimeStr);
        }

        return RepeatStatus.FINISHED;
    }

    /**
     * ジョブ実行処理
     *
     * @return 無し
     */
    private void executeJob(String jobName, String jobParameter) throws Exception {

        BatchJobRequestInput input = new BatchJobRequestInput();

        input.setJobName(jobName);
        input.setJobParameter(jobParameter);
        input.setPriority(1);
        input.setPollingStatus("INIT");

        mdb0005Repository.create(input);
    }

    private String[] getFileName(String path) {
        File file = new File(path);
        String[] fileName = file.list();
        return fileName;
    }

    private boolean isExistFile(String[] fileNames, String checkStr) {

        // false:ファイルが無い、true：ファイルが有る
        boolean rtn = false;

        if (fileNames == null) {
            return false;
        }

        for (String name : fileNames) {

            if (name.length() >= 12 && name.substring(name.length() - 12, name.length()).equals(checkStr)) {
                rtn = true;
            }
        }

        return rtn;
    }
}

