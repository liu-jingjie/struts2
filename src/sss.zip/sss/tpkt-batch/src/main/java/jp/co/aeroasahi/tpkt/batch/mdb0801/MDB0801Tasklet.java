package jp.co.aeroasahi.tpkt.batch.mdb0801;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import jp.co.aeroasahi.tpkt.batch.fw.CommonLog;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;
import jp.co.aeroasahi.tpkt.common.util.DateUtil;

@Component
@Scope("step")
public class MDB0801Tasklet implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0801Tasklet.class);

    @Inject
    MDB0801Repository mdb0801Repository;

    @Inject
    DateFactory dateFactory;

    @Value("#{jobParameters['kbn']}")
    public String kbn;

    @Value("#{jobParameters['yyyymm']}")
    public String yyyymm;

    @Value("#{jobParameters['systemDateTime']}")
    public String inputSystemDateTime;

    /** 【表示用】物件管理更新の準備期間の開始日 */
    @Value("${preparation.period.date.start}")
    String preparationPeriodDateStart;

    /** 【表示用】物件管理更新の準備期間の終了日 */
    @Value("${preparation.period.date.end}")
    String preparationPeriodDateEnd;

    /** DateTimeFormatterのパターン uuuuMM */
    private static final DateTimeFormatter dtfUUUUMM = DateTimeFormatter.ofPattern("uuuuMM");

    /** DateTimeFormatterのパターン uuuu-MM-dd */
    private static final DateTimeFormatter dtfUUUUMMDD = DateTimeFormatter.ofPattern("uuuu-MM-dd");

    /** DateTimeFormatterのパターン uuuu-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.SSS");

    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        LocalDateTime getSystemDateTime = LocalDateTime.parse(inputSystemDateTime, dtf);

        LocalDateTime preparationPeriodStart =
                LocalDateTime.of(getSystemDateTime.getYear(), Integer.parseInt(preparationPeriodDateStart.substring(0, 2)),
                        Integer.parseInt(preparationPeriodDateStart.substring(2, 4)), 0, 0);
        LocalDateTime preparationPeriodEnd =
                LocalDateTime.of(getSystemDateTime.getYear(), Integer.parseInt(preparationPeriodDateEnd.substring(0, 2)),
                        Integer.parseInt(preparationPeriodDateEnd.substring(2, 4)), 23, 59);

        LocalDateTime systemDateTime = null;
        if(kbn.equals("D") && !(getSystemDateTime.isBefore(preparationPeriodStart) || preparationPeriodEnd.isBefore(getSystemDateTime)) ) {
            systemDateTime = LocalDateTime.of(getSystemDateTime.getYear(), 3, 31, 0, 0);
        }else {
            systemDateTime = LocalDateTime.parse(inputSystemDateTime, dtf);
        }

        String systemYearMonth = systemDateTime.format(dtfUUUUMM);
        String systemDate = systemDateTime.format(dtfUUUUMMDD);

        // 当月の年度或は指定した月の年度
        String ym = "";
        // 当月の年度或は指定した月の年度開始年月
        String ym1 = "";
        // 当月の年度或は指定した月の年度終了年月
        String ym2 = "";

        // 日次処理の場合
        if (kbn.equals("D")) {
            ym = yearMonthToBeginOfFiscalYearMonth(systemYearMonth).substring(0, 4);
            ym1 = yearMonthToBeginOfFiscalYearMonth(systemYearMonth);
            ym2 = yearMonthToEndOfFiscalYearMonth(systemYearMonth);

            // 月次確定処理の場合
        } else if (kbn.equals("M")) {
            LocalDateTime yyyymmP = LocalDateTime.of(Integer.parseInt(yyyymm.substring(0, 4)),
                    Integer.parseInt(yyyymm.substring(4, 6)), 1, 1, 1);
            ym = yearMonthToBeginOfFiscalYearMonth(yyyymmP.format(dtfUUUUMM)).substring(0, 4);
            ym1 = yearMonthToBeginOfFiscalYearMonth(yyyymmP.format(dtfUUUUMM));
            ym2 = yearMonthToEndOfFiscalYearMonth(yyyymmP.format(dtfUUUUMM));
        }

        MDB0801Input inputKey = new MDB0801Input();
        inputKey.setYm1(ym1);
        inputKey.setYm2(ym2);
        inputKey.setYm(yyyymm);

        // ①プロジェクトIDを抽出
        logger.debug("①プロジェクトIDを抽出 開始");

        List<MDB0801Input> pjidList = new ArrayList<MDB0801Input>();
        List<MDB0801Input> pjidList2 = new ArrayList<MDB0801Input>();

        // 日次処理の場合
        if (kbn.equals("D")) {
            pjidList = mdb0801Repository.findAllPjId(inputKey);
            pjidList2 = mdb0801Repository.findAllPjId2(inputKey);
            // 月次確定処理の場合
        } else if (kbn.equals("M")) {
            pjidList = mdb0801Repository.findAllPjId3(inputKey);
            pjidList2 = mdb0801Repository.findAllPjId4(inputKey);
        }

        // 【TEMP】物件管理に登録する前に、データを編集する。
        List<MDB0801Output> outItems = setItemOutput(pjidList, ym, ym1, ym2, kbn, yyyymm, systemYearMonth, pjidList2, systemDate);

        if (outItems.size() > 0) {

            // 合計したレコードを追加しました。
            outItems.addAll(setSumItemOutput(outItems));

            logger.debug("delete 開始");
            // データを削除
            mdb0801Repository.delete();
            logger.debug("insert 開始");
            // データを登録
            for (MDB0801Output output : getEditList(outItems)) {
             // TODO numeric をデータ型 numeric に変換中に、算術オーバーフロー エラーが発生しました。END
                mdb0801Repository.create(output);
            }
        }

        CommonLog.setInsertRecordeCountLog(logger, "【TEMP】物件管理(temp_md_disp_property)", outItems.size());

        return RepeatStatus.FINISHED;
    }

    private List<MDB0801Input> getEditedResultListKey(List<MDB0801Input> inputList) {

        List<MDB0801Input> inputItems = new ArrayList<MDB0801Input>();

        Map<String, MDB0801Input> resultListMap = new HashMap<String, MDB0801Input>();

        for (MDB0801Input mdb0801Input : inputList) {

            String pjId = mdb0801Input.getPjId();
            String fiscalYear = getFiscalYearFromYm(mdb0801Input.getSoldFiscalYear().substring(0, 7).replaceAll("-", ""));
            String concat = pjId + fiscalYear;

            if (!resultListMap.containsKey(concat)) {
                mdb0801Input.setSoldFiscalYear(fiscalYear);
                resultListMap.put(concat, mdb0801Input);
            }
        }

        inputItems = new ArrayList<MDB0801Input>(resultListMap.values());

        return inputItems;
    }

    private List<MDB0801Input> getBuPjIdList(List<MDB0801Input> inputList) {

        List<MDB0801Input> rtn = new ArrayList<MDB0801Input>();
        MDB0801Input tempInupt = new MDB0801Input();

        HashMap<String, String> checkMap = new HashMap<String, String>();

        for (MDB0801Input mdb0801Input : inputList) {
            if (!checkMap.containsKey(mdb0801Input.getPjId().substring(0, 10))) {
                tempInupt = new MDB0801Input();
                tempInupt.setPjId(mdb0801Input.getPjId().substring(0, 10));
                checkMap.put(mdb0801Input.getPjId().substring(0, 10), "");
                rtn.add(tempInupt);
            }
        }

        return rtn;
    }

    private List<MDB0801Input> getPjAttIdList(List<MDB0801Input> inputList) {

        List<MDB0801Input> rtn = new ArrayList<MDB0801Input>();
        MDB0801Input tempInupt = new MDB0801Input();

        HashMap<String, String> checkMap = new HashMap<String, String>();

        for (MDB0801Input mdb0801Input : inputList) {
            if (!checkMap.containsKey(mdb0801Input.getPjId().substring(2, 10))) {
                tempInupt = new MDB0801Input();
                tempInupt.setPjAttId(mdb0801Input.getPjId().substring(2, 10));
                checkMap.put(mdb0801Input.getPjId().substring(2, 10), "");
                rtn.add(tempInupt);
            }
        }

        return rtn;
    }

    private Map<String, MDB0801Output> getSumResultMap(List<MDB0801Output> detailList) {

        Map<String, MDB0801Output> rtn = new HashMap<String, MDB0801Output>();

        MDB0801Output item = null;
        MDB0801Output mdb0801Output = null;
        String checkKey = null;

        for (int i = 0; i < detailList.size(); i++) {

            mdb0801Output = detailList.get(i);

            checkKey = mdb0801Output.getPjId().substring(0, 10) + mdb0801Output.getSoldFiscalYear();

            if (rtn.containsKey(checkKey)) {
                item = rtn.get(checkKey);

                // 物件管理の期首仕掛原価
                item.setKisyuWorkingCost(addBD(item.getKisyuWorkingCost(), mdb0801Output.getKisyuWorkingCost()));

                // 物件管理の⑬期首仕掛品原価差異
                item.setKisyuWorkingCostDifference(
                        addBD(item.getKisyuWorkingCostDifference(), mdb0801Output.getKisyuWorkingCostDifference()));

                // 物件管理の社員工数
                item.setEmpKosu(addBD(item.getEmpKosu(), mdb0801Output.getEmpKosu()));

                // 物件管理の積算社員工数
                item.setPlanedEmpKosu(addBD(item.getPlanedEmpKosu(), mdb0801Output.getPlanedEmpKosu()));

                // 物件管理の⑳人件費（直・間接合計）
                item.setLaborCost(addBD(item.getLaborCost(), mdb0801Output.getLaborCost()));

                // 物件管理の積算⑳人件費（直・間接合計）
                item.setPlanedLaborCost(addBD(item.getPlanedLaborCost(), mdb0801Output.getPlanedLaborCost()));

                // 物件管理の①人件費（直接）
                item.setDirectLaborCost(addBD(item.getDirectLaborCost(), mdb0801Output.getDirectLaborCost()));

                // 物件管理の積算①人件費（直接）
                item.setPlanedDirectLaborCost(
                        addBD(item.getPlanedDirectLaborCost(), mdb0801Output.getPlanedDirectLaborCost()));

                // 物件管理の臨時時間
                item.setTempEmpKosu(addBD(item.getTempEmpKosu(), mdb0801Output.getTempEmpKosu()));

                // 物件管理の積算臨時時間
                item.setPlanedTempEmpKosu(addBD(item.getPlanedTempEmpKosu(), mdb0801Output.getPlanedTempEmpKosu()));

                // 物件管理の②臨時人件費
                item.setTempLaborCost(addBD(item.getTempLaborCost(), mdb0801Output.getTempLaborCost()));

                // 物件管理の積算②臨時人件費
                item.setPlanedTempLaborCost(
                        addBD(item.getPlanedTempLaborCost(), mdb0801Output.getPlanedTempLaborCost()));

                // 物件管理の③－１外注費（一般）発注ベース
                item.setOutsideOrderedCost(addBD(item.getOutsideOrderedCost(), mdb0801Output.getOutsideOrderedCost()));

                // 物件管理の積算③－１外注費（一般）発注ベース
                item.setPlanedOutsideOrderingCost(
                        addBD(item.getPlanedOutsideOrderingCost(), mdb0801Output.getPlanedOutsideOrderingCost()));

                // 物件管理の③－２外注費（一般）支払ベース
                item.setOutsidePaidCost(addBD(item.getOutsidePaidCost(), mdb0801Output.getOutsidePaidCost()));

                // 物件管理の③－３外注費（関係）発注ベース
                item.setGroupOrderedCost(addBD(item.getGroupOrderedCost(), mdb0801Output.getGroupOrderedCost()));

                // 物件管理の積算③－３外注費（関係）発注ベース
                item.setPlanedGroupOrderingCost(
                        addBD(item.getPlanedGroupOrderingCost(), mdb0801Output.getPlanedGroupOrderingCost()));

                // 物件管理の③－４外注費（関係）支払ベース
                item.setGroupPaidCost(addBD(item.getGroupPaidCost(), mdb0801Output.getGroupPaidCost()));

                // 物件管理の業務委託費発注ベース
                item.setEntrustOrderedCost(addBD(item.getEntrustOrderedCost(), mdb0801Output.getEntrustOrderedCost()));

                // 物件管理の積算業務委託費
                item.setPlanedEntrustCost(addBD(item.getPlanedEntrustCost(), mdb0801Output.getPlanedEntrustCost()));

                // 物件管理の業務委託費支払ベース
                item.setEntrustPaidCost(addBD(item.getEntrustPaidCost(), mdb0801Output.getEntrustPaidCost()));

                // 物件管理の未発注外注費（一般）支払ベース
                item.setNonOrderedOutsidePaidCost(
                        addBD(item.getNonOrderedOutsidePaidCost(), mdb0801Output.getNonOrderedOutsidePaidCost()));

                // 物件管理の未発注外注費（関係）支払ベース
                item.setNonOrderedGroupPaidCost(
                        addBD(item.getNonOrderedGroupPaidCost(), mdb0801Output.getNonOrderedGroupPaidCost()));

                // 物件管理の④材料費
                item.setMaterialCost(addBD(item.getMaterialCost(), mdb0801Output.getMaterialCost()));

                // 物件管理の積算④材料費
                item.setPlanedMaterialCost(addBD(item.getPlanedMaterialCost(), mdb0801Output.getPlanedMaterialCost()));

                // 物件管理の⑤印刷製本費
                item.setPrintingBindingCost(
                        addBD(item.getPrintingBindingCost(), mdb0801Output.getPrintingBindingCost()));

                // 物件管理の積算⑤印刷製本費
                item.setPlanedPrintingBindingCost(
                        addBD(item.getPlanedPrintingBindingCost(), mdb0801Output.getPlanedPrintingBindingCost()));

                // 物件管理の⑥旅費交通費
                item.setTravelingCarfareCost(
                        addBD(item.getTravelingCarfareCost(), mdb0801Output.getTravelingCarfareCost()));

                // 物件管理の積算⑥旅費交通費
                item.setPlanedTravelingCarfareCost(
                        addBD(item.getPlanedTravelingCarfareCost(), mdb0801Output.getPlanedTravelingCarfareCost()));

                // 物件管理の⑦車両費
                item.setCarCost(addBD(item.getCarCost(), mdb0801Output.getCarCost()));

                // 物件管理の積算⑦車両費
                item.setPlanedCarCost(addBD(item.getPlanedCarCost(), mdb0801Output.getPlanedCarCost()));

                // 物件管理の⑧大型機材
                item.setLargeMachine(addBD(item.getLargeMachine(), mdb0801Output.getLargeMachine()));

                // 物件管理の積算⑧大型機材
                item.setPlanedLargeMachine(addBD(item.getPlanedLargeMachine(), mdb0801Output.getPlanedLargeMachine()));

                // 物件管理の⑨直接作業経費
                item.setDirectWorkCost(addBD(item.getDirectWorkCost(), mdb0801Output.getDirectWorkCost()));

                // 物件管理の積算⑨直接作業経費
                item.setPlanedDirectWorkCost(
                        addBD(item.getPlanedDirectWorkCost(), mdb0801Output.getPlanedDirectWorkCost()));

                // 物件管理の⑩直接費合計
                item.setDirectCost(addBD(item.getDirectCost(), mdb0801Output.getDirectCost()));

                // 物件管理の積算⑩直接費合計
                item.setPlanedDirectCost(addBD(item.getPlanedDirectCost(), mdb0801Output.getPlanedDirectCost()));

                // 物件管理の⑪間接費
                item.setIndirectCost(addBD(item.getIndirectCost(), mdb0801Output.getIndirectCost()));

                // 物件管理の積算⑪間接費
                item.setPlanedIndirectCost(addBD(item.getPlanedIndirectCost(), mdb0801Output.getPlanedIndirectCost()));

                // 物件管理の⑫その他事業部間取引
                item.setOtherCost(addBD(item.getOtherCost(), mdb0801Output.getOtherCost()));

                // 物件管理の⑭総原価
                item.setSogenka(addBD(item.getSogenka(), mdb0801Output.getSogenka()));

                // 物件管理の⑮他勘定振替
                item.setAccountTransaction(addBD(item.getAccountTransaction(), mdb0801Output.getAccountTransaction()));

                // 物件管理の⑯今期原価差異
                item.setThisFiscalYearCostDifference(
                        addBD(item.getThisFiscalYearCostDifference(), mdb0801Output.getThisFiscalYearCostDifference()));

                // 物件管理の⑰原価合計
                item.setGenkagokei(addBD(item.getGenkagokei(), mdb0801Output.getGenkagokei()));

                // 物件管理の追加原価
                item.setAddCost(addBD(item.getAddCost(), mdb0801Output.getAddCost()));

                // 物件管理の⑱売上原価
                item.setSalesCost(addBD(item.getSalesCost(), mdb0801Output.getSalesCost()));

                // 物件管理の⑲期末仕掛原価
                item.setKimatsuWorkingCost(addBD(item.getKimatsuWorkingCost(), mdb0801Output.getKimatsuWorkingCost()));

                // 物件管理の当該年度積算額
                item.setThisFiscalYearPlanedAmount(
                        addBD(item.getThisFiscalYearPlanedAmount(), mdb0801Output.getThisFiscalYearPlanedAmount()));

                // 物件管理の当該年度積算原価率
                item.setThisFiscalYearPlanedCostRate(
                        addBD(item.getThisFiscalYearPlanedCostRate(), mdb0801Output.getThisFiscalYearPlanedCostRate()));

                // 物件管理の全年度積算額
                item.setPlanedAmount(addBD(item.getPlanedAmount(), mdb0801Output.getPlanedAmount()));

                // 物件管理の全年度積算原価率
                item.setPlanedAmountRate(addBD(item.getPlanedAmountRate(), mdb0801Output.getPlanedAmountRate()));

                // 物件管理の見込み原価
                item.setPlanedCost(addBD(item.getPlanedCost(), mdb0801Output.getPlanedCost()));

                // 当該年度初回積算額
                item.setThisFiscalYearFirstPlanedAmount(addBD(item.getThisFiscalYearFirstPlanedAmount(),
                        mdb0801Output.getThisFiscalYearFirstPlanedAmount()));

                // 当該年度初回積算原価率
                item.setThisFiscalYearFirstPlanedCostRate(addBD(item.getThisFiscalYearFirstPlanedCostRate(),
                        mdb0801Output.getThisFiscalYearFirstPlanedCostRate()));

                // 全年度初回積算額
                item.setFirstPlanedAmount(addBD(item.getFirstPlanedAmount(), mdb0801Output.getFirstPlanedAmount()));

                // 全年度初回積算原価率
                item.setFirstPlanedAmountRate(
                        addBD(item.getFirstPlanedAmountRate(), mdb0801Output.getFirstPlanedAmountRate()));

                // 全年度の⑭
                item.setPreviousYear(
                        addBD(item.getPreviousYear(), mdb0801Output.getPreviousYear()));

            } else {
                item = new MDB0801Output();

                // 物件管理の期首仕掛原価
                item.setKisyuWorkingCost(getBigDecimalValue(mdb0801Output.getKisyuWorkingCost()));

                // 物件管理の⑬期首仕掛品原価差異
                item.setKisyuWorkingCostDifference(getBigDecimalValue(mdb0801Output.getKisyuWorkingCostDifference()));

                // 物件管理の社員工数
                item.setEmpKosu(getBigDecimalValue(mdb0801Output.getEmpKosu()));

                // 物件管理の積算社員工数
                item.setPlanedEmpKosu(getBigDecimalValue(mdb0801Output.getPlanedEmpKosu()));

                // 物件管理の⑳人件費（直・間接合計）
                item.setLaborCost(getBigDecimalValue(mdb0801Output.getLaborCost()));

                // 物件管理の積算⑳人件費（直・間接合計）
                item.setPlanedLaborCost(getBigDecimalValue(mdb0801Output.getPlanedLaborCost()));

                // 物件管理の①人件費（直接）
                item.setDirectLaborCost(getBigDecimalValue(mdb0801Output.getDirectLaborCost()));

                // 物件管理の積算①人件費（直接）
                item.setPlanedDirectLaborCost(getBigDecimalValue(mdb0801Output.getPlanedDirectLaborCost()));

                // 物件管理の臨時時間
                item.setTempEmpKosu(getBigDecimalValue(mdb0801Output.getTempEmpKosu()));

                // 物件管理の積算臨時時間
                item.setPlanedTempEmpKosu(getBigDecimalValue(mdb0801Output.getPlanedTempEmpKosu()));

                // 物件管理の②臨時人件費
                item.setTempLaborCost(getBigDecimalValue(mdb0801Output.getTempLaborCost()));

                // 物件管理の積算②臨時人件費
                item.setPlanedTempLaborCost(getBigDecimalValue(mdb0801Output.getPlanedTempLaborCost()));

                // 物件管理の③－１外注費（一般）発注ベース
                item.setOutsideOrderedCost(getBigDecimalValue(mdb0801Output.getOutsideOrderedCost()));

                // 物件管理の積算③－１外注費（一般）発注ベース
                item.setPlanedOutsideOrderingCost(getBigDecimalValue(mdb0801Output.getPlanedOutsideOrderingCost()));

                // 物件管理の③－２外注費（一般）支払ベース
                item.setOutsidePaidCost(getBigDecimalValue(mdb0801Output.getOutsidePaidCost()));

                // 物件管理の③－３外注費（関係）発注ベース
                item.setGroupOrderedCost(getBigDecimalValue(mdb0801Output.getGroupOrderedCost()));

                // 物件管理の積算③－３外注費（関係）発注ベース
                item.setPlanedGroupOrderingCost(getBigDecimalValue(mdb0801Output.getPlanedGroupOrderingCost()));

                // 物件管理の③－４外注費（関係）支払ベース
                item.setGroupPaidCost(getBigDecimalValue(mdb0801Output.getGroupPaidCost()));

                // 物件管理の業務委託費発注ベース
                item.setEntrustOrderedCost(getBigDecimalValue(mdb0801Output.getEntrustOrderedCost()));

                // 物件管理の積算業務委託費
                item.setPlanedEntrustCost(getBigDecimalValue(mdb0801Output.getPlanedEntrustCost()));

                // 物件管理の業務委託費支払ベース
                item.setEntrustPaidCost(getBigDecimalValue(mdb0801Output.getEntrustPaidCost()));

                // 物件管理の未発注外注費（一般）支払ベース
                item.setNonOrderedOutsidePaidCost(getBigDecimalValue(mdb0801Output.getNonOrderedOutsidePaidCost()));

                // 物件管理の未発注外注費（関係）支払ベース
                item.setNonOrderedGroupPaidCost(getBigDecimalValue(mdb0801Output.getNonOrderedGroupPaidCost()));

                // 物件管理の④材料費
                item.setMaterialCost(getBigDecimalValue(mdb0801Output.getMaterialCost()));

                // 物件管理の積算④材料費
                item.setPlanedMaterialCost(getBigDecimalValue(mdb0801Output.getPlanedMaterialCost()));

                // 物件管理の⑤印刷製本費
                item.setPrintingBindingCost(getBigDecimalValue(mdb0801Output.getPrintingBindingCost()));

                // 物件管理の積算⑤印刷製本費
                item.setPlanedPrintingBindingCost(getBigDecimalValue(mdb0801Output.getPlanedPrintingBindingCost()));

                // 物件管理の⑥旅費交通費
                item.setTravelingCarfareCost(getBigDecimalValue(mdb0801Output.getTravelingCarfareCost()));

                // 物件管理の積算⑥旅費交通費
                item.setPlanedTravelingCarfareCost(getBigDecimalValue(mdb0801Output.getPlanedTravelingCarfareCost()));

                // 物件管理の⑦車両費
                item.setCarCost(getBigDecimalValue(mdb0801Output.getCarCost()));

                // 物件管理の積算⑦車両費
                item.setPlanedCarCost(getBigDecimalValue(mdb0801Output.getPlanedCarCost()));

                // 物件管理の⑧大型機材
                item.setLargeMachine(getBigDecimalValue(mdb0801Output.getLargeMachine()));

                // 物件管理の積算⑧大型機材
                item.setPlanedLargeMachine(getBigDecimalValue(mdb0801Output.getPlanedLargeMachine()));

                // 物件管理の⑨直接作業経費
                item.setDirectWorkCost(getBigDecimalValue(mdb0801Output.getDirectWorkCost()));

                // 物件管理の積算⑨直接作業経費
                item.setPlanedDirectWorkCost(getBigDecimalValue(mdb0801Output.getPlanedDirectWorkCost()));

                // 物件管理の⑩直接費合計
                item.setDirectCost(getBigDecimalValue(mdb0801Output.getDirectCost()));

                // 物件管理の積算⑩直接費合計
                item.setPlanedDirectCost(getBigDecimalValue(mdb0801Output.getPlanedDirectCost()));

                // 物件管理の⑪間接費
                item.setIndirectCost(getBigDecimalValue(mdb0801Output.getIndirectCost()));

                // 物件管理の積算⑪間接費
                item.setPlanedIndirectCost(getBigDecimalValue(mdb0801Output.getPlanedIndirectCost()));

                // 物件管理の⑫その他事業部間取引
                item.setOtherCost(getBigDecimalValue(mdb0801Output.getOtherCost()));

                // 物件管理の⑭総原価
                item.setSogenka(getBigDecimalValue(mdb0801Output.getSogenka()));

                // 物件管理の⑮他勘定振替
                item.setAccountTransaction(getBigDecimalValue(mdb0801Output.getAccountTransaction()));

                // 物件管理の⑯今期原価差異
                item.setThisFiscalYearCostDifference(
                        getBigDecimalValue(mdb0801Output.getThisFiscalYearCostDifference()));

                // 物件管理の⑰原価合計
                item.setGenkagokei(getBigDecimalValue(mdb0801Output.getGenkagokei()));

                // 物件管理の追加原価
                item.setAddCost(getBigDecimalValue(mdb0801Output.getAddCost()));

                // 物件管理の⑱売上原価
                item.setSalesCost(getBigDecimalValue(mdb0801Output.getSalesCost()));

                // 物件管理の⑲期末仕掛原価
                item.setKimatsuWorkingCost(getBigDecimalValue(mdb0801Output.getKimatsuWorkingCost()));

                // 物件管理の当該年度積算額
                item.setThisFiscalYearPlanedAmount(getBigDecimalValue(mdb0801Output.getThisFiscalYearPlanedAmount()));

                // 物件管理の当該年度積算原価率
                item.setThisFiscalYearPlanedCostRate(
                        getBigDecimalValue(mdb0801Output.getThisFiscalYearPlanedCostRate()));

                // 物件管理の全年度積算額
                item.setPlanedAmount(getBigDecimalValue(mdb0801Output.getPlanedAmount()));

                // 物件管理の全年度積算原価率
                item.setPlanedAmountRate(getBigDecimalValue(mdb0801Output.getPlanedAmountRate()));

                // 物件管理の見込み原価
                item.setPlanedCost(getBigDecimalValue(mdb0801Output.getPlanedCost()));

                // 進捗率
                if (null == mdb0801Output.getProgressRate()) {
                    item.setProgressRate(getBigDecimalValue(null));
                }

                // 当該年度初回積算額
                item.setThisFiscalYearFirstPlanedAmount(
                        getBigDecimalValue(mdb0801Output.getThisFiscalYearFirstPlanedAmount()));

                // 当該年度初回積算原価率
                item.setThisFiscalYearFirstPlanedCostRate(
                        getBigDecimalValue(mdb0801Output.getThisFiscalYearFirstPlanedCostRate()));

                // 全年度初回積算額
                item.setFirstPlanedAmount(getBigDecimalValue(mdb0801Output.getFirstPlanedAmount()));

                // 全年度初回積算原価率
                item.setFirstPlanedAmountRate(getBigDecimalValue(mdb0801Output.getFirstPlanedAmountRate()));

                // 全年度の⑭
                item.setPreviousYear(getBigDecimalValue(mdb0801Output.getPreviousYear()));

                rtn.put(checkKey, item);
                item = null;
            }

            // 最後のSumした結果を追加する
            if (i == detailList.size() - 1 && null != item) {
                rtn.put(checkKey, item);
            }
        }

        return rtn;
    }

    private List<MDB0801Output> setSumItemOutput(List<MDB0801Output> detailList) throws CloneNotSupportedException {
        List<MDB0801Output> rtnList = new ArrayList<MDB0801Output>();
        MDB0801Output output = new MDB0801Output();
        List<MDB0801Output> keyList = getKeyList(detailList);
        Map<String, MDB0801Output> sumResultMap = getSumResultMap(detailList);
        MDB0801Output tempOutputItem = new MDB0801Output();

        for (MDB0801Output mdb0801Output : keyList) {

            tempOutputItem =
                    sumResultMap.get(mdb0801Output.getPjId().substring(0, 10) + mdb0801Output.getSoldFiscalYear());

            output = (MDB0801Output) mdb0801Output.clone();

            // 物件管理のプロジェクトID(10桁)
            output.setPjId(mdb0801Output.getPjId().substring(0, 10));

            // 売上年度
            output.setSoldFiscalYear(mdb0801Output.getSoldFiscalYear());

            // 物件管理の期首仕掛原価
            output.setKisyuWorkingCost(tempOutputItem.getKisyuWorkingCost());

            // 物件管理の⑬期首仕掛品原価差異
            output.setKisyuWorkingCostDifference(tempOutputItem.getKisyuWorkingCostDifference());

            // 物件管理の社員工数
            output.setEmpKosu(tempOutputItem.getEmpKosu());

            // 物件管理の積算社員工数
            output.setPlanedEmpKosu(tempOutputItem.getPlanedEmpKosu());

            // 物件管理の⑳人件費（直・間接合計）
            output.setLaborCost(tempOutputItem.getLaborCost());

            // 物件管理の積算⑳人件費（直・間接合計）
            output.setPlanedLaborCost(tempOutputItem.getPlanedLaborCost());

            // 物件管理の①人件費（直接）
            output.setDirectLaborCost(tempOutputItem.getDirectLaborCost());

            // 物件管理の積算①人件費（直接）
            output.setPlanedDirectLaborCost(tempOutputItem.getPlanedDirectLaborCost());

            // 物件管理の臨時時間
            output.setTempEmpKosu(tempOutputItem.getTempEmpKosu());

            // 物件管理の積算臨時時間
            output.setPlanedTempEmpKosu(tempOutputItem.getPlanedTempEmpKosu());

            // 物件管理の②臨時人件費
            output.setTempLaborCost(tempOutputItem.getTempLaborCost());

            // 物件管理の積算②臨時人件費
            output.setPlanedTempLaborCost(tempOutputItem.getPlanedTempLaborCost());

            // 物件管理の③－１外注費（一般）発注ベース
            output.setOutsideOrderedCost(tempOutputItem.getOutsideOrderedCost());

            // 物件管理の積算③－１外注費（一般）発注ベース
            output.setPlanedOutsideOrderingCost(tempOutputItem.getPlanedOutsideOrderingCost());

            // 物件管理の③－２外注費（一般）支払ベース
            output.setOutsidePaidCost(tempOutputItem.getOutsidePaidCost());

            // 物件管理の③－３外注費（関係）発注ベース
            output.setGroupOrderedCost(tempOutputItem.getGroupOrderedCost());

            // 物件管理の積算③－３外注費（関係）発注ベース
            output.setPlanedGroupOrderingCost(tempOutputItem.getPlanedGroupOrderingCost());

            // 物件管理の③－４外注費（関係）支払ベース
            output.setGroupPaidCost(tempOutputItem.getGroupPaidCost());

            // 物件管理の業務委託費発注ベース
            output.setEntrustOrderedCost(tempOutputItem.getEntrustOrderedCost());

            // 物件管理の積算業務委託費
            output.setPlanedEntrustCost(tempOutputItem.getPlanedEntrustCost());

            // 物件管理の業務委託費支払ベース
            output.setEntrustPaidCost(tempOutputItem.getEntrustPaidCost());

            // 物件管理の未発注外注費（一般）支払ベース
            output.setNonOrderedOutsidePaidCost(tempOutputItem.getNonOrderedOutsidePaidCost());

            // 物件管理の未発注外注費（関係）支払ベース
            output.setNonOrderedGroupPaidCost(tempOutputItem.getNonOrderedGroupPaidCost());

            // 物件管理の④材料費
            output.setMaterialCost(tempOutputItem.getMaterialCost());

            // 物件管理の積算④材料費
            output.setPlanedMaterialCost(tempOutputItem.getPlanedMaterialCost());

            // 物件管理の⑤印刷製本費
            output.setPrintingBindingCost(tempOutputItem.getPrintingBindingCost());

            // 物件管理の積算⑤印刷製本費
            output.setPlanedPrintingBindingCost(tempOutputItem.getPlanedPrintingBindingCost());

            // 物件管理の⑥旅費交通費
            output.setTravelingCarfareCost(tempOutputItem.getTravelingCarfareCost());

            // 物件管理の積算⑥旅費交通費
            output.setPlanedTravelingCarfareCost(tempOutputItem.getPlanedTravelingCarfareCost());

            // 物件管理の⑦車両費
            output.setCarCost(tempOutputItem.getCarCost());

            // 物件管理の積算⑦車両費
            output.setPlanedCarCost(tempOutputItem.getPlanedCarCost());

            // 物件管理の⑧大型機材
            output.setLargeMachine(tempOutputItem.getLargeMachine());

            // 物件管理の積算⑧大型機材
            output.setPlanedLargeMachine(tempOutputItem.getPlanedLargeMachine());

            // 物件管理の⑨直接作業経費
            output.setDirectWorkCost(tempOutputItem.getDirectWorkCost());

            // 物件管理の積算⑨直接作業経費
            output.setPlanedDirectWorkCost(tempOutputItem.getPlanedDirectWorkCost());

            // 物件管理の⑩直接費合計
            output.setDirectCost(tempOutputItem.getDirectCost());

            // 物件管理の積算⑩直接費合計
            output.setPlanedDirectCost(tempOutputItem.getPlanedDirectCost());

            // 物件管理の⑪間接費
            output.setIndirectCost(tempOutputItem.getIndirectCost());

            // 物件管理の積算⑪間接費
            output.setPlanedIndirectCost(tempOutputItem.getPlanedIndirectCost());

            // 物件管理の⑫その他事業部間取引
            output.setOtherCost(tempOutputItem.getOtherCost());

            // 物件管理の⑭総原価
            output.setSogenka(tempOutputItem.getSogenka());

            // 物件管理の⑮他勘定振替
            output.setAccountTransaction(tempOutputItem.getAccountTransaction());

            // 物件管理の⑯今期原価差異
            output.setThisFiscalYearCostDifference(tempOutputItem.getThisFiscalYearCostDifference());

            // 物件管理の⑰原価合計
            output.setGenkagokei(tempOutputItem.getGenkagokei());

            // 物件管理の追加原価
            output.setAddCost(tempOutputItem.getAddCost());

            // 物件管理の⑱売上原価
            output.setSalesCost(tempOutputItem.getSalesCost());

            // 物件管理の⑲期末仕掛原価
            output.setKimatsuWorkingCost(tempOutputItem.getKimatsuWorkingCost());

            // 物件管理の当該年度積算額
            output.setThisFiscalYearPlanedAmount(tempOutputItem.getThisFiscalYearPlanedAmount());

            // 物件管理の当該年度積算原価率
            if(tempOutputItem.getThisFiscalYearPlanedAmount().compareTo(BigDecimal.ZERO) == 0) {
                output.setThisFiscalYearPlanedCostRate(BigDecimal.ZERO);
            }else {
                output.setThisFiscalYearPlanedCostRate(tempOutputItem.getSogenka().divide(tempOutputItem.getThisFiscalYearPlanedAmount(), 3, BigDecimal.ROUND_HALF_UP));
            }

            // 物件管理の全年度積算額
            output.setPlanedAmount(tempOutputItem.getPlanedAmount());

            // 物件管理の全年度積算原価率
            if(tempOutputItem.getPlanedAmount().compareTo(BigDecimal.ZERO) == 0) {
                output.setPlanedAmountRate(BigDecimal.ZERO);
            }else {
                output.setPlanedAmountRate(tempOutputItem.getPreviousYear().divide(tempOutputItem.getPlanedAmount(), 3, BigDecimal.ROUND_HALF_UP));
            }

            // 物件管理の見込み原価
            output.setPlanedCost(tempOutputItem.getPlanedCost());

            // 当該年度初回積算額
            output.setThisFiscalYearFirstPlanedAmount(null == tempOutputItem.getThisFiscalYearFirstPlanedAmount()?BigDecimal.ZERO:tempOutputItem.getThisFiscalYearFirstPlanedAmount());

            // 当該年度初回積算原価率
            if(tempOutputItem.getThisFiscalYearFirstPlanedAmount().compareTo(BigDecimal.ZERO) == 0) {
                output.setThisFiscalYearFirstPlanedCostRate(BigDecimal.ZERO);
            }else {
                output.setThisFiscalYearFirstPlanedCostRate(tempOutputItem.getSogenka().divide(tempOutputItem.getThisFiscalYearFirstPlanedAmount(), 3, BigDecimal.ROUND_HALF_UP));
            }

            // 全年度初回積算額
            output.setFirstPlanedAmount(tempOutputItem.getFirstPlanedAmount());

            // 全年度初回積算原価率
            if(tempOutputItem.getFirstPlanedAmount().compareTo(BigDecimal.ZERO) == 0) {
                output.setFirstPlanedAmountRate(BigDecimal.ZERO);
            }else {
                output.setFirstPlanedAmountRate(tempOutputItem.getPreviousYear().divide(tempOutputItem.getFirstPlanedAmount(), 3, BigDecimal.ROUND_HALF_UP));
            }

            // 枝番 「－」で表示（表示対象外）
            output.setBranchNum("-");

            // 営業担当者ＣＤ 「－」で表示（表示対象外）
            output.setSalesEmpCd("-");

            // 営業担当者名 「－」で表示（表示対象外）
            output.setSalesEmpName("-");

            // 生産担当部門支社ＣＤ 「－」で表示（表示対象外）
            output.setProductDeptBranchCd("-");

            // 生産担当部門支社名称 「－」で表示（表示対象外）
            output.setProductDeptBranchName("-");

            // 生産担当部門部ＣＤ 「－」で表示（表示対象外）
            output.setProductMDeptCd("-");

            // 生産担当部門部名称 「－」で表示（表示対象外）
            output.setProductMDeptName("-");

            // 生産担当部門ＣＤ 「－」で表示（表示対象外）
            output.setProductDeptCd("-");

            // 生産担当部門名称 「－」で表示（表示対象外）
            output.setProductDeptName("-");

            // 生産担当者ＣＤ 「－」で表示（表示対象外）
            output.setProductEmpCd("-");

            // 生産担当者名 「－」で表示（表示対象外）
            output.setProductEmpName("-");

            // 生産高 「－」で表示（表示対象外）
            output.setSeisandaka(BigDecimal.ZERO);

            // 積算⑰原価合計 「－」で表示（表示対象外）
            output.setPlanedGenkagokei(BigDecimal.ZERO);

            // 初回積算日 「－」で表示（表示対象外）
            output.setFirstPlanedOn(null);

            // 更新積算日 「－」で表示（表示対象外）
            output.setUpdatePlanedOn(null);

            rtnList.add(output);
        }

        return rtnList;
    }

    private Map<String, MDB0801Input> getEditedExceptPayBasisList(List<MDB0801Input> exceptPayBasisList,
            List<MDB0801Input> receiveresultList, List<MDB0801Input> rResultList, Map<String, MDB0801Input> rResultYMListMap) {

        // 同じ年度とプロジェクトIDの値を合計する、
        Map<String, MDB0801Input> rtn = new HashMap<String, MDB0801Input>();
        MDB0801Input item = null;
        String checkKey = "";
        MDB0801Input mdb0801Input = new MDB0801Input();

        // 売上テーブルのレコードに年度を設定する
        for (MDB0801Input amountMdb0801Input : exceptPayBasisList) {

            String pjId = amountMdb0801Input.getPjId();
            int ymAmount = Integer.parseInt(amountMdb0801Input.getYmAmount());

            if(pjId.substring(2, 3).equals("R")) {

                for (MDB0801Input rResultListInput : rResultList) {
                    int from = 190001;
                    int to = 999901;
                    if (rResultListInput.getPjAttId().equals(pjId.substring(2, 10)) && ymAmount >= from && ymAmount <= to) {
                        amountMdb0801Input.setSoldFiscalYear(rResultYMListMap.get(pjId).getSoldFiscalYear());
                        break;
                    }
                }
            }else {
                boolean inFlag = true;

                for (MDB0801Input receiveMDB0801Input : receiveresultList) {

                    int from = Integer.parseInt(receiveMDB0801Input.getDateFrom());
                    int to = Integer.parseInt(receiveMDB0801Input.getDateTo());

                    if (receiveMDB0801Input.getPjId().equals(pjId) && ymAmount >= from && ymAmount <= to) {
                        amountMdb0801Input.setSoldFiscalYear(receiveMDB0801Input.getSoldFiscalYear());
                        break;
                    }
                }

                if(inFlag) {
                    for (MDB0801Input rResultListInput : rResultList) {
                        if(pjId.substring(2, 3).equals("P")) {
                            int from = 190001;
                            int to = 999901;
                            if (rResultListInput.getPjAttId().equals(pjId.substring(2, 10)) && ymAmount >= from && ymAmount <= to) {
                                if(null != rResultYMListMap.get(pjId)) {
                                    amountMdb0801Input.setSoldFiscalYear(rResultYMListMap.get(pjId).getSoldFiscalYear());
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }

        for (int i = 0; i < exceptPayBasisList.size(); i++) {

            mdb0801Input = exceptPayBasisList.get(i);

            checkKey = mdb0801Input.getPjId() + mdb0801Input.getSoldFiscalYear();

            if (rtn.containsKey(checkKey)) {
                item = rtn.get(checkKey);

                // 外注費（一般）発注ベース
                item.setOutsideOrderedCost(addBD(item.getOutsideOrderedCost(), mdb0801Input.getOutsideOrderedCost()));

                // 外注費（一般）支払ベース
                item.setOutsidePaidCost(addBD(item.getOutsidePaidCost(), mdb0801Input.getOutsidePaidCost()));

                // 外注費（関係）発注ベース
                item.setGroupOrderedCost(addBD(item.getGroupOrderedCost(), mdb0801Input.getGroupOrderedCost()));

                // 外注費（関係）支払ベース
                item.setGroupPaidCost(addBD(item.getGroupPaidCost(), mdb0801Input.getGroupPaidCost()));

                // 業務委託費発注ベース
                item.setEntrustOrderedCost(addBD(item.getEntrustOrderedCost(), mdb0801Input.getEntrustOrderedCost()));

                // 業務委託費支払ベース
                item.setEntrustPaidCost(addBD(item.getEntrustPaidCost(), mdb0801Input.getEntrustPaidCost()));

            } else {
                item = new MDB0801Input();

                // 売上年度
                item.setSoldFiscalYear(mdb0801Input.getSoldFiscalYear());

                // プロジェクトID
                item.setPjId(mdb0801Input.getPjId());


                // 外注費（一般）発注ベース
                item.setOutsideOrderedCost(mdb0801Input.getOutsideOrderedCost());

                // 外注費（一般）支払ベース
                item.setOutsidePaidCost(mdb0801Input.getOutsidePaidCost());

                // 外注費（関係）発注ベース
                item.setGroupOrderedCost(mdb0801Input.getGroupOrderedCost());

                // 外注費（関係）支払ベース
                item.setGroupPaidCost(mdb0801Input.getGroupPaidCost());

                // 業務委託費発注ベース
                item.setEntrustOrderedCost(mdb0801Input.getEntrustOrderedCost());

                // 業務委託費支払ベース
                item.setEntrustPaidCost(mdb0801Input.getEntrustPaidCost());

                rtn.put(checkKey, item);
                item = null;
            }

            // 最後のSumした結果を追加する
            if (i == exceptPayBasisList.size() - 1 && null != item) {
                rtn.put(checkKey, item);
            }
        }

        return rtn;
    }

    private Map<String, MDB0801Input> getEditedPayBasisList(List<MDB0801Input> payBasisList,
            List<MDB0801Input> receiveresultList, List<MDB0801Input> rResultList, Map<String, MDB0801Input> rResultYMListMap) {

        // 同じ年度とプロジェクトIDの値を合計する、
        Map<String, MDB0801Input> rtn = new HashMap<String, MDB0801Input>();
        MDB0801Input item = null;
        String checkKey = "";
        MDB0801Input mdb0801Input = new MDB0801Input();

        // 売上テーブルのレコードに年度を設定する
        for (MDB0801Input amountMdb0801Input : payBasisList) {

            String pjId = amountMdb0801Input.getPjId();
            int ymAmount = Integer.parseInt(amountMdb0801Input.getYmAmount());

            if(pjId.substring(2, 3).equals("R")) {

                for (MDB0801Input rResultListInput : rResultList) {
                    int from = 190001;
                    int to = 999901;
                    if (rResultListInput.getPjAttId().equals(pjId.substring(2, 10)) && ymAmount >= from && ymAmount <= to) {
                        amountMdb0801Input.setSoldFiscalYear(rResultYMListMap.get(pjId).getSoldFiscalYear());
                        break;
                    }
                }
            }else {
                boolean inFlag = true;

                for (MDB0801Input receiveMDB0801Input : receiveresultList) {

                    int from = Integer.parseInt(receiveMDB0801Input.getDateFrom());
                    int to = Integer.parseInt(receiveMDB0801Input.getDateTo());

                    if (receiveMDB0801Input.getPjId().equals(pjId) && ymAmount >= from && ymAmount <= to) {
                        amountMdb0801Input.setSoldFiscalYear(receiveMDB0801Input.getSoldFiscalYear());
                        break;
                    }
                }

                if(inFlag) {
                    for (MDB0801Input rResultListInput : rResultList) {
                        if(pjId.substring(2, 3).equals("P")) {
                            int from = 190001;
                            int to = 999901;
                            if (rResultListInput.getPjAttId().equals(pjId.substring(2, 10)) && ymAmount >= from && ymAmount <= to) {
                                if(null != rResultYMListMap.get(pjId)) {
                                    amountMdb0801Input.setSoldFiscalYear(rResultYMListMap.get(pjId).getSoldFiscalYear());
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }

        for (int i = 0; i < payBasisList.size(); i++) {

            mdb0801Input = payBasisList.get(i);

            checkKey = mdb0801Input.getPjId() + mdb0801Input.getSoldFiscalYear();

            if (rtn.containsKey(checkKey)) {
                item = rtn.get(checkKey);

                // 外注費（一般）支払ベース
                item.setNonOrderedOutsidePaidCost(addBD(item.getNonOrderedOutsidePaidCost(), mdb0801Input.getOutsidePaidCost()));

                // 外注費（関係）支払ベース
                item.setNonOrderedGroupPaidCost(addBD(item.getNonOrderedGroupPaidCost(), mdb0801Input.getGroupPaidCost()));

            } else {
                item = new MDB0801Input();

                // 売上年度
                item.setSoldFiscalYear(mdb0801Input.getSoldFiscalYear());

                // プロジェクトID
                item.setPjId(mdb0801Input.getPjId());

                // 外注費（一般）支払ベース
                item.setNonOrderedOutsidePaidCost(mdb0801Input.getOutsidePaidCost());

                // 外注費（関係）支払ベース
                item.setNonOrderedGroupPaidCost(mdb0801Input.getGroupPaidCost());

                rtn.put(checkKey, item);
                item = null;
            }

            // 最後のSumした結果を追加する
            if (i == payBasisList.size() - 1 && null != item) {
                rtn.put(checkKey, item);
            }
        }

        return rtn;
    }

    private Map<String, MDB0801Input> getEditedSapWidgetCostList(List<MDB0801Input> sapWidgetCostList,
            List<MDB0801Input> receiveresultList, List<MDB0801Input> rResultList, Map<String, MDB0801Input> rResultYMListMap, String receiveDate) {

        // 同じ年度とプロジェクトIDの値を合計する、
        Map<String, MDB0801Input> rtn = new HashMap<String, MDB0801Input>();
        MDB0801Input item = null;
        String checkKey = "";
        MDB0801Input mdb0801Input = new MDB0801Input();

//        String fiscalYM = yearMonthToBeginOfFiscalYearMonth(receiveDate).substring(0, 4);

        for (MDB0801Input input : sapWidgetCostList) {
            input.setSoldFiscalYear(yearMonthToBeginOfFiscalYearMonth(input.getYmAmount()).substring(0, 4));
        }

        for (int i = 0; i < sapWidgetCostList.size(); i++) {

            mdb0801Input = sapWidgetCostList.get(i);

            checkKey = mdb0801Input.getPjId() + mdb0801Input.getSoldFiscalYear();

            if (rtn.containsKey(checkKey)) {
                item = rtn.get(checkKey);

                if(Integer.parseInt(item.getYmAmount()) < Integer.parseInt(mdb0801Input.getYmAmount())) {

                    // 売上年度
                    item.setSoldFiscalYear(mdb0801Input.getSoldFiscalYear());

                    // ym
                    item.setYmAmount(mdb0801Input.getYmAmount());

                    // 期首仕掛原価
                    item.setKisyuWorkingCost(mdb0801Input.getKisyuWorkingCost());

                    // 期首仕掛品原価差異
                    item.setKisyuWorkingCostDifference(mdb0801Input.getKisyuWorkingCostDifference());

                    // 今期原価差異
                    item.setThisFiscalYearCostDifference(mdb0801Input.getThisFiscalYearCostDifference());
                }

            } else {
                item = new MDB0801Input();

                // 売上年度
                item.setSoldFiscalYear(mdb0801Input.getSoldFiscalYear());

                // プロジェクトID
                item.setPjId(mdb0801Input.getPjId());

                // ym
                item.setYmAmount(mdb0801Input.getYmAmount());

                // 期首仕掛原価
                item.setKisyuWorkingCost(mdb0801Input.getKisyuWorkingCost());

                // 期首仕掛品原価差異
                item.setKisyuWorkingCostDifference(mdb0801Input.getKisyuWorkingCostDifference());

                // 今期原価差異
                item.setThisFiscalYearCostDifference(mdb0801Input.getThisFiscalYearCostDifference());

                rtn.put(checkKey, item);
                item = null;
            }

            // 最後のSumした結果を追加する
            if (i == sapWidgetCostList.size() - 1 && null != item) {
                rtn.put(checkKey, item);
            }
        }

        return rtn;
    }

    private Map<String, MDB0801Input> getEditedSalesList(List<MDB0801Input> salesList,
            List<MDB0801Input> receiveresultList) {

        // 同じ年度とプロジェクトIDの値を合計する、
        Map<String, MDB0801Input> rtn = new HashMap<String, MDB0801Input>();
        MDB0801Input item = null;
        String checkKey = "";
        MDB0801Input mdb0801Input = new MDB0801Input();

        // 売上テーブルのレコードに年度を設定する
        for (MDB0801Input amountMdb0801Input : salesList) {

            String pjId = amountMdb0801Input.getPjId();
            int ymAmount = Integer.parseInt(amountMdb0801Input.getYmAmount());

            for (MDB0801Input receiveMDB0801Input : receiveresultList) {

                int from = Integer.parseInt(receiveMDB0801Input.getDateFrom());
                int to = Integer.parseInt(receiveMDB0801Input.getDateTo());

                if (receiveMDB0801Input.getPjId().equals(pjId) && ymAmount >= from && ymAmount <= to) {
                    amountMdb0801Input.setSoldFiscalYear(receiveMDB0801Input.getSoldFiscalYear());
                    break;
                }
            }
        }

        for (int i = 0; i < salesList.size(); i++) {

            mdb0801Input = salesList.get(i);

            checkKey = mdb0801Input.getPjId() + mdb0801Input.getSoldFiscalYear();

            if (rtn.containsKey(checkKey)) {
                item = rtn.get(checkKey);

                // 売上日
                if (null != mdb0801Input.getThisFiscalYearSoldOn() && null != item.getThisFiscalYearSoldOn()) {
                    item.setThisFiscalYearSoldOn(
                            Integer.parseInt(item.getThisFiscalYearSoldOn().replaceAll("-", "")) >= Integer
                                    .parseInt(mdb0801Input.getThisFiscalYearSoldOn().replaceAll("-", ""))
                                            ? item.getThisFiscalYearSoldOn()
                                            : mdb0801Input.getThisFiscalYearSoldOn());
                }

                // himoku_51
                item.setHimoku51(addBD(item.getHimoku51(), mdb0801Input.getHimoku51()));
                // himoku_52
                item.setHimoku52(addBD(item.getHimoku52(), mdb0801Input.getHimoku52()));

            } else {
                item = new MDB0801Input();

                // 売上年度
                item.setSoldFiscalYear(mdb0801Input.getSoldFiscalYear());

                // プロジェクトID
                item.setPjId(mdb0801Input.getPjId());

                // 売上日
                item.setThisFiscalYearSoldOn(mdb0801Input.getThisFiscalYearSoldOn());

                // himoku_51
                item.setHimoku51(getBigDecimalValue(mdb0801Input.getHimoku51()));
                // himoku_52
                item.setHimoku52(getBigDecimalValue(mdb0801Input.getHimoku52()));

                rtn.put(checkKey, item);
                item = null;
            }

            // 最後のSumした結果を追加する
            if (i == salesList.size() - 1 && null != item) {
                rtn.put(checkKey, item);
            }
        }

        return rtn;
    }

    private Map<String, MDB0801Input> getEditedProgressRateList(List<MDB0801Input> progressRateList,
            List<MDB0801Input> receiveresultList, List<MDB0801Input> rResultList, Map<String, MDB0801Input> rResultYMListMap) {

        // 同じ年度とプロジェクトIDの値を合計する、
        Map<String, MDB0801Input> rtn = new HashMap<String, MDB0801Input>();
        MDB0801Input item = null;
        String checkKey = "";
        MDB0801Input mdb0801Input = new MDB0801Input();

        // テーブルのレコードに年度を設定する
        for (MDB0801Input amountMdb0801Input : progressRateList) {

            String buPjAttId = amountMdb0801Input.getBuPjAttId();
            int ymAmount = Integer.parseInt(amountMdb0801Input.getYmAmount());

            if(buPjAttId.substring(2, 3).equals("R")) {

                for (MDB0801Input rResultListInput : rResultList) {

                    int from = Integer.parseInt(rResultListInput.getDateFrom().replaceAll("-", "").substring(0, 6));
                    int to = Integer.parseInt(rResultListInput.getDateTo().replaceAll("-", "").substring(0, 6));

                    if (rResultListInput.getPjAttId().equals(buPjAttId.substring(2, 10)) && ymAmount >= from && ymAmount <= to) {
                        Map<String,MDB0801Input> resultMap = getResultMap(rResultYMListMap, from, to, buPjAttId);
                        if(null != resultMap.get(buPjAttId)) {
                            amountMdb0801Input.setSoldFiscalYear(resultMap.get(buPjAttId).getSoldFiscalYear());
                            break;
                        }
                    }
                }
            }else {
                boolean inFlag = true;

                for (MDB0801Input receiveMDB0801Input : receiveresultList) {

                    int from = Integer.parseInt(receiveMDB0801Input.getDateFrom());
                    int to = Integer.parseInt(receiveMDB0801Input.getDateTo());

                    if (receiveMDB0801Input.getPjId().substring(0, 10).equals(buPjAttId) && ymAmount >= from && ymAmount <= to) {
                        amountMdb0801Input.setSoldFiscalYear(receiveMDB0801Input.getSoldFiscalYear());
                        break;
                    }
                }

                if(inFlag) {
                    for (MDB0801Input rResultListInput : rResultList) {
                        if(buPjAttId.substring(2, 3).equals("P")) {
                            int from = Integer.parseInt(rResultListInput.getDateFrom().replaceAll("-", "").substring(0, 6));
                            int to = Integer.parseInt(rResultListInput.getDateTo().replaceAll("-", "").substring(0, 6));

                            if (rResultListInput.getPjAttId().equals(buPjAttId.substring(2, 10)) && ymAmount >= from && ymAmount <= to) {
                                Map<String,MDB0801Input> resultMap = getResultMap(rResultYMListMap, from, to, buPjAttId);
                                if(null != resultMap.get(buPjAttId)) {
                                    amountMdb0801Input.setSoldFiscalYear(resultMap.get(buPjAttId).getSoldFiscalYear());
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }

        for (int i = 0; i < progressRateList.size(); i++) {

            mdb0801Input = progressRateList.get(i);

            checkKey = mdb0801Input.getBuPjAttId() + mdb0801Input.getSoldFiscalYear();

            if (rtn.containsKey(checkKey)) {
                item = rtn.get(checkKey);

                // 最新のものを取得
                if (null != mdb0801Input.getYmAmount() && null != item.getYmAmount()) {
                    item.setProgressRate(
                            Integer.parseInt(item.getYmAmount().replaceAll("-", "")) >= Integer
                                    .parseInt(mdb0801Input.getYmAmount().replaceAll("-", ""))
                                            ? item.getProgressRate()
                                            : mdb0801Input.getProgressRate());
                }

            } else {
                item = new MDB0801Input();

                // 売上年度
                item.setSoldFiscalYear(mdb0801Input.getSoldFiscalYear());

                // BU+プロジェクト属性ID
                item.setBuPjAttId(mdb0801Input.getBuPjAttId());

                // 売上日
                item.setYmAmount(mdb0801Input.getYmAmount());

                // progressRate
                item.setProgressRate(getBigDecimalValue(mdb0801Input.getProgressRate()));

                rtn.put(checkKey, item);
                item = null;
            }

            // 最後のSumした結果を追加する
            if (i == progressRateList.size() - 1 && null != item) {
                rtn.put(checkKey, item);
            }
        }

        return rtn;
    }

    private List<MDB0801Output> setItemOutput(List<MDB0801Input> pjidList, String ym, String ym1, String ym2,
            String kbn, String yyyymm, String systemYearMonth, List<MDB0801Input> pjidList2, String systemDate) {

        List<MDB0801Output> outputItems = new ArrayList<MDB0801Output>();

        MDB0801Output item = new MDB0801Output();

        String receiveDate = "";
        // 日次処理の場合
        if (kbn.equals("D")) {
            receiveDate = systemYearMonth;

            // 月次確定処理の場合
        } else if (kbn.equals("M")) {
            receiveDate = yyyymm;
        }

        // ①プロジェクトIDを抽出 (Pのみ)
        List<MDB0801Input> pjidListP = getResultList(pjidList, "P");

        // ①プロジェクトIDを抽出 (Rのみ)
        List<MDB0801Input> pjidListR = getResultList(pjidList, "R");

        String pjidListPStr = getPjIdStr(pjidListP);
        String pjidListRStr = getPjIdStr(pjidListR);
        String pjidListPStr2 = getPjIdStr(pjidList2);

        // ②プロジェクトIDから売上年度を取得
        logger.debug("①PプロジェクトIDから売上年度を取得 ★［プロジェクト．プロジェクト種別］が「P」 開始");
        // ★［プロジェクト．プロジェクト種別］が「P」
        List<MDB0801Input> resultListP =
                (pjidListP.size() > 0) ? mdb0801Repository.findAllPPjIdAndsoldFiscalYear(pjidListPStr)
                        : new ArrayList<MDB0801Input>();

        // ②プロジェクトIDから売上年度を取得
        logger.debug("①RプロジェクトIDを抽出 ★［プロジェクト．プロジェクト種別］が「R」 開始");
        // ★［プロジェクト．プロジェクト種別］が「R」
        List<MDB0801Input> resultListR =
                (pjidListR.size() > 0) ? mdb0801Repository.findAllRPjIdAndsoldFiscalYear(pjidListRStr)
                        : new ArrayList<MDB0801Input>();

        // ②プロジェクトIDから売上年度を取得
        logger.debug("①P2プロジェクトIDから売上年度を取得 ★［プロジェクト．プロジェクト種別］が「P」 開始");
        // ★［プロジェクト．プロジェクト種別］が「P」
        List<MDB0801Input> resultListP2 =
                (pjidList2.size() > 0) ? mdb0801Repository.findAllPPjIdAndsoldFiscalYear2(pjidListPStr2)
                        : new ArrayList<MDB0801Input>();

        resultListR.addAll(resultListP2);

        // ②プロジェクトIDから売上年度を取得(「P」と「R」両方)
        logger.debug("②プロジェクトIDから売上年度を取得(「P」と「R」両方) 開始");
        List<MDB0801Input> resultListKey = new ArrayList<MDB0801Input>();
        resultListKey.addAll(getEditedResultListKey(resultListP));
        resultListKey.addAll(getEditedResultListKey(resultListR));

        // ③対象プロジェクトIDのデータを抽出（主処理）
        logger.debug("③対象プロジェクトIDのデータを抽出（主処理） 開始");
        List<MDB0801Input> pjidListKey = new ArrayList<MDB0801Input>();
        pjidListKey.addAll(pjidListP);
        pjidListKey.addAll(pjidListR);
        pjidListKey.addAll(pjidList2);

        List<MDB0801Input> pjidListKey2 = new ArrayList<MDB0801Input>();
        pjidListKey2.addAll(pjidListP);
        pjidListKey2.addAll(pjidListR);

        String pjIdStr = getPjIdStr(pjidListKey);
        String pjIdStrOr = getPjIdStrByOr(pjidListKey,"pj_id");

        String buPjIdStr = getPjIdStr(getBuPjIdList(pjidListKey2));
        String pjAttIdStr = getPjAttIdStr(getPjAttIdList(resultListR));

        List<MDB0801Input> resultList = new ArrayList<MDB0801Input>();
        // 日次処理の場合
        if (kbn.equals("D")) {
            if(pjidListKey.size() > 0) {
                resultList = mdb0801Repository.findAll1(ym, pjIdStr);
                resultList.addAll(mdb0801Repository.findAll2(ym, pjIdStr, systemDate));
            }

        // 月次確定処理の場合
        } else if (kbn.equals("M")) {
            if(pjidListKey.size() > 0) {
                LocalDateTime yyyymmP = LocalDateTime.of(Integer.parseInt(yyyymm.substring(0, 4)), Integer.parseInt(yyyymm.substring(4, 6)), 1, 1, 1);
                String specifiedMonth = yyyymmP.plusMonths(1).minusDays(1).format(dtfUUUUMMDD);
                resultList = mdb0801Repository.findAll3(ym, pjIdStr, specifiedMonth);
                resultList.addAll(mdb0801Repository.findAll4(ym, pjIdStr, specifiedMonth));
            }
        }

        Map<String, MDB0801Input> resultListMap =
                resultList.stream().collect(Collectors.toMap(MDB0801Input::getPjId, Function.identity()));

        // ③対象プロジェクトIDのデータを抽出（副処理）
        logger.debug("③対象プロジェクトIDのデータを抽出（副処理） 受注 開始");
        // ★受注
        List<MDB0801Input> receiveresultList =
                (pjidListKey.size() > 0)
                        ? getResultReceive(mdb0801Repository.findAllReceive(receiveDate, buPjIdStr))
                        : new ArrayList<MDB0801Input>();

        Map<String, MDB0801Input> receiveresultListMap =
                receiveresultList.stream().collect(Collectors.toMap(MDB0801Input::concat, Function.identity()));

        // （Rプロジェクトの場合）、契約工期(FROM)   契約工期(TO)を取得する
        logger.debug("（Rプロジェクトの場合）、契約工期(FROM)   契約工期(TO)を取得する 開始");
        List<MDB0801Input> rResultList =
                (resultListR.size() > 0)
                        ? mdb0801Repository.findAllRPjidFromTo(pjAttIdStr)
                        : new ArrayList<MDB0801Input>();

        Map<String, MDB0801Input> rResultYMListMap =
                resultListR.stream().collect(Collectors.toMap(MDB0801Input::getPjId, Function.identity()));

        Map<String, MDB0801Input> rResultListMap = getFiscalFromTo(rResultYMListMap, rResultList);

        // ★金額(実績)
        logger.debug("金額(実績) 開始");
        List<MDB0801Input> amountPerformancetList =
                (pjidListKey.size() > 0) ? mdb0801Repository.findAllAmountPerformance(receiveDate, pjIdStr)
                        : new ArrayList<MDB0801Input>();
        Map<String, MDB0801Input> amountPerformancetListMap =
                getEditedAmountList(amountPerformancetList, receiveresultList, rResultList, rResultYMListMap);

        // ★金額(積算)
        logger.debug("金額(積算) 開始");
        List<MDB0801Input> amountIntegrationList =
                (pjidListKey.size() > 0) ? mdb0801Repository.findAllAmountIntegration(pjIdStr)
                        : new ArrayList<MDB0801Input>();
        Map<String, MDB0801Input> amountIntegrationListMap =
                getEditedAmountList(amountIntegrationList, receiveresultList, rResultList, rResultYMListMap);

        // ★金額(積算)（実績積算区分「3」（初回積算））
        logger.debug("金額(積算)（実績積算区分「3」（初回積算）） 開始");
        List<MDB0801Input> amountIntegration3List =
                (pjidListKey.size() > 0) ? mdb0801Repository.findAllAmountIntegration3(pjIdStr)
                        : new ArrayList<MDB0801Input>();
        Map<String, MDB0801Input> amountIntegration3ListMap =
                getEditedAmountList(amountIntegration3List, receiveresultList, rResultList, rResultYMListMap);

        // ★工数金額(実績)
        logger.debug("工数金額(実績) 開始");
        List<MDB0801Input> amountCostPerformancetList =
                (pjidListKey.size() > 0) ? mdb0801Repository.findAllCostAmountPerformance(receiveDate, pjIdStr)
                        : new ArrayList<MDB0801Input>();
        Map<String, MDB0801Input> amountCostPerformancetListMap =
                getEditedCostAmountList(amountCostPerformancetList, receiveresultList, rResultList, rResultYMListMap);

        // ★工数金額(積算)
        logger.debug("工数金額(積算) 開始");
        List<MDB0801Input> amountCostIntegrationList =
                (pjidListKey.size() > 0) ? mdb0801Repository.findAllCostAmountIntegration(pjIdStr)
                        : new ArrayList<MDB0801Input>();
        Map<String, MDB0801Input> amountCostIntegrationListMap =
                getEditedCostAmountList(amountCostIntegrationList, receiveresultList, rResultList, rResultYMListMap);

        // ★売上
        logger.debug("売上 開始");
        List<MDB0801Input> salesList =
                (pjidListKey.size() > 0) ? mdb0801Repository.findAllSales(receiveDate, buPjIdStr)
                        : new ArrayList<MDB0801Input>();
        Map<String, MDB0801Input> salesListMap = getEditedSalesList(salesList, receiveresultList);

        // ★積算月別プロジェクト進捗率データ
        logger.debug("積算月別プロジェクト進捗率データ 開始");
        List<MDB0801Input> progressRateList =
                (pjidListKey.size() > 0) ? mdb0801Repository.findAllProgressRate(buPjIdStr)
                        : new ArrayList<MDB0801Input>();
        Map<String, MDB0801Input> progressRateListMap = getEditedProgressRateList(progressRateList, receiveresultList, rResultList, rResultYMListMap);

        // ★積算基本情報
        logger.debug("積算基本情報 開始");
        List<MDB0801Input> basicInformationList =
                (pjidListKey.size() > 0) ? mdb0801Repository.findAllBasicInformation(pjIdStr)
                        : new ArrayList<MDB0801Input>();
        Map<String, MDB0801Input> basicInformationListMap =
                basicInformationList.stream().collect(Collectors.toMap(MDB0801Input::getPjId, Function.identity()));

        logger.debug("初回積算基本情報 開始");
        // ★初回積算基本情報
        List<MDB0801Input> firstBasicInformationList =
                (pjidListKey.size() > 0) ? mdb0801Repository.findAllFirstBasicInformation(pjIdStr)
                        : new ArrayList<MDB0801Input>();
        Map<String, MDB0801Input> firstBasicInformationListMap =
                firstBasicInformationList.stream()
                        .collect(Collectors.toMap(MDB0801Input::getPjId, Function.identity()));

        logger.debug("外注情報（未発注外注費（一般）支払ベース、未発注外注費（関係）支払ベースは除く） 開始");
        // ★外注情報（未発注外注費（一般）支払ベース、未発注外注費（関係）支払ベースは除く）
        List<MDB0801Input> exceptPayBasisList =
                (pjidListKey.size() > 0) ? mdb0801Repository.findAllExceptPayBasis(receiveDate, pjIdStr)
                        : new ArrayList<MDB0801Input>();
        Map<String, MDB0801Input> exceptPayBasisListMap =
                getEditedExceptPayBasisList(exceptPayBasisList, receiveresultList, rResultList, rResultYMListMap);

        logger.debug("外注情報（未発注外注費（一般）支払ベース、未発注外注費（関係）支払ベースのみ） 開始");
        // ★外注情報（未発注外注費（一般）支払ベース、未発注外注費（関係）支払ベースのみ）
        List<MDB0801Input> payBasisList =
                (pjidListKey.size() > 0) ? mdb0801Repository.findAllPayBasis(receiveDate, pjIdStr)
                        : new ArrayList<MDB0801Input>();
        Map<String, MDB0801Input> payBasisListMap = getEditedPayBasisList(payBasisList, receiveresultList, rResultList, rResultYMListMap);

        // ★SAP仕掛原価
        // 全年度の積算⑩＋全年度の積算⑪
        List<MDB0801Input> sumAmountList =
                (pjidListKey.size() > 0) ? mdb0801Repository.findAllSumAmount(pjIdStr)
                        : new ArrayList<MDB0801Input>();
        Map<String, MDB0801Input> sumAmountListMap =
                sumAmountList.stream().collect(Collectors.toMap(MDB0801Input::getPjId, Function.identity()));

        // ★SAP仕掛原価
        List<MDB0801Input> sapWidgetCostList = new ArrayList<MDB0801Input>();
        Map<String, MDB0801Input> sapWidgetCostMap = new HashMap<String, MDB0801Input>();

        // ★SAP仕掛原価を取得した件数は0件の場合、実施する
        List<MDB0801Input> mdDispPropertyMonthlyList = new ArrayList<MDB0801Input>();

        // ★SAP仕掛原価を取得した件数は0件の場合、実施する
        // ［SAP仕掛原価］の前年度3月のデータ
        List<MDB0801Input> sapWidgetCostList2 = new ArrayList<MDB0801Input>();
        Map<String, MDB0801Input> sapWidgetCostMap2 = new HashMap<String, MDB0801Input>();

        // 支払い未外注費の加算用 外注情報テーブルの情報を取得する
        List<MDB0801Input> mdOutsourcingList = new ArrayList<MDB0801Input>();

        // ★SAP仕掛原価に当年度4月のデータがあるかどうか
        List<MDB0801Input> sapInProcessCostList = mdb0801Repository.findAllSAPInProcessCostDataCount(yearMonthToBeginOfFiscalYearMonth(systemYearMonth).substring(0, 4));

        if(sapInProcessCostList.size() == 0) {

            // ★SAP仕掛原価を取得した件数は0件の場合、［物件管理_月次用］を取得する
            mdDispPropertyMonthlyList =
                    (pjidListKey.size() > 0) ? mdb0801Repository.findAllMdDispPropertyMonthlyByPjId(pjIdStr)
                            : new ArrayList<MDB0801Input>();

            // ★SAP仕掛原価を取得した件数は0件の場合、［SAP仕掛原価］の前年度3月のデータを取得する
            String receiveDateMarch = String.valueOf((Integer.parseInt(receiveDate.substring(0, 4)) -1));
            sapWidgetCostList2 = mdb0801Repository.findAllSAPInProcessCostByFiscalYearMonat(receiveDateMarch);
            sapWidgetCostMap2 = sapWidgetCostList2.stream().collect(Collectors.toMap(MDB0801Input::getPjId, Function.identity()));
        }

        // ★SAP仕掛原価
        logger.debug("SAP仕掛原価 開始");
        sapWidgetCostList =
                (pjidListKey.size() > 0) ? mdb0801Repository.findAllSapWidgetCost(receiveDate, pjIdStr)
                        : new ArrayList<MDB0801Input>();
        sapWidgetCostMap = getEditedSapWidgetCostList(sapWidgetCostList, receiveresultList, rResultList, rResultYMListMap, receiveDate);

        // 前年度の終了月
        String lastYearfiscalYearMonth = "";

        // 今年度の開始月
        String thisYearfiscalYearMonth = "";

        // 日次：システム日付の前年度の終了月、月次：（指定月）前年度の終了月
        lastYearfiscalYearMonth = (yearMonthToBeginOfFiscalYearMonth(receiveDate).substring(0, 4)) + "03";

        // 日次：システム日付の今年度の開始月、月次：（指定月）今年度の開始月
        thisYearfiscalYearMonth = (yearMonthToBeginOfFiscalYearMonth(receiveDate).substring(0, 4)) + "04";

        // 支払い未外注費の加算用、［外注情報］を取得する
        mdOutsourcingList = (pjidListKey.size() > 0) ? mdb0801Repository.findAllMdOutsourcing(pjIdStr, lastYearfiscalYearMonth, thisYearfiscalYearMonth): new ArrayList<MDB0801Input>();

        // 実績（全年度⑭総原価）
        logger.debug("実績（全年度⑭総原価） 開始");
        // ★金額
        // --⑩直接費合計の外注費以外＋⑪間接費＋⑫その他事業部間取引
        List<MDB0801Input> allSumTotalCostAmountList =
                (pjidListKey.size() > 0) ? mdb0801Repository.findAllSumTotalCostAmount("190001", ym2, pjIdStr)
                        : new ArrayList<MDB0801Input>();
        Map<String, MDB0801Input> allSumTotalCostAmountListMap =
                allSumTotalCostAmountList.stream()
                        .collect(Collectors.toMap(MDB0801Input::getPjId, Function.identity()));

        // 実績（全年度⑭総原価）
        // ★外注情報（未発注外注費（一般）支払ベース、未発注外注費（関係）支払ベースは除く）
        // --⑩直接費合計の未発注以外の外注費
        List<MDB0801Input> allSumExceptList =
                (pjidListKey.size() > 0) ? mdb0801Repository.findAllSumExcept("190001", ym2, pjIdStr)
                        : new ArrayList<MDB0801Input>();
        Map<String, MDB0801Input> allSumExceptListMap =
                allSumExceptList.stream().collect(Collectors.toMap(MDB0801Input::getPjId, Function.identity()));

        // 実績（全年度⑭総原価）
        // ★外注情報（未発注外注費（一般）支払ベース、未発注外注費（関係）支払ベースのみ）
        // --⑩直接費合計の未発注外注費
        List<MDB0801Input> allSumOnlyList =
                (pjidListKey.size() > 0) ? mdb0801Repository.findAllSumOnly("190001", ym2, pjIdStr)
                        : new ArrayList<MDB0801Input>();
        Map<String, MDB0801Input> allSumOnlyListMap =
                allSumOnlyList.stream().collect(Collectors.toMap(MDB0801Input::getPjId, Function.identity()));

        // 金額の追加原価（金額）
        logger.debug("金額の追加原価（金額） 開始");
        List<MDB0801Input> addAmountList =
                (pjidListKey.size() > 0) ? mdb0801Repository.findAllAddAmount(receiveDate, pjIdStr)
                        : new ArrayList<MDB0801Input>();
        Map<String, MDB0801Input> addAmountListMap =
                addAmountList.stream().collect(Collectors.toMap(MDB0801Input::getPjId, Function.identity()));

        // 外注情報の追加原価（金額）
        logger.debug("外注情報の追加原価（金額） 開始");
        List<MDB0801Input> addCostPayBasisList =
                (pjidListKey.size() > 0) ? mdb0801Repository.findAllAddCostPayBasis(DateUtil.getFirstLocalDate(receiveDate), pjIdStrOr)
                        : new ArrayList<MDB0801Input>();
        Map<String, MDB0801Input> addCostPayBasisListMap =
                addCostPayBasisList.stream().collect(Collectors.toMap(MDB0801Input::getPjId, Function.identity()));

        // 全年度の金額の追加原価（金額）
        logger.debug("全年度の金額の追加原価（金額） 開始");
        List<MDB0801Input> addAmountSumList =
                (pjidListKey.size() > 0) ? mdb0801Repository.findAllAddAmountSum(receiveDate, pjIdStr)
                        : new ArrayList<MDB0801Input>();
        Map<String, MDB0801Input> addAmountSumListMap =
                addAmountSumList.stream().collect(Collectors.toMap(MDB0801Input::getPjId, Function.identity()));

        // 全年度の外注情報の追加原価（金額）
        logger.debug("全年度の外注情報の追加原価（金額） 開始");
        List<MDB0801Input> addCostPayBasisSumList =
                (pjidListKey.size() > 0) ? mdb0801Repository.findAllAddCostPayBasisSum(receiveDate, pjIdStrOr)
                        : new ArrayList<MDB0801Input>();
        Map<String, MDB0801Input> addCostPayBasisSumListMap =
                addCostPayBasisSumList.stream().collect(Collectors.toMap(MDB0801Input::getPjId, Function.identity()));

        /** ⑰ 合計 */
        Map<String, BigDecimal> genkagokeiTotal17 = new HashMap<String, BigDecimal>();

        /** 当該年度積算額 合計 */
        Map<String, BigDecimal> thisFiscalYearPlanedAmountTotal = new HashMap<String, BigDecimal>();

        /** 見込み原価 合計 */
        Map<String, BigDecimal> planedCostTotal = new HashMap<String, BigDecimal>();

        //システム日付の年度
        int fiscalYMSystem = Integer.parseInt(yearMonthToBeginOfFiscalYearMonth(systemYearMonth).substring(0, 4));

        logger.debug("outputBean set 開始");
        for (MDB0801Input mdb0801Input : resultListKey) {
            item = new MDB0801Output();

            MDB0801Input correspondExceptPayBasisMdb0801Input =
                    (null == exceptPayBasisListMap.get(mdb0801Input.getPjId() + mdb0801Input.getSoldFiscalYear()))
                            ? new MDB0801Input()
                            : exceptPayBasisListMap.get(mdb0801Input.getPjId() + mdb0801Input.getSoldFiscalYear());

            MDB0801Input correspondPayBasisMdb0801Input =
                    (null == payBasisListMap.get(mdb0801Input.getPjId() + mdb0801Input.getSoldFiscalYear()))
                            ? new MDB0801Input()
                            : payBasisListMap.get(mdb0801Input.getPjId() + mdb0801Input.getSoldFiscalYear());

            MDB0801Input correspondSapWidgetCostMdb0801Input = new MDB0801Input();
            if(Integer.parseInt(mdb0801Input.getSoldFiscalYear()) == fiscalYMSystem
                    && null == sapWidgetCostMap.get(mdb0801Input.getPjId() + mdb0801Input.getSoldFiscalYear())) {
                correspondSapWidgetCostMdb0801Input =
                        (null == sapWidgetCostMap.get(mdb0801Input.getPjId() + (Integer.parseInt(mdb0801Input.getSoldFiscalYear()) -1)))
                                ? new MDB0801Input()
                                : sapWidgetCostMap.get(mdb0801Input.getPjId() + (Integer.parseInt(mdb0801Input.getSoldFiscalYear()) -1));
            }else {
                correspondSapWidgetCostMdb0801Input =
                        (null == sapWidgetCostMap.get(mdb0801Input.getPjId() + mdb0801Input.getSoldFiscalYear()))
                                ? new MDB0801Input()
                                : sapWidgetCostMap.get(mdb0801Input.getPjId() + mdb0801Input.getSoldFiscalYear());
            }

            MDB0801Input correspondSapWidgetCostMdb0801Input2 =
                    (null == sapWidgetCostMap2.get(mdb0801Input.getPjId()))
                            ? new MDB0801Input()
                            : sapWidgetCostMap2.get(mdb0801Input.getPjId());

            // 枝番「01」
            if (isBranch01PjId(mdb0801Input.getPjId())) {

                // 該当PjIdのレコード情報(枝番「01」)
                MDB0801Input correspondMdb0801Input =
                        !resultListMap.containsKey(mdb0801Input.getPjId()) ? new MDB0801Input()
                                : resultListMap.get(mdb0801Input.getPjId());

                /** 売上年度 */
                item.setSoldFiscalYear(new BigDecimal(mdb0801Input.getSoldFiscalYear()));

                /** プロジェクトID */
                item.setPjId(mdb0801Input.getPjId());

                /** プロジェクト名称 */
                item.setPjName(correspondMdb0801Input.getPjName());

                /** 物件区分 */
                item.setPjKbn(correspondMdb0801Input.getPjKbn());

                /** 名義会社 */
                item.setMeigiCorpCd(correspondMdb0801Input.getMeigiCorpCd());

                /** 顧客名称 */
                item.setCustomerName(correspondMdb0801Input.getCustomerName());

                /** BU */
                item.setBu(correspondMdb0801Input.getBu());

                /** プロジェクト属性ID */
                item.setPjAttId(correspondMdb0801Input.getPjAttId());

                /** 枝番 */
                item.setBranchNum(correspondMdb0801Input.getBranchNum());

                /** 契約件名 */
                item.setContractName(correspondMdb0801Input.getContractName());

                /** 契約工期(FROM) */
                item.setContractFrom(correspondMdb0801Input.getContractFrom());

                /** 契約工期(TO) */
                item.setContractTo(correspondMdb0801Input.getContractTo());

                /** 取引種別 */
                item.setDealType(correspondMdb0801Input.getDealType());

                /** 案件情報 */
                item.setPjInfo(correspondMdb0801Input.getPjInfo());

                /** 分野コード */
                item.setFieldCd(correspondMdb0801Input.getFieldCd());

                /** 分野コード名称 */
                item.setFieldName(correspondMdb0801Input.getFieldName());

                /** 業務コード */
                item.setBusinessCd(correspondMdb0801Input.getBusinessCd());

                /** 業務コード名称 */
                item.setBusinessName(correspondMdb0801Input.getBusinessName());

                /** 顧客種別 */
                item.setCustomerCategoryCd(correspondMdb0801Input.getCustomerCategoryCd());

                /** 物件管理責任者部門支社ＣＤ */
                item.setPjManageRespDeptBranchCd(correspondMdb0801Input.getPjManageRespDeptBranchCd());

                /** 物件管理責任者部門支社名称 */
                item.setPjManageRespDeptBranchName(correspondMdb0801Input.getPjManageRespDeptBranchName());

                /** 物件管理責任者部門部ＣＤ */
                item.setPjManageRespMDeptCd(correspondMdb0801Input.getPjManageRespMDeptCd());

                /** 物件管理責任者部門部名称 */
                item.setPjManageRespMDeptName(correspondMdb0801Input.getPjManageRespMDeptName());

                /** 物件管理責任者部門部署ＣＤ */
                item.setPjManageRespDeptCd(correspondMdb0801Input.getPjManageRespDeptCd());

                /** 物件管理責任者部門部署名称 */
                item.setPjManageRespDeptName(correspondMdb0801Input.getPjManageRespDeptName());

                /** 物件管理責任者ＣＤ */
                item.setPjManageRespEmpCd(correspondMdb0801Input.getPjManageRespEmpCd());

                /** 物件管理責任者名 */
                item.setPjManageRespEmpName(correspondMdb0801Input.getPjManageRespEmpName());

                /** 生産主管部門支社ＣＤ */
                item.setProductMainDeptBranchCd(correspondMdb0801Input.getProductMainDeptBranchCd());

                /** 生産主管部門支社名称 */
                item.setProductMainDeptBranchName(correspondMdb0801Input.getProductMainDeptBranchName());

                /** 生産主管部門部ＣＤ */
                item.setProductMainMDeptCd(correspondMdb0801Input.getProductMainMDeptCd());

                /** 生産主管部門部名称 */
                item.setProductMainMDeptName(correspondMdb0801Input.getProductMainMDeptName());

                /** 生産主管部門ＣＤ */
                item.setProductMainDeptCd(correspondMdb0801Input.getProductMainDeptCd());

                /** 生産主管部門名称 */
                item.setProductMainDeptName(correspondMdb0801Input.getProductMainDeptName());

                /** 生産プロデューサーＣＤ */
                item.setProductProducerEmpCd(correspondMdb0801Input.getProductProducerEmpCd());

                /** 生産プロデューサー名 */
                item.setProductProducerName(correspondMdb0801Input.getProductProducerName());

                /** 営業主管部門支社ＣＤ */
                item.setSalesMainDeptBranchCd(correspondMdb0801Input.getSalesMainDeptBranchCd());

                /** 営業主管部門支社名称 */
                item.setSalesMainDeptBranchName(correspondMdb0801Input.getSalesMainDeptBranchName());

                /** 営業主管部門部ＣＤ */
                item.setSalesMainMDeptCd(correspondMdb0801Input.getSalesMainMDeptCd());

                /** 営業主管部門部名称 */
                item.setSalesMainMDeptName(correspondMdb0801Input.getSalesMainMDeptName());

                /** 営業主管部門ＣＤ */
                item.setSalesMainDeptCd(correspondMdb0801Input.getSalesMainDeptCd());

                /** 営業主管部門名称 */
                item.setSalesMainDeptName(correspondMdb0801Input.getSalesMainDeptName());

                /** 営業担当者ＣＤ */
                item.setSalesEmpCd(correspondMdb0801Input.getSalesEmpCd());

                /** 営業担当者名 */
                item.setSalesEmpName(correspondMdb0801Input.getSalesEmpName());

                /** 生産担当部門支社ＣＤ */
                item.setProductDeptBranchCd(correspondMdb0801Input.getProductDeptBranchCd());

                /** 生産担当部門支社名称 */
                item.setProductDeptBranchName(correspondMdb0801Input.getProductDeptBranchName());

                /** 生産担当部門部ＣＤ */
                item.setProductMDeptCd(correspondMdb0801Input.getProductMDeptCd());

                /** 生産担当部門部名称 */
                item.setProductMDeptName(correspondMdb0801Input.getProductMDeptName());

                /** 生産担当部門ＣＤ */
                item.setProductDeptCd(correspondMdb0801Input.getProductDeptCd());

                /** 生産担当部門名称 */
                item.setProductDeptName(correspondMdb0801Input.getProductDeptName());

                /** 生産担当者ＣＤ */
                item.setProductEmpCd(correspondMdb0801Input.getProductEmpCd());

                /** 生産担当者名 */
                item.setProductEmpName(correspondMdb0801Input.getProductEmpName());

                /** 受注区分 */
                MDB0801Input correspondReceiveMdb0801Input =
                        (null == receiveresultListMap.get(mdb0801Input.getPjId() + mdb0801Input.getSoldFiscalYear()))
                                ? new MDB0801Input()
                                : receiveresultListMap.get(mdb0801Input.getPjId() + mdb0801Input.getSoldFiscalYear());

                item.setReceiveKbn(
                        getReceiveKbn(correspondReceiveMdb0801Input.getReceivedOn(), kbn, yyyymm, systemYearMonth));

                /** 受注日 */
                item.setReceivedOn(correspondReceiveMdb0801Input.getReceivedOn());

                /** 受注額 */
                item.setReceivedMoney(null == correspondReceiveMdb0801Input.getReceivedMoney() ? BigDecimal.ZERO : correspondReceiveMdb0801Input.getReceivedMoney());

                /** 当該年度売上予定日 */
                item.setThisFiscalYearPlanedSellingOn(correspondReceiveMdb0801Input.getPlanedSellingOn());

                /** 当該年度売上日 */
                MDB0801Input correspondSalesMdb0801Input =
                        (null == salesListMap.get(mdb0801Input.getPjId() + mdb0801Input.getSoldFiscalYear()))
                                ? new MDB0801Input()
                                : salesListMap.get(mdb0801Input.getPjId() + mdb0801Input.getSoldFiscalYear());
                item.setThisFiscalYearSoldOn(correspondSalesMdb0801Input.getThisFiscalYearSoldOn());

                /** 最終売上予定日 */
                item.setLastPlanedSellingOn(correspondMdb0801Input.getLastPlanedSellingOn());

                /** 最終売上完了日 */
                item.setLastSoldOn(getEditedLastSoldOn(correspondMdb0801Input.getLastSoldOn(),receiveDate));

                /** 完了フラグ */
                item.setPjEnded(correspondMdb0801Input.getPjEnded());

                /** ステータス */
                item.setPjStatus(correspondMdb0801Input.getPjStatus());

                /** 高原価・政策受注フラグ */
                item.setHighCostReceive(null == correspondReceiveMdb0801Input.getHighCostReceive() ? "0"
                        : correspondReceiveMdb0801Input.getHighCostReceive());

                /** 応札時積算額 */
                item.setOsatsuPlanedAmount(correspondMdb0801Input.getOsatsuPlanedAmount());

                /** 応札時積算率 */
                item.setOsatsuPlanedRate((null == correspondReceiveMdb0801Input.getOsatsuPlanedRate()) ? BigDecimal.ZERO
                        : correspondReceiveMdb0801Input.getOsatsuPlanedRate().divide(new BigDecimal("100"), 3,
                                BigDecimal.ROUND_HALF_UP));

                /** 生産高 */
                item.setSeisandaka(BigDecimal.ZERO);

                /** 一般売上 */
                item.setOutsideSoldAmount(null == correspondSalesMdb0801Input.getHimoku51() ? BigDecimal.ZERO
                        : correspondSalesMdb0801Input.getHimoku51());

                /** 関係会社売上額 */
                item.setGroupSoldAmount(null == correspondSalesMdb0801Input.getHimoku52() ? BigDecimal.ZERO
                        : correspondSalesMdb0801Input.getHimoku52());

                /** 期首仕掛原価 */
                if(String.valueOf(fiscalYMSystem).equals(mdb0801Input.getSoldFiscalYear())
                        && sapInProcessCostList.size() == 0
                        && kbn.equals("D")) {
                    item.setKisyuWorkingCost(getKisyuWorkingCost(mdb0801Input.getPjId(), mdDispPropertyMonthlyList, item.getThisFiscalYearSoldOn(), systemYearMonth));
                } else {
                    item.setKisyuWorkingCost(
                            addBD(
                                null == correspondSapWidgetCostMdb0801Input.getKisyuWorkingCost() ? BigDecimal.ZERO : correspondSapWidgetCostMdb0801Input.getKisyuWorkingCost(),
                                getMdOutsourcingOrderedCost(mdb0801Input.getPjId(), mdOutsourcingList, mdb0801Input.getSoldFiscalYear(), receiveresultListMap))
                            );
                }

                /** ⑬期首仕掛品原価差異 */
                if(String.valueOf(fiscalYMSystem).equals(mdb0801Input.getSoldFiscalYear()) && sapInProcessCostList.size() == 0 && kbn.equals("D")) {
                    if(correspondSapWidgetCostMdb0801Input2.getInprocessCostBalance() == null
                            && correspondSapWidgetCostMdb0801Input2.getCurrentCostBalance() == null) {
                        item.setKisyuWorkingCostDifference(BigDecimal.ZERO);
                    }else {

                        item.setKisyuWorkingCostDifference(addBD(correspondSapWidgetCostMdb0801Input2.getInprocessCostBalance(), correspondSapWidgetCostMdb0801Input2.getCurrentCostBalance()));
                    }
                } else {
                    item.setKisyuWorkingCostDifference(
                            null == correspondSapWidgetCostMdb0801Input.getKisyuWorkingCostDifference()
                                    ? BigDecimal.ZERO
                                    : correspondSapWidgetCostMdb0801Input.getKisyuWorkingCostDifference());
                }

                /** 社員工数 */
                item.setEmpKosu(BigDecimal.ZERO);

                /** 積算社員工数 */
                item.setPlanedEmpKosu(BigDecimal.ZERO);

                /** 積算⑳人件費（直・間接合計） */
                item.setPlanedLaborCost(BigDecimal.ZERO);

                /** ①人件費（直接） */
                item.setDirectLaborCost(getAmountPerformance(receiveDate, "01", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountPerformancetListMap, rResultListMap));

                /** 積算①人件費（直接） */
                item.setPlanedDirectLaborCost(BigDecimal.ZERO);

                /** 臨時時間 */
                item.setTempEmpKosu(BigDecimal.ZERO);

                /** 積算臨時時間 */
                item.setPlanedTempEmpKosu(BigDecimal.ZERO);

                /** ②臨時人件費 */
                item.setTempLaborCost(getAmountPerformance(receiveDate, "02", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountPerformancetListMap, rResultListMap));

                /** 積算②臨時人件費 */
                item.setPlanedTempLaborCost(BigDecimal.ZERO);

                /** ③－１外注費（一般）発注ベース */
                item.setOutsideOrderedCost(
                        null == correspondExceptPayBasisMdb0801Input.getOutsideOrderedCost() ? BigDecimal.ZERO
                                : correspondExceptPayBasisMdb0801Input.getOutsideOrderedCost());

                /** 積算外注費（一般）発注ベース */
                item.setPlanedOutsideOrderingCost(BigDecimal.ZERO);

                /** ③－２外注費（一般）支払ベース */
                item.setOutsidePaidCost(
                        null == correspondExceptPayBasisMdb0801Input.getOutsidePaidCost() ? BigDecimal.ZERO
                                : correspondExceptPayBasisMdb0801Input.getOutsidePaidCost());

                /** ③－３外注費（関係）発注ベース */
                item.setGroupOrderedCost(
                        null == correspondExceptPayBasisMdb0801Input.getGroupOrderedCost() ? BigDecimal.ZERO
                                : correspondExceptPayBasisMdb0801Input.getGroupOrderedCost());

                /** 積算③－３外注費（関係）発注ベース */
                item.setPlanedGroupOrderingCost(BigDecimal.ZERO);

                /** ③－４外注費（関係）支払ベース */
                item.setGroupPaidCost(null == correspondExceptPayBasisMdb0801Input.getGroupPaidCost() ? BigDecimal.ZERO
                        : correspondExceptPayBasisMdb0801Input.getGroupPaidCost());

                /** 業務委託費発注ベース */
                item.setEntrustOrderedCost(
                        null == correspondExceptPayBasisMdb0801Input.getEntrustOrderedCost() ? BigDecimal.ZERO
                                : correspondExceptPayBasisMdb0801Input.getEntrustOrderedCost());

                /** 積算業務委託費 */
                item.setPlanedEntrustCost(BigDecimal.ZERO);

                /** 業務委託費支払ベース */
                item.setEntrustPaidCost(
                        null == correspondExceptPayBasisMdb0801Input.getEntrustPaidCost() ? BigDecimal.ZERO
                                : correspondExceptPayBasisMdb0801Input.getEntrustPaidCost());

                /** 未発注外注費（一般）支払ベース */
                item.setNonOrderedOutsidePaidCost(
                        null == correspondPayBasisMdb0801Input.getNonOrderedOutsidePaidCost() ? BigDecimal.ZERO
                                : correspondPayBasisMdb0801Input.getNonOrderedOutsidePaidCost());

                /** 未発注外注費（関係）支払ベース */
                item.setNonOrderedGroupPaidCost(
                        null == correspondPayBasisMdb0801Input.getNonOrderedGroupPaidCost() ? BigDecimal.ZERO
                                : correspondPayBasisMdb0801Input.getNonOrderedGroupPaidCost());

                /** ④材料費 */
                item.setMaterialCost(getAmountPerformance(receiveDate, "05", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountPerformancetListMap, rResultListMap));

                /** 積算④材料費 */
                item.setPlanedMaterialCost(BigDecimal.ZERO);

                /** ⑤印刷製本費 */
                item.setPrintingBindingCost(getAmountPerformance(receiveDate, "06", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountPerformancetListMap, rResultListMap));

                /** 積算⑤印刷製本費 */
                item.setPlanedPrintingBindingCost(BigDecimal.ZERO);

                /** ⑥旅費交通費 */
                item.setTravelingCarfareCost(getAmountPerformance(receiveDate, "04", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountPerformancetListMap, rResultListMap));

                /** 積算⑥旅費交通費 */
                item.setPlanedTravelingCarfareCost(BigDecimal.ZERO);

                /** ⑦車両費 */
                item.setCarCost(getAmountPerformance(receiveDate, "07", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountPerformancetListMap, rResultListMap));

                /** 積算⑦車両費 */
                item.setPlanedCarCost(BigDecimal.ZERO);

                /** ⑧大型機材 */
                item.setLargeMachine(getAmountPerformance(receiveDate, "08", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountPerformancetListMap, rResultListMap));

                /** 積算⑧大型機材 */
                item.setPlanedLargeMachine(BigDecimal.ZERO);

                /** ⑨直接作業経費 */
                item.setDirectWorkCost(getAmountPerformance(receiveDate, "09", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountPerformancetListMap, rResultListMap));

                /** 積算⑨直接作業経費 */
                item.setPlanedDirectWorkCost(BigDecimal.ZERO);

                /** 積算⑩直接費合計 */
                item.setPlanedDirectCost(BigDecimal.ZERO);

                /** ⑪間接費 */
                item.setIndirectCost(getAmountPerformance(receiveDate, "11", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountPerformancetListMap, rResultListMap));

                /** 積算⑪間接費 */
                item.setPlanedIndirectCost(BigDecimal.ZERO);

                /** ⑫その他事業部間取引 */
                item.setOtherCost(getAmountPerformance(receiveDate, "12", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountPerformancetListMap, rResultListMap));

                /** 積算⑫その他事業部間取引 */
                item.setPlanedOtherCost(BigDecimal.ZERO);

                /** ⑮他勘定振替 */
                item.setAccountTransaction(getAmountPerformance(receiveDate, "15", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountPerformancetListMap, rResultListMap));

                /** ⑯今期原価差異 */
                if(String.valueOf(fiscalYMSystem).equals(mdb0801Input.getSoldFiscalYear()) && sapInProcessCostList.size() == 0 && kbn.equals("D")) {
                    item.setThisFiscalYearCostDifference(BigDecimal.ZERO);
                } else {
                    item.setThisFiscalYearCostDifference(
                            null == correspondSapWidgetCostMdb0801Input.getThisFiscalYearCostDifference() ? BigDecimal.ZERO
                                    : correspondSapWidgetCostMdb0801Input.getThisFiscalYearCostDifference());
                }

                /** 積算⑰原価合計 */
                item.setPlanedGenkagokei(BigDecimal.ZERO);

                /** ⑱売上原価 */
                item.setSalesCost(getAmountPerformance(receiveDate, "18", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountPerformancetListMap, rResultListMap));

                /** 進捗率 */
                item.setProgressRate(null == progressRateListMap
                        .get(mdb0801Input.getPjId().substring(0, 10) + mdb0801Input.getSoldFiscalYear())
                                ? BigDecimal.ZERO
                                : (null == progressRateListMap
                                        .get(mdb0801Input.getPjId().substring(0, 10) + mdb0801Input.getSoldFiscalYear())
                                        .getProgressRate()) ? BigDecimal.ZERO
                                                : progressRateListMap
                                                        .get(mdb0801Input.getPjId().substring(0, 10)
                                                                + mdb0801Input.getSoldFiscalYear())
                                                        .getProgressRate()
                                                        .divide(new BigDecimal("100"), 3, BigDecimal.ROUND_HALF_UP));

                /** 初回積算日 */
                item.setFirstPlanedOn(null);

                /** 当該年度初回積算額 */
                item.setThisFiscalYearFirstPlanedAmount(BigDecimal.ZERO);

                /** 当該年度初回積算原価率 */
                item.setThisFiscalYearFirstPlanedCostRate(BigDecimal.ZERO);

                /** 全年度初回積算額 */
                item.setFirstPlanedAmount(BigDecimal.ZERO);

                /** 全年度初回積算原価率 */
                item.setFirstPlanedAmountRate(BigDecimal.ZERO);

                /** 更新積算日 */
                item.setUpdatePlanedOn(null);

                /** 当該年度積算額 */
                item.setThisFiscalYearPlanedAmount(BigDecimal.ZERO);
                putTotalNum(item.getPjId().substring(0, 10) + item.getSoldFiscalYear(),
                        item.getThisFiscalYearPlanedAmount(), thisFiscalYearPlanedAmountTotal);

                /** 当該年度積算原価率 */
                item.setThisFiscalYearPlanedCostRate(BigDecimal.ZERO);

                /** 全年度積算額 */
                item.setPlanedAmount(BigDecimal.ZERO);

                /** 全年度積算原価率 */
                item.setPlanedAmountRate(BigDecimal.ZERO);

                /** 並び順_物件管理責任者部門 */
                item.setSortNumPjManageRespDept(correspondMdb0801Input.getSortNumPjManageRespDept());

                /** 並び順_生産主管部門 */
                item.setSortNumProductMainDept(correspondMdb0801Input.getSortNumProductMainDept());

                /** 並び順_営業主管部門 */
                item.setSortNumSalesMainDept(correspondMdb0801Input.getSortNumSalesMainDept());

                /** 並び順_生産担当部門 */
                item.setSortNumProductDept(correspondMdb0801Input.getSortNumProductDept());

                /** 追加原価 */
                item.setAddCost(getAddCost(item.getPjId(), item.getLastSoldOn(), addAmountListMap,
                        addCostPayBasisListMap, receiveDate, receiveresultListMap, item.getSoldFiscalYear()));

                /** ⑩直接費合計 */
                BigDecimal directCostSum = BigDecimal.ZERO;
                // ①＋②＋④＋⑤＋⑥＋⑦＋⑧＋⑨
                directCostSum = addBD(directCostSum, item.getDirectLaborCost());
                directCostSum = addBD(directCostSum, item.getTempLaborCost());
                directCostSum = addBD(directCostSum, item.getMaterialCost());
                directCostSum = addBD(directCostSum, item.getPrintingBindingCost());
                directCostSum = addBD(directCostSum, item.getTravelingCarfareCost());
                directCostSum = addBD(directCostSum, item.getCarCost());
                directCostSum = addBD(directCostSum, item.getLargeMachine());
                directCostSum = addBD(directCostSum, item.getDirectWorkCost());
                // ・［プロジェクト．プロジェクト種別］が「P」、［プロジェクト．最終売上完了日］が設定されている場合
                if (item.getPjId().substring(2, 3).equals("P") && (!StringUtils.isEmpty(item.getLastSoldOn())
                        && Integer.parseInt(item.getLastSoldOn().replaceAll("-", "").substring(0, 6)) <= Integer
                                .parseInt(receiveDate))) {

                    // 「③－２」＋「③－４」＋「業務委託費支払ベース」＋「未発注外注費（一般）支払ベース」＋「未発注外注費（関係）支払ベース」
                    directCostSum = addBD(directCostSum, item.getOutsidePaidCost());
                    directCostSum = addBD(directCostSum, item.getGroupPaidCost());
                    directCostSum = addBD(directCostSum, item.getEntrustPaidCost());
                    directCostSum = addBD(directCostSum, item.getNonOrderedOutsidePaidCost());
                    directCostSum = addBD(directCostSum, item.getNonOrderedGroupPaidCost());

                    // 「③－１」＋「③－３」＋「業務委託費発注ベース」
                } else {
                    directCostSum = addBD(directCostSum, item.getOutsideOrderedCost());
                    directCostSum = addBD(directCostSum, item.getGroupOrderedCost());
                    directCostSum = addBD(directCostSum, item.getEntrustOrderedCost());
                }

                item.setDirectCost(directCostSum);

                /** ⑭総原価 */
                BigDecimal sogenkaSum = BigDecimal.ZERO;
                // ⑩＋⑪＋⑫＋⑬＋追加原価
                sogenkaSum = addBD(sogenkaSum, item.getDirectCost());
                sogenkaSum = addBD(sogenkaSum, item.getIndirectCost());
                sogenkaSum = addBD(sogenkaSum, item.getOtherCost());
                sogenkaSum = addBD(sogenkaSum, item.getKisyuWorkingCostDifference());
                sogenkaSum = addBD(sogenkaSum, item.getAddCost());
                item.setSogenka(sogenkaSum);

                /** 売上種別区分 */
                item.setSalesTypeKbn(getSalesTypeKbn(item.getPjId(), item.getLastSoldOn(), item.getSoldFiscalYear(),
                        ym1, item.getAddCost(), item.getSogenka(),
                        receiveDate,"01",receiveresultListMap));

                /** 売上種別 */
                item.setSalesType(getSalesType(item.getPjId(), correspondMdb0801Input.getSoldOn(),
                        correspondMdb0801Input.getPlanedSellingOn(), correspondMdb0801Input.getLastSoldOn(), ym1,
                        receiveDate,receiveresultListMap));

                /** ⑳人件費（直・間接合計） */
                item.setLaborCost(addBD(item.getDirectLaborCost(), item.getIndirectCost()));

                /** ⑰原価合計 */
                BigDecimal genkagokeiSum = BigDecimal.ZERO;
                // ⑭＋⑮＋⑯
                genkagokeiSum = addBD(genkagokeiSum, item.getSogenka());
                genkagokeiSum = addBD(genkagokeiSum, item.getAccountTransaction());
                genkagokeiSum = addBD(genkagokeiSum, item.getThisFiscalYearCostDifference());
                item.setGenkagokei(genkagokeiSum);
                putTotalNum(item.getPjId().substring(0, 10) + item.getSoldFiscalYear(), item.getGenkagokei(),
                        genkagokeiTotal17);

                /** ⑲期末仕掛原価 */
                item.setKimatsuWorkingCost(item.getGenkagokei().subtract(item.getSalesCost()));

                /** 見込み原価 */
                item.setPlanedCost((null != item.getGenkagokei()) ? item.getGenkagokei() : BigDecimal.ZERO);
                putTotalNum(item.getPjId().substring(0, 10) + item.getSoldFiscalYear(), item.getPlanedCost(),
                        planedCostTotal);

                // 枝番「02」
            } else {

                // 該当PjIdのレコード情報(枝番「02」以降)
                MDB0801Input correspondMdb0801Input =
                        !resultListMap.containsKey(mdb0801Input.getPjId()) ? new MDB0801Input()
                                : resultListMap.get(mdb0801Input.getPjId());


                // 該当PjIdのレコード情報(枝番「01」)
                MDB0801Input assumeMdb0801Input =
                        !resultListMap.containsKey(getBranchPjId(mdb0801Input.getPjId())) ? new MDB0801Input()
                                : resultListMap.get(getBranchPjId(mdb0801Input.getPjId()));

                /** 売上年度 */
                item.setSoldFiscalYear(new BigDecimal(mdb0801Input.getSoldFiscalYear()));

                /** プロジェクトID */
                item.setPjId(mdb0801Input.getPjId());

                /** プロジェクト名称 */
                item.setPjName(correspondMdb0801Input.getPjName());

                /** 物件区分 */
                item.setPjKbn(correspondMdb0801Input.getPjKbn());

                /** 名義会社 */
                item.setMeigiCorpCd(assumeMdb0801Input.getMeigiCorpCd());

                /** 顧客名称 */
                item.setCustomerName(assumeMdb0801Input.getCustomerName());

                /** BU */
                item.setBu(correspondMdb0801Input.getBu());

                /** プロジェクト属性ID */
                item.setPjAttId(correspondMdb0801Input.getPjAttId());

                /** 枝番 */
                item.setBranchNum(correspondMdb0801Input.getBranchNum());

                /** 契約件名 */
                item.setContractName(assumeMdb0801Input.getContractName());

                /** 契約工期(FROM) */
                item.setContractFrom(assumeMdb0801Input.getContractFrom());

                /** 契約工期(TO) */
                item.setContractTo(assumeMdb0801Input.getContractTo());

                /** 取引種別 */
                item.setDealType(correspondMdb0801Input.getDealType());

                /** 案件情報 */
                item.setPjInfo(assumeMdb0801Input.getPjInfo());

                /** 分野コード */
                item.setFieldCd(assumeMdb0801Input.getFieldCd());

                /** 分野コード名称 */
                item.setFieldName(assumeMdb0801Input.getFieldName());

                /** 業務コード */
                item.setBusinessCd(assumeMdb0801Input.getBusinessCd());

                /** 業務コード名称 */
                item.setBusinessName(assumeMdb0801Input.getBusinessName());

                /** 顧客種別 */
                item.setCustomerCategoryCd(assumeMdb0801Input.getCustomerCategoryCd());

                /** 物件管理責任者部門支社ＣＤ */
                item.setPjManageRespDeptBranchCd(assumeMdb0801Input.getPjManageRespDeptBranchCd());

                /** 物件管理責任者部門支社名称 */
                item.setPjManageRespDeptBranchName(assumeMdb0801Input.getPjManageRespDeptBranchName());

                /** 物件管理責任者部門部ＣＤ */
                item.setPjManageRespMDeptCd(assumeMdb0801Input.getPjManageRespMDeptCd());

                /** 物件管理責任者部門部名称 */
                item.setPjManageRespMDeptName(assumeMdb0801Input.getPjManageRespMDeptName());

                /** 物件管理責任者部門部署ＣＤ */
                item.setPjManageRespDeptCd(assumeMdb0801Input.getPjManageRespDeptCd());

                /** 物件管理責任者部門部署名称 */
                item.setPjManageRespDeptName(assumeMdb0801Input.getPjManageRespDeptName());

                /** 物件管理責任者ＣＤ */
                item.setPjManageRespEmpCd(assumeMdb0801Input.getPjManageRespEmpCd());

                /** 物件管理責任者名 */
                item.setPjManageRespEmpName(assumeMdb0801Input.getPjManageRespEmpName());

                /** 生産主管部門支社ＣＤ */
                item.setProductMainDeptBranchCd(assumeMdb0801Input.getProductMainDeptBranchCd());

                /** 生産主管部門支社名称 */
                item.setProductMainDeptBranchName(assumeMdb0801Input.getProductMainDeptBranchName());

                /** 生産主管部門部ＣＤ */
                item.setProductMainMDeptCd(assumeMdb0801Input.getProductMainMDeptCd());

                /** 生産主管部門部名称 */
                item.setProductMainMDeptName(assumeMdb0801Input.getProductMainMDeptName());

                /** 生産主管部門ＣＤ */
                item.setProductMainDeptCd(assumeMdb0801Input.getProductMainDeptCd());

                /** 生産主管部門名称 */
                item.setProductMainDeptName(assumeMdb0801Input.getProductMainDeptName());

                /** 生産プロデューサーＣＤ */
                item.setProductProducerEmpCd(assumeMdb0801Input.getProductProducerEmpCd());

                /** 生産プロデューサー名 */
                item.setProductProducerName(assumeMdb0801Input.getProductProducerName());

                /** 営業主管部門支社ＣＤ */
                item.setSalesMainDeptBranchCd(assumeMdb0801Input.getSalesMainDeptBranchCd());

                /** 営業主管部門支社名称 */
                item.setSalesMainDeptBranchName(assumeMdb0801Input.getSalesMainDeptBranchName());

                /** 営業主管部門部ＣＤ */
                item.setSalesMainMDeptCd(assumeMdb0801Input.getSalesMainMDeptCd());

                /** 営業主管部門部名称 */
                item.setSalesMainMDeptName(assumeMdb0801Input.getSalesMainMDeptName());

                /** 営業主管部門ＣＤ */
                item.setSalesMainDeptCd(assumeMdb0801Input.getSalesMainDeptCd());

                /** 営業主管部門名称 */
                item.setSalesMainDeptName(assumeMdb0801Input.getSalesMainDeptName());

                /** 営業担当者ＣＤ */
                item.setSalesEmpCd(assumeMdb0801Input.getSalesEmpCd());

                /** 営業担当者名 */
                item.setSalesEmpName(assumeMdb0801Input.getSalesEmpName());

                /** 生産担当部門支社ＣＤ */
                item.setProductDeptBranchCd(correspondMdb0801Input.getProductDeptBranchCd());

                /** 生産担当部門支社名称 */
                item.setProductDeptBranchName(correspondMdb0801Input.getProductDeptBranchName());

                /** 生産担当部門部ＣＤ */
                item.setProductMDeptCd(correspondMdb0801Input.getProductMDeptCd());

                /** 生産担当部門部名称 */
                item.setProductMDeptName(correspondMdb0801Input.getProductMDeptName());

                /** 生産担当部門ＣＤ */
                item.setProductDeptCd(correspondMdb0801Input.getProductDeptCd());

                /** 生産担当部門名称 */
                item.setProductDeptName(correspondMdb0801Input.getProductDeptName());

                /** 生産担当者ＣＤ */
                item.setProductEmpCd(correspondMdb0801Input.getProductEmpCd());

                /** 生産担当者名 */
                item.setProductEmpName(correspondMdb0801Input.getProductEmpName());

                /** 受注区分 */
                MDB0801Input correspondReceiveMdb0801Input =
                        (null == receiveresultListMap.get(mdb0801Input.getPjId() + mdb0801Input.getSoldFiscalYear()))
                                ? new MDB0801Input()
                                : receiveresultListMap.get(mdb0801Input.getPjId() + mdb0801Input.getSoldFiscalYear());
                item.setReceiveKbn(
                        getReceiveKbn(correspondReceiveMdb0801Input.getReceivedOn(), kbn, yyyymm, systemYearMonth));

                /** 受注日 */
                MDB0801Input assumeReceiveMdb0801Input = (null == receiveresultListMap
                        .get(mdb0801Input.getPjId().substring(0, 10) + "01" + mdb0801Input.getSoldFiscalYear()))
                                ? new MDB0801Input()
                                : receiveresultListMap.get(mdb0801Input.getPjId().substring(0, 10) + "01"
                                        + mdb0801Input.getSoldFiscalYear());
                item.setReceivedOn(assumeReceiveMdb0801Input.getReceivedOn());

                /** 受注額 */
                item.setReceivedMoney(BigDecimal.ZERO);

                /** 当該年度売上予定日 */
                item.setThisFiscalYearPlanedSellingOn(assumeReceiveMdb0801Input.getPlanedSellingOn());

                /** 当該年度売上日 */
                MDB0801Input assumeSalesMdb0801Input =
                        (null == salesListMap
                                .get(getBranchPjId(mdb0801Input.getPjId()) + mdb0801Input.getSoldFiscalYear()))
                                        ? new MDB0801Input()
                                        : salesListMap.get(getBranchPjId(mdb0801Input.getPjId())
                                                + mdb0801Input.getSoldFiscalYear());
                item.setThisFiscalYearSoldOn(assumeSalesMdb0801Input.getThisFiscalYearSoldOn());

                /** 最終売上予定日 */
                item.setLastPlanedSellingOn(correspondMdb0801Input.getLastPlanedSellingOn());

                /** 最終売上完了日 */
                item.setLastSoldOn(getEditedLastSoldOn(correspondMdb0801Input.getLastSoldOn(),receiveDate));

                /** 完了フラグ */
                item.setPjEnded(correspondMdb0801Input.getPjEnded());

                /** ステータス */
                item.setPjStatus(correspondMdb0801Input.getPjStatus());

                /** 高原価・政策受注フラグ */
                item.setHighCostReceive(null == assumeReceiveMdb0801Input.getHighCostReceive() ? "0"
                        : assumeReceiveMdb0801Input.getHighCostReceive());

                /** 応札時積算額 */
                item.setOsatsuPlanedAmount(BigDecimal.ZERO);

                /** 応札時積算率 */
                item.setOsatsuPlanedRate(BigDecimal.ZERO);

                /** 一般売上 */
                item.setOutsideSoldAmount(BigDecimal.ZERO);

                /** 関係会社売上額 */
                item.setGroupSoldAmount(BigDecimal.ZERO);

                /** 売上物件原価率 */
                item.setSoldPjCostRate(BigDecimal.ZERO);

                /** 期首仕掛原価 */
                if(String.valueOf(fiscalYMSystem).equals(mdb0801Input.getSoldFiscalYear())
                        && sapInProcessCostList.size() == 0
                        && kbn.equals("D")) {
                    item.setKisyuWorkingCost(getKisyuWorkingCost(mdb0801Input.getPjId(), mdDispPropertyMonthlyList, item.getThisFiscalYearSoldOn(), systemYearMonth));
                } else {
                    item.setKisyuWorkingCost(
                            addBD(
                                null == correspondSapWidgetCostMdb0801Input.getKisyuWorkingCost() ? BigDecimal.ZERO : correspondSapWidgetCostMdb0801Input.getKisyuWorkingCost(),
                                getMdOutsourcingOrderedCost(mdb0801Input.getPjId(), mdOutsourcingList, mdb0801Input.getSoldFiscalYear(), receiveresultListMap))
                            );
                }

                /** ⑬期首仕掛品原価差異 */
                if(String.valueOf(fiscalYMSystem).equals(mdb0801Input.getSoldFiscalYear()) && sapInProcessCostList.size() == 0 && kbn.equals("D")) {
                    if(correspondSapWidgetCostMdb0801Input2.getInprocessCostBalance() == null
                            && correspondSapWidgetCostMdb0801Input2.getCurrentCostBalance() == null) {
                        item.setKisyuWorkingCostDifference(BigDecimal.ZERO);
                    }else {

                        item.setKisyuWorkingCostDifference(addBD(correspondSapWidgetCostMdb0801Input2.getInprocessCostBalance(), correspondSapWidgetCostMdb0801Input2.getCurrentCostBalance()));
                    }
                } else {
                    item.setKisyuWorkingCostDifference(
                            null == correspondSapWidgetCostMdb0801Input.getKisyuWorkingCostDifference() ? BigDecimal.ZERO
                                    : correspondSapWidgetCostMdb0801Input.getKisyuWorkingCostDifference());
                }

                /** 社員工数 */
                item.setEmpKosu(getAmountPerformance(receiveDate, "01", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountCostPerformancetListMap, rResultListMap));

                /** 積算社員工数 */
                item.setPlanedEmpKosu(getAmountIntegration(receiveDate, "01", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountCostIntegrationListMap, rResultListMap));

                /** ①人件費（直接） */
                item.setDirectLaborCost(getAmountPerformance(receiveDate, "01", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountPerformancetListMap, rResultListMap));

                /** 積算①人件費（直接） */
                item.setPlanedDirectLaborCost(getAmountIntegration(receiveDate, "01", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountIntegrationListMap, rResultListMap));

                /** 臨時時間 */
                item.setTempEmpKosu(getAmountPerformance(receiveDate, "02", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountCostPerformancetListMap, rResultListMap));

                /** 積算臨時時間 */
                item.setPlanedTempEmpKosu(getAmountIntegration(receiveDate, "02", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountCostIntegrationListMap, rResultListMap));

                /** ②臨時人件費 */
                item.setTempLaborCost(getAmountPerformance(receiveDate, "02", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountPerformancetListMap, rResultListMap));

                /** 積算②臨時人件費 */
                item.setPlanedTempLaborCost(getAmountIntegration(receiveDate, "02", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountIntegrationListMap, rResultListMap));

                /** ③－１外注費（一般）発注ベース */
                item.setOutsideOrderedCost(
                        null == correspondExceptPayBasisMdb0801Input.getOutsideOrderedCost() ? BigDecimal.ZERO
                                : correspondExceptPayBasisMdb0801Input.getOutsideOrderedCost());

                /** 積算③－１外注費（一般）発注ベース */
                item.setPlanedOutsideOrderingCost(getAmountIntegration(receiveDate, "03", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountIntegrationListMap, rResultListMap));

                /** ③－２外注費（一般）支払ベース */
                item.setOutsidePaidCost(
                        null == correspondExceptPayBasisMdb0801Input.getOutsidePaidCost() ? BigDecimal.ZERO
                                : correspondExceptPayBasisMdb0801Input.getOutsidePaidCost());

                /** ③－３外注費（関係）発注ベース */
                item.setGroupOrderedCost(
                        null == correspondExceptPayBasisMdb0801Input.getGroupOrderedCost() ? BigDecimal.ZERO
                                : correspondExceptPayBasisMdb0801Input.getGroupOrderedCost());

                /** 積算③－３外注費（関係）発注ベース */
                item.setPlanedGroupOrderingCost(getAmountIntegration(receiveDate, "32", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountIntegrationListMap, rResultListMap));

                /** ③－４外注費（関係）支払ベース */
                item.setGroupPaidCost(null == correspondExceptPayBasisMdb0801Input.getGroupPaidCost() ? BigDecimal.ZERO
                        : correspondExceptPayBasisMdb0801Input.getGroupPaidCost());

                /** 業務委託費発注ベース */
                item.setEntrustOrderedCost(
                        null == correspondExceptPayBasisMdb0801Input.getEntrustOrderedCost() ? BigDecimal.ZERO
                                : correspondExceptPayBasisMdb0801Input.getEntrustOrderedCost());

                /** 積算業務委託費 */
                item.setPlanedEntrustCost(getAmountIntegration(receiveDate, "10", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountIntegrationListMap, rResultListMap));

                /** 業務委託費支払ベース */
                item.setEntrustPaidCost(
                        null == correspondExceptPayBasisMdb0801Input.getEntrustPaidCost() ? BigDecimal.ZERO
                                : correspondExceptPayBasisMdb0801Input.getEntrustPaidCost());

                /** 未発注外注費（一般）支払ベース */
                item.setNonOrderedOutsidePaidCost(
                        null == correspondPayBasisMdb0801Input.getNonOrderedOutsidePaidCost() ? BigDecimal.ZERO
                                : correspondPayBasisMdb0801Input.getNonOrderedOutsidePaidCost());

                /** 未発注外注費（関係）支払ベース */
                item.setNonOrderedGroupPaidCost(
                        null == correspondPayBasisMdb0801Input.getNonOrderedGroupPaidCost() ? BigDecimal.ZERO
                                : correspondPayBasisMdb0801Input.getNonOrderedGroupPaidCost());

                /** ④材料費 */
                item.setMaterialCost(getAmountPerformance(receiveDate, "05", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountPerformancetListMap, rResultListMap));

                /** 積算④材料費 */
                item.setPlanedMaterialCost(getAmountIntegration(receiveDate, "05", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountIntegrationListMap, rResultListMap));

                /** ⑤印刷製本費 */
                item.setPrintingBindingCost(getAmountPerformance(receiveDate, "06", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountPerformancetListMap, rResultListMap));

                /** 積算⑤印刷製本費 */
                item.setPlanedPrintingBindingCost(getAmountIntegration(receiveDate, "06", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountIntegrationListMap, rResultListMap));

                /** ⑥旅費交通費 */
                item.setTravelingCarfareCost(getAmountPerformance(receiveDate, "04", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountPerformancetListMap, rResultListMap));

                /** 積算⑥旅費交通費 */
                item.setPlanedTravelingCarfareCost(getAmountIntegration(receiveDate, "04", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountIntegrationListMap, rResultListMap));

                /** ⑦車両費 */
                item.setCarCost(getAmountPerformance(receiveDate, "07", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountPerformancetListMap, rResultListMap));

                /** 積算⑦車両費 */
                item.setPlanedCarCost(getAmountIntegration(receiveDate, "07", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountIntegrationListMap, rResultListMap));

                /** ⑧大型機材 */
                item.setLargeMachine(getAmountPerformance(receiveDate, "08", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountPerformancetListMap, rResultListMap));

                /** 積算⑧大型機材 */
                item.setPlanedLargeMachine(getAmountIntegration(receiveDate, "08", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountIntegrationListMap, rResultListMap));

                /** ⑨直接作業経費 */
                item.setDirectWorkCost(getAmountPerformance(receiveDate, "09", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountPerformancetListMap, rResultListMap));

                /** 積算⑨直接作業経費 */
                item.setPlanedDirectWorkCost(getAmountIntegration(receiveDate, "09", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountIntegrationListMap, rResultListMap));

                /** ⑪間接費 */
                item.setIndirectCost(getAmountPerformance(receiveDate, "11", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountPerformancetListMap, rResultListMap));

                /** 積算⑪間接費 */
                item.setPlanedIndirectCost(getAmountIntegration(receiveDate, "11", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountIntegrationListMap, rResultListMap));

                /** ⑫その他事業部間取引 */
                item.setOtherCost(getAmountPerformance(receiveDate, "12", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountPerformancetListMap, rResultListMap));

                /** 積算⑫その他事業部間取引 */
                item.setPlanedOtherCost(BigDecimal.ZERO);

                /** ⑮他勘定振替 */
                item.setAccountTransaction(getAmountPerformance(receiveDate, "15", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountPerformancetListMap, rResultListMap));

                /** 積算⑰原価合計 */
                item.setPlanedGenkagokei(BigDecimal.ZERO);

                /** ⑱売上原価 */
                item.setSalesCost(getAmountPerformance(receiveDate, "18", mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountPerformancetListMap, rResultListMap));

                /** 進捗率 */
                item.setProgressRate(null == progressRateListMap
                        .get(mdb0801Input.getPjId().substring(0, 10) + mdb0801Input.getSoldFiscalYear())
                                ? BigDecimal.ZERO
                                : (null == progressRateListMap
                                        .get(mdb0801Input.getPjId().substring(0, 10) + mdb0801Input.getSoldFiscalYear())
                                        .getProgressRate()) ? BigDecimal.ZERO
                                                : progressRateListMap
                                                        .get(mdb0801Input.getPjId().substring(0, 10)
                                                                + mdb0801Input.getSoldFiscalYear())
                                                        .getProgressRate()
                                                        .divide(new BigDecimal("100"), 3, BigDecimal.ROUND_HALF_UP));

                /** 初回積算日 */
                item.setFirstPlanedOn(null == firstBasicInformationListMap.get(mdb0801Input.getPjId()) ? null
                        : firstBasicInformationListMap.get(mdb0801Input.getPjId()).getUpdatePlanedOn());

                /** 全年度初回積算額 */
                item.setFirstPlanedAmount(getFirstPlanedAmount(amountIntegration3List, mdb0801Input.getPjId()));

                /** 更新積算日 */
                item.setUpdatePlanedOn(null == basicInformationListMap.get(mdb0801Input.getPjId()) ? null
                        : basicInformationListMap.get(mdb0801Input.getPjId()).getUpdatePlanedOn());

                /** 並び順_物件管理責任者部門 */
                item.setSortNumPjManageRespDept(assumeMdb0801Input.getSortNumPjManageRespDept());

                /** 並び順_生産主管部門 */
                item.setSortNumProductMainDept(assumeMdb0801Input.getSortNumProductMainDept());

                /** 並び順_営業主管部門 */
                item.setSortNumSalesMainDept(assumeMdb0801Input.getSortNumSalesMainDept());

                /** 並び順_生産担当部門 */
                item.setSortNumProductDept(correspondMdb0801Input.getSortNumProductDept());

                /** 追加原価 */
                item.setAddCost(getAddCost(item.getPjId(), item.getLastSoldOn(), addAmountListMap,
                        addCostPayBasisListMap, receiveDate, receiveresultListMap, item.getSoldFiscalYear()));

                /** ⑩直接費合計 */
                BigDecimal directCostSum = BigDecimal.ZERO;
                // ①＋②＋④＋⑤＋⑥＋⑦＋⑧＋⑨
                directCostSum = addBD(directCostSum, item.getDirectLaborCost());
                directCostSum = addBD(directCostSum, item.getTempLaborCost());
                directCostSum = addBD(directCostSum, item.getMaterialCost());
                directCostSum = addBD(directCostSum, item.getPrintingBindingCost());
                directCostSum = addBD(directCostSum, item.getTravelingCarfareCost());
                directCostSum = addBD(directCostSum, item.getCarCost());
                directCostSum = addBD(directCostSum, item.getLargeMachine());
                directCostSum = addBD(directCostSum, item.getDirectWorkCost());
                // ・［プロジェクト．プロジェクト種別］が「P」、［プロジェクト．最終売上完了日］が設定されている場合
                if (item.getPjId().substring(2, 3).equals("P") && (!StringUtils.isEmpty(item.getLastSoldOn())
                        && Integer.parseInt(item.getLastSoldOn().replaceAll("-", "").substring(0, 6)) <= Integer
                                .parseInt(receiveDate))) {

                    // 「③－２」＋「③－４」＋「業務委託費支払ベース」＋「未発注外注費（一般）支払ベース」＋「未発注外注費（関係）支払ベース」
                    directCostSum = addBD(directCostSum, item.getOutsidePaidCost());
                    directCostSum = addBD(directCostSum, item.getGroupPaidCost());
                    directCostSum = addBD(directCostSum, item.getEntrustPaidCost());
                    directCostSum = addBD(directCostSum, item.getNonOrderedOutsidePaidCost());
                    directCostSum = addBD(directCostSum, item.getNonOrderedGroupPaidCost());

                    // 「③－１」＋「③－３」＋「業務委託費発注ベース」
                } else {
                    directCostSum = addBD(directCostSum, item.getOutsideOrderedCost());
                    directCostSum = addBD(directCostSum, item.getGroupOrderedCost());
                    directCostSum = addBD(directCostSum, item.getEntrustOrderedCost());
                }

                item.setDirectCost(directCostSum);

                /** ⑭総原価 */
                BigDecimal sogenkaSum = BigDecimal.ZERO;
                // ⑩＋⑪＋⑫＋⑬＋追加原価
                sogenkaSum = addBD(sogenkaSum, item.getDirectCost());
                sogenkaSum = addBD(sogenkaSum, item.getIndirectCost());
                sogenkaSum = addBD(sogenkaSum, item.getOtherCost());
                sogenkaSum = addBD(sogenkaSum, item.getKisyuWorkingCostDifference());
                sogenkaSum = addBD(sogenkaSum, item.getAddCost());
                item.setSogenka(sogenkaSum);

                /** 売上種別区分 */
                item.setSalesTypeKbn(getSalesTypeKbn(item.getPjId(), item.getLastSoldOn(), item.getSoldFiscalYear(),
                        ym1.substring(0, 4) + "-" + ym1.substring(4, 6), item.getAddCost(), item.getSogenka(),
                        receiveDate,"",receiveresultListMap));

                /** 売上種別 */
                item.setSalesType(getSalesType(item.getPjId(), correspondMdb0801Input.getSoldOn(),
                        correspondMdb0801Input.getPlanedSellingOn(), correspondMdb0801Input.getLastSoldOn(), ym1,
                        receiveDate,receiveresultListMap));

                /** ⑳人件費（直・間接合計） */
                item.setLaborCost(addBD(item.getDirectLaborCost(), item.getIndirectCost()));

                /** 積算⑳人件費（直・間接合計） */
                item.setPlanedLaborCost(addBD(item.getPlanedDirectLaborCost(), item.getPlanedIndirectCost()));

                /** ⑯今期原価差異 */
                if(String.valueOf(fiscalYMSystem).equals(mdb0801Input.getSoldFiscalYear()) && sapInProcessCostList.size() == 0 && kbn.equals("D")) {
                    item.setThisFiscalYearCostDifference(BigDecimal.ZERO);
                } else {
                    item.setThisFiscalYearCostDifference(
                            null == correspondSapWidgetCostMdb0801Input.getThisFiscalYearCostDifference() ? BigDecimal.ZERO
                                    : correspondSapWidgetCostMdb0801Input.getThisFiscalYearCostDifference());
                }

                /** ⑰原価合計 */
                BigDecimal genkagokeiSum = BigDecimal.ZERO;
                // ⑭＋⑮＋⑯
                genkagokeiSum = addBD(genkagokeiSum, item.getSogenka());
                genkagokeiSum = addBD(genkagokeiSum, item.getAccountTransaction());
                genkagokeiSum = addBD(genkagokeiSum, item.getThisFiscalYearCostDifference());
                item.setGenkagokei(genkagokeiSum);
                putTotalNum(item.getPjId().substring(0, 10) + item.getSoldFiscalYear(), item.getGenkagokei(),
                        genkagokeiTotal17);

                /** 受注原価率 */
                item.setReceivedCostRate(BigDecimal.ZERO);

                /** ⑲期末仕掛原価 */
                item.setKimatsuWorkingCost(item.getGenkagokei().subtract(item.getSalesCost()));

                /** 積算⑩直接費合計 */
                BigDecimal planedDirectCostSum = BigDecimal.ZERO;
                // 積算①＋積算②＋積算④＋積算⑤＋積算⑥＋積算⑦＋積算⑧＋積算⑨＋「積算③－１」＋「積算③－３」＋「積算業務委託費」
                planedDirectCostSum = addBD(planedDirectCostSum, item.getPlanedDirectLaborCost());
                planedDirectCostSum = addBD(planedDirectCostSum, item.getPlanedTempLaborCost());
                planedDirectCostSum = addBD(planedDirectCostSum, item.getPlanedMaterialCost());
                planedDirectCostSum = addBD(planedDirectCostSum, item.getPlanedPrintingBindingCost());
                planedDirectCostSum = addBD(planedDirectCostSum, item.getPlanedTravelingCarfareCost());
                planedDirectCostSum = addBD(planedDirectCostSum, item.getPlanedCarCost());
                planedDirectCostSum = addBD(planedDirectCostSum, item.getPlanedLargeMachine());
                planedDirectCostSum = addBD(planedDirectCostSum, item.getPlanedDirectWorkCost());
                planedDirectCostSum = addBD(planedDirectCostSum, item.getPlanedOutsideOrderingCost());
                planedDirectCostSum = addBD(planedDirectCostSum, item.getPlanedGroupOrderingCost());
                planedDirectCostSum = addBD(planedDirectCostSum, item.getPlanedEntrustCost());
                item.setPlanedDirectCost(planedDirectCostSum);

                /** 当該年度積算額 */
                // 積算⑩＋積算⑪
                item.setThisFiscalYearPlanedAmount(addBD(item.getPlanedDirectCost(), item.getPlanedIndirectCost()));
                putTotalNum(item.getPjId().substring(0, 10) + item.getSoldFiscalYear(),
                        item.getThisFiscalYearPlanedAmount(), thisFiscalYearPlanedAmountTotal);

                /** 当該年度積算原価率 */
                if (item.getThisFiscalYearPlanedAmount().compareTo(BigDecimal.ZERO) == 0) {
                    item.setThisFiscalYearPlanedCostRate(BigDecimal.ZERO);
                } else {
                    item.setThisFiscalYearPlanedCostRate(item.getSogenka().divide(item.getThisFiscalYearPlanedAmount(),
                            3, BigDecimal.ROUND_HALF_UP));
                }

                /** 見込み原価 */
                BigDecimal planedCost = BigDecimal.ZERO;

                if (null != item.getSalesTypeKbn() && item.getSalesTypeKbn().equals("1")) {

                    planedCost = item.getGenkagokei();
                } else {

                    if (item.getGenkagokei().compareTo(item.getThisFiscalYearPlanedAmount()) >= 0) {
                        planedCost = item.getGenkagokei();
                    } else {
                        planedCost = item.getThisFiscalYearPlanedAmount();
                    }
                }
                item.setPlanedCost(planedCost);
                putTotalNum(item.getPjId().substring(0, 10) + item.getSoldFiscalYear(), item.getPlanedCost(),
                        planedCostTotal);

                /** 全年度積算額 */
                item.setPlanedAmount(null == sumAmountListMap.get(item.getPjId()) ? BigDecimal.ZERO
                        : null == sumAmountListMap.get(item.getPjId()).getKINGAKU()? BigDecimal.ZERO : sumAmountListMap.get(item.getPjId()).getKINGAKU());

                /** 当該年度初回積算額 */
                item.setThisFiscalYearFirstPlanedAmount(getAmountIntegration3(receiveDate, mdb0801Input.getPjId(),
                        mdb0801Input.getSoldFiscalYear(), receiveresultListMap, amountIntegration3ListMap, rResultListMap));

                /** 当該年度初回積算原価率 */
                if (null == item.getThisFiscalYearFirstPlanedAmount()
                        || item.getThisFiscalYearFirstPlanedAmount().compareTo(BigDecimal.ZERO) == 0) {
                    item.setThisFiscalYearFirstPlanedCostRate(BigDecimal.ZERO);
                } else {
                    item.setThisFiscalYearFirstPlanedCostRate(item.getSogenka()
                            .divide(item.getThisFiscalYearFirstPlanedAmount(), 3, BigDecimal.ROUND_HALF_UP));
                }

                /** 全年度積算原価率 */
                BigDecimal planedAmountRateSum = BigDecimal.ZERO;

                planedAmountRateSum = addBD(planedAmountRateSum,
                        (null == allSumTotalCostAmountListMap.get(item.getPjId())) ? BigDecimal.ZERO
                                : allSumTotalCostAmountListMap.get(item.getPjId()).getKINGAKU());
                // ・［プロジェクト．プロジェクト種別］が「P」、［プロジェクト．最終売上完了日］が設定されている場合
                if (item.getPjId().substring(2, 3).equals("P")
                        && (null != item.getLastSoldOn() && item.getLastSoldOn().length() > 0)) {

                    // 「③－２」＋「③－４」＋「業務委託費支払ベース」＋「未発注外注費（一般）支払ベース」＋「未発注外注費（関係）支払ベース」
                    planedAmountRateSum = addBD(planedAmountRateSum,
                            (null == allSumExceptListMap.get(item.getPjId())) ? BigDecimal.ZERO
                                    : allSumExceptListMap.get(item.getPjId()).getGICHUSB());
                    planedAmountRateSum =
                            addBD(planedAmountRateSum, (null == allSumOnlyListMap.get(item.getPjId())) ? BigDecimal.ZERO
                                    : allSumOnlyListMap.get(item.getPjId()).getGICHUSBM());

                    // 「③－１」＋「③－３」＋「業務委託費発注ベース」
                } else {
                    planedAmountRateSum = addBD(planedAmountRateSum,
                            (null == allSumExceptListMap.get(item.getPjId())) ? BigDecimal.ZERO
                                    : allSumExceptListMap.get(item.getPjId()).getGICHUHB());
                }

                planedAmountRateSum =
                        addBD(planedAmountRateSum, item.getKisyuWorkingCostDifference());

                // 全年度の金額の追加原価（金額）
                planedAmountRateSum =
                        addBD(planedAmountRateSum, (null == addAmountSumListMap.get(item.getPjId())) ? BigDecimal.ZERO
                                : addAmountSumListMap.get(item.getPjId()).getADDKINGAKU());

                // 全年度の外注情報の追加原価（金額）
                planedAmountRateSum = addBD(planedAmountRateSum,
                        (null == addCostPayBasisSumListMap.get(item.getPjId())) ? BigDecimal.ZERO
                                : addCostPayBasisSumListMap.get(item.getPjId()).getADDKINGAKU());

                if (item.getPlanedAmount().compareTo(BigDecimal.ZERO) == 0) {
                    item.setPlanedAmountRate(BigDecimal.ZERO);
                } else {
                    item.setPlanedAmountRate(
                            planedAmountRateSum.divide(item.getPlanedAmount(), 3, BigDecimal.ROUND_HALF_UP));
                }

                // 全年度の⑭
                item.setPreviousYear(planedAmountRateSum);

                /** 全年度初回積算原価率 */
                if (item.getFirstPlanedAmount().compareTo(BigDecimal.ZERO) == 0) {
                    item.setFirstPlanedAmountRate(BigDecimal.ZERO);
                } else {
                    item.setFirstPlanedAmountRate(
                            planedAmountRateSum.divide(item.getFirstPlanedAmount(), 3, BigDecimal.ROUND_HALF_UP));
                }

                /** 見込み原価率 */
                item.setPlanedCostRate(BigDecimal.ZERO);

            }

            outputItems.add(item);
        }

        logger.debug("計算処理  開始");
        for (MDB0801Output mdb0801Output : outputItems) {

            /** ⑰ 合計 */
            BigDecimal genkagokei = (null == genkagokeiTotal17
                    .get(mdb0801Output.getPjId().substring(0, 10) + mdb0801Output.getSoldFiscalYear()))
                            ? BigDecimal.ZERO
                            : genkagokeiTotal17
                                    .get(mdb0801Output.getPjId().substring(0, 10) + mdb0801Output.getSoldFiscalYear());

            /** 当該年度積算額 合計 */
            BigDecimal thisFiscalYearPlanedAmount = (null == thisFiscalYearPlanedAmountTotal
                    .get(mdb0801Output.getPjId().substring(0, 10) + mdb0801Output.getSoldFiscalYear()))
                            ? BigDecimal.ZERO
                            : thisFiscalYearPlanedAmountTotal
                                    .get(mdb0801Output.getPjId().substring(0, 10) + mdb0801Output.getSoldFiscalYear());

            // 枝番「01」
            if (isBranch01PjId(mdb0801Output.getPjId())) {

                /** 受注原価率 */
                mdb0801Output.setReceivedCostRate(getReceivedCostRate(genkagokei, mdb0801Output.getOutsideSoldAmount(),
                        mdb0801Output.getSalesTypeKbn(), mdb0801Output.getGroupSoldAmount(),
                        mdb0801Output.getReceivedMoney()));

                /** 売上物件原価率 */
                if (thisFiscalYearPlanedAmount.compareTo(BigDecimal.ZERO) == 0) {
                    mdb0801Output.setSoldPjCostRate(BigDecimal.ZERO);
                } else {
                    mdb0801Output.setSoldPjCostRate(
                            genkagokei.divide(thisFiscalYearPlanedAmount, 3, BigDecimal.ROUND_HALF_UP));
                }

                /** 見込み原価率 */
                /** 見込み原価 合計 */
                BigDecimal planedCost = (null == planedCostTotal
                        .get(mdb0801Output.getPjId().substring(0, 10) + mdb0801Output.getSoldFiscalYear()))
                                ? BigDecimal.ZERO
                                : planedCostTotal.get(
                                        mdb0801Output.getPjId().substring(0, 10) + mdb0801Output.getSoldFiscalYear());

                mdb0801Output.setPlanedCostRate(getReceivedCostRate(planedCost, mdb0801Output.getOutsideSoldAmount(),
                        mdb0801Output.getSalesTypeKbn(), mdb0801Output.getGroupSoldAmount(),
                        mdb0801Output.getReceivedMoney()));

                // 枝番「02」
            } else {

                /** 生産高 */
                // （プロジェクトIDの［【TEMP】物件管理．当該年度積算額］÷BU+PJ属性の［【TEMP】物件管理．当該年度積算額］）×「BU+PJ属性+枝番01」の［【TEMP】物件管理．受注額］
                if (thisFiscalYearPlanedAmount.compareTo(BigDecimal.ZERO) == 0) {
                    mdb0801Output.setSeisandaka(BigDecimal.ZERO);

                } else {

                    BigDecimal receivedMoney = BigDecimal.ZERO;
                    for (MDB0801Output output : outputItems) {

                        if(output.getPjId().equals(mdb0801Output.getPjId().substring(0, 10) + "01")
                                && output.getSoldFiscalYear().equals(mdb0801Output.getSoldFiscalYear())) {
                            receivedMoney = output.getReceivedMoney();
                        }
                    }

                    mdb0801Output.setSeisandaka(
                            multiplyBD(mdb0801Output.getThisFiscalYearPlanedAmount().divide(thisFiscalYearPlanedAmount,
                                    12, BigDecimal.ROUND_HALF_UP), receivedMoney));
                }
            }
        }

        return outputItems;
    }

    private BigDecimal getAmountPerformance(String ym, String himoku, String pjId, String soldFiscalYear,
            Map<String, MDB0801Input> receiveresultListMap, Map<String, MDB0801Input> amountPerformancetListMap, Map<String, MDB0801Input> rResultListMap) {

        BigDecimal rtn = BigDecimal.ZERO;

        String dateFrom = null;
        String dateTo = null;

        if(pjId.substring(2, 3).equals("R")) {
            dateFrom = "190001";
            dateTo = "999901";
        }else {
            dateFrom = receiveresultListMap.containsKey(pjId + soldFiscalYear)
                    ? receiveresultListMap.get(pjId + soldFiscalYear).getDateFrom()
                    : null;
            dateTo = receiveresultListMap.containsKey(pjId + soldFiscalYear)
                    ? receiveresultListMap.get(pjId + soldFiscalYear).getDateTo()
                    : null;

            if (null == dateFrom || null == dateTo) {
                dateFrom = "190001";
                dateTo = "999901";
                // 日次処理の場合
                if (kbn.equals("M")) {
                    dateTo = yyyymm;
                }
            }
        }

        String ymMax = amountPerformancetListMap.containsKey(pjId + soldFiscalYear)
                ? amountPerformancetListMap.get(pjId + soldFiscalYear).getYmAmount()
                : null;
        String ymMin = ymMax;

        if (null != dateFrom && null != dateTo && null != ymMax && null != ymMin && !dateFrom.equals("")
                && !dateTo.equals("") && !ymMax.equals("") && !ymMin.equals("")) {

            // 指定月
            int intYm = Integer.parseInt(ym);

            // 金額．年月 Max
            int intYmMax = Integer.parseInt(ymMax);

            // 金額．年月 Min
            int intYmMin = Integer.parseInt(ymMin);

            // from
            int intDateFrom = Integer.parseInt(dateFrom);

            // to
            int intDateTo = Integer.parseInt(dateTo);

            switch (himoku) {
                case "01":
                    if (intYmMax <= intYm && (intDateFrom <= intYmMin && intYmMax <= intDateTo)) {
                        rtn = amountPerformancetListMap.get(pjId + soldFiscalYear).getHimoku01();
                    }
                    break;
                case "02":
                    if (intYmMax <= intYm && (intDateFrom <= intYmMin && intYmMax <= intDateTo)) {
                        rtn = amountPerformancetListMap.get(pjId + soldFiscalYear).getHimoku02();
                    }
                    break;
                case "05":
                    if (intYmMax <= intYm && (intDateFrom <= intYmMin && intYmMax <= intDateTo)) {
                        rtn = amountPerformancetListMap.get(pjId + soldFiscalYear).getHimoku05();
                    }
                    break;
                case "06":
                    if (intYmMax <= intYm && (intDateFrom <= intYmMin && intYmMax <= intDateTo)) {
                        rtn = amountPerformancetListMap.get(pjId + soldFiscalYear).getHimoku06();
                    }
                    break;
                case "04":
                    if (intYmMax <= intYm && (intDateFrom <= intYmMin && intYmMax <= intDateTo)) {
                        rtn = amountPerformancetListMap.get(pjId + soldFiscalYear).getHimoku04();
                    }
                    break;
                case "07":
                    if (intYmMax <= intYm && (intDateFrom <= intYmMin && intYmMax <= intDateTo)) {
                        rtn = amountPerformancetListMap.get(pjId + soldFiscalYear).getHimoku07();
                    }
                    break;
                case "08":
                    if (intYmMax <= intYm && (intDateFrom <= intYmMin && intYmMax <= intDateTo)) {
                        rtn = amountPerformancetListMap.get(pjId + soldFiscalYear).getHimoku08();
                    }
                    break;
                case "09":
                    if (intYmMax <= intYm && (intDateFrom <= intYmMin && intYmMax <= intDateTo)) {
                        rtn = amountPerformancetListMap.get(pjId + soldFiscalYear).getHimoku09();
                    }
                    break;
                case "11":
                    if (intYmMax <= intYm && (intDateFrom <= intYmMin && intYmMax <= intDateTo)) {
                        rtn = amountPerformancetListMap.get(pjId + soldFiscalYear).getHimoku11();
                    }
                    break;
                case "12":
                    if (intYmMax <= intYm && (intDateFrom <= intYmMin && intYmMax <= intDateTo)) {
                        rtn = amountPerformancetListMap.get(pjId + soldFiscalYear).getHimoku12();
                    }
                    break;
                case "15":
                    if (intYmMax <= intYm && (intDateFrom <= intYmMin && intYmMax <= intDateTo)) {
                        rtn = amountPerformancetListMap.get(pjId + soldFiscalYear).getHimoku15();
                    }
                    break;
                case "18":
                    if (intYmMax <= intYm && (intDateFrom <= intYmMin && intYmMax <= intDateTo)) {
                        rtn = amountPerformancetListMap.get(pjId + soldFiscalYear).getHimoku18();
                    }
                    break;
            }
        }

        return rtn;
    }

    private BigDecimal getAmountIntegration(String ym, String himoku, String pjId, String soldFiscalYear,
            Map<String, MDB0801Input> receiveresultListMap, Map<String, MDB0801Input> amountIntegrationListMap, Map<String, MDB0801Input> rResultListMap) {

        BigDecimal rtn = BigDecimal.ZERO;

        String dateFrom = null;
        String dateTo = null;

        if(pjId.substring(2, 3).equals("R")) {
            dateFrom = "190001";
            dateTo = "999901";
        }else {
            dateFrom = receiveresultListMap.containsKey(pjId + soldFiscalYear)
                    ? receiveresultListMap.get(pjId + soldFiscalYear).getDateFrom()
                    : null;
            dateTo = receiveresultListMap.containsKey(pjId + soldFiscalYear)
                    ? receiveresultListMap.get(pjId + soldFiscalYear).getDateTo()
                    : null;

            if (null == dateFrom || null == dateTo) {
                dateFrom = "190001";
                dateTo = "999901";
            }
        }

        String ymMax = amountIntegrationListMap.containsKey(pjId + soldFiscalYear)
                ? amountIntegrationListMap.get(pjId + soldFiscalYear).getYmAmount()
                : null;
        String ymMin = ymMax;

        if (null != dateFrom && null != dateTo && null != ymMax && null != ymMin && !dateFrom.equals("")
                && !dateTo.equals("") && !ymMax.equals("") && !ymMin.equals("")) {

            // 金額．年月 Max
            int intYmMax = Integer.parseInt(ymMax);

            // 金額．年月 Min
            int intYmMin = Integer.parseInt(ymMin);

            // from
            int intDateFrom = Integer.parseInt(dateFrom);

            // to
            int intDateTo = Integer.parseInt(dateTo);

            switch (himoku) {
                case "01":
                    if (intDateFrom <= intYmMin && intYmMax <= intDateTo) {
                        rtn = amountIntegrationListMap.get(pjId + soldFiscalYear).getHimoku01();
                    }
                    break;
                case "02":
                    if (intDateFrom <= intYmMin && intYmMax <= intDateTo) {
                        rtn = amountIntegrationListMap.get(pjId + soldFiscalYear).getHimoku02();
                    }
                    break;
                case "03":
                    if (intDateFrom <= intYmMin && intYmMax <= intDateTo) {
                        rtn = amountIntegrationListMap.get(pjId + soldFiscalYear).getHimoku03();
                    }
                    break;
                case "32":
                    if (intDateFrom <= intYmMin && intYmMax <= intDateTo) {
                        rtn = amountIntegrationListMap.get(pjId + soldFiscalYear).getHimoku32();
                    }
                    break;
                case "10":
                    if (intDateFrom <= intYmMin && intYmMax <= intDateTo) {
                        rtn = amountIntegrationListMap.get(pjId + soldFiscalYear).getHimoku10();
                    }
                    break;
                case "05":
                    if (intDateFrom <= intYmMin && intYmMax <= intDateTo) {
                        rtn = amountIntegrationListMap.get(pjId + soldFiscalYear).getHimoku05();
                    }
                    break;
                case "06":
                    if (intDateFrom <= intYmMin && intYmMax <= intDateTo) {
                        rtn = amountIntegrationListMap.get(pjId + soldFiscalYear).getHimoku06();
                    }
                    break;
                case "04":
                    if (intDateFrom <= intYmMin && intYmMax <= intDateTo) {
                        rtn = amountIntegrationListMap.get(pjId + soldFiscalYear).getHimoku04();
                    }
                    break;
                case "07":
                    if (intDateFrom <= intYmMin && intYmMax <= intDateTo) {
                        rtn = amountIntegrationListMap.get(pjId + soldFiscalYear).getHimoku07();
                    }
                    break;
                case "08":
                    if (intDateFrom <= intYmMin && intYmMax <= intDateTo) {
                        rtn = amountIntegrationListMap.get(pjId + soldFiscalYear).getHimoku08();
                    }
                    break;
                case "09":
                    if (intDateFrom <= intYmMin && intYmMax <= intDateTo) {
                        rtn = amountIntegrationListMap.get(pjId + soldFiscalYear).getHimoku09();
                    }
                    break;
                case "11":
                    if (intDateFrom <= intYmMin && intYmMax <= intDateTo) {
                        rtn = amountIntegrationListMap.get(pjId + soldFiscalYear).getHimoku11();
                    }
                    break;
            }
        }

        return rtn;
    }

    private BigDecimal getAmountIntegration3(String ym, String pjId, String soldFiscalYear,
            Map<String, MDB0801Input> receiveresultListMap, Map<String, MDB0801Input> amountIntegration3ListMap, Map<String, MDB0801Input> rResultListMap) {

        BigDecimal rtn = BigDecimal.ZERO;

        String dateFrom = null;
        String dateTo = null;

        if(pjId.substring(2, 3).equals("R")) {
            dateFrom = "190001";
            dateTo = "999901";
        }else {
            dateFrom = receiveresultListMap.containsKey(pjId + soldFiscalYear)
                    ? receiveresultListMap.get(pjId + soldFiscalYear).getDateFrom()
                    : null;
            dateTo = receiveresultListMap.containsKey(pjId + soldFiscalYear)
                    ? receiveresultListMap.get(pjId + soldFiscalYear).getDateTo()
                    : null;

            if (null == dateFrom || null == dateTo) {
                dateFrom = "190001";
                dateTo = "999901";
            }
        }

        String ymMax = amountIntegration3ListMap.containsKey(pjId + soldFiscalYear)
                ? amountIntegration3ListMap.get(pjId + soldFiscalYear).getYmAmount()
                : null;
        String ymMin = ymMax;

        if (null != dateFrom && null != dateTo && null != ymMax && null != ymMin && !dateFrom.equals("")
                && !dateTo.equals("") && !ymMax.equals("") && !ymMin.equals("")) {

            // 金額．年月 Max
            int intYmMax = Integer.parseInt(ymMax);

            // 金額．年月 Min
            int intYmMin = Integer.parseInt(ymMin);

            // from
            int intDateFrom = Integer.parseInt(dateFrom);

            // to
            int intDateTo = Integer.parseInt(dateTo);

            if (intDateFrom <= intYmMin && intYmMax <= intDateTo) {
                rtn = addBD(rtn, amountIntegration3ListMap.get(pjId + soldFiscalYear).getHimoku01());
                rtn = addBD(rtn, amountIntegration3ListMap.get(pjId + soldFiscalYear).getHimoku02());
                rtn = addBD(rtn, amountIntegration3ListMap.get(pjId + soldFiscalYear).getHimoku05());
                rtn = addBD(rtn, amountIntegration3ListMap.get(pjId + soldFiscalYear).getHimoku06());
                rtn = addBD(rtn, amountIntegration3ListMap.get(pjId + soldFiscalYear).getHimoku04());
                rtn = addBD(rtn, amountIntegration3ListMap.get(pjId + soldFiscalYear).getHimoku07());
                rtn = addBD(rtn, amountIntegration3ListMap.get(pjId + soldFiscalYear).getHimoku08());
                rtn = addBD(rtn, amountIntegration3ListMap.get(pjId + soldFiscalYear).getHimoku09());
                rtn = addBD(rtn, amountIntegration3ListMap.get(pjId + soldFiscalYear).getHimoku11());
                rtn = addBD(rtn, amountIntegration3ListMap.get(pjId + soldFiscalYear).getHimoku03());
                rtn = addBD(rtn, amountIntegration3ListMap.get(pjId + soldFiscalYear).getHimoku32());
                rtn = addBD(rtn, amountIntegration3ListMap.get(pjId + soldFiscalYear).getHimoku10());
            }
        }

        return rtn;
    }

    private String getReceiveKbn(String date, String kbn, String yyyymm, String systemYearMonth) {

        String rtn = null;

        int from = 0;
        int to = 0;

        if (null == date || date.equals("")) {
            return null;
        }

        // 日次処理の場合
        if (kbn.equals("D")) {
            from = Integer.parseInt(yearMonthToBeginOfFiscalYearMonth(systemYearMonth) + "01");
            to = Integer.parseInt(yearMonthToEndOfFiscalYearMonth(systemYearMonth) + "31");

            // 月次確定処理の場合
        } else if (kbn.equals("M")) {
            from = Integer.parseInt(yearMonthToBeginOfFiscalYearMonth(yyyymm) + "01");
            to = Integer.parseInt(yearMonthToEndOfFiscalYearMonth(yyyymm) + "31");
        }

        int checkDate = Integer.parseInt(date.replaceAll("-", ""));
        if (from <= checkDate && checkDate <= to) {
            rtn = "2";
        } else if (checkDate < from) {
            rtn = "1";
        }

        return rtn;
    }

    private String getFiscalYearFromYm(String soldFiscalYear) {

        int year = Integer.parseInt(soldFiscalYear.substring(0, 4));
        int month = Integer.parseInt(soldFiscalYear.substring(4, 6));

        if (month < 4) {
            year--;
        }

        return String.valueOf(year);
    }

    private String yearMonthToBeginOfFiscalYearMonth(String yearMonth) {

        int year = Integer.parseInt(yearMonth.substring(0, 4));
        int month = Integer.parseInt(yearMonth.substring(4, 6));

        if (month < 4) {
            year--;
        }

        return String.valueOf(year + "04");

    }

    private String yearMonthToEndOfFiscalYearMonth(String yearMonth) {

        int year = Integer.parseInt(yearMonth.substring(0, 4));
        int month = Integer.parseInt(yearMonth.substring(4, 6));

        if (month < 4) {
            year--;
        }

        return String.valueOf(year + 1 + "03");

    }

    private List<MDB0801Input> getResultList(List<MDB0801Input> pjidList, String key) {

        Stream<MDB0801Input> stream = pjidList.stream()
                .filter((e) -> {
                    return e.getPjId().substring(2, 3).equals(key);
                });

        return stream.collect(Collectors.toList());
    }

    private List<MDB0801Output> getKeyList(List<MDB0801Output> pjidList) {

        Stream<MDB0801Output> stream = pjidList.stream()
                .filter((e) -> {
                    return e.getPjId().substring(10, 12).equals("01");
                });

        return stream.collect(Collectors.toList());
    }

    private boolean isBranch01PjId(String pjId) {
        String branch = pjId.substring(pjId.length() - 2, pjId.length());
        return branch.equals("01");
    }

    private String getBranchPjId(String pjId) {
        String branch = pjId.substring(0, 10);
        return branch + "01";
    }

    private Map<String, MDB0801Input> getEditedReceiveList(List<MDB0801Input> receiveresultList) {

        // 同じ年度とプロジェクトIDの値を合計する、
        Map<String, MDB0801Input> rtn = new LinkedHashMap<String, MDB0801Input>();
        MDB0801Input item = null;
        String checkKey = "";
        MDB0801Input mdb0801Input = new MDB0801Input();


        for (int i = 0; i < receiveresultList.size(); i++) {

            mdb0801Input = receiveresultList.get(i);

            checkKey = mdb0801Input.getPjId() + mdb0801Input.getSoldFiscalYear();

            if (rtn.containsKey(checkKey)) {
                item = rtn.get(checkKey);

                // 受注日
                if(null != mdb0801Input.getReceivedOn() && !mdb0801Input.getReceivedOn().equals("")) {

                    if(null == item.getReceivedOn() || item.getReceivedOn().equals("")) {

                        item.setReceivedOn(mdb0801Input.getReceivedOn());
                    }else {

                        int oldNum = Integer.parseInt(item.getReceivedOn().replaceAll("-", ""));
                        int newNum = Integer.parseInt(mdb0801Input.getReceivedOn().replaceAll("-", ""));

                        if (oldNum > newNum) {
                            item.setReceivedOn(mdb0801Input.getReceivedOn());
                        }
                    }
                }

                // 受上額
                item.setReceivedMoney((addBD(item.getReceivedMoney(), getBigDecimalValue(mdb0801Input.getReceivedMoney()))));

                // 売上予定日（or売上日）
                if(null != mdb0801Input.getThisFiscalYearPlanedSellingOn() && !mdb0801Input.getThisFiscalYearPlanedSellingOn().equals("")) {

                    if(null == item.getThisFiscalYearPlanedSellingOn() || item.getThisFiscalYearPlanedSellingOn().equals("")) {

                        item.setThisFiscalYearPlanedSellingOn(mdb0801Input.getThisFiscalYearPlanedSellingOn());
                    }else {

                        int oldNum = Integer.parseInt(item.getThisFiscalYearPlanedSellingOn().replaceAll("-", ""));
                        int newNum = Integer.parseInt(mdb0801Input.getThisFiscalYearPlanedSellingOn().replaceAll("-", ""));

                        if (oldNum < newNum) {

                            item.setThisFiscalYearPlanedSellingOn(mdb0801Input.getThisFiscalYearPlanedSellingOn());

                            // 売上予定日（［物件管理．当該年度売上予定日］の設定用）
                            item.setPlanedSellingOn(mdb0801Input.getPlanedSellingOn());
                        }
                    }
                }

                // 高原価・政策受注フラグ
                if((null != mdb0801Input.getHighCostReceive() && mdb0801Input.getHighCostReceive().equals("1"))
                        ||
                        (null != item.getHighCostReceive() && item.getHighCostReceive().equals("1"))
                        ) {
                    item.setHighCostReceive("1");
                }

                // 受注申請時積算原価率
                item.setOsatsuPlanedRate(BigDecimal.ZERO);


            } else {
                item = new MDB0801Input();

                // 年度                     soldFiscalYear
                item.setSoldFiscalYear(mdb0801Input.getSoldFiscalYear());

                // プロジェクトID           pjId
                item.setPjId(mdb0801Input.getPjId());

                // 受注日                   receivedOn
                item.setReceivedOn(mdb0801Input.getReceivedOn());

                // 受上額                   receivedMoney
                item.setReceivedMoney(getBigDecimalValue(mdb0801Input.getReceivedMoney()));

                // 売上予定日（or売上日）   thisFiscalYearPlanedSellingOn
                item.setThisFiscalYearPlanedSellingOn(mdb0801Input.getThisFiscalYearPlanedSellingOn());

                // 高原価・政策受注フラグ   highCostReceive
                item.setHighCostReceive(mdb0801Input.getHighCostReceive());

                // 受注申請時積算原価率     osatsuPlanedRate
                item.setOsatsuPlanedRate(mdb0801Input.getOsatsuPlanedRate());

                // 売上予定日（［物件管理．当該年度売上予定日］の設定用）
                item.setPlanedSellingOn(mdb0801Input.getPlanedSellingOn());

                rtn.put(checkKey, item);
                item = null;
            }

            // 最後のSumした結果を追加する
            if (i == receiveresultList.size() - 1 && null != item) {
                rtn.put(checkKey, item);
            }
        }

        return rtn;
    }

    private List<MDB0801Input> getResultReceive(List<MDB0801Input> inputList) {

        List<MDB0801Input> rtn = new ArrayList<MDB0801Input>();
        MDB0801Input tempInput = new MDB0801Input();
        Map<String, MDB0801Input> tempResultListMap = new HashMap<String, MDB0801Input>();

        String tempFrom = "";
        Map<String, String> tempFromMap = new HashMap<String, String>();

        List<MDB0801Input> result = getEditedReceiveList(inputList).values().stream().collect(Collectors.toList());

        for (MDB0801Input mdb0801Input : result) {
            tempInput = new MDB0801Input();

            tempInput.setPjId(mdb0801Input.getPjId());
            tempInput.setSoldFiscalYear(mdb0801Input.getSoldFiscalYear());
            tempInput.setReceivedOn(mdb0801Input.getReceivedOn());
            tempInput.setReceivedMoney(mdb0801Input.getReceivedMoney());
            tempInput.setThisFiscalYearPlanedSellingOn(mdb0801Input.getThisFiscalYearPlanedSellingOn());
            tempInput.setOsatsuPlanedRate(mdb0801Input.getOsatsuPlanedRate());
            tempInput.setPlanedSellingOn(mdb0801Input.getPlanedSellingOn());
            tempInput.setHighCostReceive(mdb0801Input.getHighCostReceive());

            if (!tempResultListMap.containsKey(mdb0801Input.getPjId())) {
                tempInput.setDateFrom("190001");
                tempResultListMap.put(mdb0801Input.getPjId(), new MDB0801Input());
            } else {
                tempInput.setDateFrom(tempFromMap.get(mdb0801Input.getPjId()));
            }

            tempFrom = getFrom(mdb0801Input.getThisFiscalYearPlanedSellingOn());
            tempFromMap.put(mdb0801Input.getPjId(), tempFrom);
            tempInput.setDateTo(mdb0801Input.getThisFiscalYearPlanedSellingOn().replaceAll("-", "").substring(0, 6));
            rtn.add(tempInput);
        }
        return rtn;
    }

    private BigDecimal addBD(BigDecimal input1, BigDecimal input2) {

        BigDecimal rtn = null;

        if (input1 != null && input2 != null) {
            rtn = input1.add(input2);
        } else {

            if (input1 == null && input2 == null) {
                rtn = null;
            } else if (input1 == null) {
                rtn = input2;
            } else {
                rtn = input1;
            }
        }

        return rtn;
    }

    private void putTotalNum(String key, BigDecimal num, Map<String, BigDecimal> inputMap) {


        if (inputMap.containsKey(key)) {
            inputMap.put(key, addBD(inputMap.get(key), num));
        } else {
            inputMap.put(key, num);
        }
    }

    private String getFrom(String input) {

        String rtn = "";
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMM");
        int year = Integer.parseInt(input.substring(0, 4));
        int month = Integer.parseInt(input.substring(5, 7));
        int day = 1;

        LocalDate ld = LocalDate.of(year, month, day);
        rtn = ld.plusMonths(1).format(dtf);
        return rtn;
    }

    private BigDecimal getBigDecimalValue(BigDecimal input1) {
        return null == input1 ? BigDecimal.ZERO : input1;
    }

    private BigDecimal getAddCost(String pjId, String lastSoldOn, Map<String, MDB0801Input> addAmountListMap,
            Map<String, MDB0801Input> addCostPayBasisListMap,
            String receiveDate, Map<String, MDB0801Input> receiveresultListMap, BigDecimal soldFiscalYear) {

        BigDecimal rtn = BigDecimal.ZERO;

        if (null != addAmountListMap.get(pjId)) {

            String soldFiscalYearStr = getFiscalYearFromYm(addAmountListMap.get(pjId).getYmAmount().substring(0, 4)
                    + addAmountListMap.get(pjId).getYmAmount().substring(4, 6));

            if (soldFiscalYear.toString().equals(soldFiscalYearStr)
                    && null != addAmountListMap.get(pjId)) {

                    // ★金額 追加原価（金額）
                    rtn = addBD(rtn, addAmountListMap.get(pjId).getADDKINGAKU());
            }
        }

        if (null != addCostPayBasisListMap.get(pjId)) {

            String soldFiscalYearStr = getFiscalYearFromYm(addCostPayBasisListMap.get(pjId).getYmAmount().substring(0, 4)
                    + addCostPayBasisListMap.get(pjId).getYmAmount().substring(4, 6));

            if (soldFiscalYear.toString().equals(soldFiscalYearStr)
                    && null != addCostPayBasisListMap.get(pjId)) {

                    // ★外注情報 追加原価（外注費）
                    rtn = addBD(rtn, addCostPayBasisListMap.get(pjId).getADDKINGAKU());
            }
        }

        return rtn;
    }

    private String getSalesTypeKbn(String pjId, String lastSoldOn, BigDecimal soldFiscalYear, String ym1,
            BigDecimal addCost, BigDecimal sogenka, String receiveDate, String branchNum, Map<String, MDB0801Input> receiveresultListMap) {

        // ［プロジェクト．プロジェクト種別］が「P」以外の場合
        String rtnSalesTypeKbn = null;

        boolean isExistenceFlag = false;

        for(Map.Entry<String, MDB0801Input> entry : receiveresultListMap.entrySet()) {

            String editedMapKey = entry.getKey().substring(0, entry.getKey().length() -4);
            String editedPjId = pjId.substring(0, pjId.length()-2) + "01";

            if(editedMapKey.equals(editedPjId)) {
                isExistenceFlag = true;
                break;
            }
        }

        // ［プロジェクト．プロジェクト種別］が「P」かつ［受注］に「BU+プロジェクト属性ID+枝番01」のレコードが登録されている場合
        if (pjId.substring(2, 3).equals("P") && isExistenceFlag) {

            // 日次処理の場合
            if (kbn.equals("D")) {

                // ・［プロジェクト．最終売上完了日］が設定されている、かつ、［【TEMP】物件管理．追加原価］が0円の場合
                if (!StringUtils.isEmpty(lastSoldOn)
                        && addCost.compareTo(BigDecimal.ZERO) == 0) {
                    // 「1」（売上済）
                    rtnSalesTypeKbn = "1";

                    // ・枝番が01以外、かつ、［プロジェクト．最終売上完了日］がNULL、かつ、［【TEMP】物件管理．売上年度］が来年度以降で、かつ、［【TEMP】物件管理．総原価］が0円の場合
                } else if (branchNum.equals("")
                            && null == lastSoldOn
                            && soldFiscalYear.intValue() > Integer.parseInt(getFiscalYearFromYm(ym1.replace("-", "")))
                            && sogenka.compareTo(BigDecimal.ZERO) == 0) {
                    // 「3」（未稼働）
                    rtnSalesTypeKbn = "3";

                    // ・枝番が01以外、かつ、［プロジェクト．最終売上完了日］が設定されている、かつ、［【TEMP】物件管理．追加原価］が0円以外の場合
                } else if (branchNum.equals("")
                            && null != lastSoldOn
                            && addCost.compareTo(BigDecimal.ZERO) != 0) {

                    // 「4」（追加原価）
                    rtnSalesTypeKbn = "4";

                } else {

                    // ・上記以外で［プロジェクト．最終売上完了日］がNULLの場合
                    if (null == lastSoldOn) {
                        // 「2」（仕掛）
                        rtnSalesTypeKbn = "2";
                    }
                }

            // 月次確定処理の場合
            } else if (kbn.equals("M")) {

                // ・［プロジェクト．最終売上完了日］が設定されている、かつ、指定月以前の日付、かつ、［【TEMP】物件管理．追加原価］が0円の場合
                if (!StringUtils.isEmpty(lastSoldOn)
                        && Integer.parseInt(lastSoldOn.replaceAll("-", "").substring(0, 6)) <= Integer.parseInt(receiveDate)
                        && addCost.compareTo(BigDecimal.ZERO) == 0) {
                    // 「1」（売上済）
                    rtnSalesTypeKbn = "1";

                    // ・枝番が01以外、かつ、［プロジェクト．最終売上完了日］がNULLまたは指定月より未来日が設定されている、かつ、［【TEMP】物件管理．売上年度］が来年度以降で、かつ、［【TEMP】物件管理．総原価］が0円の場合
                } else if (branchNum.equals("")
                                && (null == lastSoldOn
                                    || (!StringUtils.isEmpty(lastSoldOn) && Integer.parseInt(lastSoldOn.replaceAll("-", "").substring(0, 6)) > Integer.parseInt(receiveDate)))
                                && soldFiscalYear.intValue() > Integer.parseInt(getFiscalYearFromYm(ym1.replace("-", "")))
                                && sogenka.compareTo(BigDecimal.ZERO) == 0) {
                    // 「3」（未稼働）
                    rtnSalesTypeKbn = "3";

                // ・枝番が01以外、かつ、［プロジェクト．最終売上完了日］が設定されている、かつ、指定月以前の日付、かつ、［【TEMP】物件管理．追加原価］が0円以外の場合
                } else if (branchNum.equals("")
                                && null != lastSoldOn
                                && Integer.parseInt(lastSoldOn.replaceAll("-", "").substring(0, 6)) <= Integer.parseInt(receiveDate)
                                && addCost.compareTo(BigDecimal.ZERO) != 0) {

                    // 「4」（追加原価）
                    rtnSalesTypeKbn = "4";
                } else {
                    // ・上記以外で［プロジェクト．最終売上完了日］がNULLまたは指定月より未来日が設定されている場合
                    if (null == lastSoldOn
                            || (!StringUtils.isEmpty(lastSoldOn) && Integer.parseInt(lastSoldOn.replaceAll("-", "").substring(0, 6)) > Integer.parseInt(receiveDate))) {
                        // 「2」（仕掛）
                        rtnSalesTypeKbn = "2";
                    }
                }
            }
        }

        return rtnSalesTypeKbn;
    }

    private BigDecimal getReceivedCostRate(BigDecimal genkagokei, BigDecimal outsideSoldAmount, String salesTypeKbn,
            BigDecimal groupSoldAmount, BigDecimal receivedMoney) {

        BigDecimal rtn = BigDecimal.ZERO;

        if (null == salesTypeKbn) {
            return rtn;
        }

        // ・［【TEMP】物件管理．一般売上］が0以外、かつ、［【TEMP】物件管理．売上種別区分］が「1」（売上済）の場合、
        if (outsideSoldAmount.compareTo(BigDecimal.ZERO) != 0 && salesTypeKbn.equals("1")) {
            // ⑰÷［【TEMP】物件管理．一般売上］
            if (null != outsideSoldAmount && outsideSoldAmount.compareTo(BigDecimal.ZERO) != 0) {
                rtn = genkagokei.divide(outsideSoldAmount, 12, BigDecimal.ROUND_HALF_UP);
            }
            // ・［【TEMP】物件管理．関係会社売上額］が0以外、かつ、［【TEMP】物件管理．売上種別区分］が「1」（売上済）の場合、
        } else if (groupSoldAmount.compareTo(BigDecimal.ZERO) != 0 && salesTypeKbn.equals("1")) {
            // ⑰÷［【TEMP】物件管理．関係会社売上額］
            if (null != groupSoldAmount && groupSoldAmount.compareTo(BigDecimal.ZERO) != 0) {
                rtn = genkagokei.divide(groupSoldAmount, 12, BigDecimal.ROUND_HALF_UP);
            }
            // ・［【TEMP】物件管理．売上種別区分］が「1」以外（仕掛）の場合、
        } else if (!salesTypeKbn.equals("1")) {
            // ⑰÷［【TEMP】物件管理．受注額］
            if (null != receivedMoney && receivedMoney.compareTo(BigDecimal.ZERO) != 0) {
                rtn = genkagokei.divide(receivedMoney, 12, BigDecimal.ROUND_HALF_UP);
            }
        }

        return rtn.divide(BigDecimal.ONE, 3, BigDecimal.ROUND_HALF_UP);
    }

    private boolean isThisFiscalYear(String ym, String planedSellingOn) {

        boolean rtn = false;

        if (null == planedSellingOn || planedSellingOn.equals("")) {
            return rtn;
        }

        int from = Integer.parseInt(yearMonthToBeginOfFiscalYearMonth(ym) + "01");
        int to = Integer.parseInt(yearMonthToEndOfFiscalYearMonth(ym) + "31");
        int planedSellingOnNum = Integer.parseInt(planedSellingOn.replaceAll("-", ""));

        if (from <= planedSellingOnNum && planedSellingOnNum <= to) {
            rtn = true;
        }
        return rtn;
    }


    private boolean isNextFiscalYear(String ym, String planedSellingOn) {

        boolean rtn = false;

        if (StringUtils.isEmpty(planedSellingOn)) {
            return rtn;
        }

        int to = Integer.parseInt(yearMonthToEndOfFiscalYearMonth(ym) + "31");
        int planedSellingOnNum = Integer.parseInt(planedSellingOn.replaceAll("-", ""));

        if (planedSellingOnNum > to) {
            rtn = true;
        }
        return rtn;
    }

    private String getSalesType(String pjId, String soldOn, String planedSellingOn, String lastSoldOn, String ym1,
            String receiveDate, Map<String, MDB0801Input> receiveresultListMap) {

        // ［プロジェクト．プロジェクト種別］が「P」以外の場合
        String rtnSalesType = null;

        boolean isExistenceFlag = false;

        for(Map.Entry<String, MDB0801Input> entry : receiveresultListMap.entrySet()) {

            String editedMapKey = entry.getKey().substring(0, entry.getKey().length() -4);
            String editedPjId = pjId.substring(0, pjId.length()-2) + "01";

            if(editedMapKey.equals(editedPjId)) {
                isExistenceFlag = true;
                break;
            }
        }

        // ［プロジェクト．プロジェクト種別］が「P」かつ［受注］に「BU+プロジェクト属性ID+枝番01」のレコードが登録されている場合
        if (pjId.substring(2, 3).equals("P") && isExistenceFlag) {

            // 日次処理の場合
            if (kbn.equals("D")) {

                // ・［プロジェクト．最終売上完了日］が設定されている場合
                if (!StringUtils.isEmpty(lastSoldOn)) {
                    // 「1」（売上完了）
                    rtnSalesType = "1";

                    // ・［プロジェクト．最終売上完了日］がNULL、かつ、［プロジェクト．初回売上日］が設定されている場合
                } else if (null == lastSoldOn
                            && !StringUtils.isEmpty(soldOn)) {

                    // 「2」（一部売上済）
                    rtnSalesType = "2";

                    // ・［プロジェクト．最終売上完了日］がNULL、かつ、［プロジェクト．初回売上日］がNULL、かつ、
                } else if (null == lastSoldOn && null == soldOn) {

                    // ①［プロジェクト．売上予定日］に今年度内の日付が設定されている場合
                    if (isThisFiscalYear(ym1, planedSellingOn)) {
                        // 「9」（今期売上予定）
                        rtnSalesType = "9";

                    // ②［プロジェクト．売上予定日］に来年度以降の日付が設定されている場合
                    } else if (isNextFiscalYear(ym1, planedSellingOn)) {
                        // 「99」（来期以降売上予定）
                        rtnSalesType = "99";

                    // ③上記以外はNULL
                    }else {
                        rtnSalesType = null;
                    }
                }

            // 月次確定処理の場合
            } else if (kbn.equals("M")) {

                // ・［プロジェクト．最終売上完了日］が設定されている、かつ、指定月以前の日付の場合
                if (!StringUtils.isEmpty(lastSoldOn)
                        && Integer.parseInt(lastSoldOn.replaceAll("-", "").substring(0, 6)) <= Integer.parseInt(receiveDate)) {

                    // 「1」（売上完了）
                    rtnSalesType = "1";

                    // ・［プロジェクト．最終売上完了日］がNULLまたは指定月より未来日が設定されている、かつ、［プロジェクト．初回売上日］が設定されている場合
                } else if ((null == lastSoldOn
                                || (!StringUtils.isEmpty(lastSoldOn) && Integer.parseInt(lastSoldOn.replaceAll("-", "").substring(0, 6)) > Integer.parseInt(receiveDate)))
                             && !StringUtils.isEmpty(soldOn)) {
                    // 「2」（一部売上済）
                    rtnSalesType = "2";

                    // ・［プロジェクト．最終売上完了日］がNULLまたは指定月より未来日が設定されている、かつ、［プロジェクト．初回売上日］がNULL、かつ、
                } else if ((null == lastSoldOn
                                || (!StringUtils.isEmpty(lastSoldOn) && Integer.parseInt(lastSoldOn.replaceAll("-", "").substring(0, 6)) > Integer.parseInt(receiveDate)))
                             && null == soldOn) {

                    // ①［プロジェクト．売上予定日］に今年度内の日付が設定されている場合
                    if (isThisFiscalYear(ym1, planedSellingOn)) {
                        // 「9」（今期売上予定）
                        rtnSalesType = "9";

                        // ②［プロジェクト．売上予定日］に来年度以降の日付が設定されている場合
                    } else if (isNextFiscalYear(ym1, planedSellingOn)) {
                        // 「99」（来期以降売上予定）
                        rtnSalesType = "99";
                    }
                }
            }
        }

        return rtnSalesType;
    }

    private BigDecimal multiplyBD(BigDecimal input1, BigDecimal input2) {

        BigDecimal rtn = null;

        if (input1 != null && input2 != null) {
            rtn = input1.multiply(input2);
        } else {

            if (input1 == null && input2 == null) {
                rtn = new BigDecimal(0);
            } else if (input1 == null) {
                rtn = input2;
            } else {
                rtn = input1;
            }
        }

        return rtn;
    }

    private Map<String, MDB0801Input> getEditedAmountList(List<MDB0801Input> amountPerformancetList,
            List<MDB0801Input> receiveresultList, List<MDB0801Input> rResultList, Map<String, MDB0801Input> rResultYMListMap) {

        // 同じ年度とプロジェクトIDの値を合計する、
        Map<String, MDB0801Input> rtn = new HashMap<String, MDB0801Input>();
        MDB0801Input item = null;
        String checkKey = "";
        MDB0801Input mdb0801Input = new MDB0801Input();

        // 金額テーブルのレコードに年度を設定する
        for (MDB0801Input amountMdb0801Input : amountPerformancetList) {

            String pjId = amountMdb0801Input.getPjId();
            int ymAmount = Integer.parseInt(amountMdb0801Input.getYmAmount());

            if(pjId.substring(2, 3).equals("R")) {

                for (MDB0801Input rResultListInput : rResultList) {

                    int from = 190001;
                    int to = 999901;
                    if (rResultListInput.getPjAttId().equals(pjId.substring(2, 10)) && ymAmount >= from && ymAmount <= to) {
                        amountMdb0801Input.setSoldFiscalYear(rResultYMListMap.get(pjId).getSoldFiscalYear());
                        break;
                    }
                }
            }else {
                boolean inFlag = true;

                for (MDB0801Input receiveMDB0801Input : receiveresultList) {

                    int from = Integer.parseInt(receiveMDB0801Input.getDateFrom());
                    int to = Integer.parseInt(receiveMDB0801Input.getDateTo());

                    if (receiveMDB0801Input.getPjId().equals(pjId) && ymAmount >= from && ymAmount <= to) {
                        amountMdb0801Input.setSoldFiscalYear(receiveMDB0801Input.getSoldFiscalYear());
                        inFlag = false;
                        break;
                    }
                }

                if(inFlag) {
                    for (MDB0801Input rResultListInput : rResultList) {
                        if(pjId.substring(2, 3).equals("P")) {
                            int from = 190001;
                            int to = 999901;
                            if (rResultListInput.getPjAttId().equals(pjId.substring(2, 10)) && ymAmount >= from && ymAmount <= to) {
                                if(null != rResultYMListMap.get(pjId)) {
                                    amountMdb0801Input.setSoldFiscalYear(rResultYMListMap.get(pjId).getSoldFiscalYear());
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }

        for (int i = 0; i < amountPerformancetList.size(); i++) {

            mdb0801Input = amountPerformancetList.get(i);

            if(null == mdb0801Input.getSoldFiscalYear()) {
                continue;
            }

            checkKey = mdb0801Input.getPjId() + mdb0801Input.getSoldFiscalYear();

            if (rtn.containsKey(checkKey)) {
                item = rtn.get(checkKey);

                // himoku_01
                item.setHimoku01(addBD(item.getHimoku01(), mdb0801Input.getHimoku01()));
                // himoku_02
                item.setHimoku02(addBD(item.getHimoku02(), mdb0801Input.getHimoku02()));
                // himoku_03
                item.setHimoku03(addBD(item.getHimoku03(), mdb0801Input.getHimoku03()));
                // himoku_32
                item.setHimoku32(addBD(item.getHimoku32(), mdb0801Input.getHimoku32()));
                // himoku_10
                item.setHimoku10(addBD(item.getHimoku10(), mdb0801Input.getHimoku10()));
                // himoku_05
                item.setHimoku05(addBD(item.getHimoku05(), mdb0801Input.getHimoku05()));
                // himoku_06
                item.setHimoku06(addBD(item.getHimoku06(), mdb0801Input.getHimoku06()));
                // himoku_04
                item.setHimoku04(addBD(item.getHimoku04(), mdb0801Input.getHimoku04()));
                // himoku_07
                item.setHimoku07(addBD(item.getHimoku07(), mdb0801Input.getHimoku07()));
                // himoku_08
                item.setHimoku08(addBD(item.getHimoku08(), mdb0801Input.getHimoku08()));
                // himoku_09
                item.setHimoku09(addBD(item.getHimoku09(), mdb0801Input.getHimoku09()));
                // himoku_11
                item.setHimoku11(addBD(item.getHimoku11(), mdb0801Input.getHimoku11()));
                // himoku_12
                item.setHimoku12(addBD(item.getHimoku12(), mdb0801Input.getHimoku12()));
                // himoku_15
                item.setHimoku15(addBD(item.getHimoku15(), mdb0801Input.getHimoku15()));
                // himoku_18
                item.setHimoku18(addBD(item.getHimoku18(), mdb0801Input.getHimoku18()));
                // himoku_20
                item.setHimoku20(addBD(item.getHimoku20(), mdb0801Input.getHimoku20()));
                // himoku_31
                item.setHimoku31(addBD(item.getHimoku31(), mdb0801Input.getHimoku31()));
                // himoku_33
                item.setHimoku33(addBD(item.getHimoku33(), mdb0801Input.getHimoku33()));
                // himoku_34
                item.setHimoku34(addBD(item.getHimoku34(), mdb0801Input.getHimoku34()));
                // himoku_35
                item.setHimoku35(addBD(item.getHimoku35(), mdb0801Input.getHimoku35()));

            } else {
                item = new MDB0801Input();

                // 売上年度
                item.setSoldFiscalYear(mdb0801Input.getSoldFiscalYear());

                // プロジェクトID
                item.setPjId(mdb0801Input.getPjId());

                // YM
                item.setYmAmount(mdb0801Input.getYmAmount());

                // himoku_01
                item.setHimoku01(getBigDecimalValue(mdb0801Input.getHimoku01()));
                // himoku_02
                item.setHimoku02(getBigDecimalValue(mdb0801Input.getHimoku02()));
                // himoku_03
                item.setHimoku03(getBigDecimalValue(mdb0801Input.getHimoku03()));
                // himoku_32
                item.setHimoku32(getBigDecimalValue(mdb0801Input.getHimoku32()));
                // himoku_10
                item.setHimoku10(getBigDecimalValue(mdb0801Input.getHimoku10()));
                // himoku_05
                item.setHimoku05(getBigDecimalValue(mdb0801Input.getHimoku05()));
                // himoku_06
                item.setHimoku06(getBigDecimalValue(mdb0801Input.getHimoku06()));
                // himoku_04
                item.setHimoku04(getBigDecimalValue(mdb0801Input.getHimoku04()));
                // himoku_07
                item.setHimoku07(getBigDecimalValue(mdb0801Input.getHimoku07()));
                // himoku_08
                item.setHimoku08(getBigDecimalValue(mdb0801Input.getHimoku08()));
                // himoku_09
                item.setHimoku09(getBigDecimalValue(mdb0801Input.getHimoku09()));
                // himoku_11
                item.setHimoku11(getBigDecimalValue(mdb0801Input.getHimoku11()));
                // himoku_12
                item.setHimoku12(getBigDecimalValue(mdb0801Input.getHimoku12()));
                // himoku_15
                item.setHimoku15(getBigDecimalValue(mdb0801Input.getHimoku15()));
                // himoku_18
                item.setHimoku18(getBigDecimalValue(mdb0801Input.getHimoku18()));
                // himoku_20
                item.setHimoku20(getBigDecimalValue(mdb0801Input.getHimoku20()));
                // himoku_31
                item.setHimoku31(getBigDecimalValue(mdb0801Input.getHimoku31()));
                // himoku_33
                item.setHimoku33(getBigDecimalValue(mdb0801Input.getHimoku33()));
                // himoku_34
                item.setHimoku34(getBigDecimalValue(mdb0801Input.getHimoku34()));
                // himoku_35
                item.setHimoku35(getBigDecimalValue(mdb0801Input.getHimoku35()));

                rtn.put(checkKey, item);
                item = null;
            }

            // 最後のSumした結果を追加する
            if (i == amountPerformancetList.size() - 1 && null != item) {
                rtn.put(checkKey, item);
            }
        }

        return rtn;
    }

    private Map<String, MDB0801Input> getEditedCostAmountList(List<MDB0801Input> amountCostPerformancetList,
            List<MDB0801Input> receiveresultList, List<MDB0801Input> rResultList, Map<String, MDB0801Input> rResultYMListMap) {

        // 同じ年度とプロジェクトIDの値を合計する、
        Map<String, MDB0801Input> rtn = new HashMap<String, MDB0801Input>();
        MDB0801Input item = null;
        String checkKey = "";
        MDB0801Input mdb0801Input = new MDB0801Input();

        // 工数金額テーブルのレコードに年度を設定する
        for (MDB0801Input amountMdb0801Input : amountCostPerformancetList) {

            String pjId = amountMdb0801Input.getPjId();
            int ymAmount = Integer.parseInt(amountMdb0801Input.getYmAmount());

            if(pjId.substring(2, 3).equals("R")) {

                for (MDB0801Input rResultListInput : rResultList) {

                    int from = 190001;
                    int to = 999901;
                    if (rResultListInput.getPjAttId().equals(pjId.substring(2, 10)) && ymAmount >= from && ymAmount <= to) {
                        amountMdb0801Input.setSoldFiscalYear(rResultYMListMap.get(pjId).getSoldFiscalYear());
                        break;
                    }
                }
            }else {
                boolean inFlag = true;

                for (MDB0801Input receiveMDB0801Input : receiveresultList) {

                    int from = Integer.parseInt(receiveMDB0801Input.getDateFrom());
                    int to = Integer.parseInt(receiveMDB0801Input.getDateTo());

                    if (receiveMDB0801Input.getPjId().equals(pjId) && ymAmount >= from && ymAmount <= to) {
                        amountMdb0801Input.setSoldFiscalYear(receiveMDB0801Input.getSoldFiscalYear());
                        break;
                    }
                }

                if(inFlag) {
                    for (MDB0801Input rResultListInput : rResultList) {
                        if(pjId.substring(2, 3).equals("P")) {
                            int from = 190001;
                            int to = 999901;
                            if (rResultListInput.getPjAttId().equals(pjId.substring(2, 10)) && ymAmount >= from && ymAmount <= to) {
                                if(null != rResultYMListMap.get(pjId)) {
                                    amountMdb0801Input.setSoldFiscalYear(rResultYMListMap.get(pjId).getSoldFiscalYear());
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }

        for (int i = 0; i < amountCostPerformancetList.size(); i++) {

            mdb0801Input = amountCostPerformancetList.get(i);

            if(null == mdb0801Input.getSoldFiscalYear()) {
                continue;
            }

            checkKey = mdb0801Input.getPjId() + mdb0801Input.getSoldFiscalYear();

            if (rtn.containsKey(checkKey)) {
                item = rtn.get(checkKey);

                // himoku_01
                item.setHimoku01(addBD(item.getHimoku01(), mdb0801Input.getHimoku01()));
                // himoku_02
                item.setHimoku02(addBD(item.getHimoku02(), mdb0801Input.getHimoku02()));

            } else {
                item = new MDB0801Input();

                // 売上年度
                item.setSoldFiscalYear(mdb0801Input.getSoldFiscalYear());

                // プロジェクトID
                item.setPjId(mdb0801Input.getPjId());

                // YM
                item.setYmAmount(mdb0801Input.getYmAmount());

                // himoku_01
                item.setHimoku01(getBigDecimalValue(mdb0801Input.getHimoku01()));
                // himoku_02
                item.setHimoku02(getBigDecimalValue(mdb0801Input.getHimoku02()));

                rtn.put(checkKey, item);
                item = null;
            }

            // 最後のSumした結果を追加する
            if (i == amountCostPerformancetList.size() - 1 && null != item) {
                rtn.put(checkKey, item);
            }
        }

        return rtn;
    }

    private Map<String, MDB0801Input> getFiscalFromTo(Map<String, MDB0801Input> inputMap, List<MDB0801Input> inputList){

        Map<String, MDB0801Input> rtn = new HashMap<String, MDB0801Input>();

        for (MDB0801Input value : inputMap.values()) {

            for (MDB0801Input mdb0801Input : inputList) {

                if(value.getPjId().substring(2, 10).equals(mdb0801Input.getPjAttId())) {

                    value.setDateFrom(mdb0801Input.getDateFrom().replaceAll("-", "").substring(0, 6));
                    value.setDateTo(mdb0801Input.getDateTo().replaceAll("-", "").substring(0, 6));
                    rtn.put(value.getPjId()+value.getSoldFiscalYear() , value);
                }
            }
        }

        return rtn;
    }

    private List<MDB0801Output> getEditList(List<MDB0801Output> inputList){

        BigDecimal sevenThreeBD = new BigDecimal("9999.999");
        BigDecimal twelveTwoBD = new BigDecimal("9999999999.99");

        for (MDB0801Output output : inputList) {

            // 受注原価率
            if (sevenThreeBD.compareTo(output.getReceivedCostRate()) < 0) {
                output.setReceivedCostRate(sevenThreeBD);
            }

            // 応札時積算率
            if (sevenThreeBD.compareTo(output.getOsatsuPlanedRate()) < 0) {
                output.setOsatsuPlanedRate(sevenThreeBD);
            }

            // 売上物件原価率
            if (sevenThreeBD.compareTo(output.getSoldPjCostRate()) < 0) {
                output.setSoldPjCostRate(sevenThreeBD);
            }

            // 社員工数
            if (twelveTwoBD.compareTo(output.getEmpKosu()) < 0) {
                output.setEmpKosu(twelveTwoBD);
            }

            // 積算社員工数
            if (twelveTwoBD.compareTo(output.getPlanedEmpKosu()) < 0) {
                output.setPlanedEmpKosu(twelveTwoBD);
            }

            // 臨時時間
            if (twelveTwoBD.compareTo(output.getTempEmpKosu()) < 0) {
                output.setTempEmpKosu(twelveTwoBD);
            }

            // 積算臨時時間
            if (twelveTwoBD.compareTo(output.getPlanedTempEmpKosu()) < 0) {
                output.setPlanedTempEmpKosu(twelveTwoBD);
            }

            // 進捗率
            if (sevenThreeBD.compareTo(output.getProgressRate()) < 0) {
                output.setProgressRate(sevenThreeBD);
            }

            // 当該年度初回積算原価率
            if (sevenThreeBD.compareTo(output.getThisFiscalYearFirstPlanedCostRate()) < 0) {
                output.setThisFiscalYearFirstPlanedCostRate(sevenThreeBD);
            }

            // 全年度初回積算原価率
            if (sevenThreeBD.compareTo(output.getFirstPlanedAmountRate()) < 0) {
                output.setFirstPlanedAmountRate(sevenThreeBD);
            }

            // 当該年度積算原価率
            if (sevenThreeBD.compareTo(output.getThisFiscalYearPlanedCostRate()) < 0) {
                output.setThisFiscalYearPlanedCostRate(sevenThreeBD);
            }

            // 全年度積算原価率
            if (sevenThreeBD.compareTo(output.getPlanedAmountRate()) < 0) {
                output.setPlanedAmountRate(sevenThreeBD);
            }

            // 見込み原価率
            if (sevenThreeBD.compareTo(output.getPlanedCostRate()) < 0) {
                output.setPlanedCostRate(sevenThreeBD);
            }
        }

        return inputList;
    }

    private String getPjIdStr(List<MDB0801Input> inputList) {

        String rtnPjIdStr = "";

        for (int i = 0; i < inputList.size(); i++) {
            rtnPjIdStr += "'";
            rtnPjIdStr += inputList.get(i).getPjId();
            rtnPjIdStr += "',";

            if(i == inputList.size() -1) {
                rtnPjIdStr = rtnPjIdStr.substring(0, rtnPjIdStr.length() -1);
            }
        }

        return rtnPjIdStr;
    }

    private String getPjIdStrByOr(List<MDB0801Input> inputList, String itemName) {

        String rtnPjIdStr = "";

        for (int i = 0; i < inputList.size(); i++) {
            rtnPjIdStr += "'";
            rtnPjIdStr += inputList.get(i).getPjId();

            if(i%10000 == 0 && i != inputList.size() -1) {
                rtnPjIdStr += "') OR " + itemName + " IN (";
            }else {
                rtnPjIdStr += "',";
            }

            if(i == inputList.size() -1) {
                rtnPjIdStr = rtnPjIdStr.substring(0, rtnPjIdStr.length() -1);
            }
        }

        return rtnPjIdStr;
    }

    private String getPjAttIdStr(List<MDB0801Input> inputList) {

        String rtnPjAttIdStr = "";

        for (int i = 0; i < inputList.size(); i++) {
            rtnPjAttIdStr += "'";
            rtnPjAttIdStr += inputList.get(i).getPjAttId();
            rtnPjAttIdStr += "',";

            if(i == inputList.size() -1) {
                rtnPjAttIdStr = rtnPjAttIdStr.substring(0, rtnPjAttIdStr.length() -1);
            }
        }

        return rtnPjAttIdStr;
    }

    private String getEditedLastSoldOn(String lastSoldOn, String receiveDate) {

        String rtnEditedLastSoldOn = null;

        // 日次処理の場合
        if (kbn.equals("D")) {

            // ・日次の場合は、［プロジェクト．最終売上完了日］を格納する
            rtnEditedLastSoldOn = lastSoldOn;

        // 月次確定処理の場合
        } else if (kbn.equals("M")) {

            // ・月次確定、かつ、［プロジェクト．最終売上完了日］が指定月以前の場合
            if (!StringUtils.isEmpty(lastSoldOn)
                    && Integer.parseInt(lastSoldOn.replaceAll("-", "").substring(0, 6)) <= Integer.parseInt(receiveDate)) {

                // プロジェクト．最終売上完了日］を格納する
                rtnEditedLastSoldOn = lastSoldOn;

            //・月次確定、かつ、［プロジェクト．最終売上完了日］が指定月より未来日の場合は、NULLを格納する
            }else if (!StringUtils.isEmpty(lastSoldOn)
                    && Integer.parseInt(lastSoldOn.replaceAll("-", "").substring(0, 6)) > Integer.parseInt(receiveDate)) {
                // NULLを格納する
                rtnEditedLastSoldOn = null;
            }
        }

        return rtnEditedLastSoldOn;
    }

    private Map<String, MDB0801Input> getResultMap(Map<String, MDB0801Input> rResultYMListMap, int from, int to, String buPjAttId) {

        Map<String, MDB0801Input> rtnMap = new HashMap<String, MDB0801Input>();

        for (Entry<String, MDB0801Input> entry : rResultYMListMap.entrySet()) {

            String getBuPjAttId = entry.getKey().substring(0, 10);

            if(getBuPjAttId.equals(buPjAttId)) {
                int fiscalYear = Integer.parseInt(entry.getValue().getSoldFiscalYear());
                int fiscalFrom = Integer.parseInt(fiscalYear + "04");
                int fiscalTo = Integer.parseInt((fiscalYear + 1) + "03");

                if(from <= fiscalFrom && to >= fiscalTo) {
                    rtnMap.put(entry.getKey().substring(0, 10), entry.getValue());
                }
            }
        }

        return rtnMap;
    }

    private BigDecimal getFirstPlanedAmount(List<MDB0801Input> amountIntegration3List, String pjId) {

        BigDecimal rtn = new BigDecimal("0");

        Stream<MDB0801Input> stream = amountIntegration3List.stream()
                .filter((e) -> {
                    return e.getPjId().equals(pjId);
                });

        for (MDB0801Input mdb0801Input : stream.collect(Collectors.toList())) {
            rtn = addBD(rtn, mdb0801Input.getHimoku01());
            rtn = addBD(rtn, mdb0801Input.getHimoku02());
            rtn = addBD(rtn, mdb0801Input.getHimoku05());
            rtn = addBD(rtn, mdb0801Input.getHimoku06());
            rtn = addBD(rtn, mdb0801Input.getHimoku04());
            rtn = addBD(rtn, mdb0801Input.getHimoku07());
            rtn = addBD(rtn, mdb0801Input.getHimoku08());
            rtn = addBD(rtn, mdb0801Input.getHimoku09());
            rtn = addBD(rtn, mdb0801Input.getHimoku11());
            rtn = addBD(rtn, mdb0801Input.getHimoku03());
            rtn = addBD(rtn, mdb0801Input.getHimoku32());
            rtn = addBD(rtn, mdb0801Input.getHimoku10());
        }

        return rtn;
    }

    private BigDecimal getKisyuWorkingCost(String pjId, List<MDB0801Input> mdDispPropertyMonthlyList, String thisFiscalYearSoldOn, String systemYearMonth) {

        BigDecimal rtn = new BigDecimal("0");

        // システム日付の年度(文字列)
        String fiscalYear = yearMonthToBeginOfFiscalYearMonth(systemYearMonth).substring(0, 4);

        // システム日付の今年度
        int thisFiscalYear = Integer.parseInt(fiscalYear);

        // システム日付の前年度
        int beforeFiscalYear = thisFiscalYear -1;

        int tempFiscalYear = 0;

        //・［物件管理．当該年度売上日］がNULLの場合、同一キーのレコードから取得する
        if((null == thisFiscalYearSoldOn || thisFiscalYearSoldOn.equals(""))) {

            tempFiscalYear = thisFiscalYear;

        // ・［物件管理．当該年度売上日］が設定されている場合、
        } else if(null != thisFiscalYearSoldOn) {

            tempFiscalYear = beforeFiscalYear;
        }

        int maxFiscalYear = 0;

        // 上記以外
        if(tempFiscalYear == 0) {
            return rtn;
        }

        for (MDB0801Input mdb0801Input : mdDispPropertyMonthlyList) {

            //（システム日付から見て）前年度以前で最新の売上年度かつ同一プロジェクトIDのレコードから取得する
            if(mdb0801Input.getPjId().equals(pjId)) {

                // （前年度・今年度）以前で最新の売上年度以降、最新の年度のレコードから取得する
                if (Integer.parseInt(mdb0801Input.getSoldFiscalYear()) <= tempFiscalYear
                        && maxFiscalYear < Integer.parseInt(mdb0801Input.getSoldFiscalYear()) ) {

                    maxFiscalYear = Integer.parseInt(mdb0801Input.getSoldFiscalYear());
                    rtn = (null == mdb0801Input.getKimatsuWorkingCost()) ? BigDecimal.ZERO : mdb0801Input.getKimatsuWorkingCost();
                }
            }

        }

        return rtn;
    }

    private BigDecimal getMdOutsourcingOrderedCost(String pjId, List<MDB0801Input> mdOutsourcingList, String soldFiscalYear, Map<String, MDB0801Input> receiveresultListMap) {
        BigDecimal rtn = new BigDecimal("0");

        for (MDB0801Input mdb0801Input : mdOutsourcingList) {

            if(mdb0801Input.getPjId().equals(pjId)) {


                // 受注テーブルの中に、レコードがある場合、FROM、TOをチェックしてから、外注情報から取得します。
                if(receiveresultListMap.containsKey(pjId + soldFiscalYear)) {

                    MDB0801Input thisInput = receiveresultListMap.get(pjId + soldFiscalYear);

                    int from = Integer.parseInt(thisInput.getDateFrom());
                    int to = Integer.parseInt(thisInput.getDateTo());
                    int ymAmount = Integer.parseInt(mdb0801Input.getYmAmount());

                    if (from <= ymAmount && to>= ymAmount) {
                        rtn = addBD(rtn, mdb0801Input.getOrderedCost());
                    }

                // 受注テーブルの中に、レコードがない場合、そのままで外注情報から取得します。
                }else {
                    rtn = addBD(rtn, mdb0801Input.getOrderedCost());
                }
            }
        }

        return (null == rtn) ? BigDecimal.ZERO : rtn;
    }

}
