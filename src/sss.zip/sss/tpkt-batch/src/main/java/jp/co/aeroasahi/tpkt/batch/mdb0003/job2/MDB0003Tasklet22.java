package jp.co.aeroasahi.tpkt.batch.mdb0003.job2;

import javax.inject.Inject;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.mdb0003.BatchDataHolder;
import jp.co.aeroasahi.tpkt.batch.mdb0003.MDB0003SharedServiceImpl;

/**
 * 工数取込の実行結果を確認するTasklet
 */
@Component
@Scope("step")
public class MDB0003Tasklet22 implements Tasklet {

    /** 工数取込ジョブ名 */
    private static final String KOSU_JOB_NAME = "mdb0101Job";

    /** ジョブ番号 */
    private static final int TARGET_JOB_NUMBER = 2;

    @Inject
    MDB0003SharedServiceImpl mdb0003SharedService;

    @Autowired
    private BatchDataHolder batchDataHolder;

    /**
     *
     * 工数取込の実行結果を確認する
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return 一括で各ジョブを実行した状態
     * @throws InterruptedException スレッドスリープの際に異常があった場合(基本的に発生しないはず)
     */
    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws InterruptedException  {

        String jobStartDateTime = batchDataHolder.getJobStartDateTime();

        // 工数取込の終了まで待つ (規定時間を待っても終わらない or 異常終了していた場合は例外をスロー)
        mdb0003SharedService.checkExecuteResult(KOSU_JOB_NAME, jobStartDateTime, TARGET_JOB_NUMBER);

        return RepeatStatus.FINISHED;
    }
}
