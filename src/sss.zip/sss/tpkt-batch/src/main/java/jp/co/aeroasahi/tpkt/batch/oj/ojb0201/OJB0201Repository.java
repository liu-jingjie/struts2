package jp.co.aeroasahi.tpkt.batch.oj.ojb0201;

import java.util.List;

/**
 * 支払処理日反映
 *
 */
public interface OJB0201Repository {



    /**
     * 応受援基本情報を更新。
     *
     * @param kbn
     * @param date
     * @param today
     */

    List<OjuenEntrustBranchInfoOutInfor> findOjuenEntrustBranchInfoOutInfor();

    /**
     * 応受援委託先枝番情報のステータスを更新。
     *
     * @param kbn
     * @param date
     * @param today
     */
    int updateOjuenEntrustBranchInfo(OjuenEntrustBranchInfoOutInfor input);


}
