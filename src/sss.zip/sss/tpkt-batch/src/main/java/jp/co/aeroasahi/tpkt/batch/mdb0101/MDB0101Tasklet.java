package jp.co.aeroasahi.tpkt.batch.mdb0101;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.validator.ValidationException;
import org.springframework.batch.item.validator.Validator;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.fw.CommonLog;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

@Component
@Scope("step")
public class MDB0101Tasklet implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0101Tasklet.class);

    @Inject
    MDB0101Repository mdb0101Repository;

    @Inject
    DateFactory dateFactory;

    @Inject
    Validator<MDB0101KosuCostOutput> validatorKosuCost;

    @Inject
    Validator<MDB0101DeptPersonalKosuOutput> validatorDeptPersonalKosu;

    @Value("#{jobParameters['kbn']}")
    public String kbn;

    @Value("#{jobParameters['yyyymm']}")
    public String yyyymm;

    boolean isErrFlag = false;

    /** DateTimeFormatterのパターン yyyy-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    /** DateTimeFormatterのパターン uuuuMM */
    private static final DateTimeFormatter dtfUUUUMM = DateTimeFormatter.ofPattern("uuuuMM");

    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        LocalDateTime systemDateTime = dateFactory.newDateTime();
        String systemYearMonth = dateFactory.newDateTime().format(dtf);

        // 年月(当月)
        String ym1 = getCurrentMonth(systemDateTime);

        // 年月(前月或は指定した年月)
        String ym2 = "";

        // 日次処理の場合
        if (kbn.equals("D")) {
            ym2 = getPreviousMonth(systemDateTime);

        // 月次確定処理の場合
        } else if (kbn.equals("M")) {
            LocalDateTime yyyymmP = LocalDateTime.of(Integer.parseInt(yyyymm.substring(0, 4)),
                    Integer.parseInt(yyyymm.substring(4, 6)), 1, 1, 1);
            ym2 = getCurrentMonth(yyyymmP);
        }

        // ■直接工数と間接工数のデータを設定
        List<MDB0101KosuCostOutput> outKosuCostDataItems = setKosuCostData(ym1, ym2, systemYearMonth, systemDateTime);

        // ■社員と合計工数データを設定
        List<MDB0101DeptPersonalKosuOutput> outDeptPersonalKosuDataItems = setDeptPersonalKosuData(ym1, ym2, systemYearMonth);

        if (!isErrFlag) {

            // ■データを登録
            isErrFlag = insertData(ym1, ym2, outKosuCostDataItems, outDeptPersonalKosuDataItems, getPreviousMonth(systemDateTime));
        }

        if (isErrFlag) {
            throw new RuntimeException("mdb0101工数取込の処理実行に異常が発生しました。");
        }

        return RepeatStatus.FINISHED;
    }

    private boolean insertData(String ym1, String ym2, List<MDB0101KosuCostOutput> outItems1, List<MDB0101DeptPersonalKosuOutput> outItems2, String ym3) {

        boolean isErrFlag = false;

        for (int i = 0; i < outItems1.size(); i++) {
            try {
                validatorKosuCost.validate(outItems1.get(i));
            } catch (ValidationException e) {
                isErrFlag = true;
                CommonLog.setFromDbErrorLog(logger, e, "【TEMP】工数金額(temp_md_kosu_cost)");
            }
        }

        if (!isErrFlag) {
            for (int i = 0; i < outItems2.size(); i++) {
                try {
                    validatorDeptPersonalKosu.validate(outItems2.get(i));
                } catch (ValidationException e) {
                    isErrFlag = true;
                    CommonLog.setFromDbErrorLog(logger, e, "【TEMP】部門別社員工数(temp_md_dept_personal_kosu)");
                }
            }
        }

        if (!isErrFlag) {

            if (outItems1.size() > 0) {

                MDB0101KosuCostInput itemInputKosuCost = new MDB0101KosuCostInput();
                itemInputKosuCost.setYm1(ym1);
                itemInputKosuCost.setYm2(ym2);

                //［【TEMP】工数金額］から当月または(前月の年月または［パラメータ．処理年月］の年月)のデータを削除する
                mdb0101Repository.deleteKosuCost(itemInputKosuCost);

                itemInputKosuCost.setYm2(ym3);
                mdb0101Repository.deleteKosuCostPerformance(itemInputKosuCost);
                mdb0101Repository.deleteKosuCostPerformanceFirstTime(itemInputKosuCost);

                //【TEMP】工数金額のデータを登録する
                for (MDB0101KosuCostOutput output : outItems1) {
                    mdb0101Repository.createKosuCost(output);
                }

                if (outItems2.size() > 0) {

                    MDB0101DeptPersonalKosuInput itemInputDeptPersonalKosu = new MDB0101DeptPersonalKosuInput();
                    itemInputDeptPersonalKosu.setYm1(ym1);
                    itemInputDeptPersonalKosu.setYm2(ym2);

                    //［【TEMP】部門別社員工数］から当月または(前月の年月または［パラメータ．処理年月］の年月)のデータを削除する
                    mdb0101Repository.deleteDeptPersonalKosu(itemInputDeptPersonalKosu);

                    // 【TEMP】部門別社員工数のデータを登録する
                    for (MDB0101DeptPersonalKosuOutput output : outItems2) {
                        mdb0101Repository.createDeptPersonalKosu(output);
                    }
                }
            }

            CommonLog.setInsertRecordeCountLog(logger, "【TEMP】工数金額(temp_md_kosu_cost)", outItems1.size());
            CommonLog.setInsertRecordeCountLog(logger, "【TEMP】部門別社員工数(temp_md_dept_personal_kosu)", outItems2.size());

        } else {
            logger.error("登録データでエラーが発生しました。");
        }

        return isErrFlag;
    }

    private List<MDB0101KosuCostOutput> setKosuCostData(String ym1, String ym2, String systemYearMonth, LocalDateTime systemDateTime) {

        List<MDB0101KosuCostOutput> outputItems = new ArrayList<MDB0101KosuCostOutput>();
        MDB0101KosuCostOutput itemOutput = new MDB0101KosuCostOutput();
        HashMap<String, MDB0101KosuCostOutput> dateMap = new HashMap<String, MDB0101KosuCostOutput>();

        MDB0101KosuCostInput itemInput = new MDB0101KosuCostInput();
        itemInput.setYm1(ym1);
        itemInput.setYm2(ym2);

        List<MDB0101KosuCostInput> detailList1 = mdb0101Repository.findAllByDirectlyNormal(itemInput);
        List<MDB0101KosuCostInput> detailList2 = mdb0101Repository.findAllByDirectlyFormer(itemInput);
        List<MDB0101KosuCostInput> detailList3 = mdb0101Repository.findAllByDirectlyAhead(itemInput);
        List<MDB0101KosuCostInput> detailList5 = mdb0101Repository.findAllByIndirectNormal(itemInput);
        List<MDB0101KosuCostInput> detailList6 = mdb0101Repository.findAllByIndirectFormer(itemInput);
        List<MDB0101KosuCostInput> detailList7 = mdb0101Repository.findAllByIndirectAhead(itemInput);

        itemInput.setYm2(getPreviousMonth(systemDateTime));
        //積算
        List<MDB0101KosuCostInput> detailList4 = mdb0101Repository.findAllByDirectlyEstimate(itemInput);
        //初回積算
        List<MDB0101KosuCostInput> detailList8 = mdb0101Repository.findAllByDirectlyFirstTime(itemInput);

        detailList1.addAll(detailList2);
        detailList1.addAll(detailList3);
        detailList1.addAll(detailList4);
        detailList1.addAll(detailList5);
        detailList1.addAll(detailList6);
        detailList1.addAll(detailList7);
        detailList1.addAll(detailList8);

        for (int i = 0; i < detailList1.size(); i++) {

            MDB0101KosuCostInput mdb0101DetailList1Input = detailList1.get(i);

            MDB0101KosuCostOutput mapData = dateMap.get(mdb0101DetailList1Input.concat());

            if (dateMap.containsKey(mdb0101DetailList1Input.concat())) {

                // 工数
                mapData.setKosu(addBD(mapData.getKosu(), mdb0101DetailList1Input.getKosu()));

                if (i == detailList1.size() - 1) {

                    dateMap.put(mdb0101DetailList1Input.concat(), mapData);
                }
            } else {

                itemOutput = new MDB0101KosuCostOutput();

                // プロジェクトID
                itemOutput.setPjId(mdb0101DetailList1Input.getPjId());

                // 年月
                itemOutput.setYm(mdb0101DetailList1Input.getYm());

                // 部門CD
                itemOutput.setDeptCd(mdb0101DetailList1Input.getDeptCd());

                // 工程CD
                itemOutput.setKoteiCd(mdb0101DetailList1Input.getKoteiCd());

                // 費目CD
                itemOutput.setHimokuCd(mdb0101DetailList1Input.getHimokuCd());

                // 実績積算区分
                itemOutput.setResultPlanedKbn(mdb0101DetailList1Input.getResultPlanedKbn());

                // 給与等級
                itemOutput.setTokyu(mdb0101DetailList1Input.getTokyu());

                // 代表リソースCD
                itemOutput.setDistResourceCd(mdb0101DetailList1Input.getDistResourceCd());

                // リソースCD
                itemOutput.setResourceCd(mdb0101DetailList1Input.getResourceCd());

                // 単価
                itemOutput.setUnitCost(mdb0101DetailList1Input.getUnitCost());

                // 直接単価
                itemOutput.setDirectUnitCost(mdb0101DetailList1Input.getDirectUnitCost());

                // 直接部門間接単価
                itemOutput.setDirectDeptIndirectUnitCost(mdb0101DetailList1Input.getDirectDeptIndirectUnitCost());

                // 間接部門間接単価
                itemOutput.setIndirectDeptIndirectUnitCost(mdb0101DetailList1Input.getIndirectDeptIndirectUnitCost());

                // 製造間接単価
                itemOutput.setIndirectUnitCost(mdb0101DetailList1Input.getIndirectUnitCost());

                // 大型機材単価
                itemOutput.setLargeMachineIndirectCost(mdb0101DetailList1Input.getLargeMachineIndirectCost());

                // 工数
                itemOutput.setKosu(mdb0101DetailList1Input.getKosu());

                // 作成日
                itemOutput.setCreatedAt(systemYearMonth);

                // 更新日
                itemOutput.setUpdatedAt(systemYearMonth);

                dateMap.put(mdb0101DetailList1Input.concat(), itemOutput);
            }
        }
        outputItems = new ArrayList<MDB0101KosuCostOutput>(dateMap.values());

        return outputItems;
    }

    private List<MDB0101DeptPersonalKosuOutput> setDeptPersonalKosuData(String ym1, String ym2, String systemYearMonth) {

        List<MDB0101DeptPersonalKosuOutput> outputItems = new ArrayList<MDB0101DeptPersonalKosuOutput>();
        MDB0101DeptPersonalKosuOutput itemOutput = new MDB0101DeptPersonalKosuOutput();
        HashMap<String, MDB0101DeptPersonalKosuOutput> dateMap = new HashMap<String, MDB0101DeptPersonalKosuOutput>();

        MDB0101DeptPersonalKosuInput itemInput = new MDB0101DeptPersonalKosuInput();
        itemInput.setYm1(ym1);
        itemInput.setYm2(ym2);

        List<MDB0101DeptPersonalKosuInput> detailList1 = mdb0101Repository.findAllByDeptPersonalKosuNormal(itemInput);
        List<MDB0101DeptPersonalKosuInput> detailList2 = mdb0101Repository.findAllByDeptPersonalKosuFormer(itemInput);
        List<MDB0101DeptPersonalKosuInput> detailList3 = mdb0101Repository.findAllByDeptPersonalKosuAhead(itemInput);

        detailList1.addAll(detailList2);
        detailList1.addAll(detailList3);

        for (int i = 0; i < detailList1.size(); i++) {

            MDB0101DeptPersonalKosuInput mdb0101DetailList1Input = detailList1.get(i);

            MDB0101DeptPersonalKosuOutput mapData = dateMap.get(mdb0101DetailList1Input.concat());

            if (dateMap.containsKey(mdb0101DetailList1Input.concat())) {

                // 合計工数
                mapData.setTotalKosu(addBD(mapData.getTotalKosu(), mdb0101DetailList1Input.getTotalKosu()));

                if (i == detailList1.size() - 1) {

                    dateMap.put(mdb0101DetailList1Input.concat(), mapData);
                }
            } else {

                itemOutput = new MDB0101DeptPersonalKosuOutput();

                // 部門CD
                itemOutput.setDeptCd(mdb0101DetailList1Input.getDeptCd());

                // 年月
                itemOutput.setYm(mdb0101DetailList1Input.getYm());

                // 社員区分
                itemOutput.setEmpKbn(mdb0101DetailList1Input.getEmpKbn());

                // 社員CD
                itemOutput.setEmpCd(mdb0101DetailList1Input.getEmpCd());

                // 合計工数
                itemOutput.setTotalKosu(mdb0101DetailList1Input.getTotalKosu());

                // 作成日
                itemOutput.setCreatedAt(systemYearMonth);

                // 更新日
                itemOutput.setUpdatedAt(systemYearMonth);

                dateMap.put(mdb0101DetailList1Input.concat(), itemOutput);
            }
        }
        outputItems = new ArrayList<MDB0101DeptPersonalKosuOutput>(dateMap.values());

        return outputItems;
    }

    private String getCurrentMonth(LocalDateTime systemDateTime) {
        return systemDateTime.format(dtfUUUUMM);
    }

    private String getPreviousMonth(LocalDateTime systemDateTime) {
        return systemDateTime.minusMonths(1).format(dtfUUUUMM);
    }

    private BigDecimal addBD(BigDecimal input1, BigDecimal input2) {

        BigDecimal rtn = null;

        if (input1 != null && input2 != null) {
            rtn = input1.add(input2);
        } else {

            if (input1 == null && input2 == null) {
                rtn = null;
            } else if (input1 == null) {
                rtn = input2;
            } else {
                rtn = input1;
            }
        }

        return rtn;
    }

}
