package jp.co.aeroasahi.tpkt.batch.ckb0101;

import org.springframework.batch.item.ItemCountAware;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜BU+PJ属性別帳票登録状況＞のinputBean。
 */
@Setter
@Getter
public class CKB0101RegStsBuPjInput implements ItemCountAware {

    private int count;

    /** BU+プロジェクト属性ID */
    private String buPjAttId;

    /** 帳票種別 */
    private String docType;

    /** 帳票登録状況 */
    private String docRegStatus;

    /** 原本有無フラグ */
    private boolean originalReged;

    /** 判断用帳票登録状況_×（最大） */
    private String maxReqInfo;

    /** 判断用帳票登録状況_△（最大） */
    private String maxRegStas;

    /** 判断用帳票登録状況_△（最小） */
    private String minRegStas;

    @Override
    public void setItemCount(int count) {
        this.count = count;
    }
}
