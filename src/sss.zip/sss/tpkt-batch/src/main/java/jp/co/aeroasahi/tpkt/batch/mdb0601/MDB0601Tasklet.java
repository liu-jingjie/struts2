package jp.co.aeroasahi.tpkt.batch.mdb0601;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.validator.ValidationException;
import org.springframework.batch.item.validator.Validator;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.fw.CommonLog;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

@Component
@Scope("step")
public class MDB0601Tasklet implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0601Tasklet.class);

    @Inject
    MDB0601Repository mdb0601Repository;

    @Inject
    DateFactory dateFactory;

    @Inject
    Validator<MDB0601Output> validator;

    @Value("#{jobParameters['kbn']}")
    public String kbn;

    @Value("#{jobParameters['yyyymm']}")
    public String yyyymm;

    boolean isErrFlag = false;

    /** DateTimeFormatterのパターン yyyy-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    /** DateTimeFormatterのパターン uuuuMM */
    private static final DateTimeFormatter dtfUUUUMM = DateTimeFormatter.ofPattern("uuuuMM");

    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        LocalDateTime systemDateTime = dateFactory.newDateTime();
        String systemYearMonth = dateFactory.newDateTime().format(dtf);

        // 当月の年月
        String ym1 = getCurrentMonth(systemDateTime);

        // 前月或は指定した月の年月
        String ym2 = "";

        // 日次処理の場合
        if (kbn.equals("D")) {
            ym2 = getPreviousMonth(systemDateTime);

        // 月次確定処理の場合
        } else if (kbn.equals("M")) {
            LocalDateTime yyyymmP = LocalDateTime.of(Integer.parseInt(yyyymm.substring(0, 4)), Integer.parseInt(yyyymm.substring(4, 6)), 1, 1, 1);
            ym2 = getCurrentMonth(yyyymmP);
        }
        List<MDB0601Output> outItems = setItemOutput(ym1, ym2, systemYearMonth);

        List<MDB0601Output> outItems2 = setItemOutput2(ym1, ym2, systemYearMonth);

        logger.debug("validation開始");
        if (!isErrFlag) {
            for (int i = 0; i < outItems.size(); i++) {
                try {
                    validator.validate(outItems.get(i));
                } catch (ValidationException e) {
                    isErrFlag = true;
                    CommonLog.setFromDbErrorLog(logger, e, "【TEMP】金額(temp_md_cost)");
                }
            }

            if (!isErrFlag) {
                for (int i = 0; i < outItems2.size(); i++) {
                    try {
                        validator.validate(outItems2.get(i));
                    } catch (ValidationException e) {
                        isErrFlag = true;
                        CommonLog.setFromDbErrorLog(logger, e, "【TEMP】金額(temp_md_cost)");
                    }
                }
            }

            if (!isErrFlag) {

                MDB0601Input itemInput = new MDB0601Input();
                itemInput.setYm1(getFormatedYearMonth(ym1));
                itemInput.setYm2(getFormatedYearMonth(ym2));
                itemInput.setYm3(getFormatedYearMonth(ym1));
                itemInput.setYm4(getFormatedYearMonth2(ym1));

                // 実績データ削除
                mdb0601Repository.deletePerformance(itemInput);

                // 積算データ削除
                mdb0601Repository.deleteIntegration(itemInput);

                // 初回積算データ削除
                mdb0601Repository.deleteInitialIntegration(itemInput);

                logger.debug("金額既存データ取得開始");
                // 【TEMP】金額の既存データを取得する
                List<MDB0601Output> checkList = mdb0601Repository.findAllByKey();
                Map<String, MDB0601Output> checkListMap =
                        checkList.stream().collect(Collectors.toMap(MDB0601Output::concat, Function.identity()));

                List<MDB0601Output> insertRecordList = new ArrayList<MDB0601Output>();
                List<MDB0601Output> updateRecordList = new ArrayList<MDB0601Output>();

                List<MDB0601Output> updateRecordListSum = new ArrayList<MDB0601Output>();
                List<MDB0601Output> insertRecordListSum = new ArrayList<MDB0601Output>();
                for (MDB0601Output mdb0601Output : outItems) {

                    logger.debug("登録/更新判定開始");
                    // 更新
                    if (checkListMap.containsKey(mdb0601Output.concat())) {
                        updateRecordList.add(mdb0601Output);
                        // 登録
                    } else {

                        insertRecordList.add(mdb0601Output);
                    }
                }
                logger.debug("更新開始");
                // 【TEMP】金額のデータを更新する
                if (updateRecordList.size() > 0) {
                    updateRecordListSum = getSumItemOutput(updateRecordList);
                    for (MDB0601Output output : updateRecordListSum) {
                        mdb0601Repository.update(output);
                    }
                }
                logger.debug("登録開始");
                insertRecordList.addAll(outItems2);
                // 【TEMP】金額のデータを登録する
                if (insertRecordList.size() > 0) {
                    insertRecordListSum = getSumItemOutput(insertRecordList);
                    for (MDB0601Output output : insertRecordListSum) {
                        mdb0601Repository.create(output);
                    }
                }
                CommonLog.setInsertRecordeCountLog(logger, "【TEMP】金額(temp_md_cost)", insertRecordListSum.size());
                CommonLog.setUpdateRecordeCountLog(logger, "【TEMP】金額(temp_md_cost)", updateRecordListSum.size());

            } else {
                logger.error("登録データでエラーが発生しました。");
            }
            outItems.clear();
        }

        if (isErrFlag) {
            throw new RuntimeException("mdb0601原価取込処理実行に異常が発生しました。");
        }

        return RepeatStatus.FINISHED;
    }

    private List<MDB0601Output> getSumItemOutput(List<MDB0601Output> inputList){

        List<MDB0601Output> rtn = new ArrayList<MDB0601Output>();

        Map<String, MDB0601Output> rtnMap = new HashMap<String, MDB0601Output>();

        MDB0601Output item = null;
        MDB0601Output mdb0601Output = null;
        String checkKey = null;

        for (int i = 0; i < inputList.size(); i++) {

            mdb0601Output = inputList.get(i);

            checkKey = mdb0601Output.concat();

            if (rtnMap.containsKey(checkKey)) {
                item = rtnMap.get(checkKey);

                // 金額
                item.setPrice((addBD(item.getPrice(), mdb0601Output.getPrice())));

            } else {
                item = new MDB0601Output();

                // プロジェクト属性ID
                item.setPjAttId(mdb0601Output.getPjAttId());

                // プロジェクトID
                item.setPjId(mdb0601Output.getPjId());

                // 年月
                item.setYm(mdb0601Output.getYm());

                // 費目CD
                item.setHimokuCd(mdb0601Output.getHimokuCd());

                // 実績積算区分
                item.setResultPlanedKbn(mdb0601Output.getResultPlanedKbn());

                // 工程CD
                item.setKoteiCd(mdb0601Output.getKoteiCd());

                // 代表リソースCD
                item.setDistResourceCd(mdb0601Output.getDistResourceCd());

                // 金額
                item.setPrice(mdb0601Output.getPrice());

                // 作成日
                item.setCreatedAt(mdb0601Output.getCreatedAt());

                // 更新日
                item.setUpdatedAt(mdb0601Output.getUpdatedAt());

                rtnMap.put(checkKey, item);
                item = null;
            }

            // 最後のSumした結果を追加する
            if (i == inputList.size() - 1 && null != item) {
                rtnMap.put(checkKey, item);
            }
        }
        rtn = new ArrayList<MDB0601Output>(rtnMap.values());
        return rtn;
    }

    private List<MDB0601Output> setItemOutput(String ym1, String ym2, String systemYearMonth) {

        List<MDB0601Output> outputItems = new ArrayList<MDB0601Output>();
        MDB0601Output itemOutput = new MDB0601Output();

        // 検索条件を設定する
        MDB0601Input itemInput = new MDB0601Input();
        itemInput.setYm1(ym1);
        itemInput.setYm2(ym2);
        itemInput.setYm3(getFormatedYearMonth(ym1));
        itemInput.setYm4(getFormatedYearMonth2(ym1));

        logger.debug("findAll1開始");
        List<MDB0601Input> mdb0601Inputs = mdb0601Repository.findAll1(itemInput);

        for (MDB0601Input mdb0601Input : mdb0601Inputs) {

            itemOutput = new MDB0601Output();

            // プロジェクト属性ID
            itemOutput.setPjAttId(mdb0601Input.getPjAttId());

            // プロジェクトID
            itemOutput.setPjId(mdb0601Input.getPjId());

            // 年月
            itemOutput.setYm(getFormatedYearMonth(mdb0601Input.getYm()));

            // 費目CD
            itemOutput.setHimokuCd(mdb0601Input.getHimokuCd());

            // 実績積算区分
            itemOutput.setResultPlanedKbn(mdb0601Input.getResultPlanedKbn());

            // 工程CD
            itemOutput.setKoteiCd(mdb0601Input.getKoteiCd());

            // 代表リソースCD
            itemOutput.setDistResourceCd(mdb0601Input.getDistResourceCd());

            // 金額
            itemOutput.setPrice(null == mdb0601Input.getPrice() ? BigDecimal.ZERO : mdb0601Input.getPrice() );

            // 作成日
            itemOutput.setCreatedAt(systemYearMonth);

            // 更新日
            itemOutput.setUpdatedAt(systemYearMonth);

            outputItems.add(itemOutput);
        }

        logger.debug("findAll2開始");
        List<MDB0601Input> mdb0601Input2 = mdb0601Repository.findAll2(itemInput);
        for (MDB0601Input mdb0601Input : mdb0601Input2) {

            itemOutput = new MDB0601Output();

            // プロジェクト属性ID
            itemOutput.setPjAttId(mdb0601Input.getPjAttId());

            // プロジェクトID
            itemOutput.setPjId(mdb0601Input.getPjId());

            // 年月
            itemOutput.setYm(mdb0601Input.getYm());

            // 費目CD
            itemOutput.setHimokuCd(mdb0601Input.getHimokuCd());

            // 実績積算区分
            itemOutput.setResultPlanedKbn(mdb0601Input.getResultPlanedKbn());

            // 工程CD
            itemOutput.setKoteiCd(mdb0601Input.getKoteiCd());

            // 代表リソースCD
            itemOutput.setDistResourceCd(mdb0601Input.getDistResourceCd());

            // 金額
            itemOutput.setPrice(null == mdb0601Input.getPrice() ? BigDecimal.ZERO : mdb0601Input.getPrice());

            // 作成日
            itemOutput.setCreatedAt(systemYearMonth);

            // 更新日
            itemOutput.setUpdatedAt(systemYearMonth);

            outputItems.add(itemOutput);
        }

        logger.debug("findAll3開始");
        List<MDB0601Input> mdb0601Input3 = mdb0601Repository.findAll3(itemInput);
        for (MDB0601Input mdb0601Input : mdb0601Input3) {

            itemOutput = new MDB0601Output();

            // プロジェクト属性ID
            itemOutput.setPjAttId(mdb0601Input.getPjAttId());

            // プロジェクトID
            itemOutput.setPjId(mdb0601Input.getPjId());

            // 年月
            itemOutput.setYm(mdb0601Input.getYm());

            // 費目CD
            itemOutput.setHimokuCd(mdb0601Input.getHimokuCd());

            // 実績積算区分
            itemOutput.setResultPlanedKbn(mdb0601Input.getResultPlanedKbn());

            // 工程CD
            itemOutput.setKoteiCd(mdb0601Input.getKoteiCd());

            // 代表リソースCD
            itemOutput.setDistResourceCd(mdb0601Input.getDistResourceCd());

            // 金額
            itemOutput.setPrice(null == mdb0601Input.getPrice() ? BigDecimal.ZERO : mdb0601Input.getPrice());

            // 作成日
            itemOutput.setCreatedAt(systemYearMonth);

            // 更新日
            itemOutput.setUpdatedAt(systemYearMonth);

            outputItems.add(itemOutput);
        }

        return outputItems;
    }

    private List<MDB0601Output> setItemOutput2(String ym1, String ym2, String systemYearMonth) {

        List<MDB0601Output> outputItems = new ArrayList<MDB0601Output>();
        MDB0601Output itemOutput = new MDB0601Output();

        // 検索条件を設定する
        MDB0601Input itemInput = new MDB0601Input();
        itemInput.setYm3(getFormatedYearMonth(ym1));
        itemInput.setYm4(getFormatedYearMonth2(ym1));

        logger.debug("findAll4開始");
        List<MDB0601Input> mdb0601Input4 = mdb0601Repository.findAll4(itemInput);
        for (MDB0601Input mdb0601Input : mdb0601Input4) {

            itemOutput = new MDB0601Output();

            // プロジェクト属性ID
            itemOutput.setPjAttId(mdb0601Input.getPjAttId());

            // プロジェクトID
            itemOutput.setPjId(mdb0601Input.getPjId());

            // 年月
            itemOutput.setYm(mdb0601Input.getYm());

            // 費目CD
            itemOutput.setHimokuCd(mdb0601Input.getHimokuCd());

            // 実績積算区分
            itemOutput.setResultPlanedKbn(mdb0601Input.getResultPlanedKbn());

            // 工程CD
            itemOutput.setKoteiCd(mdb0601Input.getKoteiCd());

            // 代表リソースCD
            itemOutput.setDistResourceCd(mdb0601Input.getDistResourceCd());

            // 金額
            itemOutput.setPrice(null == mdb0601Input.getPrice() ? BigDecimal.ZERO : mdb0601Input.getPrice());

            // 作成日
            itemOutput.setCreatedAt(systemYearMonth);

            // 更新日
            itemOutput.setUpdatedAt(systemYearMonth);

            outputItems.add(itemOutput);
        }

        logger.debug("findAll5開始");
        List<MDB0601Input> mdb0601Input5 = mdb0601Repository.findAll5(itemInput);
        for (MDB0601Input mdb0601Input : mdb0601Input5) {

            itemOutput = new MDB0601Output();

            // プロジェクト属性ID
            itemOutput.setPjAttId(mdb0601Input.getPjAttId());

            // プロジェクトID
            itemOutput.setPjId(mdb0601Input.getPjId());

            // 年月
            itemOutput.setYm(mdb0601Input.getYm());

            // 費目CD
            itemOutput.setHimokuCd(mdb0601Input.getHimokuCd());

            // 実績積算区分
            itemOutput.setResultPlanedKbn(mdb0601Input.getResultPlanedKbn());

            // 工程CD
            itemOutput.setKoteiCd(mdb0601Input.getKoteiCd());

            // 代表リソースCD
            itemOutput.setDistResourceCd(mdb0601Input.getDistResourceCd());

            // 金額
            itemOutput.setPrice(null == mdb0601Input.getPrice() ? BigDecimal.ZERO : mdb0601Input.getPrice());

            // 作成日
            itemOutput.setCreatedAt(systemYearMonth);

            // 更新日
            itemOutput.setUpdatedAt(systemYearMonth);

            outputItems.add(itemOutput);
        }

        return outputItems;
    }

    private String getCurrentMonth(LocalDateTime systemDateTime) {

        return systemDateTime.plusMonths(-3).format(dtfUUUUMM);
    }

    private String getPreviousMonth(LocalDateTime systemDateTime) {

        return systemDateTime.plusMonths(-4).format(dtfUUUUMM);
    }

    private String getFormatedYearMonth(String input) {
        LocalDate ld = LocalDate.of(Integer.parseInt(input.substring(0, 4)), Integer.parseInt(input.substring(4, 6)), 1) ;
        return ld.plusMonths(3).format(dtfUUUUMM);
    }

    private String getFormatedYearMonth2(String input) {
        LocalDate ld = LocalDate.of(Integer.parseInt(input.substring(0, 4)), Integer.parseInt(input.substring(4, 6)), 1) ;
        return ld.plusMonths(2).format(dtfUUUUMM);
    }

    private BigDecimal addBD(BigDecimal input1, BigDecimal input2) {

        BigDecimal rtn = null;

        if (input1 != null && input2 != null) {
            rtn = input1.add(input2);
        } else {

            if (input1 == null && input2 == null) {
                rtn = null;
            } else if (input1 == null) {
                rtn = input2;
            } else {
                rtn = input1;
            }
        }

        return rtn;
    }
}
