package jp.co.aeroasahi.tpkt.batch.mdb0204;

import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】SAP得意先マスタ＞のInputBean。
 */
@Setter
@Getter
public class MDB0204Input {

    /** 顧客ID */
    private String KUNNR;

    /** 顧客名 */
    private String NAME1;

    /** 顧客名（カナ） */
    private String NAME2;

    /** 顧客小分類コード */
    private String BRAN1;

}
