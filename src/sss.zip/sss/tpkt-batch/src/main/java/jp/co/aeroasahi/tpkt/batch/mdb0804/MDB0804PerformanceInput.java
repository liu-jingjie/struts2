package jp.co.aeroasahi.tpkt.batch.mdb0804;

import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜工数金額＞＜プロジェクト＞＜部門マスタ＞＜部門別稼働人数＞＜部門表示順マスタ＞のInputBean。
 */
@Setter
@Getter
public class MDB0804PerformanceInput {

    /** 工数金額の部門CD */
    private String deptCd;

    /** 部門マスタの部門名称 */
    private String deptName;

    /** 部門マスタの会社名 */
    private String corpName;

    /** 部門マスタの支社コード */
    private String branchCd;

    /** 部門マスタの支社名 */
    private String branchName;

    /** 部門マスタの中部門CD */
    private String deptMCd;

    /** 部門マスタの中部門名称 */
    private String deptMName;

    /** 部門マスタの小部門CD */
    private String deptSCd;

    /** 部門マスタの小部門名称 */
    private String deptSName;

    /** 部門マスタの部門種別 */
    private String deptType;

    /** 工数金額の年月 */
    private String ym;

    /** 部門別稼働人数の社員区分 */
    private String empKbn;

    /** 部門別稼働人数の稼働人数 */
    private BigDecimal activePeople;

    /** 工数金額の工数 */
    private BigDecimal kosu;

    /** 部門表示順マスタの表示順 */
    private BigDecimal dispOrder;

    /** プロジェクトのプロジェクトID */
    private String pjId;

    /** プロジェクトのプロジェクト名 */
    private String pjName;

    /** 工数金額の工程CD */
    private String koteiCd;

    /** 年月 検索用(当月)*/
    private String ym1;

    /** 年月 検索用(前月或は指定した年月)*/
    private String ym2;

    /** 年度 検索用*/
    private String ym3;

    /** 年度 検索用 指定月 */
    private String ym4;

    /** 日次・月次 検索用*/
    private String kbn;

    /** システム日付（YYYY-MM-DD）*/
    private String systemDate;

    /** システム日付（YYYY-MM-DD）指定月月末用　*/
    private String systemDate2;

    /**
     * 工数金額の部門CDと工数金額の年月と部門別稼働人数の社員区分を結合する
     * @return
     */
    public String concat() {
        return deptCd + "," + ym.substring(0,4) + "," + Integer.parseInt(ym.substring(4,6)) + "," + empKbn;
    }

}
