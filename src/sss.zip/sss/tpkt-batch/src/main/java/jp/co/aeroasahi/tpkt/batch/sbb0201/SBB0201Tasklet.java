package jp.co.aeroasahi.tpkt.batch.sbb0201;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.inject.Inject;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import com.google.common.collect.Lists;
import jp.co.aeroasahi.tpkt.batch.fw.CommonLog;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;
import jp.co.aeroasahi.tpkt.common.fw.message.MessageSharedService;

@Component
@Scope("step")
public class SBB0201Tasklet implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(SBB0201Tasklet.class);

    /** DateTimeFormatterのパターン yyyy-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
    /** DateTimeFormatterのパターン yyyyMMdd */
    private static final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyyMMdd");

    /** 金額データ */
    private static final int DATA_FROM_COST = 1;
    /** 工数金額データ */
    private static final int DATA_FROM_KOSU = 2;

    /** 処理区分 */
    @Value("#{jobParameters['jobKbn']}")
    public String jobKbn;

    /** 処理年月（YYYYMM形式） */
    @Value("#{jobParameters['jobYm']}")
    public String jobYm;

    /** システム日時 */
    @Value("#{jobParameters['sysDate']}")
    public String sysDate;

    @Inject
    SBB0201Repository sbb0201Repository;

    @Inject
    MessageSharedService messageService;

    @Inject
    DateFactory dateFactory;

    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

        // 入力チェック
        inputCheck();

        // システム日付を取得
        LocalDateTime sysDatetime = dateFactory.newDateTime();
        // 第三パラメータ(メインバッチからわたってきます。メインバッチの組み込みが別途必要)
        // 第三パラメータ（システム日時）が未入力の場合、ジョブ開始時に取得した「システム日時」に設定する
        if (sysDate != null && !sysDate.isEmpty()) {
            sysDatetime = LocalDateTime.parse(sysDate, timeFormatter);
        }

        // 更新対象年月リストを取得
        List<String> updateTarget = getParam(sysDatetime);
        // 原価更新処理
        updateCost(updateTarget, sysDatetime);

        // 工数更新処理
        updateKosu(updateTarget, sysDatetime);

        // 発生原価更新
        updateOccuredCost(updateTarget, sysDatetime);

        return RepeatStatus.FINISHED;
    }

    /**
     * 入力チェック
     *
     * @return チェック結果（true:エラーなし、false:エラーあり）
     */
    private void inputCheck() {
        // 処理区分をチェック
        if (StringUtils.isEmpty(jobKbn)) {
            logger.error(messageService.getMessage("e.bat.sb.001"));
            throw new RuntimeException();
        }
        if (!jobKbn.equals("D") && !jobKbn.equals("M")) {
            logger.error(messageService.getMessage("e.bat.sb.002", jobKbn));
            throw new RuntimeException();
        }

        // 処理年月（YYYYMM形式）をチェック
        if (StringUtils.isNotEmpty(jobYm)) {
            // フォーマットをチェック
            try {
                LocalDate.parse(jobYm + "01", dateFormatter);
            } catch (DateTimeException e) {
                logger.error(messageService.getMessage("e.bat.sb.003", jobYm));
                throw new RuntimeException();
            }
        }
        // 月次確定処理の場合、月次が指定されないとエラーにする
        if (jobKbn.equals("M") && StringUtils.isEmpty(jobYm)) {
            logger.error(messageService.getMessage("e.bat.sb.004"));
            throw new RuntimeException();
        }
    }

    /**
     * 更新対象年月リストを取得
     *
     * @param sysDatetime システム日付
     * @return 更新対象年月リスト
     */
    private List<String> getParam(LocalDateTime sysDatetime) {
        // 当月を取得（YYYYMM）
        String currentYm = sysDatetime.getYear() + String.format("%02d", sysDatetime.getMonthValue());

        // 第一パラメータ（処理区分）によって処理入力パラメータを用意する
        List<String> updateTarget = new ArrayList<>();
        updateTarget.add(currentYm);
        // 日次処理の場合、［金額．年月］が当月と前月のデータ
        if (jobKbn.equals("D")) {
            // 前月を取得
            LocalDateTime preDatetime = sysDatetime.minusMonths(1);
            String preYm = preDatetime.getYear() + String.format("%02d", preDatetime.getMonthValue());
            // 処理年月を設定
            updateTarget.add(preYm);
            // 月次確定処理の場合、［金額．年月］が当月と［パラメータ．処理年月］のデータ
        } else if (jobKbn.equals("M")) {
            // 処理年月を設定
            updateTarget.add(jobYm);
        }
        return updateTarget;
    }


    /**
     * 原価更新処理
     */
    private void updateCost(List<String> updateTarget, LocalDateTime sysDatetime) {

        // 金額＆積算差分状況を取得
        List<SBB0201KosuCost> costList = sbb0201Repository.findCostByYm(updateTarget);

        if (costList != null && costList.size() > 0) {
            // 並び順を取得
            List<SbDataMaxSort> sbDataMaxSort = sbb0201Repository.findMaxSortNum(DATA_FROM_COST);
            // 枝番を取得
            List<SbDataMaxBranch> sbDataMaxBranch = sbb0201Repository.findMaxBranchNum(DATA_FROM_COST);
            // ①の新規レコードの並び順を設定
            costList = setSortBranchNum(costList, sbDataMaxSort, sbDataMaxBranch);

            Stream<SBB0201KosuCost> streamNone = costList.stream().filter((e) -> {
                return e.getIsExists() == 0;
            });

            List<SBB0201KosuCost> resultNone = streamNone.collect(Collectors.toList());

            // 積算データ更新
            // ①［積算データ．実績積算区分］が「1」に登録データなし→［積算データ．実績積算区分］が「1」のレコードを追加する
            for (SBB0201KosuCost entry : resultNone) {
                sbb0201Repository.insertSBDataBudget(entry);
            }
            CommonLog.setInsertRecordeCountLog(logger, "積算データ(sb_data)予算", resultNone.size());

            // ②［積算データ．実績積算区分］が「2」に登録データなし→［積算データ．実績積算区分］が「2」のレコードを追加する
            // ③［積算データ．実績積算区分］が「2」に登録データあり→［積算データ．実績積算区分］が「2」のレコードを更新する
            for (SBB0201KosuCost entry : costList) {
                sbb0201Repository.updateSBDataResult(entry);
            }
            CommonLog.setUpdateRecordeCountLog(logger, "積算データ(sb_data)実績", costList.size());
            List<SBB0201MonthKosuCost> monthCostList = Lists.newArrayList();
            for (String target : updateTarget) {
                List<String> list = new ArrayList<>();
                list.add(target);
                monthCostList.addAll(sbb0201Repository.findMonthCostByYm(list));
            }
            // ④［積算月別展開データ］にデータを反映する(レコードが存在すれば更新、なければ追加)

            for (SBB0201MonthKosuCost entry : monthCostList) {
                sbb0201Repository.updateSBMonthDataResult(entry, sysDatetime);
            }
            CommonLog.setUpdateRecordeCountLog(logger, "積算月別データ(sb_month_data)実績", monthCostList.size());
        }
    }

    /**
     * 並び順と枝番を設定
     *
     * @param list 積算情報リスト
     * @param sbDataMaxSort 並び順情報
     * @param sbDataMaxBranch 枝番情報
     * @return 並び順設定する積算情報リスト
     */
    List<SBB0201KosuCost> setSortBranchNum(List<SBB0201KosuCost> list, List<SbDataMaxSort> sbDataMaxSort,
            List<SbDataMaxBranch> sbDataMaxBranch) {
        List<SBB0201KosuCost> result = new ArrayList<SBB0201KosuCost>();

        // 並び順MAP
        Map<String, SbDataMaxSort> sortMap =
                sbDataMaxSort.stream().collect(Collectors.toMap(SbDataMaxSort::getPjId, Function.identity()));
        Map<String, Integer> maxSortMap = new HashMap<String, Integer>();
        // 枝番MAP
        Map<String, SbDataMaxBranch> branchMap =
                sbDataMaxBranch.stream().collect(Collectors.toMap(SbDataMaxBranch::getConcat, Function.identity()));
        Map<String, Integer> maxBranchMap = new HashMap<String, Integer>();

        for (SBB0201KosuCost bean : list) {
            // 予算データがない場合、並び順と枝番を設定
            if (bean.getIsExists() != 1) {
                // 並び順
                if (maxSortMap.containsKey(bean.getPjId())) {
                    // MAX並び順を取得
                    Integer sortNum = maxSortMap.get(bean.getPjId());
                    // MAX並び順を更新
                    maxSortMap.put(bean.getPjId(), sortNum + 1);
                } else {
                    // MAX並び順を取得
                    Integer sortNum = 0;
                    if (sortMap.get(bean.getPjId()) != null) {
                        sortNum = sortMap.get(bean.getPjId()).getMaxSortNum().intValue();
                    }
                    // Integer sortNum = sortMap.get(bean.getPjId()).getMaxSortNum().intValue();
                    // MAX並び順を更新
                    maxSortMap.put(bean.getPjId(), sortNum + 1);
                }
                // 並び順を設定
                bean.setSortNum(maxSortMap.get(bean.getPjId()));

                // 枝番
                if (maxBranchMap.containsKey(bean.getPjId() + bean.getKoteiCd())) {
                    // MAX並び順を取得
                    Integer branchNum = maxBranchMap.get(bean.getPjId() + bean.getKoteiCd());
                    // MAX並び順を更新
                    maxBranchMap.put(bean.getPjId() + bean.getKoteiCd(), branchNum + 1);
                } else {
                    // MAX並び順を取得
                    Integer branchNum = 0;
                    if (branchMap.get(bean.getPjId() + bean.getKoteiCd()) != null) {
                        branchNum = Integer.parseInt(
                                branchMap.get(bean.getPjId() + bean.getKoteiCd()).getMaxBranchNum().replace(" ", ""));
                    }
                    // Integer branchNum = Integer.parseInt(
                    // branchMap.get(bean.getPjId() + bean.getKoteiCd()).getMaxBranchNum().replace(" ", ""));
                    // MAX並び順を更新
                    maxBranchMap.put(bean.getPjId() + bean.getKoteiCd(), branchNum + 1);
                }
                // 並び順を設定
                bean.setBranchNum(maxBranchMap.get(bean.getPjId() + bean.getKoteiCd()).toString());
            }

            // 結果に追加
            result.add(bean);
        }
        return result;
    }

    /**
     * 工数更新処理
     */
    private void updateKosu(List<String> updateTarget, LocalDateTime sysDatetime) {
        // 工数金額＆積算差分状況を取得
        List<SBB0201KosuCost> kosuList = sbb0201Repository.findKosuByYm(updateTarget);

        if (kosuList != null && kosuList.size() > 0) {
            // 並び順を取得
            List<SbDataMaxSort> sbDataMaxSort = sbb0201Repository.findMaxSortNum(DATA_FROM_KOSU);
            // 枝番を取得
            List<SbDataMaxBranch> sbDataMaxBranch = sbb0201Repository.findMaxBranchNum(DATA_FROM_KOSU);
            // ①の新規レコードの並び順を設定
            kosuList = setSortBranchNum(kosuList, sbDataMaxSort, sbDataMaxBranch);

            Stream<SBB0201KosuCost> streamNone = kosuList.stream().filter((e) -> {
                return e.getIsExists() == 0;
            });

            List<SBB0201KosuCost> resultNone = streamNone.collect(Collectors.toList());

            // 積算データ更新
            // ①［積算データ．実績積算区分］が「1」に登録データなし→［積算データ．実績積算区分］が「1」のレコードを追加する
            for (SBB0201KosuCost entry : resultNone) {
                sbb0201Repository.insertSBDataBudget(entry);
            }
            CommonLog.setInsertRecordeCountLog(logger, "積算データ(sb_data)予算", resultNone.size());

            // ②［積算データ．実績積算区分］が「2」に登録データなし→［積算データ．実績積算区分］が「2」のレコードを追加する
            // ③［積算データ．実績積算区分］が「2」に登録データあり→［積算データ．実績積算区分］が「2」のレコードを更新する
            for (SBB0201KosuCost entry : kosuList) {
                sbb0201Repository.updateSBDataResult(entry);
            }
            CommonLog.setUpdateRecordeCountLog(logger, "積算データ(sb_data)実績", kosuList.size());

            // ④［積算月別展開データ］にデータを反映する(レコードが存在すれば更新、なければ追加)
            List<SBB0201MonthKosuCost> monthKosuList = Lists.newArrayList();
            for (String entry : updateTarget) {
                List<String> list = new ArrayList<>();
                list.add(entry);
                monthKosuList.addAll(sbb0201Repository.findMonthKosuByYm(list));
            }
            for (SBB0201MonthKosuCost entry : monthKosuList) {
                sbb0201Repository.updateSBMonthDataResult(entry, sysDatetime);
            }
            CommonLog.setUpdateRecordeCountLog(logger, "積算月別データ(sb_month_data)実績", monthKosuList.size());
        }
    }


    /**
     * 発生原価更新処理
     */
    private void updateOccuredCost(List<String> updateTarget, LocalDateTime sysDatetime) {
        // 発生原価を取得
        List<SBB0201SapCost> occuredCostList = sbb0201Repository.findSAPCostByYm(updateTarget);

        if (occuredCostList != null && occuredCostList.size() > 0) {
            // 発生原価、積算原価率を算出し、［積算基本情報］を更新する
            if (occuredCostList.size() > 0) {
                for (SBB0201SapCost entry : occuredCostList) {
                    sbb0201Repository.updateSBBaseInfo(entry, sysDatetime);
                }
                CommonLog.setUpdateRecordeCountLog(logger, "積算基本情報", occuredCostList.size());
            }
        }
    }

}
