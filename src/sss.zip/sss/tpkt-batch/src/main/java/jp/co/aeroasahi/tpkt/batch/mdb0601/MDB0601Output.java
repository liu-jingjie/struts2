package jp.co.aeroasahi.tpkt.batch.mdb0601;

import java.math.BigDecimal;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.batch.item.ItemCountAware;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】部門経費管理＞のOutputBean。
 */
@Setter
@Getter
public class MDB0601Output implements ItemCountAware {

    private int count;

    /** プロジェクト属性ID */
    @NotBlank
    @Size(min = 1, max = 8)
    private String pjAttId;

    /** プロジェクトID */
    @NotBlank
    @Size(min = 1, max = 12)
    private String pjId;

    /** 年月 */
    @NotBlank
    @Size(min = 1, max = 6)
    private String ym;

    /** 費目CD */
    @NotBlank
    @Size(min = 1, max = 2)
    private String himokuCd;

    /** 実績積算区分 */
    @NotBlank
    @Size(min = 1, max = 1)
    private String resultPlanedKbn;

    /** 工程CD */
    @NotBlank
    @Size(min = 1, max = 5)
    private String koteiCd;

    /** 代表リソースCD */
    @NotBlank
    @Size(min = 1, max = 4)
    private String distResourceCd;

    /** 金額 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal price;

    /** 作成日 */
    @Size(min = 0, max = 23)
    private String createdAt;

    /** 更新日 */
    @Size(min = 0, max = 23)
    private String updatedAt;

    /**
     * プロジェクト属性IDとプロジェクトIDと年月と費目CDと実績積算区分と工程CDと代表リソースCDを結合する
     * @return
     */
    public String concat() {
        return pjAttId + "," + pjId + "," + ym + "," + himokuCd + "," + resultPlanedKbn + "," + koteiCd + "," + distResourceCd;
    }

    @Override
    public void setItemCount(int count) {
        this.count = count;
    }
}
