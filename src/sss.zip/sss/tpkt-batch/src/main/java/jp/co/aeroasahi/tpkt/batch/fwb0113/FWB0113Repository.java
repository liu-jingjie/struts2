package jp.co.aeroasahi.tpkt.batch.fwb0113;

import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 * テーブル＜【TEMP】SAPプロジェクト＞に操作
 */
public interface FWB0113Repository {

    /**
     * テーブル＜【TEMP】SAPプロジェクト＞情報を取得する。
     *
     * @return データ情報
     */
    List<FWB0113Output> findAll();

    /**
     * テーブル＜汎用マスタ＞情報を取得する。
     *
     * @return データ情報
     */
    List<FWB0113Output> findAllByTypeId(@Param("typeid") int typeid);

    /**
     * テーブル＜【TEMP】SAPプロジェクト＞に登録する。
     *
     * @param output FWB0113Output
     * @return
     */
    void create(FWB0113Output output);

    /**
     * テーブル＜【TEMP】SAPプロジェクト＞に更新する。
     *
     * @param output FWB0113Output
     * @return
     */
    void update(FWB0113Output output);

    /**
     * テーブル＜【TEMP】プロジェクト＞情報を取得する。
     *
     * @return データ情報
     */
    List<FWB0113TpktOutput> findAllTpkt();

    /**
     * テーブル＜【TEMP】プロジェクト＞に登録する。
     *
     * @param output FWB0113TpktOutput
     * @return
     */
    void tpktCreate(FWB0113TpktOutput output);

    /**
     * テーブル＜【TEMP】プロジェクト＞に更新する。
     *
     * @param output FWB0113TpktOutput
     * @return
     */
    void tpktUpdate(FWB0113TpktOutput output);
}
