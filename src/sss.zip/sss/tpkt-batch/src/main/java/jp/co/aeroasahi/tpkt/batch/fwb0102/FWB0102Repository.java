package jp.co.aeroasahi.tpkt.batch.fwb0102;

/**
 * テーブル＜【TEMP】SAP仕入先マスタ＞に操作
 */
public interface FWB0102Repository {

    /**
     * テーブル＜SAP仕入先マスタ＞に登録する。
     *
     * @param output FWB0102Output
     * @return
     */
    void create(FWB0102Output output);

    /**
     * テーブル＜SAP仕入先マスタ＞に削除する。
     *
     * @param output FWB0102Output
     * @return
     */
    void delete(FWB0102Output output);
}
