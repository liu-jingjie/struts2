package jp.co.aeroasahi.tpkt.batch.mdb0802;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.fw.CommonLog;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

@Component
@Scope("step")
public class MDB0802Tasklet implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0802Tasklet.class);

    @Inject
    MDB0802Repository mdb0802Repository;

    @Inject
    DateFactory dateFactory;

    @Value("#{jobParameters['kbn']}")
    public String kbn;

    @Value("#{jobParameters['yyyymm']}")
    public String yyyymm;

    /** DateTimeFormatterのパターン uuuuMM */
    private static final DateTimeFormatter dtfUUUUMM = DateTimeFormatter.ofPattern("uuuuMM");

    /** DateTimeFormatterのパターン uuuu-MM-dd */
    private static final DateTimeFormatter dtfUUUUMMDD = DateTimeFormatter.ofPattern("uuuu-MM-dd");

    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        LocalDateTime systemDate = dateFactory.newDateTime();
        String systemDateTimeYearMonthStr = systemDate.format(dtfUUUUMM);
        String systemDateTimeYearMonthDayStr = systemDate.format(dtfUUUUMMDD);

        // 年度開始月
        String fiscalStartYearMonth = getStartOfFiscalYearMonth(systemDateTimeYearMonthStr);

        // 年度終了月
        String fiscalEndYearMonth = getEndOfFiscalYearMonth(systemDateTimeYearMonthStr);

        // 年度
        String fiscalYear = fiscalStartYearMonth.substring(0, 4);

        // 月次の場合用、指定年月
        String designationYearMonth = yyyymm;

        List<MDB0802Input> detailList = new ArrayList<MDB0802Input>();

        // 各テーブルからデータ情報を取得する。
        MDB0802Input inputKey = new MDB0802Input();

        // 日次処理の場合
        if (kbn.equals("D")) {

            inputKey.setSystemDate(systemDateTimeYearMonthDayStr);
            inputKey.setFiscalStartYearMonth(fiscalStartYearMonth);
            inputKey.setFiscalEndYearMonth(fiscalEndYearMonth);
            inputKey.setFiscalYear(fiscalYear);

            detailList = mdb0802Repository.findAllDay1(inputKey);
            detailList.addAll(mdb0802Repository.findAllDay2(inputKey));

        // 月次確定処理の場合
        } else if (kbn.equals("M")) {

            LocalDateTime yyyymmP = LocalDateTime.of(Integer.parseInt(yyyymm.substring(0, 4)), Integer.parseInt(yyyymm.substring(4, 6)), 1, 1, 1);

            inputKey.setSpecifiedMonth(yyyymmP.plusMonths(1).minusDays(1).format(dtfUUUUMMDD));
            inputKey.setDesignationYearMonth(designationYearMonth);
            inputKey.setFiscalStartYearMonth(getStartOfFiscalYearMonth(yyyymm));
            inputKey.setFiscalEndYearMonth(getEndOfFiscalYearMonth(yyyymm));
            inputKey.setFiscalYear(getStartOfFiscalYearMonth(yyyymm).substring(0, 4));

            detailList = mdb0802Repository.findAllMonth1(inputKey);
            detailList.addAll(mdb0802Repository.findAllMonth2(inputKey));
        }

        List<MDB0802Output> canceledPjList = mdb0802Repository.findAllByCanceled();
        Map<String, MDB0802Output> canceledPjListMap =
                canceledPjList.stream().collect(Collectors.toMap(MDB0802Output::getBuPjAttId, Function.identity()));

        // 【【TEMP】外注管理に登録する前に、データを編集する。
        List<MDB0802Output> outItems = getResultList(setItemOutput(detailList), canceledPjListMap);

        if(outItems.size() > 0) {

            // データを削除
            mdb0802Repository.delete();

            // データを登録
            for (MDB0802Output output : outItems) {
                mdb0802Repository.create(output);
            }
        }
        CommonLog.setInsertRecordeCountLog(logger, "【TEMP】外注管理(temp_md_disp_outsourcing)", outItems.size());

        return RepeatStatus.FINISHED;
    }

    private List<MDB0802Output> setItemOutput(List<MDB0802Input> inputList) {

        List<MDB0802Output> outputItems = new ArrayList<MDB0802Output>();

        MDB0802Output item = new MDB0802Output();

        for (MDB0802Input mdb0802Input : inputList) {
            item = new MDB0802Output();

            // 発注書番号
            item.setOrderNum(mdb0802Input.getOrderNum());

            // プロジェクトID
            item.setPjId(mdb0802Input.getPjId());

            // プロジェクト名称
            item.setPjName(mdb0802Input.getPjName());

            // 物件管理責任者部門支社ＣＤ
            item.setPjManageRespDeptBranchCd(mdb0802Input.getPjManageRespDeptBranchCd());

            // 物件管理責任者部門支社名称
            item.setPjManageRespDeptBranchName(mdb0802Input.getPjManageRespDeptBranchName());

            // 物件管理責任者部門部ＣＤ
            item.setPjManageRespMiddleDeptCd(mdb0802Input.getPjManageRespMiddleDeptCd());

            // 物件管理責任者部門部名称
            item.setPjManageRespMiddleDeptName(mdb0802Input.getPjManageRespMiddleDeptName());

            // 物件管理責任者部門ＣＤ
            item.setPjManageRespDeptCd(mdb0802Input.getPjManageRespDeptCd());

            // 物件管理責任者部門名称
            item.setPjManageRespDeptName(mdb0802Input.getPjManageRespDeptName());

            // 物件管理責任者ＣＤ
            item.setPjManageRespEmpCd(mdb0802Input.getPjManageRespEmpCd());

            // 物件管理責任者名
            item.setPjManageRespEmpName(mdb0802Input.getPjManageRespEmpName());

            // 生産主管部門支社ＣＤ
            item.setProductMainDeptBranchCd(mdb0802Input.getProductMainDeptBranchCd());

            // 生産主管部門支社名称
            item.setProductMainDeptBranchName(mdb0802Input.getProductMainDeptBranchName());

            // 生産主管部門部ＣＤ
            item.setProductMainMiddleDeptCd(mdb0802Input.getProductMainMiddleDeptCd());

            // 生産主管部門部名称
            item.setProductMainMiddleDeptName(mdb0802Input.getProductMainMiddleDeptName());

            // 生産主管部門ＣＤ
            item.setProductMainDeptCd(mdb0802Input.getProductMainDeptCd());

            // 生産主管部門名称
            item.setProductMainDeptName(mdb0802Input.getProductMainDeptName());

            // 生産プロデューサーＣＤ
            item.setProductProducerEmpCd(mdb0802Input.getProductProducerEmpCd());

            // 生産プロデューサー名
            item.setProductProducerName(mdb0802Input.getProductProducerName());

            // 生産担当部門支社ＣＤ
            item.setProductDeptBranchCd(mdb0802Input.getProductDeptBranchCd());

            // 生産担当部門支社名称
            item.setProductDeptBranchName(mdb0802Input.getProductDeptBranchName());;

            // 生産担当部門部ＣＤ
            item.setProductMiddleDeptCd(mdb0802Input.getProductMiddleDeptCd());

            // 生産担当部門部名称
            item.setProductMiddleDeptName(mdb0802Input.getProductMiddleDeptName());

            // 生産担当部門ＣＤ
            item.setProductDeptCd(mdb0802Input.getProductDeptCd());

            // 生産担当部門名称
            item.setProductDeptName(mdb0802Input.getProductDeptName());

            // 起案者ＣＤ
            item.setAppliedEmpCd(mdb0802Input.getAppliedEmpCd());

            // 起案者名
            item.setAppliedEmpName(mdb0802Input.getAppliedEmpName());

            // 申請日
            item.setAppliedAt(mdb0802Input.getAppliedAt());

            // 申請番号
            item.setApplyNum(mdb0802Input.getApplyNum());

            // 再委託条件
            if(!(null == mdb0802Input.getReentrustKbn() || mdb0802Input.getReentrustKbn().trim().equals(""))) {
                item.setReentrustKbn(new BigDecimal(mdb0802Input.getReentrustKbn()));
            }

            // 外注費積算額
            item.setPlanedOutsourcing(mdb0802Input.getPlanedOutsourcing());

            // 売上完了日
            item.setSoldOn(mdb0802Input.getSoldOn());

            // 売上予定日
            item.setPlannedSalesOn(mdb0802Input.getPlannedSalesOn());

            // 業者コード
            item.setVendorCd(mdb0802Input.getVendorCd());

            // 委託業者
            item.setVendorName(mdb0802Input.getVendorName());

            // 発注日
            item.setOrderedOn(mdb0802Input.getOrderedOn());

            // 作業期間FROM
            item.setWorkFrom(mdb0802Input.getWorkFrom());

            // 作業期間TO
            item.setWorkTo(mdb0802Input.getWorkTo());

            // 納品予定日
            item.setPlanedDeliveryOn(mdb0802Input.getPlanedDeliveryOn());

            // 支払処理日
            if(kbn.equals("M")) {

                LocalDate yyyymmP = LocalDate.of(Integer.parseInt(yyyymm.substring(0, 4)), Integer.parseInt(yyyymm.substring(4, 6)), 1);
                LocalDate specifiedMonth = yyyymmP.plusMonths(1).minusDays(1);
                LocalDate paymentProcessedOn = (null == mdb0802Input.getPaymentProcessedOn()) ? LocalDate.of(1900, 1, 1) : LocalDate.parse(mdb0802Input.getPaymentProcessedOn(), dtfUUUUMMDD);

                if(paymentProcessedOn.isAfter(specifiedMonth)) {
                    item.setPaymentProcessedOn(null);

                    // 外注費（一般）支払ベース
                    item.setOutsidePaidCost(BigDecimal.ZERO);

                    // 外注費（関係）支払ベース
                    item.setGroupPaidCost(BigDecimal.ZERO);

                    // 業務委託費支払ベース
                    item.setEntrustPaidCost(BigDecimal.ZERO);

                    // 合計支払ベース
                    item.setTotalPaidCost(BigDecimal.ZERO);
                }else {
                    item.setPaymentProcessedOn(mdb0802Input.getPaymentProcessedOn());

                    // 外注費（一般）支払ベース
                    item.setOutsidePaidCost(mdb0802Input.getOutsidePaidCost());

                    // 外注費（関係）支払ベース
                    item.setGroupPaidCost(mdb0802Input.getGroupPaidCost());

                    // 業務委託費支払ベース
                    item.setEntrustPaidCost(mdb0802Input.getEntrustPaidCost());

                    // 合計支払ベース
                    item.setTotalPaidCost(mdb0802Input.getTotalPaidCost());
                }
            }else {
                item.setPaymentProcessedOn(mdb0802Input.getPaymentProcessedOn());

                // 外注費（一般）支払ベース
                item.setOutsidePaidCost(mdb0802Input.getOutsidePaidCost());

                // 外注費（関係）支払ベース
                item.setGroupPaidCost(mdb0802Input.getGroupPaidCost());

                // 業務委託費支払ベース
                item.setEntrustPaidCost(mdb0802Input.getEntrustPaidCost());

                // 合計支払ベース
                item.setTotalPaidCost(mdb0802Input.getTotalPaidCost());
            }

            // 外注費（一般）発注ベース
            item.setOutsideOrderedCost(mdb0802Input.getOutsideOrderedCost());

            // 外注費（関係）発注ベース
            item.setGroupOrderedCost(mdb0802Input.getGroupOrderedCost());

            // 業務委託費発注ベース
            item.setEntrustOrderedCost(mdb0802Input.getEntrustOrderedCost());

            // 合計発注ベース
            item.setTotalOrderedCost(mdb0802Input.getTotalOrderedCost());

            // 並び順_物件管理責任者部門
            item.setSortNumPjManageRespDept(mdb0802Input.getSortNumPjManageRespDept());

            // 並び順_生産主管部門
            item.setSortNumProductMainDept(mdb0802Input.getSortNumProductMainDept());

            // 並び順_生産担当部門
            item.setSortNumProductDept(mdb0802Input.getSortNumProductDept());

            outputItems.add(item);
        }

        return outputItems;
    }

    private String getStartOfFiscalYearMonth(String yearMonth) {

        int year = Integer.parseInt(yearMonth.substring(0, 4));
        int month = Integer.parseInt(yearMonth.substring(4, 6));

        if (month < 4) {
            year--;
        }

        return String.valueOf(year + "04");

    }

    private String getEndOfFiscalYearMonth(String yearMonth) {

        int year = Integer.parseInt(yearMonth.substring(0, 4));
        int month = Integer.parseInt(yearMonth.substring(4, 6));

        if (month < 4) {
            year--;
        }

        return String.valueOf(year + 1 + "03");

    }

    private List<MDB0802Output> getResultList(List<MDB0802Output> inputList, Map<String, MDB0802Output> canceledPjListMap) {

        Stream<MDB0802Output> stream = inputList.stream()
                .filter((e) -> {
                    return !canceledPjListMap.containsKey(e.getPjId().substring(0, e.getPjId().length()-2));
                });

        return stream.collect(Collectors.toList());
    }
}
