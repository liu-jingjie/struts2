package jp.co.aeroasahi.tpkt.batch.mdb0203;

import java.math.BigDecimal;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜SAPプロジェクト＞＜汎用マスタ＞＜【TEMP】受注＞＜【TEMP】売上＞のInputBean。
 */
@Setter
@Getter
public class MDB0203Input {

    /** SAPプロジェクトのプロジェクトID */
    private String PSPNR;

    /** SAPプロジェクトのプロジェクト属性ID */
    private String ZPSPID;

    /** SAPプロジェクトのプロジェクト名称 */
    private String ZPSPNAME;

    /** SAPプロジェクトの生産・営業担当部門 */
    private String PRCTR;

    /** SAPプロジェクトの生産・営業担当者 */
    private String ZSEISANEIGYOTANTOSHA;

    /** 汎用マスタ29の値 */
    private String VALUE29;

    /** 汎用マスタ30の値 */
    private String VALUE30;

    /** 【TEMP】受注のプロジェクトID */
    private String pjIdReceive;

    /** 【TEMP】受注の受注金額合計 */
    private BigDecimal totalReceivedAmount;

    /** 【TEMP】受注の応札積算額合計 */
    private BigDecimal totalOsatsuPlanedAmount;

    /** 【TEMP】受注の受注日(一番古い) */
    private Date minReceivedOn;

    /** 【TEMP】売上のプロジェクトID */
    private String pjIdSoldAmount;

    /** 【TEMP】売上の売上額合計 */
    private BigDecimal totalSoldAmount;

    /** 【TEMP】売上の売上日(一番古い) */
    private Date minSoldOn;

    /** 【TEMP】売上の売上日(一番新しい) */
    private Date maxSoldOn;

    /** SAPプロジェクトの取引種別 */
    private String ZTORISYUBETU;

    /** 【TEMP】受注の売上予定日 */
    private String planedSellingOn;

    /** 【TEMP】受注の売上予定日(一番未来の日付) */
    private String lastPlannedSalesOn;
}
