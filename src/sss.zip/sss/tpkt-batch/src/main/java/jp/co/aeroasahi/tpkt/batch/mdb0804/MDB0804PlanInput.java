package jp.co.aeroasahi.tpkt.batch.mdb0804;

import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜部門計画工数マスタ＞＜部門マスタ＞＜部門表示順マスタ＞のInputBean。
 */
@Setter
@Getter
public class MDB0804PlanInput {

    /** 部門計画工数マスタの部門CD */
    private String deptCd;

    /** 部門マスタの部門名称 */
    private String deptName;

    /** 部門マスタの会社名 */
    private String corpName;

    /** 部門マスタの支社コード */
    private String branchCd;

    /** 部門マスタの支社名 */
    private String branchName;

    /** 部門マスタの中部門CD */
    private String deptMCd;

    /** 部門マスタの中部門名称 */
    private String deptMName;

    /** 部門マスタの小部門CD */
    private String deptSCd;

    /** 部門マスタの小部門名称 */
    private String deptSName;

    /** 部門マスタの部門種別 */
    private String deptType;

    /** 部門計画工数マスタの計画年月 */
    private String planYm;

    /** 部門計画工数マスタの計画人数 */
    private BigDecimal planDeptPeople;

    /** 部門計画工数マスタの直接工数 */
    private BigDecimal directKosu;

    /** 部門計画工数マスタの直接の内【間機】工数 */
    private BigDecimal directMachineKosu;

    /** 部門計画工数マスタの有休工数 */
    private BigDecimal paidHolidayKosu;

    /** 部門計画工数マスタの販売工数 */
    private BigDecimal saleKosu;

    /** 部門計画工数マスタのその他間接工数 */
    private BigDecimal otherIndirectKosu;

    /** 部門表示順マスタの表示順 */
    private BigDecimal dispOrder;

    /** 年度 検索用*/
    private String ym3;

    /** システム日付（YYYY-MM-DD）*/
    private String systemDate;
}
