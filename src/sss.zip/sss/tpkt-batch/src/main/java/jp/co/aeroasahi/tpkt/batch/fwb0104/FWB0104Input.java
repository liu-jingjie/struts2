package jp.co.aeroasahi.tpkt.batch.fwb0104;

import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】SAPプロジェクト＞のInputBean。
 */
@Setter
@Getter
public class FWB0104Input {

    /** プロジェクトID */
    private String PSPNR;

    /** プロジェクト名称 */
    private String ZPSPNAME;

    /** 生産・営業担当部門 */
    private String PRCTR;

    /** 生産・営業担当者 */
    private String ZSEISANEIGYOTANTOSHA;

    /** プロジェクトID ステータス */
    private String STAT;

    /** プロジェクト登録日 */
    private String ZCMCREADT;

    /** プロジェクト属性ID */
    private String ZPSPID;

    /** 取引種別 */
    private String ZTORISYUBETU;

    /** 作成日 */
    private String INS_DT;

    /** 更新日 */
    private String UPD_DT;

}
