package jp.co.aeroasahi.tpkt.batch.oj.ojb0201;

import java.util.List;
import javax.inject.Inject;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import jp.co.aeroasahi.tpkt.batch.fw.CommonLog;

@Component
@Scope("step")
public class OJB0201Tasklet implements Tasklet {

    // 定数
    private static final String NOT_UPDATE = "notUpdate";
    // ログ
    private static final Logger logger = LoggerFactory.getLogger(OJB0201Tasklet.class);

    @Inject
    OJB0201Repository ojb0201Repository;

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
        // データを抽出する
        List<OjuenEntrustBranchInfoOutInfor> result = ojb0201Repository.findOjuenEntrustBranchInfoOutInfor();
        // 更新件数
        int count = 0;
        // SAPの主キー
        String applyNumTemp = "";
        String entrustBranchNumTemp = "";

        for (OjuenEntrustBranchInfoOutInfor entry : result) {
            boolean isDuplicate = isDuplicate(entry, applyNumTemp, entrustBranchNumTemp);
            if (!NOT_UPDATE.equals(entry.getStatus()) && !isDuplicate) {
                updateOjuen(entry);
                count++;
                applyNumTemp = "";
                entrustBranchNumTemp = "";
            } else {
                if (StringUtils.isEmpty(entrustBranchNumTemp)) {
                    // メッセージを出力
                    logger.warn("重登録の可能性があります。SAP側のデータを確認してください。;申請番号={};枝番={}", entry.getApplyNum(),
                            entry.getEntrustBranchNum());
                }
                applyNumTemp = entry.getApplyNum();
                entrustBranchNumTemp = entry.getEntrustBranchNum();
            }
        }
        // ログを出力
        CommonLog.setUpdateRecordeCountLog(logger, "応受援委託先枝番情報(oj_entrust_branch_info)", count);
        return RepeatStatus.FINISHED;
    }

    /**
     * データベースを更新
     *
     * @param input
     */
    private void updateOjuen(OjuenEntrustBranchInfoOutInfor input) {
        ojb0201Repository.updateOjuenEntrustBranchInfo(input);
    }
    /**
     * 重複データかどうか
     * @param entry
     * @param applyNum
     * @param entrustBranchNum
     * @return
     */
    private boolean isDuplicate (OjuenEntrustBranchInfoOutInfor entry, String applyNum, String entrustBranchNum) {
        if (entry.getApplyNum().equals(applyNum) && entry.getEntrustBranchNum().equals(entrustBranchNum)) {
            return true;
        } else {
            return false;
        }
    }
}
