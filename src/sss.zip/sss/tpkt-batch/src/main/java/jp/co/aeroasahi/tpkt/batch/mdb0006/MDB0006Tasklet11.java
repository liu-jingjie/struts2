package jp.co.aeroasahi.tpkt.batch.mdb0006;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.inject.Inject;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

/**
 * スケジュールされたタイミングで、応受援帳票登録状況一覧および帳票登録状況一覧の作成処理を実行する
 */
@Component
@Scope("step")
public class MDB0006Tasklet11 implements Tasklet {

    @Inject
    DateFactory dateFactory;

    @Inject
    MDB0006Repository mdb0006Repository;

    @Autowired
    private BatchDataHolder batchDataHolder;

    /** DateTimeFormatterのパターン uuuu-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.SSS");

    /**
     *
     * メインバッチ（帳票登録）
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return バッチ終了ステータス
     */
    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        LocalDateTime systemDateTime = dateFactory.newDateTime();
        String systemDateTimeStr = systemDateTime.format(dtf);

        // 実施時間
        batchDataHolder.setSystemDateTime(systemDateTimeStr);

        batchDataHolder.setCheckResult(true);

        // 応受援帳票登録状況一覧の作成
        executeJob("ojb0102Job", "systemDateTime=" + systemDateTimeStr);

        // 実施バッチ数
        batchDataHolder.setCheckCount(1);

        return RepeatStatus.FINISHED;
    }

    /**
     * ジョブ実行処理
     *
     * @return 無し
     */
    private void executeJob(String jobName, String jobParameter) throws Exception {

        BatchJobRequestInput input = new BatchJobRequestInput();

        input.setJobName(jobName);
        input.setJobParameter(jobParameter);
        input.setPriority(1);
        input.setPollingStatus("INIT");

        mdb0006Repository.create(input);
    }
}

