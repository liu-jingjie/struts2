package jp.co.aeroasahi.tpkt.batch.mdb0002;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

/**
 * 各ジョブを実行するTasklet
 */
@Component
@Scope("step")
public class MDB0002Tasklet12 implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0002Tasklet12.class);

    /** DateTimeFormatterのパターン uuuuMMdd_HHmmssSSS_ */
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("uuuuMMdd_HHmmssSSS_");
    /** DateTimeFormatterのパターン uuuu-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf4 = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.SSS");

    /** 仕入先差分連携jobName */
    private static final String VENDOR_DIF_JOB_NAME = "fwb0111Job";
    /** プロジェクト属性差分連携jobName */
    private static final String PROJECT_DIF_ATTRIBUTE_JOB_NAME = "fwb0112Job";
    /** プロジェクト差分連携jobName */
    private static final String PROJECT_DIF_JOB_NAME = "fwb0113Job";

    private static final boolean TEMP_TO_MAIN = true;
    private static final boolean MAIN_TO_TEMP = false;

    /** ファイルバックアップ先（取込で異常が発生した場合） */
    @Value("${sap.error.dirpath}")
    String errorDirPath;

    @Autowired
    private BatchDataHolder batchDataHolder;

    @Inject
    DateFactory dateFactory;

    @Inject
    MDB0002Repository mdb0002Repository;

    @Inject
    MDB0002DataCopyRepository mainDataCopyRepository;

    /*
     * 仕様メモ
     * ・NGフォルダにファイルがあってもファイル取込を実行する
     * ・終了判定の判定条件はmdb0007と同じく全てExecutedになっていることとする(後でtempフォルダにファイルがないことを追加する)
     * ・成功判定はmdb0002の実行単位で実施する
     * ・成功判定条件1：対象のジョブの実行結果が全てCOMPLETEDになっていること
     * ・成功判定条件2：NGフォルダにシステム時間に紐づくファイル名がそんざいしないこと
     *
     * ・成功判定結果が成功だった場合、tmepテーブルの内容を本体テーブルへミラーリング
     * ・成功判定結果が失敗だった場合、本体テーブルの内容をtempテーブルへミラーリング
     */

    /**
     *
     * ミラーリング処理
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return 一括で各ジョブを実行した状態
     */
    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {
        try {
            // 前のステップでエラーが発生している場合
            if (!batchDataHolder.isCheckResult()) {
                throw new RuntimeException("前のステップでエラーが発生しています。");
            }
            String jobStartDateTimeStr = batchDataHolder.getSystemDateTime();
            LocalDateTime jobStartDateTime = LocalDateTime.parse(jobStartDateTimeStr, dtf4);
            String fileSystemDateTime = jobStartDateTime.format(dtf);

            // 差分取込処理が全て完了している場合
            if (checkAllSapJobCompleted(jobStartDateTimeStr)) {
                // NGファイルが存在しない場合
                if (isExistNG(getFileName(errorDirPath), fileSystemDateTime)) {
                    // TEMPの情報を本体に書き込む
                    dataCopy(TEMP_TO_MAIN);
                    return RepeatStatus.FINISHED;
                }
            }
        } catch (Exception e) {
            logger.error("処理結果:{}の実行時に、異常が発生しました。", "SAP連携");
            logger.error("stackTrace：", e);
        }
        /*
         * 以下の場合に当てはまる場合は本体の情報をTEMPに書き込む
         * ・なんらかのシステムエラーが発生した場合
         * ・NGファイルが存在した場合
         * ・時間内に差分取込が終わらなかった場合
         */
        dataCopy(MAIN_TO_TEMP);
        batchDataHolder.setCheckResult(false);
        return RepeatStatus.FINISHED;
    }

    /**
     * SAP取込完了確認
     *
     * @param jobStartDateTimeStr メインjob開始日時
     *
     * @return true:全てが完了している、false:いずれかが完了していない、1時間経過しても終了していないjobがある
     * @throws InterruptedException threadに割り込みがあった場合等
     */
    private boolean checkAllSapJobCompleted(String jobStartDateTimeStr) throws InterruptedException {
        // 差分連携取込のjobIDのリストを生成
        List<String> jobIds = setJobNames();
        LocalDateTime stepStartDateTime = dateFactory.newDateTime();
        while (true) {
            // 5秒待機
            Thread.sleep(5000);

            // 全取込処理のjobの終了確認のために、メインjobの起動時間を条件に検索し、まだ終了していないjob件数を取得する
            int notExecutedJobCount = mdb0002Repository.countAllNotExecuted(jobIds, jobStartDateTimeStr);

            // countが0 =全て終了
            if (notExecutedJobCount == 0) {
                // 完了していないジョブの件数を取得
                int notCompletedJobCount = mdb0002Repository.countAllNotCompleted(jobIds, jobStartDateTimeStr);

                if (notCompletedJobCount == 0) {
                    return true;
                }
                logger.info("いずれかのSAP差分連携取込処理に異常がありました。");
                return false;
            }

            LocalDateTime systemDateTime = dateFactory.newDateTime();
            if (systemDateTime.isAfter(stepStartDateTime.plusMinutes(10))) {
                // 現在日時がこのjobの起動から10分以上経過している場合はエラーとする
                logger.info("SAP差分連携取込処理が10分待機しても終了しないため、待機を終了する");
                return false;
            }
            // 現在日時がこのstepの起動から10分経過していない場合は5秒待機し、再度取込処理の終了確認を実施する
            logger.info("まだ全ての差分連携ファイル取込処理が終了していないため、5秒間待機します。");
        }
    }

    private List<String> setJobNames() {
        List<String> resultList = new ArrayList<>();

        resultList.add(VENDOR_DIF_JOB_NAME);
        resultList.add(PROJECT_DIF_ATTRIBUTE_JOB_NAME);
        resultList.add(PROJECT_DIF_JOB_NAME);

        return resultList;
    }

    private String[] getFileName(String path) {
        File file = new File(path);
        String[] fileName = file.list();
        return fileName;
    }

    private boolean isExistNG(String[] fileNames, String fileSystemDateTime) {

        if (fileNames == null || fileNames.length == 0) {
            return true;
        }

        int targetLength = fileSystemDateTime.length();
        // 引数fileSystemDateTimeが含まれるファイル名が存在する場合はエラーとする
        for (String name : fileNames) {
            if (name.length() >= 18 && name.substring(0, targetLength).equals(fileSystemDateTime)) {
                logger.info("errorフォルダに{}に実行したファイルが存在します。", fileSystemDateTime.substring(0, targetLength - 1));
                return false;
            }
        }
        return true;
    }

    private void dataCopy(boolean isTempToMain) {
        if (isTempToMain) {
            logger.info("TEMPテーブルの情報を本体テーブルへ書き込みます。");
            // fwb0111Job 仕入先マスタ（一定時間間隔）
            mainDataCopyRepository.dataCopy("temp_sap_ma_vendor", "SAPVendor");
            mainDataCopyRepository.dataCopyOjMaVendor();

            // fwb0112Job プロジェクト属性（一定時間間隔）
            mainDataCopyRepository.dataCopy("temp_sap_project", "SAPProject");
            mainDataCopyRepository.dataCopy("temp_project_attribute", "project_attribute");

            // fwb0113Job プロジェクト個別（一定時間間隔）
            mainDataCopyRepository.dataCopy("temp_sap_project_attribute", "SAPProjectAttribute");
            mainDataCopyRepository.dataCopy("temp_project", "project");
        } else {
            logger.info("本体テーブルの情報をTEMPテーブルへ書き込みます。");
            // fwb0111Job 仕入先マスタ（一定時間間隔）
            mainDataCopyRepository.dataCopy("SAPVendor", "temp_sap_ma_vendor");
            mainDataCopyRepository.dataReverseCopyOjMaVendor();

            // fwb0112Job プロジェクト属性（一定時間間隔）
            mainDataCopyRepository.dataCopy("SAPProject", "temp_sap_project");
            mainDataCopyRepository.dataCopy("project_attribute", "temp_project_attribute");

            // fwb0113Job プロジェクト個別（一定時間間隔）
            mainDataCopyRepository.dataCopy("SAPProjectAttribute", "temp_sap_project_attribute");
            mainDataCopyRepository.dataCopy("project", "temp_project");
        }
    }
}
