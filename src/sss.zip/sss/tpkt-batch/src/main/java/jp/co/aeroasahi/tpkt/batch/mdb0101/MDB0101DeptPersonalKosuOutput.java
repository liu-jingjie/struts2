package jp.co.aeroasahi.tpkt.batch.mdb0101;

import java.math.BigDecimal;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.batch.item.ItemCountAware;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】部門別社員工数＞のOutputBean。
 */
@Setter
@Getter
public class MDB0101DeptPersonalKosuOutput implements ItemCountAware {

    private int count;

    /** 部門CD */
    @NotBlank
    @Size(min = 1, max = 6)
    private String deptCd;

    /** 年月 */
    @NotBlank
    @Size(min = 1, max = 6)
    private String ym;

    /** 社員区分 */
    @NotBlank
    @Size(min = 1, max = 1)
    private String empKbn;

    /** 社員CD */
    @NotBlank
    @Size(min = 1, max = 5)
    private String empCd;

    /** 合計工数 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal totalKosu;

    /** 作成日 */
    @Size(min = 23, max = 23)
    private String createdAt;

    /** 更新日 */
    @Size(min = 23, max = 23)
    private String updatedAt;

    /**
     * 部門CDと年月と社員区分と社員CDを結合する
     * @return
     */
    public String concat() {
        return deptCd + "," + ym + "," + empKbn + "," + empCd;
    }

    @Override
    public void setItemCount(int count) {
        this.count = count;
    }
}
