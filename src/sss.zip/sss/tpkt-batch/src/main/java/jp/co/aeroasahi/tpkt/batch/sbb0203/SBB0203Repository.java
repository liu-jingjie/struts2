package jp.co.aeroasahi.tpkt.batch.sbb0203;

import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 * 積算実績登録
 */
public interface SBB0203Repository {

    /**
     * 発生原価を取得する。
     *
     * @return 発生原価リスト
     */
    List<SBB0203SapCost> findSAPCost();


    /**
     * 積算基本情報を更新
     *
     * @param item 発生原価
     */
    void updateSBBaseInfo(@Param("item") SBB0203SapCost item);

}
