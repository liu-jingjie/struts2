package jp.co.aeroasahi.tpkt.batch.mdb0004;

import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 * ジョブについてテーブルに操作
 */
public interface MDB0004Repository {

    /**
     * テーブル＜ジョブ要求テーブル＞に登録する。
     *
     * @param input BatchJobRequestInput
     * @return
     */
    void create(BatchJobRequestInput batchJobRequestInput);

    /**
     * 条件によって、テーブル＜ジョブ要求テーブル＞の情報を取得する
     *
     * @param number 検索件数
     * @param systemDateTime システム時間
     *
     * @return ジョブ要求リスト
     */
    List<BatchJobRequestOutput> findByTopNum(@Param("number") int number, @Param("systemDateTime") String systemDateTime);

    /**
     * 条件によって、テーブル＜ジョブ異常テーブル＞の情報を取得する
     *
     * @param executionIds ジョブ実行開始ID
     *
     * @return ジョブ異常リスト
     */
     List<BatchJobExecutionOutput> findByExecutionIds(@Param("executionIds") List<Integer> executionIds);
}
