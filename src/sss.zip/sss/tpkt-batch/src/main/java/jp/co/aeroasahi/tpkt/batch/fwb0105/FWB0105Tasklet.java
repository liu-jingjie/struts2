package jp.co.aeroasahi.tpkt.batch.fwb0105;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.inject.Inject;
import javax.inject.Named;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ItemStreamReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.validator.ValidationException;
import org.springframework.batch.item.validator.Validator;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.fw.CommonLog;
import jp.co.aeroasahi.tpkt.batch.util.CommonUtils;

@Component
@Scope("step")
public class FWB0105Tasklet implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(FWB0105Tasklet.class);

    /** DateTimeFormatterのパターン uuuuMMdd_HHmmssSSS_ */
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("uuuuMMdd_HHmmssSSS_");

    /** DateTimeFormatterのパターン uuuu-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf4 = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.SSS");

    /** 勘定明細のパス */
    private static final String DIRECTORY_PATH = "AccountDetail/";

    /** 勘定明細のファイル */
    private static final String FILE_NAME = "SATP0005.txt";

    /** ファイルバックアップ先（取込が正常に行われた場合） */
    @Value("${sap.output.dirpath}")
    String outputDirPath;

    /** ファイルバックアップ先（取込で異常が発生した場合） */
    @Value("${sap.error.dirpath}")
    String errorDirPath;

    @Value("#{jobParameters['inputFile']}")
    public String inputFile;

    @Value("#{jobParameters['systemDateTime']}")
    public String systemDateTime;

    @Inject
    @Named("reader")
    ItemStreamReader<FWB0105Input> reader;

    @Inject
    ItemWriter<FWB0105Output> writer;

    @Inject
    ItemWriter<FWB0105Output> delete;

    @Inject
    Validator<FWB0105Output> validator;


    @Inject
    FWB0105Repository mdb0105Repository;

    boolean isErrFlag = false;

    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        String fileSystemDateTime = LocalDateTime.parse(systemDateTime, dtf4).format(dtf);

        String[] tableItemKeys = new String[] {"BUKRS", "BELNR", "GJAHR", "MONAT", "BUDAT", "RBUKRS", "HKONT", "PRCTR",
                "PROJK", "EBELN", "ABLAD", "WEMPF", "ZFBDT", "DMBTR", "INS_DT", "UPD_DT"};
        String[] tableItemNames = new String[] {"会社コード", "伝票番号", "会計年度", "会計期間", "転記日付", "請求書伝票番号", "勘定コード", "部門",
                "プロジェクトID", "発注番号", "申請番号", "委託先枝番", "支払予定日", "金額", "作成日", "更新日"};
        Map<String, String> tableItemInfo = new HashMap<String, String>();
        for (int i = 0; i < tableItemKeys.length; i++) {
            tableItemInfo.put(tableItemKeys[i], tableItemNames[i]);
        }

        List<FWB0105Output> outItems = setItemOutput(chunkContext);

        if (!isErrFlag) {
            for (int i = 0; i < outItems.size(); i++) {
                try {
                    validator.validate(outItems.get(i));
                } catch (ValidationException e) {
                    isErrFlag = true;
                    CommonLog.setFromFileErrorLog(logger, e, tableItemInfo, inputFile, i);
                }
            }

            if (!isErrFlag) {
                try {
                    try {
                        delete.write(outItems);
                    } catch (EmptyResultDataAccessException e) {
                        // logger.error("削除対象が0件でした。");
                    }
                    writer.write(outItems);
                    CommonLog.setInsertRecordeCountLog(logger, "【TEMP】SAP勘定明細(temp_sap_account_detail)",
                            outItems.size());
                } catch (Exception e) {
                    isErrFlag = true;
                    logger.error("stackTrace：", e);
                }
            } else {
                logger.error("入力データでエラーが発生しました。");
            }
            outItems.clear();
        }
        System.gc();
        if (isErrFlag) {
            // 正常に取り込めなかった場合はtempフォルダに格納されているファイルをerrorフォルダへ移動させる
            try {
                CommonUtils.fileMove(inputFile, errorDirPath + fileSystemDateTime + FILE_NAME);
            } catch (IOException e) {
                logger.error(FILE_NAME + "のtempフォルダからerrorフォルダへのファイル移動に失敗しました。");
                logger.error("stackTrace：", e);
            }
            throw new RuntimeException("fwb0109発注番号データ取込実行に異常が発生しました。");
        }

        // 正常に取り込めた場合はtempフォルダに格納されているファイルをoutputフォルダへ移動させる
        CommonUtils.fileMove(inputFile, outputDirPath + DIRECTORY_PATH + fileSystemDateTime + FILE_NAME);

        return RepeatStatus.FINISHED;
    }

    private List<FWB0105Output> setItemOutput(ChunkContext chunkContext) {

        List<FWB0105Output> outputItems = new ArrayList<>();

        FWB0105Input itemInput = null;
        FWB0105Output itemOutput = null;
        boolean firstFlag = true;

        try {
            reader.open(chunkContext.getStepContext().getStepExecution().getExecutionContext());
            do {
                itemInput = reader.read();

                // 1行目(ヘッダ行)の場合は、ヘッダ判定用のフラグを降ろして次の行へ
                if (firstFlag) {
                    firstFlag = false;
                    continue;
                }

                // 行が読み込めなかったらファイルの読込処理を終了する
                if (itemInput == null) {
                    break;
                }
                itemOutput = new FWB0105Output();
                // 会社コード-BUKRS
                itemOutput.setBUKRS(itemInput.getBUKRS());

                // 伝票番号-BELNR
                itemOutput.setBELNR(itemInput.getBELNR());

                // 会計年度-GJAHR
                itemOutput.setGJAHR(itemInput.getGJAHR());

                // 会計期間-MONAT
                itemOutput.setMONAT(itemInput.getMONAT());

                // 転記日付-BUDAT
                itemOutput.setBUDAT(getTimestamp(itemInput.getBUDAT()));

                // 請求書伝票番号-RBUKRS
                itemOutput.setRBUKRS(itemInput.getRBUKRS());

                // 勘定コード-HKONT
                itemOutput.setHKONT(itemInput.getHKONT());

                // 部門-PRCTR
                itemOutput.setPRCTR(itemInput.getPRCTR());

                // プロジェクトID-PROJK
                itemOutput.setPROJK(itemInput.getPROJK().equals("") ? "############" : itemInput.getPROJK());

                // 発注番号-EBELN
                itemOutput.setEBELN(itemInput.getEBELN());

                // 申請番号-ABLAD
                itemOutput.setABLAD(itemInput.getABLAD());

                // 委託先枝番-WEMPF
                itemOutput.setWEMPF(itemInput.getWEMPF());

                // 支払予定日-ZFBDT
                itemOutput.setZFBDT(getTimestamp(itemInput.getZFBDT()));

                // 金額-DMBTR
                itemOutput.setDMBTR(getBigDecimal(itemInput.getDMBTR()));

                // 作成日-INS_DT
                itemOutput.setINS_DT(systemDateTime);

                // 更新日-UPD_DT
                itemOutput.setUPD_DT(systemDateTime);

                outputItems.add(itemOutput);
            } while (itemInput != null);

        } catch (Exception e) {
            isErrFlag = true;
            logger.error("stackTrace：", e);
        } finally {
            try {
                reader.close();
            } catch (Exception e) {
                isErrFlag = true;
                logger.error("stackTrace：", e);
            }
        }

        return outputItems;
    }

    private String getTimestamp(String inputString) {

        String rtn = "";
        String str = " 00:00:00.000";
        if (inputString.length() == 10) {
            rtn = inputString.replaceAll("/", "-") + str;

        } else {
            rtn = inputString.replaceAll("/", "-");
        }
        return rtn;
    }

    private BigDecimal getBigDecimal(String inputString) {

        BigDecimal rtn = new BigDecimal("0");
        String replaceedStr = inputString.replaceAll(",", "");

        if (!replaceedStr.isEmpty()) {
            rtn = new BigDecimal(replaceedStr);
        } else {
            rtn = null;
        }
        return rtn;
    }
}
