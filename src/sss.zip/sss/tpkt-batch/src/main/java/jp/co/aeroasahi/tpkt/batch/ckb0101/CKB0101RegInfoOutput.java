package jp.co.aeroasahi.tpkt.batch.ckb0101;

import org.springframework.batch.item.ItemCountAware;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜PJID別登録状況＞のOutputBean。
 */
@Setter
@Getter
public class CKB0101RegInfoOutput implements ItemCountAware {

    private int count;

    /** プロジェクトID */
    private String pjId;

    /** 帳票種別 */
    private String docType;

    /** ファイルパス */
    private String filePath;

    /** ファイル名 */
    private String fileName;

    /** 作成日 */
    private String createdAt;

    @Override
    public void setItemCount(int count) {
        this.count = count;
    }
}
