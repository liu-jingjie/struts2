package jp.co.aeroasahi.tpkt.batch.fw;

import javax.sql.DataSource;
import org.springframework.batch.core.jsr.JsrJobParametersConverter;
import org.springframework.batch.item.database.support.DataFieldMaxValueIncrementerFactory;
import org.springframework.batch.item.database.support.DefaultDataFieldMaxValueIncrementerFactory;
import org.springframework.batch.support.DatabaseType;
import org.springframework.jdbc.support.incrementer.AbstractColumnMaxValueIncrementer;

public class SimosJsrJobParametersConverter extends JsrJobParametersConverter {

    public SimosJsrJobParametersConverter(DataSource dataSource) {
        super(dataSource);
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        DataFieldMaxValueIncrementerFactory factory = new DefaultDataFieldMaxValueIncrementerFactory(dataSource);

        this.incremeter = factory.getIncrementer(DatabaseType.fromMetaData(dataSource).name(), tablePrefix + "JOB_SEQ");
        if (this.incremeter instanceof AbstractColumnMaxValueIncrementer) {
            ((AbstractColumnMaxValueIncrementer) this.incremeter).setCacheSize(100);
        }
    }

}
