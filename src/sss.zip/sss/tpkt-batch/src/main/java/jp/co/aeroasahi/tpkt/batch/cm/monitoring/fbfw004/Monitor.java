package jp.co.aeroasahi.tpkt.batch.cm.monitoring.fbfw004;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import jp.co.aeroasahi.tpkt.common.util.DateUtil;

public class Monitor {

    /** Webのログ文字列をタブで区切った際の要素数 */
    private static final int WEB_LOGBACK_ELEMENT_NUM = 6;
    /** Batchのログ文字列をタブで区切った際の要素数 */
    private static final int BATCH_LOGBACK_ELEMENT_NUM = 5;
    /** web監視ログファイルパス */
    private Path webLogFilePath;
    /** バッチ監視ログファイルパス */
    private Path batchLogFilePath;

    /**
     * ファイルパスを指定し、対象のログファイルから新規のエラー情報を抽出する
     *
     * @param webLogFile WebApの監視ログファイルパス
     * @param batLogFile batの監視ログファイルパス
     * @param cimLogFile cimの監視ログファイルパス
     */
    public Monitor(String webLogFilePathStr, String batchLogFilePathStr) {
        this.webLogFilePath = Paths.get(webLogFilePathStr);
        this.batchLogFilePath = Paths.get(batchLogFilePathStr);
    }

    /**
     * 指定した日時以降に出力された情報を抽出する
     * <p>
     * 以下をそれぞれのパス毎に実施する<br>
     * ・指定されたパスのファイルの中身を文字列型のリストで取得<br>
     * ・最終完了日時よりも未来の行のみを抽出<br>
     * ・各行に対して、ログの種類と日時部分とメッセージ部分を抽出し、結合する(例： Web uuuuMMdd メッセージ)
     * </p>
     *
     * @param lastCompleteDateTime 最終完了日時
     * @return 指定した日時以降に出力されたログ情報の日時とメッセージ部
     * @throws IOException ファイルパスが誤っていた場合
     */
    public List<String> monitor(LocalDateTime lastCompleteDateTime) throws IOException {
        List<String> resultList = new ArrayList<>();

        // webの監視ログから抽出
        List<String> webFilteredMonitoringLogStrs = fetchFilteredMonitoringLogStrs(webLogFilePath, lastCompleteDateTime);
        if (webFilteredMonitoringLogStrs != null && webFilteredMonitoringLogStrs.size() != 0) {
            resultList.addAll(webFilteredMonitoringLogStrs);
        }

        // バッチの監視ログから抽出
        List<String> batchFilteredMonitoringLogStrs = fetchFilteredMonitoringLogStrs(batchLogFilePath, lastCompleteDateTime);
        if (batchFilteredMonitoringLogStrs != null && batchFilteredMonitoringLogStrs.size() != 0) {
            resultList.addAll(batchFilteredMonitoringLogStrs);
        }

        // 結果を返却
        return resultList;
    }

    private List<String> fetchFilteredMonitoringLogStrs(Path logFilePath, LocalDateTime lastCompleteDateTime)
            throws IOException {
        List<String> logStrList = Files.readAllLines(logFilePath, Charset.forName("MS932"));

        // ファイルの行数が0の場合は監視処理を中断し、nullを返却する
        if (logStrList != null && logStrList.size() == 0) {
            return null;
        }

        List<String> filteredList;
        if (lastCompleteDateTime == null) {
            // 最終完了日時が存在しない場合は、特定部分が日時にparseできることを条件にフィルタリング
            filteredList = filterByParseDateTime(logStrList);
        } else {
            // 最終完了日時がDBに存在する場合は、最終完了日時以降の情報のみを取得する
            filteredList = filterBylastcompleteDateTime(logStrList, lastCompleteDateTime);
        }

        // 余計な行を日時とスレッドを条件にグルーピングすることで取り除く
        return groupingByDateTimeAndThread(filteredList);
    }

    private List<String> filterBylastcompleteDateTime(List<String> monitoringLogList,
            LocalDateTime lastCompleteDateTime) {
        // 日時部分(5～24文字目部分)がperse出来る、更新日時より未来、という2段階でフィルタリング

        return monitoringLogList.stream()
                .filter(each -> canParseDateTime(each))
                .filter(e -> parseDateTimeOfLogStr(e).isAfter(lastCompleteDateTime))
                .collect(Collectors.toList());
    }

    private List<String> filterByParseDateTime(List<String> targetList) {
        List<String> resultList = new ArrayList<>();
        // 日時部分(5～24文字目部分)がperse出来ることを条件とし、フィルタリング
        for (String each : targetList) {
            try {
                DateUtil.parseDateTime(each.substring(5, 24));
                resultList.add(each);
            } catch (StringIndexOutOfBoundsException | DateTimeParseException e) {
                continue;
            }
        }
        return resultList;
    }

    private boolean canParseDateTime(String eachStr) {
        // 行単位のログ文字列の中から日時部分を切り出して日時型で返却
        try {
            DateUtil.parseDateTime(eachStr.substring(5, 24));
            return true;
        } catch (StringIndexOutOfBoundsException | DateTimeParseException e) {
            return false;
        }
    }

    private LocalDateTime parseDateTimeOfLogStr(String eachStr) {
        // 行単位のログ文字列の中から日時部分を切り出して日時型で返却
        return DateUtil.parseDateTime(eachStr.substring(5, 24));
    }

    private List<String> groupingByDateTimeAndThread(List<String> filteredList) {
        String tempStr = "";
        List<String> resultlist = new ArrayList<>();
        for (String each : filteredList) {
            if (tempStr.equals("")) {
                // 1行目(tempが空文字)の場合は比較を実施せず、そのままresultに追加
                tempStr = getKeyStr(each);
                resultlist.add(getMessageStr(each));
                continue;
            }

            // ログ文字列から日時部分とスレッド部分のみを取得
            String targetStr = getKeyStr(each);

            // 文字列が一致しない(別のエラーを検知した)場合、resultに追加
            if (!targetStr.equals(tempStr)) {
                resultlist.add(getMessageStr(each));
            }
            // 次の行と比較するために、文字列をtempStrに格納
            tempStr = targetStr;
        }

        return resultlist;
    }

    private String getKeyStr(String target) {
        String[] targetArray = target.split("\t");
        // 配列の要素0：日時と要素1：スレッドを結合して返却
        return targetArray[0].substring(5, 24) + targetArray[1].substring(1, targetArray[1].length() - 1);
    }

    private String getMessageStr(String target) {
        // 日時とメッセージを結合して返却
        String[] targetArray = target.split("\t");

        if (targetArray.length == WEB_LOGBACK_ELEMENT_NUM) {
            return targetArray[0].substring(5, 24) + "：" + targetArray[WEB_LOGBACK_ELEMENT_NUM - 1];
        }
        return targetArray[0].substring(5, 24) + "：" + targetArray[BATCH_LOGBACK_ELEMENT_NUM - 1];
    }
}
