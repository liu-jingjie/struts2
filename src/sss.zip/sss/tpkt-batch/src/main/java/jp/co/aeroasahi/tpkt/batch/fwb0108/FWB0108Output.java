package jp.co.aeroasahi.tpkt.batch.fwb0108;

import java.math.BigDecimal;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.batch.item.ItemCountAware;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】SAP受注＞のOutputBean。
 */
@Setter
@Getter
public class FWB0108Output implements ItemCountAware {

    private int count;

    /** 受注伝票番号 */
    @NotBlank
    @Size(min = 1, max = 10)
    private String VBELN;

    /** 得意先コード */
    @Size(min = 0, max = 10)
    private String KUNNR;

    /** プロジェクトID */
    @Size(min = 0, max = 12)
    private String PS_PSP_PNR;

    /** 受注日 */
    @Size(min = 0, max = 23)
    private String AUDAT;

    /** 受注明細番号 */
    @NotBlank
    @Size(min = 1, max = 6)
    private String POSNR;

    /** 受注金額（税抜き） */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal NETWR;

    /** 売上予定日 */
    @Size(min = 0, max = 23)
    private String FKDAT;

    /** 積算原価額 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal ZSEKISANA3;

    /** 個人情報 */
    @Size(min = 0, max = 2)
    private String ZKOJIN;

    /** 高原価・政策受注フラグ */
    @Size(min = 0, max = 1)
    private String ZKOUFLAG;

    /** 受注申請時積算原価率 */
    @DecimalMin("-9999.9")
    @DecimalMax("9999.9")
    private BigDecimal ZSEKISANR3;

    /** 作成日 */
    @Size(min = 23, max = 23)
    private String INS_DT;

    /** 更新日 */
    @Size(min = 23, max = 23)
    private String UPD_DT;

    @Override
    public void setItemCount(int count) {
        this.count = count;
    }

    /**
     * 受注伝票番号と受注明細番号を結合する
     * @return
     */
    public String concat() {
        return VBELN + "," + POSNR;
    }
}
