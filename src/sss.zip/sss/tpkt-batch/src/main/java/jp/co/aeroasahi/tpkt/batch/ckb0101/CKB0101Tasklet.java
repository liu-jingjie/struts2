package jp.co.aeroasahi.tpkt.batch.ckb0101;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.inject.Inject;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;
import jp.co.aeroasahi.tpkt.common.fw.message.MessageSharedService;

/**
 *
 * 帳票登録状況一覧の作成
 * 指定のファイルパスから帳票の一覧を取得し
 * 品質記録管理帳票マスタ&プロジェクトTBLのデータより
 * それぞれの帳票管理用データを作成する
 *
 *
 */
@Component
@Scope("step")
public class CKB0101Tasklet implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(CKB0101Tasklet.class);

    @Inject
    DateFactory dateFactory;

    @Value("${ckb0101.filepath}")
    String filePath;

    @Value("${ckb0101.filter}")
    String fileFilter;

    @Value("${file.serverpath}")
    String serverPath;

    @Value("${file.disk}")
    String disk;

    @Inject
    CKB0101Repository ckb0101Repository;

    @Inject
    MessageSharedService messageService;

    /** ジョブID */
    private static final String JOB_ID = "ckb0101";

    /** DateTimeFormatterのパターン yyyy-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dateTimeFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    /** DateFormatterのパターン yyyy-MM-dd */
    private static final DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    /** Pj別帳票登録状況(-)なし */
    private static final String pjNoRegster = "0";

    /** Pj別帳票登録状況(○)あり */
    private static final String pjRegster = "1";

    /** 帳票登録状況(×) */
    private static final String noRegster = "0";

    /** 帳票登録状況(△) */
    private static final String regster = "1";

    /** 帳票登録状況(〇) */
    private static final String partRegster = "2";

    /** 初回受注 */
    private static final String firstOrder = "1";

    /** 初回売上 */
    private static final String firstSale = "2";

    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {


        // システム日を作成
        String sysdate = dateFactory.newDate().format(dateFormat);

        // システム日時を作成
        String sysdatetime = dateFactory.newDateTime().format(dateTimeFormat);

        // 品質記録管理帳票マスタのデータを取得
        List<CKB0101QualityRecordDocInput> qualityRecordDoc = ckb0101Repository.findQualityRecordDoc();

        if (CollectionUtils.isEmpty(qualityRecordDoc)) {
            logger.error(messageService.getMessage("e.bat.ck.001", JOB_ID, "品質記録管理帳票マスタデータの取得"));

            throw new RuntimeException(messageService.getMessage("e.bat.ck.002", JOB_ID, "品質記録管理帳票マスタデータの取得"));
        }

        // 検索用MAP(帳票名,帳票タイプ)を作成
        Map<String, String> checkListMap =
                qualityRecordDoc.stream().collect(Collectors.toMap(CKB0101QualityRecordDocInput::getDocName,
                        CKB0101QualityRecordDocInput::getDocType));

        // １．フォルダ→リンク
        // 帳票登録情報TBL操作用Listを作成
        List<CKB0101RegInfoOutput> regInfoOutItems = this.setRegInfoItemOutput(checkListMap, sysdatetime);

        try {
            // 帳票登録情報を削除
            logger.info(messageService.getMessage("i.bat.fw.001", JOB_ID, "帳票登録情報の削除"));
            ckb0101Repository.truncateTable("ck_doc_reg_info");
            logger.info(messageService.getMessage("i.bat.fw.002", JOB_ID, "帳票登録情報の削除"));

            // 帳票登録情報を登録
            logger.info(messageService.getMessage("i.bat.fw.001", JOB_ID, "帳票登録情報の登録"));

            for (CKB0101RegInfoOutput regInfoOutItem : regInfoOutItems) {
                ckb0101Repository.createRegInfo(regInfoOutItem);
            }

            logger.info(messageService.getMessage("i.bat.fw.002", JOB_ID, "帳票登録情報の登録"));

            // PjIdより対象外の帳票登録情報を削除
            logger.info(messageService.getMessage("i.bat.fw.001", JOB_ID, "帳票登録情報の削除"));
            ckb0101Repository.deleteDocRegInfoByPjid();
            logger.info(messageService.getMessage("i.bat.fw.002", JOB_ID, "帳票登録情報の削除"));

        } catch (Exception e) {
            logger.error(messageService.getMessage("e.bat.ck.001", JOB_ID, "フォルダ→リンク"));
            logger.error(messageService.getMessage("e.bat.ck.002", JOB_ID, "フォルダ→リンク"));

            throw new RuntimeException(e);
        }

        // 帳票登録日情報TBL操作用Listを作成
        List<CKB0101RegDateInfoOutput> regDateInfoOutItems =
                this.setRegDateInfoItemOutput(regInfoOutItems, sysdate, sysdatetime);
        try {
            // 帳票登録日情報を登録
            logger.info(messageService.getMessage("i.bat.fw.001", JOB_ID, "帳票登録日情報の登録"));
            if (!CollectionUtils.isEmpty(regDateInfoOutItems)) {
                for (CKB0101RegDateInfoOutput regDateInfoOutItem : regDateInfoOutItems) {
                    ckb0101Repository.createRegDateInfo(regDateInfoOutItem);
                }
            }
            logger.info(messageService.getMessage("i.bat.fw.002", JOB_ID, "帳票登録日情報の登録"));

        } catch (Exception e) {
            logger.error(messageService.getMessage("e.bat.ck.001", JOB_ID, "フォルダ→リンク"));
            logger.error(messageService.getMessage("e.bat.ck.002", JOB_ID, "帳票登録日情報"));
            throw new RuntimeException(e);
        }

        // ２．PJID別登録状況更新
        try {
            // PJID別登録状況を削除
            logger.info(messageService.getMessage("i.bat.fw.001", JOB_ID, "PJID別登録状況の削除"));
            ckb0101Repository.truncateTable("ck_doc_reg_status_pj");
            logger.info(messageService.getMessage("i.bat.fw.002", JOB_ID, "PJID別登録状況の削除"));

            // PJID別登録状況を登録
            logger.info(messageService.getMessage("i.bat.fw.001", JOB_ID, "PJID別登録状況の登録"));
            ckb0101Repository.createRegStsPj(sysdatetime);
            logger.info(messageService.getMessage("i.bat.fw.002", JOB_ID, "PJID別登録状況の登録"));

            // PJID別登録状況を更新
            logger.info(messageService.getMessage("i.bat.fw.001", JOB_ID, "PJID別登録状況の更新"));
            ckb0101Repository.updateRegStsPj(sysdatetime);
            logger.info(messageService.getMessage("i.bat.fw.002", JOB_ID, "PJID別登録状況の更新"));

        } catch (Exception e) {
            logger.error(messageService.getMessage("e.bat.ck.001", JOB_ID, "PJID別登録状況更新"));
            logger.error(messageService.getMessage("e.bat.ck.002", JOB_ID, "PJID別登録状況更新"));
            throw new RuntimeException(e);
        }

        // ３．BU+PJ属性別帳票登録状況
        // BU+PJ属性別帳票登録状況に登録するためのレコードを取得
        List<CKB0101RegStsBuPjInput> buPjInsertTargets = ckb0101Repository.findAllInsertTarget();

        try {
            // BU+PJ属性別帳票登録状況を削除
            logger.info(messageService.getMessage("i.bat.fw.001", JOB_ID, "BU+PJ属性別登録状況の削除"));
            ckb0101Repository.truncateTable("ck_doc_reg_status_bu");
            logger.info(messageService.getMessage("i.bat.fw.002", JOB_ID, "BU+PJ属性別登録状況の削除"));

            // BU+PJ属性別帳票登録状況に取得したレコードを1行ずつ加工し、登録する
            logger.info(messageService.getMessage("i.bat.fw.001", JOB_ID, "BU+PJ属性別帳票登録状況の登録"));
            createBuPjRegStatusInfo(buPjInsertTargets, sysdatetime);
            logger.info(messageService.getMessage("i.bat.fw.002", JOB_ID, "BU+PJ属性別帳票登録状況の登録"));

        } catch (Exception e) {
            logger.error(messageService.getMessage("e.bat.ck.001", JOB_ID, "BU+PJ属性別帳票登録状況"));
            logger.error(messageService.getMessage("e.bat.ck.002", JOB_ID, "BU+PJ属性別帳票登録状況"));

            throw new RuntimeException(e);

        }

        // ４．未登録状況更新
        // 未登録状況操作用Listを作成
        List<CKB0101UnregStatusOutput> ｑualityRecordDocOutItems =
                this.setQualityRecordDocItemOutput(sysdate, sysdatetime);

        try {
            // 未登録状況を削除
            logger.info(messageService.getMessage("i.bat.fw.001", JOB_ID, "未登録状況の削除"));
            ckb0101Repository.truncateTable("ck_doc_unreg_status");
            logger.info(messageService.getMessage("i.bat.fw.002", JOB_ID, "未登録状況の削除"));

            // 未登録状況を登録
            logger.info(messageService.getMessage("i.bat.fw.001", JOB_ID, "未登録状況の登録"));
            if (!CollectionUtils.isEmpty(ｑualityRecordDocOutItems)) {
                for (CKB0101UnregStatusOutput ｑualityRecordDocOutItem : ｑualityRecordDocOutItems) {
                    ckb0101Repository.createUnregStatus(ｑualityRecordDocOutItem);
                }
            }
            logger.info(messageService.getMessage("i.bat.fw.002", JOB_ID, "未登録状況の登録"));

        } catch (Exception e) {
            logger.error(messageService.getMessage("e.bat.ck.001", JOB_ID, "未登録状況更新"));
            logger.error(messageService.getMessage("e.bat.ck.002", JOB_ID, "未登録状況更新"));

            throw new RuntimeException(e);
        }
        // ５．データ収集
        // EXCELファイルからデータを読込
        try {
            // Excelファイル格納パスなどの情報を取得
            logger.info(messageService.getMessage("i.bat.fw.001", JOB_ID, "Excelファイル格納パスなどの情報取得"));
            List<CKB0101ExcelInput> excelInputItems = ckb0101Repository.findExcelInfos();
            logger.info(messageService.getMessage("i.bat.fw.002", JOB_ID, "Excelファイル格納パスなどの情報取得"));

            List<CKB0101ExcelOutput> excelOutItems = this.setExcelItemOutput(excelInputItems, sysdatetime);

            // Excelデータを登録
            logger.info(messageService.getMessage("i.bat.fw.001", JOB_ID, "Excelデータの登録"));

            excelOutItems.stream().forEach(entry -> ckb0101Repository.updateProjectById(entry));

            logger.info(messageService.getMessage("i.bat.fw.002", JOB_ID, "Excelデータの登録"));

        } catch (Exception e) {
            logger.error(messageService.getMessage("e.bat.ck.001", JOB_ID, "Excelデータの登録"));
            logger.error(messageService.getMessage("e.bat.ck.002", JOB_ID, "Excelデータの登録"));

            throw new RuntimeException(e);
        }

        return RepeatStatus.FINISHED;
    }

    private List<CKB0101RegInfoOutput> setRegInfoItemOutput(Map<String, String> checkListMap, String sysdatetime) {

        List<CKB0101RegInfoOutput> outputItems = new ArrayList<>();

        // サーバからファイルリストを取得
        List<File> fileList = this.getServerFileList();

        if (!CollectionUtils.isEmpty(fileList)) {
            for (File tempFile : fileList) {
                // ファイルパスを取得
                String filePath = tempFile.getPath();
                // ファイル名を取得
                String fileName = tempFile.getName();
                // ファイルのネーミングルールを設定
                // [12桁]_[帳票名][自由文字列].[拡張子]
                String regrex = "^[0-9A-Z]{12}_.+";

                if (Pattern.matches(regrex, fileName)) {

                    int indexStart = fileName.indexOf("_");

                    int indexEnd = fileName.lastIndexOf(".");

                    if (indexStart == -1 || indexEnd == -1 || indexEnd < indexStart) {
                        continue;
                    }

                    String file = fileName.substring(indexStart + 1, indexEnd);
                    String[] nameContents = fileName.split("_");
                    for (Map.Entry<String, String> entry : checkListMap.entrySet()) {

                        // マスタTBLで存在する帳票名対象とする
                        if (nameContents.length > 0 && file.startsWith(entry.getKey())) {

                            CKB0101RegInfoOutput cbk0101RegInfoOutput = new CKB0101RegInfoOutput();

                            cbk0101RegInfoOutput.setPjId(nameContents[0]);
                            cbk0101RegInfoOutput.setFilePath(filePath.replace(disk, serverPath));
                            cbk0101RegInfoOutput.setFileName(fileName);
                            cbk0101RegInfoOutput.setDocType(entry.getValue());
                            cbk0101RegInfoOutput.setCreatedAt(sysdatetime);

                            outputItems.add(cbk0101RegInfoOutput);
                        }
                    }
                }
            }
        }

        return outputItems;
    }

    private List<File> getServerFileList() {

        // Defaultの「rootパス」と「拡張子Filter」を設定
        String rootFilePath = "";

        // 帳票のRootPathを取得
        if (!StringUtils.isEmpty(filePath)) {
            rootFilePath = filePath;
        }
        Path configFilePath = Paths.get(rootFilePath);

        String[] extensions;
        // 帳票の拡張子Filterを取得
        if (!StringUtils.isEmpty(fileFilter)) {
            extensions = fileFilter.split(",");
            // 取得できない場合、""を設定
        } else {
            extensions = new String[] {""};
        }

        // ファイルリストを作成する
        try (Stream<Path> pathStream = Files.walk(configFilePath)) {

            List<File> fileList = new ArrayList<>();
            pathStream.map(path -> path.toFile())
                    // ファイルのみ取得
                    .filter(file -> !file.isDirectory())
                    .filter(file -> {
                        boolean checkFlg = true;
                        if (extensions.length > 0) {
                            for (String extension : extensions) {
                                // 拡張子リストで設定された拡張子は対象外
                                if (file.getName().toLowerCase().endsWith(extension)) {
                                    checkFlg = false;
                                    break;
                                }
                            }
                        }
                        return checkFlg;
                    })
                    .forEach(fileList::add);

            return fileList;
        } catch (IOException e) {
            logger.error(messageService.getMessage("e.bat.ck.001", JOB_ID, "ファイル取得"));
            logger.error(messageService.getMessage("e.bat.ck.002", JOB_ID, "ファイル取得"));

            throw new RuntimeException(e);
        }
    }


    private List<CKB0101RegDateInfoOutput> setRegDateInfoItemOutput(List<CKB0101RegInfoOutput> regInfoOutItems,
            String sysdate, String sysdatetime) {
        logger.info(messageService.getMessage("i.bat.fw.001", JOB_ID, "帳票登録日情報の登録リスト作成"));

        List<CKB0101RegDateInfoOutput> outputItems = new ArrayList<>();

        // ファイルサーバーから取得したファイルの一覧から、
        // 重複を省いたファイル名のリストを取得する
        List<String> fileNameList = regInfoOutItems.stream()
                .map(CKB0101RegInfoOutput::getFileName)
                .distinct()
                .collect(Collectors.toList());

        // 帳票登録日情報TBLから取得したファイル
        List<CKB0101RegDateInfoOutput> tblFileName = ckb0101Repository.findRegDateInfo();

        // 帳票登録日情報TBLに対象のfile_nameがなかったら作成、あったら無視
        if (!CollectionUtils.isEmpty(tblFileName)) {
            fileNameList.removeAll(
                    tblFileName.stream()
                            .map(CKB0101RegDateInfoOutput::getFileName)
                            .collect(Collectors.toList()));
        }

        // 帳票登録日情報TBL登録用リスト作成
        if (!CollectionUtils.isEmpty(fileNameList)) {
            for (String fileName : fileNameList) {
                CKB0101RegDateInfoOutput ckb0101RegDateInfo = new CKB0101RegDateInfoOutput();
                ckb0101RegDateInfo.setFileName(fileName);
                ckb0101RegDateInfo.setRegedOn(sysdate);
                ckb0101RegDateInfo.setCreatedAt(sysdatetime);
                ckb0101RegDateInfo.setUpdatedAt(sysdatetime);

                outputItems.add(ckb0101RegDateInfo);
            }
        }
        logger.info(messageService.getMessage("i.bat.fw.002", JOB_ID, "帳票登録日情報の登録リスト作成"));

        return outputItems;
    }

    private void createBuPjRegStatusInfo(List<CKB0101RegStsBuPjInput> targets, String sysdatetime) {

        if (!CollectionUtils.isEmpty(targets)) {
            for (CKB0101RegStsBuPjInput orgCollectedInfo : targets) {
                // ×_判断用帳票登録状況（最大）
                String maxReqInfo = orgCollectedInfo.getMaxReqInfo();

                // △_判断用帳票登録状況（最小）
                String minRegStas = orgCollectedInfo.getMinRegStas();
                // △_判断用帳票登録状況（最大）
                String maxRegStas = orgCollectedInfo.getMaxRegStas();

                CKB0101RegStsBuPjOutput ckb0101RegStsBuPjOutput = new CKB0101RegStsBuPjOutput();
                ckb0101RegStsBuPjOutput.setBuPjAttId(orgCollectedInfo.getBuPjAttId());
                ckb0101RegStsBuPjOutput.setDocType(orgCollectedInfo.getDocType());
                ckb0101RegStsBuPjOutput.setOriginalReged(orgCollectedInfo.isOriginalReged());
                ckb0101RegStsBuPjOutput.setCreatedAt(sysdatetime);

                if (pjNoRegster.equals(maxReqInfo)) {
                    // 帳票登録状況_×を設定
                    ckb0101RegStsBuPjOutput.setDocRegStatus(noRegster);
                } else if (pjNoRegster.equals(minRegStas) && pjRegster.equals(maxRegStas)) {
                    // 帳票登録状況_△を設定
                    ckb0101RegStsBuPjOutput.setDocRegStatus(partRegster);
                } else {
                    // 帳票登録状況_〇を設定
                    ckb0101RegStsBuPjOutput.setDocRegStatus(regster);
                }
                ckb0101Repository.createBuPjRegStatusInfo(ckb0101RegStsBuPjOutput);
            }
        }

    }

    private List<CKB0101UnregStatusOutput> setQualityRecordDocItemOutput(String sysdate, String sysdatetime) {

        List<CKB0101UnregStatusOutput> outputItems = new ArrayList<>();

        // 各テーブルから＜未登録状況＞を取得する。
        List<CKB0101UnregStatusInput> unregStatusInfos = ckb0101Repository.findUnregStatus();
        SimpleDateFormat sysSdFormat = new SimpleDateFormat("yyyy-MM-dd");

        try {
            Date tmpSysDate = sysSdFormat.parse(sysdate);

            if (!CollectionUtils.isEmpty(unregStatusInfos)) {
                for (CKB0101UnregStatusInput unregStatusInfo : unregStatusInfos) {

                    // 未登録対象:null→非対象
                    if (StringUtils.isEmpty(unregStatusInfo.getUnregTarget())) {
                        continue;
                    }

                    // 登録日(初回受注日/初回売上日)を取得
                    String regDate = unregStatusInfo.getRegDate();
                    // 未登録対象確認日を取得
                    Integer unregTargetDate = unregStatusInfo.getUnregTargetDate();

                    if (StringUtils.isEmpty(regDate) || Objects.isNull(unregTargetDate)) {
                        continue;
                    }

                    // カレンダークラスのインスタンスを取得
                    Calendar cal = Calendar.getInstance();
                    SimpleDateFormat sdFormat = new SimpleDateFormat("yyyy-MM-dd");

                    // 日付を設定
                    cal.setTime(sdFormat.parse(regDate));
                    // 日を加算
                    cal.add(Calendar.DATE, unregTargetDate.intValue());
                    // System日付と比較
                    if (tmpSysDate.after(DateUtils.truncate(cal.getTime(), Calendar.DAY_OF_MONTH))) {

                        // 出力メッセージを作成する。
                        // MSG:[doc_name]が[初回受注日/初回売上日]から[unreg_target_date]過ぎていますが未登録です。
                        StringBuilder msg = new StringBuilder();
                        msg.append(unregStatusInfo.getDocName());
                        msg.append("が");
                        if (firstOrder.equals(unregStatusInfo.getUnregTarget())) {
                            msg.append("初回受注日");
                        } else if (firstSale.equals(unregStatusInfo.getUnregTarget())) {
                            msg.append("初回売上日");
                        }
                        msg.append("から");
                        msg.append(unregTargetDate.toString());
                        msg.append("日過ぎていますが未登録です。");

                        CKB0101UnregStatusOutput cbk0101UnregStatusOutput = new CKB0101UnregStatusOutput();
                        cbk0101UnregStatusOutput.setPjId(unregStatusInfo.getPjId());
                        cbk0101UnregStatusOutput.setDocType(unregStatusInfo.getDocType());
                        cbk0101UnregStatusOutput.setMessage(msg.toString());
                        cbk0101UnregStatusOutput.setCreatedAt(sysdatetime);

                        outputItems.add(cbk0101UnregStatusOutput);
                    }
                }
            }
        } catch (ParseException e) {
            logger.error(messageService.getMessage("e.bat.ck.001", JOB_ID, "日付変換"));
            logger.error(messageService.getMessage("e.bat.ck.002", JOB_ID, "日付変換"));

            throw new RuntimeException(e);
        }

        return outputItems;
    }

    @SuppressWarnings("deprecation")
    private List<CKB0101ExcelOutput> setExcelItemOutput(List<CKB0101ExcelInput> excelInfos, String sysdatetime) {
        List<CKB0101ExcelOutput> outputItems = new ArrayList<>();

        logger.info(messageService.getMessage("i.bat.fw.001", JOB_ID, "Excelファイル読込"));

        FileInputStream inputStream = null;
        Workbook workbook = null;
        try {
            if (!CollectionUtils.isEmpty(excelInfos)) {

                for (CKB0101ExcelInput excelInfo : excelInfos) {
                    String fileName = excelInfo.getFileName();

                    if (!fileName.endsWith(".xlsx") && !fileName.endsWith(".xls")) {
                        continue;
                    }

                    // 特定のファイルを取得
                    File excelfile = new File(excelInfo.getFilePath().replace(serverPath, disk));
                    if (excelfile.exists()) {

                        inputStream = new FileInputStream(excelfile);
                        workbook = new XSSFWorkbook(inputStream);

                        // Sheet[0]の値を取得する
                        Sheet firstSheet = workbook.getSheetAt(0);

                        // 固定のCell(0,0)の値を取得する
                        if (firstSheet.getRow(0) == null) {
                            continue;
                        }
                        Cell cell = firstSheet.getRow(0).getCell(0);

                        String cellData = "";
                        switch (cell.getCellType()) {
                            case Cell.CELL_TYPE_STRING:
                                cellData = cell.getStringCellValue();
                                break;
                            case Cell.CELL_TYPE_NUMERIC:
                                double cellValue = cell.getNumericCellValue();
                                cellData = new DecimalFormat("#").format(cellValue);
                                break;
                        }
                        try {
                            CKB0101ExcelOutput ckb0101ExcelOutput = new CKB0101ExcelOutput();
                            ckb0101ExcelOutput.setColA(Integer.parseInt(cellData));
                            ckb0101ExcelOutput.setCreatedAt(sysdatetime);
                            ckb0101ExcelOutput.setPjId(excelInfo.getPjId());
                            outputItems.add(ckb0101ExcelOutput);
                        } catch (NumberFormatException e) {
                            logger.error(messageService.getMessage("e.bat.ck.001", JOB_ID, "Excelファイル読込[excelの値取得]"));
                            logger.error("stacktrace:", e);
                            continue;
                        }
                    }
                }
            }
            logger.info(messageService.getMessage("i.bat.fw.002", JOB_ID, "Excelファイル読込"));
        } catch (IOException e) {
            logger.error(messageService.getMessage("e.bat.ck.001", JOB_ID, "Excelファイル読込"));
            logger.error(messageService.getMessage("e.bat.ck.002", JOB_ID, "Excelファイル読込"));

            throw new RuntimeException(e);

        } finally {
            try {
                if (!Objects.isNull(workbook)) {
                    workbook.close();
                }

            } catch (IOException e) {
                logger.error(messageService.getMessage("e.bat.ck.001", JOB_ID, "Excelファイルクローズ"));
                logger.error(messageService.getMessage("e.bat.ck.002", JOB_ID, "Excelファイルクローズ"));

                throw new RuntimeException(e);
            }
        }

        return outputItems;
    }
}
