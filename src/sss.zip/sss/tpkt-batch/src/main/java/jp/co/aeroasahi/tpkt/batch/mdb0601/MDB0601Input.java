package jp.co.aeroasahi.tpkt.batch.mdb0601;

import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜SAP勘定残高＞とテーブル＜勘定科目マスタ＞のInputBean。
 */
@Setter
@Getter
public class MDB0601Input {

    /** プロジェクト属性ID */
    private String pjAttId;

    /** プロジェクトID */
    private String pjId;

    /** 年月 */
    private String ym;

    /** 費目CD */
    private String himokuCd;

    /** 実績積算区分 */
    private String resultPlanedKbn;

    /** 工程CD */
    private String koteiCd;

    /** 代表リソースCD */
    private String distResourceCd;

    /** 金額 */
    private BigDecimal price;

    /** 会計年度と会計期間 検索用(当月) */
    private String ym1;

    /** 会計年度と会計期間 検索用(前月或は指定した月) */
    private String ym2;

    /** (積算) 検索用(当月) */
    private String ym3;

    /** (積算) 検索用(前月或は指定した月) */
    private String ym4;
}
