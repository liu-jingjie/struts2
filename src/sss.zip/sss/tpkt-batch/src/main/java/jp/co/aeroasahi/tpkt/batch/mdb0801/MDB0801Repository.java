package jp.co.aeroasahi.tpkt.batch.mdb0801;

import java.time.LocalDate;
import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 * テーブルに操作
 */
public interface MDB0801Repository {

    /**
     * (日次)条件によって、テーブル＜プロジェクト＞＜プロジェクト属性＞＜金額＞の情報を取得する。
     *
     * @param input MDB0801Input
     * @return プロジェクトIDリストデータ情報
     */
    List<MDB0801Input> findAllPjId(MDB0801Input input);

    /**
     * (日次)(★［プロジェクト．プロジェクト種別］が「P」（［受注］にデータ未登録）)条件によって、テーブル＜プロジェクト＞＜プロジェクト属性＞＜金額＞の情報を取得する。
     *
     * @param input MDB0801Input
     * @return プロジェクトIDリストデータ情報
     */
    List<MDB0801Input> findAllPjId2(MDB0801Input input);

    /**
     * (月次)条件によって、テーブル＜プロジェクト＞＜プロジェクト属性＞＜金額＞の情報を取得する。
     *
     * @param input MDB0801Input
     * @return プロジェクトIDリストデータ情報
     */
    List<MDB0801Input> findAllPjId3(MDB0801Input input);

    /**
     * (月次)(★［プロジェクト．プロジェクト種別］が「P」（［受注］にデータ未登録）)条件によって、テーブル＜プロジェクト＞＜プロジェクト属性＞＜金額＞の情報を取得する。
     *
     * @param input MDB0801Input
     * @return プロジェクトIDリストデータ情報
     */
    List<MDB0801Input> findAllPjId4(MDB0801Input input);

    /**
     * 条件によって、テーブル＜プロジェクト＞＜プロジェクト属性＞＜受注＞の情報を取得する。
     *
     * @param pPjIdList プロジェクトID（プロジェクト種別=「P」）
     *
     * @return プロジェクトIDと売上年度リストデータ情報
     */
    List<MDB0801Input> findAllPPjIdAndsoldFiscalYear(@Param("pPjIdList") String pPjIdList);

    /**
     * (★［プロジェクト．プロジェクト種別］が「P」（［受注］にデータ未登録）)条件によって、テーブル＜プロジェクト＞＜プロジェクト属性＞＜受注＞の情報を取得する。
     *
     * @param pPjIdList プロジェクトID（プロジェクト種別=「P」）
     *
     * @return プロジェクトIDと売上年度リストデータ情報
     */
    List<MDB0801Input> findAllPPjIdAndsoldFiscalYear2(@Param("pPjIdList") String pPjIdList);


    /**
     * 条件によって、テーブル＜プロジェクト＞＜プロジェクト属性＞＜受注＞の情報を取得する。
     *
     * @param rPjIdList プロジェクトID（プロジェクト種別=「R」）
     *
     * @return プロジェクトIDと売上年度リストデータ情報
     */
    List<MDB0801Input> findAllRPjIdAndsoldFiscalYear(@Param("rPjIdList") String rPjIdList);

    /**
     * 条件によって、テーブル＜プロジェクト＞＜プロジェクト属性＞＜顧客マスタ＞＜汎用マスタ＞
     * ＜部門マスタ＞＜社員＞＜部門表示順マスタ＞の情報を取得する。
     *
     * @param fiscalYear 年度の年
     * @param pjIdList プロジェクトIDリスト
     *
     * @return プロジェクトIDと売上年度リストデータ情報
     */
    List<MDB0801Input> findAll(@Param("fiscalYear") String fiscalYear, @Param("pjIdList") String pjIdList);

    /**
     * (日次、最終売上完了日がNULL以外の場合)条件によって、テーブル＜プロジェクト＞＜プロジェクト属性＞＜顧客マスタ＞＜汎用マスタ＞
     * ＜部門マスタ＞＜社員＞＜部門表示順マスタ＞の情報を取得する。
     *
     * @param fiscalYear 年度の年
     * @param pjIdList プロジェクトIDリスト
     *
     * @return プロジェクトIDと売上年度リストデータ情報
     */
    List<MDB0801Input> findAll1(@Param("fiscalYear") String fiscalYear, @Param("pjIdList") String pjIdList);

    /**
     * (日次、最終売上完了日がNULLの場合)条件によって、テーブル＜プロジェクト＞＜プロジェクト属性＞＜顧客マスタ＞＜汎用マスタ＞
     * ＜部門マスタ＞＜社員＞＜部門表示順マスタ＞の情報を取得する。
     *
     * @param fiscalYear 年度の年
     * @param pjIdList プロジェクトIDリスト
     * @param systemDate システム日付
     *
     * @return プロジェクトIDと売上年度リストデータ情報
     */
    List<MDB0801Input> findAll2(@Param("fiscalYear") String fiscalYear, @Param("pjIdList") String pjIdList, @Param("systemDate") String systemDate);

    /**
     * (月次、最終売上完了日がNULL以外かつ指定月以前の日付の場合)条件によって、テーブル＜プロジェクト＞＜プロジェクト属性＞＜顧客マスタ＞＜汎用マスタ＞
     * ＜部門マスタ＞＜社員＞＜部門表示順マスタ＞の情報を取得する。
     *
     * @param fiscalYear 年度の年
     * @param pjIdList プロジェクトIDリスト
     * @param specifiedMonth 指定月の末日
     *
     * @return プロジェクトIDと売上年度リストデータ情報
     */
    List<MDB0801Input> findAll3(@Param("fiscalYear") String fiscalYear, @Param("pjIdList") String pjIdList, @Param("specifiedMonth") String specifiedMonth);

    /**
     * (月次、最終売上完了日がNULL以外かつ指定月より未来日、または、最終売上完了日がNULLの場合)条件によって、テーブル＜プロジェクト＞＜プロジェクト属性＞＜顧客マスタ＞＜汎用マスタ＞
     * ＜部門マスタ＞＜社員＞＜部門表示順マスタ＞の情報を取得する。
     *
     * @param fiscalYear 年度の年
     * @param pjIdList プロジェクトIDリスト
     * @param specifiedMonth 指定月の末日
     *
     * @return プロジェクトIDと売上年度リストデータ情報
     */
    List<MDB0801Input> findAll4(@Param("fiscalYear") String fiscalYear, @Param("pjIdList") String pjIdList, @Param("specifiedMonth") String specifiedMonth);

    /**
     * 条件によって、テーブル＜プロジェクト＞＜プロジェクト属性＞＜受注＞の情報を取得する。
     *
     * @param ym 指定年月或は今の年月
     * @param buPjIdList BU+プロジェクト属性リスト
     *
     * @return リストデータ情報
     */
    List<MDB0801Input> findAllReceive(@Param("ym") String ym, @Param("buPjIdList") String buPjIdList);

    /**
     * 条件によって、金額の実績データ情報を取得する。
     *
     * @param ym 指定年月或は今の年月
     * @param pjIdList プロジェクトIDリスト
     *
     * @return リストデータ情報
     */
    List<MDB0801Input> findAllAmountPerformance(@Param("ym") String ym, @Param("pjIdList") String pjIdList);

    /**
     * 条件によって、金額の積算データ情報を取得する。
     *
     * @param pjIdList プロジェクトIDリスト
     *
     * @return リストデータ情報
     */
    List<MDB0801Input> findAllAmountIntegration(@Param("pjIdList") String pjIdList);

    /**
     * 条件によって、★金額（実績積算区分「3」（初回積算））データ情報を取得する。
     *
     * @param pjIdList プロジェクトIDリスト
     *
     * @return リストデータ情報
     */
    List<MDB0801Input> findAllAmountIntegration3(@Param("pjIdList") String pjIdList);

    /**
     * 条件によって、工数金額の実績データ情報を取得する。
     *
     * @param ym 指定年月或は今の年月
     * @param pjIdList プロジェクトIDリスト
     *
     * @return リストデータ情報
     */
    List<MDB0801Input> findAllCostAmountPerformance(@Param("ym") String ym,
            @Param("pjIdList") String pjIdList);

    /**
     * 条件によって、工数金額の積算データ情報を取得する。
     *
     * @param pjIdList プロジェクトIDリスト
     *
     * @return リストデータ情報
     */
    List<MDB0801Input> findAllCostAmountIntegration(@Param("pjIdList") String pjIdList);

    /**
     * 条件によって、売上のデータ情報を取得する。
     *
     * @param ym 指定年月或は今の年月
     * @param buPjIdList buPjIdList BU+プロジェクト属性リスト
     *
     * @return リストデータ情報
     */
    List<MDB0801Input> findAllSales(@Param("ym") String ym, @Param("buPjIdList") String buPjIdList);

    /**
     * 条件によって、テーブル＜積算月別プロジェクト進捗率データ＞の情報を取得する。
     *
     * @param buPjIdList BU+プロジェクト属性リスト
     *
     * @return リストデータ情報
     */
    List<MDB0801Input> findAllProgressRate(@Param("buPjIdList") String buPjIdList);

    /**
     * 条件によって、テーブル＜積算基本情報＞の情報を取得する。
     *
     * @param pjIdList プロジェクトIDリスト
     *
     * @return リストデータ情報
     */
    List<MDB0801Input> findAllBasicInformation(@Param("pjIdList") String pjIdList);

    /**
     * 条件によって、テーブル＜初回積算基本情報＞の情報を取得する。
     *
     * @param pjIdList プロジェクトIDリスト
     *
     * @return リストデータ情報
     */
    List<MDB0801Input> findAllFirstBasicInformation(@Param("pjIdList") String pjIdList);

    /**
     * 条件によって、外注情報（未発注外注費（一般）支払ベース、未発注外注費（関係）支払ベースは除く）のデータ情報を取得する。
     *
     * @param ym 指定年月或は今の年月
     * @param pjIdList プロジェクトIDリスト
     *
     * @return リストデータ情報
     */
    List<MDB0801Input> findAllExceptPayBasis(@Param("ym") String ym, @Param("pjIdList") String pjIdList);

    /**
     * 条件によって、外注情報（未発注外注費（一般）支払ベース、未発注外注費（関係）支払ベースのみ）のデータ情報を取得する。
     *
     * @param ym 指定年月或は今の年月
     * @param pjIdList プロジェクトIDリスト
     *
     * @return リストデータ情報
     */
    List<MDB0801Input> findAllPayBasis(@Param("ym") String ym, @Param("pjIdList") String pjIdList);

    /**
     * 条件によって、SAP仕掛原価のデータ情報を取得する。
     *
     * @param ym 指定年月或は今の年月
     * @param pjIdList プロジェクトIDリスト
     *
     * @return リストデータ情報
     */
    List<MDB0801Input> findAllSapWidgetCost(@Param("ym") String ym, @Param("pjIdList") String pjIdList);

    /**
     * 条件によって、積算（全年度の積算⑩＋全年度の積算⑪）のデータ情報を取得する。
     *
     * @param pjIdList プロジェクトIDリスト
     *
     * @return リストデータ情報
     */
    List<MDB0801Input> findAllSumAmount(@Param("pjIdList") String pjIdList);

    /**
     * ★金額
     * 条件によって、⑩直接費合計の外注費以外＋⑪間接費＋⑫その他事業部間取引のデータ情報を取得する。
     *
     * @param ym1 当月の年度或は指定した月の年度開始年月
     * @param ym2 当月の年度或は指定した月の年度終了年月
     * @param pjIdList プロジェクトIDリスト
     *
     * @return リストデータ情報
     */
    List<MDB0801Input> findAllSumTotalCostAmount(@Param("ym1") String ym1, @Param("ym2") String ym2,
            @Param("pjIdList") String pjIdList);

    /**
     * ★外注情報（未発注外注費（一般）支払ベース、未発注外注費（関係）支払ベースは除く）
     * 条件によって、⑩直接費合計の未発注以外の外注費のデータ情報を取得する。
     *
     * @param ym1 当月の年度或は指定した月の年度開始年月
     * @param ym2 当月の年度或は指定した月の年度終了年月
     * @param pjIdList プロジェクトIDリスト
     *
     * @return リストデータ情報
     */
    List<MDB0801Input> findAllSumExcept(@Param("ym1") String ym1, @Param("ym2") String ym2,
            @Param("pjIdList") String pjIdList);

    /**
     * ★外注情報（未発注外注費（一般）支払ベース、未発注外注費（関係）支払ベースのみ）
     * 条件によって、⑩直接費合計の未発注外注費のデータ情報を取得する。
     *
     * @param ym1 当月の年度或は指定した月の年度開始年月
     * @param ym2 当月の年度或は指定した月の年度終了年月
     * @param pjIdList プロジェクトIDリスト
     *
     * @return リストデータ情報
     */
    List<MDB0801Input> findAllSumOnly(@Param("ym1") String ym1, @Param("ym2") String ym2,
            @Param("pjIdList") String pjIdList);

    /**
     * 条件によって、金額の追加原価（金額）情報を取得する。
     *
     * @param ym3 日次処理：システム日付（YYYYMM）、月次確定処理：確定処理時に指定された年月
     * @param pjIdList プロジェクトIDリスト
     *
     * @return リストデータ情報
     */
    List<MDB0801Input> findAllAddAmount(@Param("ym3") String ym, @Param("pjIdList") String pjIdList);

    /**
     * 条件によって、外注情報の追加原価（金額）情報を取得する。
     *
     * @param ym3 日次処理：システム日付（YYYYMM）、月次確定処理：確定処理時に指定された年月
     * @param pjIdList プロジェクトIDリスト
     *
     * @return リストデータ情報
     */
    List<MDB0801Input> findAllAddCostPayBasis(@Param("ym3") LocalDate ym, @Param("pjIdList") String pjIdList);

    /**
     * 条件によって、全年度の金額の追加原価（金額）情報を取得する。
     *
     * @param ym3 日次処理：システム日付（YYYYMM）、月次確定処理：確定処理時に指定された年月
     * @param pjIdList プロジェクトIDリスト
     *
     * @return リストデータ情報
     */
    List<MDB0801Input> findAllAddAmountSum(@Param("ym3") String ym, @Param("pjIdList") String pjIdList);

    /**
     * 条件によって、全年度の外注情報の追加原価（金額）情報を取得する。
     *
     * @param ym3 日次処理：システム日付（YYYYMM）、月次確定処理：確定処理時に指定された年月
     * @param pjIdList プロジェクトIDリスト
     *
     * @return リストデータ情報
     */
    List<MDB0801Input> findAllAddCostPayBasisSum(@Param("ym3") String ym,
            @Param("pjIdList") String pjIdList);

    /**
     * テーブル＜【TEMP】物件管理＞に登録する。
     *
     * @param output MDB0801Output
     * @return
     */
    void create(MDB0801Output output);

    /**
     * テーブル＜【TEMP】物件管理＞に削除する。
     *
     * @return
     */
    void delete();

    /**
     * 条件によって、テーブル＜プロジェクト属性＞の情報を取得する。
     *
     * @param buPjIdList プロジェクト属性IDリスト
     *
     * @return リストデータ情報
     */
    List<MDB0801Input> findAllRPjidFromTo(@Param("pjAttIdList") String pjAttIdList);

    /**
     * 条件によって、テーブル＜物件管理_月次用＞の情報を取得する。
     *
     * @param pPjIdList プロジェクトID
     *
     * @return 売上年度とプロジェクトIDと期末仕掛原価リストデータ情報
     */
    List<MDB0801Input> findAllMdDispPropertyMonthlyByPjId(@Param("pPjIdList") String pPjIdList);

    /**
     * 条件によって、テーブル＜SAP仕掛原価＞の情報を取得する。
     *
     * @param soldFiscalYear 売上年度
     *
     * @return 売上年度リストデータ情報
     */
    List<MDB0801Input> findAllSAPInProcessCostDataCount(@Param("soldFiscalYear") String soldFiscalYear);

    /**
     * 条件によって、テーブル＜SAP仕掛原価＞の情報を取得する。
     *
     * @param soldFiscalYear 売上年度
     *
     * @return 売上年度リストデータ情報
     */
    List<MDB0801Input> findAllSAPInProcessCostByFiscalYearMonat(@Param("soldFiscalYear") String soldFiscalYear);

    /**
     * 条件によって、テーブル＜外注情報＞の情報を取得する。
     *
     * @param soldFiscalYear 売上年度
     *
     * @return 売上年度リストデータ情報
     */
    List<MDB0801Input> findAllMdOutsourcing(@Param("pjIdStr") String pjIdStr, @Param("lastYearfiscalYearMonth") String lastYearfiscalYearMonth, @Param("thisYearfiscalYearMonth") String thisYearfiscalYearMonth);

}
