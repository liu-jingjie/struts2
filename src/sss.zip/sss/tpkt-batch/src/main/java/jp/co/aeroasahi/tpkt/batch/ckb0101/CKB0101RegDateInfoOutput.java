package jp.co.aeroasahi.tpkt.batch.ckb0101;

import org.springframework.batch.item.ItemCountAware;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜帳票登録日情報＞のOutputBean。
 */
@Setter
@Getter
public class CKB0101RegDateInfoOutput implements ItemCountAware {

    private int count;

    /** ファイル名 */
    private String fileName;

    /** 登録日 */
    private String regedOn;

    /** 原本回収日 */
    private String originalCollected;

    /** 作成者 */
    private String createdBy;

    /** 作成日 */
    private String createdAt;

    /** 更新者 */
    private String updatedBy;

    /** 更新日 */
    private String updatedAt;

    @Override
    public void setItemCount(int count) {
        this.count = count;
    }
}
