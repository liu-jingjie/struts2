package jp.co.aeroasahi.tpkt.batch.fwb0111;

import java.util.List;

/**
 * テーブル＜【TEMP】SAP仕入先マスタ＞に操作
 */
public interface FWB0111Repository {

    /**
     * テーブル＜【TEMP】SAP仕入先マスタ＞情報を取得する。
     *
     * @return データ情報
     */
    List<FWB0111Output> findAll();

    /**
     * テーブル＜【TEMP】SAP仕入先マスタ＞に登録する。
     *
     * @param output FWB0111Output
     * @return
     */
    void create(FWB0111Output output);

    /**
     * テーブル＜【TEMP】SAP仕入先マスタ＞に更新する。
     *
     * @param output FWB0111Output
     * @return
     */
    void update(FWB0111Output output);

    /**
     * テーブル＜【TEMP】委託先マスタ＞情報を取得する。
     *
     * @return データ情報
     */
    List<FWB0111TpktOutput> findAllTpkt();

    /**
     * テーブル＜【TEMP】委託先マスタ＞に登録する。
     *
     * @param output FWB0111TpktOutput
     * @return
     */
    void tpktCreate(FWB0111TpktOutput output);

    /**
     * テーブル＜【TEMP】委託先マスタ＞に更新する。
     *
     * @param output FWB0111TpktOutput
     * @return
     */
    void tpktUpdate(FWB0111TpktOutput output);
}
