package jp.co.aeroasahi.tpkt.common.kn.check;

import java.util.List;
import jp.co.aeroasahi.tpkt.common.model.fw.Personal;
import jp.co.aeroasahi.tpkt.common.model.kn.CompanyData;
import jp.co.aeroasahi.tpkt.common.model.kn.KosuData;
import lombok.Getter;
import lombok.Setter;

/**
 * 工数チェッカー
 */
@Getter
@Setter
public class KosuChecker {

    /** 全体チェック */
    private List<WholeCheck> wholeChecks;

    /** フラグチェック */
    private List<FlgCheck> flgChecks;

    /** 行単位チェック */
    private List<RowCheck> rowChecks;

    /** チェックNo */
    private int checkNo;

    /** エラー表示 */
    private String errorDisp;

    /** エラー説明 */
    private String errorExp;

    /** チェックフラグ */
    private String chkFlg;

    /** 登録チェックフラグ */
    private String registerChkFlg;

    /** 夜間チェックフラグ */
    private String nightChkFlg;

    /** 手動チェックフラグ */
    private String manualChkFlg;

    /** 振替適用フラグ */
    private String furikaeChkFlg;

    /**
     * 工数チェック
     * <p>
     * チェックに指定した内容が合致するか判定する。(バッチ時)
     * </p>
     *
     * @param emp 社員情報
     * @param companyData Companyのデータ
     * @param kosuData 工数詳細データ
     * @return 合致した場合true
     */
    public boolean match(Personal emp, CompanyData companyData, List<KosuData> kosuDataList,
            KosuData kosuData) {
        // 全体検証処理
        for (WholeCheck each : wholeChecks) {
            if (!each.matches(emp, companyData, kosuDataList)) {
                return false;
            }
        }

        // フラグ検証処理
        for (FlgCheck each : flgChecks) {
            if (!each.matches(kosuData)) {
                return false;
            }
        }

        // 行単位検証処理
        if (matchRowCheck(emp, kosuData)) {
            return true;
        }

        return false;
    }

    private boolean matchRowCheck(Personal emp, KosuData kosuData) {
        for (RowCheck eachCheck : rowChecks) {
            if (!eachCheck.matches(emp, kosuData)) {
                return false;
            }
        }
        // 全てに合致した場合、行単位のチェック一覧オブジェクトに情報をセットし、返却する
        return true;
    }

}
