package jp.co.aeroasahi.tpkt.common.kn.check;

import java.math.BigDecimal;
import java.util.List;
import jp.co.aeroasahi.tpkt.common.model.fw.Personal;
import jp.co.aeroasahi.tpkt.common.model.kn.CompanyData;
import jp.co.aeroasahi.tpkt.common.model.kn.KosuData;

/**
 * 勤怠稼働チェック
 */
public class KintaiInputTimeCheck implements WholeCheck {

    /** チェックマスタの勤怠稼動時間 */
    private BigDecimal inputTime;

    /** 比較演算子 */
    private Sign sign;

    /** 休暇工数の工程CD */
    private static final String OFF_TIME = "ZCZ10";

    /**
     * 比較演算子を指定して勤怠の稼働時間をチェックする
     *
     * @param inputTime 稼働時間
     * @param sign 比較演算子
     */
    public KintaiInputTimeCheck(BigDecimal inputTime, Sign sign) {
        // nullは0として扱う
        this.inputTime = inputTime == null ? BigDecimal.ZERO : inputTime;
        this.sign = sign;
    }

    /**
     * 勤怠稼働チェック
     * <p>
     * チェックマスタの勤怠稼働時間と比較演算子を用いて、勤怠データの稼働時間をチェックする
     * </p>
     *
     * @param emp 社員情報
     * @param companyData 勤怠情報
     * @param kosuData 工数データリスト
     * @return true:チェックマスタの勤怠稼働時間と比較演算子と勤怠データの稼働時間を比較した結果がtrueだった場合
     */
    @Override
    public boolean matches(Personal emp, CompanyData companyData, List<KosuData> kosuData) {
        // nullの場合は0として扱う
        BigDecimal kitnaiInputTime = companyData.getInputTime() == null ? BigDecimal.ZERO : companyData.getInputTime();
        BigDecimal ChikokuSoutaitime =
                companyData.getCikokuSoutaiTime() == null ? BigDecimal.ZERO : companyData.getCikokuSoutaiTime();

        switch (sign) {
            case GREATER:
                return inputTime.compareTo(kitnaiInputTime) > 0;
            case LESS:
                return inputTime.compareTo(kitnaiInputTime) < 0;
            case GREATER_OR_EQUAL:
                return inputTime.compareTo(kitnaiInputTime) >= 0;
            case LESS_OR_EQUAL:
                return inputTime.compareTo(kitnaiInputTime) <= 0;
            case NOT_EQUAL:
                return inputTime.compareTo(kitnaiInputTime) != 0;
            case EQUAL:
                return inputTime.compareTo(kitnaiInputTime) == 0;
            case NOT_EQUAL2:
                // 休暇工数(工程CD ZCZ10)を除いた工数データの工数の合算値を取得する
                BigDecimal kosuKintai = kosuData.stream()
                        .filter(kosu -> !kosu.getKoteiCd().equals(OFF_TIME))
                        .map(KosuData::getKosu)
                        .reduce(BigDecimal.ZERO, (prev, current) -> prev.add(current));
                return kosuKintai.compareTo(kitnaiInputTime) != 0;
            case GREATER_PLUS:
                return inputTime.compareTo(kitnaiInputTime.add(ChikokuSoutaitime)) > 0;
            case LESS_PLUS:
                return inputTime.compareTo(kitnaiInputTime.add(ChikokuSoutaitime)) < 0;
            case GREATER_OR_EQUAL_PLUS:
                return inputTime.compareTo(kitnaiInputTime.add(ChikokuSoutaitime)) >= 0;
            case LESS_OR_EQUAL_PLUS:
                return inputTime.compareTo(kitnaiInputTime.add(ChikokuSoutaitime)) <= 0;
            case NOT_EQUAL_PLUS:
                return inputTime.compareTo(kitnaiInputTime.add(ChikokuSoutaitime)) != 0;
            case EQUAL_PLUS:
                return inputTime.compareTo(kitnaiInputTime.add(ChikokuSoutaitime)) == 0;
            default:
                throw new IllegalArgumentException("記号：" + sign + "はサポートされていません。");
        }
    }
}
