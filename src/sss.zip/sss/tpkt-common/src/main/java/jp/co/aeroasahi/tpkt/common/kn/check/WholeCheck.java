package jp.co.aeroasahi.tpkt.common.kn.check;

import java.util.List;
import jp.co.aeroasahi.tpkt.common.model.fw.Personal;
import jp.co.aeroasahi.tpkt.common.model.kn.CompanyData;
import jp.co.aeroasahi.tpkt.common.model.kn.KosuData;

/**
 * 工数詳細ごとでなく、当日の工数全体に対するチェック。
 *
 * @see RowCheck
 */
public interface WholeCheck {

    /**
     * 指定した社員情報や工数が条件に合致するときにtrueを返す。
     *
     * @param emp 社員情報
     * @param companyData companyデータ
     * @param kosuData 工数情報
     * @return 合致するときにtrue
     */
    boolean matches(Personal emp, CompanyData companyData, List<KosuData> kosuData);
}
