package jp.co.aeroasahi.tpkt.common.model.fw;

import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BatchJobRequest {

    /** ジョブシーケンスID */
    private String jobSequenceId;

    /** ジョブ名 */
    private String jobName;

    /** ジョブパラメータ */
    private String jobParameter;

    /** 優先度 */
    private String priority;

    /** ジョブ実行ID */
    private String jobExecutionId;

    /** ポーリングステータス */
    private String pollingStatus;

    /** 作成日時 */
    private LocalDateTime createDate;

    /** 更新日時 */
    private LocalDateTime updateDate;
}
