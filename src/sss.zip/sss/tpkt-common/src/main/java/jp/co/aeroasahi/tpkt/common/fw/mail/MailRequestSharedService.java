package jp.co.aeroasahi.tpkt.common.fw.mail;

import jp.co.aeroasahi.tpkt.common.model.fw.MailManagement;

public interface MailRequestSharedService {

    /**
     * fs_cm_046
     * 添付無しメール送信要求処理
     *
     * <p>
     * 必要な情報をメール管理テーブルに格納し、メール送信ジョブをインサートする
     * </p>
     *
     * @param mailParameter メールのパラメータ
     */
    void requestNoAttachmentMail(MailManagement mailParameter);

}
