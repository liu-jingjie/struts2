package jp.co.aeroasahi.tpkt.common.fw.validation;


import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.*;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.Payload;

/**
 * 日付形式の文字列であることをチェックするためのカスタムアノテーション。
 *
 * LocalDateTime.parse()でparse可能であることを検証する。
 * uuuu-MM-dd HH:mm:ss.SSSのような形式がparse可能。
 */
@Documented
@Constraint(validatedBy = {DateTimeStringValidator2.class})
@Target({METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER})
@Retention(RUNTIME)
public @interface DateTimeString2 {
    String message() default "{jp.co.aeroasahi.tpkt.common.fw.validation.DateTimeString.message}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    @Target({METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER})
    @Retention(RUNTIME)
    @Documented
    public @interface List {
        DateTimeString2[] value();
    }
}
