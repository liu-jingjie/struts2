package jp.co.aeroasahi.tpkt.common.fw.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.hibernate.validator.internal.util.logging.Log;
import org.hibernate.validator.internal.util.logging.LoggerFactory;
import jp.co.aeroasahi.tpkt.common.util.CommonUtils;

public class Size2Validator implements ConstraintValidator<Size2, String> {

    private static final Log log = LoggerFactory.make();
    private long min;
    private long max;

    @Override
    public void initialize(Size2 parameters) {

        this.min = parameters.min();
        this.max = parameters.max();

        validateParameters();
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {

        if (null == value) {
            value = "";
        }

        long length = CommonUtils.getSurrogatePairCharacterLength(value);

        boolean result = (length >= min) && (length <= max);

        log.info("Size2.validator:[value:" + (String) value + ",min:" + min + ",max:" + max + ",length:" + length
                + "],result:" + result);

        return result;
    }

    private void validateParameters() {

        if (this.min < 0) {
            throw log.getMinCannotBeNegativeException();
        }

        if (this.max < 0) {
            throw log.getMaxCannotBeNegativeException();
        }

        if (this.max < this.min) {
            throw log.getLengthCannotBeNegativeException();
        }
    }
}
