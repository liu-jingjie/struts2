package jp.co.aeroasahi.tpkt.common.fw.project;

/**
 * プロジェクトID
 */
public class ProjectId {

    /**
     * ID文字列
     */
    private String id;

    /**
     * プロジェクトタイプ
     */
    private PjType type;

    /**
     * 12桁のプロジェクトIDを指定してオブジェクトを作成する。
     *
     * @param id プロジェクトID文字列
     */
    public ProjectId(String id) {
        this.id = id;
        switch (id.charAt(2)) {
            case 'P':
                type = PjType.P_PJ;
                break;
            case 'R':
                type = PjType.R_PJ;
                break;
            case 'O':
                type = PjType.O_PJ;
                break;
        }
    }

    /**
     * このプロジェクトがPプロジェクトであるか判定する。
     *
     * @return このプロジェクトがPプロジェクトである場合はtrue
     */
    public boolean isPPj() {
        return type == PjType.P_PJ;
    }

    /**
     * このプロジェクトがRプロジェクトであるか判定する。
     *
     * @return このプロジェクトがRプロジェクトである場合はtrue
     */
    public boolean isRPj() {
        return type == PjType.R_PJ;
    }

    /**
     * fs_cm_31
     * このプロジェクトがOプロジェクトであるか判定する。
     *
     * @return このプロジェクトがOプロジェクトである場合はtrue
     */
    public boolean isOPj() {
        return type == PjType.O_PJ;
    }

    /**
     * fs_cm_32
     * このプロジェクトが営業プロジェクト(01プロジェクト)であるか判定する。
     *
     * @return 営業プロジェクトの場合true
     */
    public boolean isSalesPj() {
        return (isPPj() || isRPj()) && id.endsWith("01");
    }

    /**
     * fs_cm_33
     * このプロジェクトが直接プロジェクト(01以外)であるかを判定する。
     *
     * @return
     */
    public boolean isProductPj() {
        return (isPPj() || isRPj()) && !id.endsWith("01");
    }

    /**
     * fs_cm_30
     * プロジェクト種別を取得する。
     *
     * @return type 種別
     */
    public PjType getType() {
        return type;
    }

    /**
     * ビジネスユニットを取得する。
     *
     * @return ビジネスユニット(2桁)
     */
    public String getBU() {
        return id.substring(0, 2);
    }

    /**
     * fs_cm_29
     * プロジェクト属性ID取得
     * プロジェクト属性IDを取得する。
     *
     * @return プロジェクト属性ID
     */
    public String getPjAttId() {
        return id.substring(2, 10);
    }

    /**
     * プロジェクトの枝番を取得する。
     *
     * @return プロジェクトの枝番
     */
    public String getBranchNum() {
        return id.substring(10, 12);
    }

    @Override
    public String toString() {
        return id;
    }
}
