package jp.co.aeroasahi.tpkt.common.fw.template;

import java.io.IOException;
import java.io.UncheckedIOException;
import javax.inject.Inject;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;

/**
 * TemplateService実装。
 */
@Service
public class TemplateServiceImpl implements TemplateService {

    @Inject
    Configuration freemarkerConfiguration;

    @Override
    public String create(String templateId, Object param) {

        Template temp = getTemplate(templateId);

        try {
            String text = FreeMarkerTemplateUtils.processTemplateIntoString(temp, param);
            return text;
        } catch (TemplateException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    private Template getTemplate(String templateId) {
        try {
            return freemarkerConfiguration.getTemplate(templateId + ".ftl");
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }
}
