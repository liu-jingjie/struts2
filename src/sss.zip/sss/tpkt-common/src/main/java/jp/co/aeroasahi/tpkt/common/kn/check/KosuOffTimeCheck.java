package jp.co.aeroasahi.tpkt.common.kn.check;

import java.math.BigDecimal;
import java.util.List;
import jp.co.aeroasahi.tpkt.common.model.fw.Personal;
import jp.co.aeroasahi.tpkt.common.model.kn.CompanyData;
import jp.co.aeroasahi.tpkt.common.model.kn.KosuData;

/**
 * 休暇工数チェック
 */
public class KosuOffTimeCheck implements WholeCheck {

    /** 工数チェックマスタの工数休暇工数 */
    private BigDecimal offTime;

    /** 比較演算子 */
    private Sign sign;

    /**
     * 比較演算子を指定して工数の休暇工数をチェックする
     *
     * @param offTime 工数チェックマスタの工数休暇工数
     * @param sign 比較演算子
     */
    public KosuOffTimeCheck(BigDecimal offTime, Sign sign) {
        //nullは0として扱う
        this.offTime = offTime == null ? BigDecimal.ZERO : offTime;
        this.sign = sign;
    }

    /**
     * 工数データの休暇工数チェック
     *
     * @param emp 社員情報
     * @param companyData 勤怠情報
     * @param kosuData 工数データリスト
     * @return true:チェックマスタの休暇稼働と比較演算子と、工数データの休暇工数を比較した結果がtrueだった場合
     */
    @Override
    public boolean matches(Personal emp, CompanyData companyData, List<KosuData> kosuData) {
        BigDecimal total;

        // nullの場合は0として扱う
        if (kosuData == null) {
            total = BigDecimal.ZERO;
        } else {
            total = kosuData.stream()
                    .filter(kosu -> kosu.getKoteiCd().equals("ZCZ10"))
                    .map(KosuData::getKosu)
                    .reduce(BigDecimal.ZERO, (prev, current) -> prev.add(current));
        }

        switch (sign) {
            case GREATER:
                return offTime.compareTo(total) > 0;
            case LESS:
                return offTime.compareTo(total) < 0;
            case GREATER_OR_EQUAL:
                return offTime.compareTo(total) >= 0;
            case LESS_OR_EQUAL:
                return offTime.compareTo(total) <= 0;
            case NOT_EQUAL:
                return offTime.compareTo(total) != 0;
            case EQUAL:
                return offTime.compareTo(total) == 0;
            default:
                throw new IllegalArgumentException("記号：" + sign + "はサポートされていません。");
        }
    }
}
