package jp.co.aeroasahi.tpkt.common.kn.check;

import java.math.BigDecimal;
import java.util.List;
import jp.co.aeroasahi.tpkt.common.model.fw.Personal;
import jp.co.aeroasahi.tpkt.common.model.kn.CompanyData;
import jp.co.aeroasahi.tpkt.common.model.kn.KosuData;

/**
 * 稼働工数チェック
 */
public class KosuTimeCheck implements WholeCheck {

    /** 工数チェックマスタの工数稼働工数 */
    private BigDecimal kado;

    /** 比較演算子 */
    private Sign sign;

    /** 休暇の工程CD */
    private static final String OFF_TIME = "ZCZ10";

    /**
     * 比較演算子を指定して工数の稼働工数をチェックする
     *
     * @param kado 工数チェックマスタの工数稼働工数
     * @param sign 比較演算子
     */
    public KosuTimeCheck(BigDecimal kado, Sign sign) {
        // nullは0として扱う
        this.kado = kado == null ? BigDecimal.ZERO : kado;
        this.sign = sign;
    }

    /**
     * 工数データの稼働工数チェック
     *
     * @param emp 社員情報
     * @param companyData 勤怠情報
     * @param kosuData 工数データリスト
     * @return true:チェックマスタの工数稼働と比較演算子と、工数データの稼働工数を比較した結果がtrueだった場合
     */
    @Override
    public boolean matches(Personal emp, CompanyData companyData, List<KosuData> kosuData) {

        BigDecimal total;

        // nullの場合は0として扱う
        if (kosuData == null) {
            total = BigDecimal.ZERO;
        } else {
            // 休暇工数(工程CD ZCZ10)を除いた工数の合算値を取得する
            total = kosuData.stream()
                    .filter(kosu -> !kosu.getKoteiCd().equals(OFF_TIME))
                    .map(KosuData::getKosu)
                    .reduce(BigDecimal.ZERO, (prev, current) -> prev.add(current));
        }
        switch (sign) {
            case GREATER:
                return kado.compareTo(total) > 0;
            case LESS:
                return kado.compareTo(total) < 0;
            case GREATER_OR_EQUAL:
                return kado.compareTo(total) >= 0;
            case LESS_OR_EQUAL:
                return kado.compareTo(total) <= 0;
            case NOT_EQUAL:
                return kado.compareTo(total) != 0;
            case EQUAL:
                return kado.compareTo(total) == 0;
            case NOT_EQUAL2:
                BigDecimal kintaiInputTime =
                        companyData.getInputTime() == null ? BigDecimal.ZERO : companyData.getInputTime();
                return kintaiInputTime.compareTo(total) != 0;
            default:
                throw new IllegalArgumentException("記号：" + sign + "はサポートされていません。");
        }
    }
}
