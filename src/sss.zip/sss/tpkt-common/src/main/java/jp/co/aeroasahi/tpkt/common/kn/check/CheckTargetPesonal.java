package jp.co.aeroasahi.tpkt.common.kn.check;

import java.time.LocalDate;
import lombok.Getter;
import lombok.Setter;

/**
 * チェック対象の社員情報を保持するオブジェクト
 *
 */
@Getter
@Setter
public class CheckTargetPesonal {

    /** チェック対象日付 */
    private LocalDate date;

    /** 社員CD */
    private String empCd;

    /** 会社CD */
    private String corpCd;

    /** 部門CD */
    private String deptCd;

    /** 社員区分 */
    private String empKbn;

    /** カレンダー種別 */
    private String calendarType;
}
