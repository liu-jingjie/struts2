package jp.co.aeroasahi.tpkt.common.fw.mail;

import javax.inject.Inject;
import org.springframework.stereotype.Service;
import freemarker.template.Configuration;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;
import jp.co.aeroasahi.tpkt.common.model.fw.BatchJobRequest;
import jp.co.aeroasahi.tpkt.common.model.fw.MailManagement;
import jp.co.aeroasahi.tpkt.common.repository.fw.BatchJobRequestRepository;
import jp.co.aeroasahi.tpkt.common.repository.fw.MailManagementRepository;

@Service
public class MailRequestSharedServiceImpl implements MailRequestSharedService {

    /** HTMLメール(添付ファイル無し)を送信する際のジョブ名 */
    private static final String NO_ATTACHMENT_JOB_NAME = "fbfw001Job";

    /** パラメータのプレフィックス */
    private static final String PARAMATER_PREFIX = "sequence=";

    @Inject
    Configuration freemarkerConfiguration;

    @Inject
    MailManagementRepository mailManagementRepository;

    @Inject
    BatchJobRequestRepository batchJobRequestRepository;

    @Inject
    DateFactory dateFactory;

    @Override
    public void requestNoAttachmentMail(MailManagement mailManagement) {
        // テーブルロック取得(解除されるのは呼び出し側のトランザクションを抜けたタイミング)
        mailManagementRepository.findForTableLock();
        int sequence = mailManagementRepository.createReturnSequence(mailManagement);

        BatchJobRequest batchJobRequest = setBatchJobRequest(NO_ATTACHMENT_JOB_NAME, sequence);
        batchJobRequestRepository.create(batchJobRequest);
    }

    private BatchJobRequest setBatchJobRequest(String jobName, int sequence) {
        BatchJobRequest batchJobRequest = new BatchJobRequest();

        batchJobRequest.setJobName(jobName);
        batchJobRequest.setJobParameter(PARAMATER_PREFIX + Integer.toString(sequence));
        batchJobRequest.setCreateDate(dateFactory.newDateTime());

        return batchJobRequest;
    }
}
