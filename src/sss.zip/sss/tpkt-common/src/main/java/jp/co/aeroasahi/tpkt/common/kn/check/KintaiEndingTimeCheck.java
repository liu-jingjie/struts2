package jp.co.aeroasahi.tpkt.common.kn.check;

import java.math.BigDecimal;
import java.util.List;
import jp.co.aeroasahi.tpkt.common.model.fw.Personal;
import jp.co.aeroasahi.tpkt.common.model.kn.CompanyData;
import jp.co.aeroasahi.tpkt.common.model.kn.KosuData;
import jp.co.aeroasahi.tpkt.common.util.CommonUtils;

/**
 * 終業チェック
 */
public class KintaiEndingTimeCheck implements WholeCheck {

    /** チェックマスタの終業 */
    private BigDecimal endingTime;

    /** 比較演算子 */
    private Sign sign;

    /**
     * 比較演算子を指定して勤怠の終業時間をチェックする
     *
     * @param endingTime
     * @param sign
     */
    public KintaiEndingTimeCheck(BigDecimal endingTime, Sign sign) {
        // nullは0として扱う
        this.endingTime = endingTime == null ? BigDecimal.ZERO : endingTime;
        this.sign = sign;
    }

    /**
     * 終業チェック
     * <p>
     * チェックマスタの終業と比較演算子を用いて、勤怠データの終業時間をチェックする
     * </p>
     *
     * @param emp 社員情報
     * @param companyData 勤怠情報
     * @param kosuData 工数データリスト
     * @return true:チェックマスタの終業と比較演算子と勤怠データの終業時間を比較した結果がtrueだった場合
     */
    @Override
    public boolean matches(Personal emp, CompanyData companyData, List<KosuData> kosuData) {
        /*
         * null -> 0
         * 変換不可 -> null
         * 変換可能 -> BigDecimal
         */
        BigDecimal kitnaiEndingTime = CommonUtils.timeStringToBigDecimal(companyData.getEndingTime());

        // 数値変換できない値が入力されていた場合はtrueを返却する
        if (kitnaiEndingTime == null) {
            return true;
        }

        switch (sign) {
            case GREATER:
                return endingTime.compareTo(kitnaiEndingTime) > 0;
            case LESS:
                return endingTime.compareTo(kitnaiEndingTime) < 0;
            case GREATER_OR_EQUAL:
                return endingTime.compareTo(kitnaiEndingTime) >= 0;
            case LESS_OR_EQUAL:
                return endingTime.compareTo(kitnaiEndingTime) <= 0;
            case NOT_EQUAL:
                return endingTime.compareTo(kitnaiEndingTime) != 0;
            case EQUAL:
                return endingTime.compareTo(kitnaiEndingTime) == 0;
            default:
                throw new IllegalArgumentException("記号：" + sign + "はサポートされていません。");
        }
    }
}
