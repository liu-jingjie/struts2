package jp.co.aeroasahi.tpkt.common.model.fw;

import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BatchCompleteInfo {
    /** 前回日次処理完了日時 */
    private LocalDateTime lastDailyBatchCompleteDateTime;

    /** 前回月次確定処理完了日時 */
    private LocalDateTime lastMonthlyConfirmCompleteDateTime;

    /** 前回月次確定処理年月 */
    private LocalDateTime lastMonthlyConfirmYm;

    /** 前回監視完了日時 */
    private LocalDateTime lastMonitoringCompleteDateTime;

    /** 更新日 */
    private LocalDateTime updatedAt;
}
