package jp.co.aeroasahi.tpkt.common.fw.calendar;

import java.time.LocalDate;
import java.util.List;

public interface PublicHolidaySharedService {

    /**
     * 指定したカレンダー種別の全休日データを取得する。
     *
     * @param calendarType カレンダー種別
     * @return 休日データ
     */
    List<LocalDate> findOffDays(String calendarType);
}
