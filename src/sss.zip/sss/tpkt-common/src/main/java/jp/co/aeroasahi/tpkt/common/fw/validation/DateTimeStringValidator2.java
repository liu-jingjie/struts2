package jp.co.aeroasahi.tpkt.common.fw.validation;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.springframework.util.StringUtils;

/**
 * 日付形式の文字列であることをチェックするためのValidator
 */
public class DateTimeStringValidator2 implements ConstraintValidator<DateTimeString2, String> {

    /** 解析時の日時パターン */
    private static final DateTimeFormatter PARSE_PATTERN = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.SSS");

    @Override
    public void initialize(DateTimeString2 constraintAnnotation) {
        // nothing to do
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (!StringUtils.hasLength(value)) {
            return true;
        }
        try {
            LocalDateTime.parse(value, PARSE_PATTERN);
            return true;
        } catch (DateTimeParseException e) {
            return false;
        }
    }
}
