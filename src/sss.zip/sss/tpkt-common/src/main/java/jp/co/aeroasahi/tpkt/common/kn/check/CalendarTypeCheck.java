package jp.co.aeroasahi.tpkt.common.kn.check;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;
import jp.co.aeroasahi.tpkt.common.model.fw.Personal;
import jp.co.aeroasahi.tpkt.common.model.fw.PublicHoliday;
import jp.co.aeroasahi.tpkt.common.model.kn.KosuData;

/**
 * カレンダー種別チェック
 */
public class CalendarTypeCheck implements RowCheck {

    /** カレンダー種別 */
    private String calendarType;
    private List<PublicHoliday> publicHolidayList;

    /**
     * カレンダー種別を指定して、カレンダー種別チェックと祝日チェックを実施する
     *
     * @param calendarType カレンダー種別
     * @param publicHolidayList 祝日情報のリスト
     */
    public CalendarTypeCheck(String calendarType, List<PublicHoliday> publicHolidayList) {
        this.calendarType = calendarType;
        this.publicHolidayList = publicHolidayList;
    }

    /**
     * カレンダー種別/休日チェックを実施する
     * <p>
     * 対象のカレンダー種別が等しい場合のみ、休日チェックを実施する。
     * </p>
     *
     * @param personal 社員情報
     * @param kosuData 工数データ
     * @return true:カレンダー種別がマスタと一致し、対象の日付が休日(土日あるいは、祝日マスタに存在する)
     */
    @Override
    public boolean matches(Personal personal, KosuData kosuData) {

        // 工数入力していないレコードに対してはチェックしない
        if (kosuData.getDate() == null) {
            return false;
        }
        // 工数チェックマスタのカレンダー種別と、対象のカレンダー種別が異なる場合、falseを返却する
        if (!personal.getCalendarType().matches(calendarType)) {
            return false;
        }

        // チェック対象の日付が休日であればtrue(休日：土日or祝日)
        return isOffDay(kosuData.getDate(), personal.getCalendarType());
    }

    private boolean isOffDay(LocalDate date, String calendarType) {
        DayOfWeek dayOfweek = date.getDayOfWeek();

        // 日付が土曜日か日曜日の場合trueを返却する
        if (dayOfweek.equals(DayOfWeek.SATURDAY) || dayOfweek.equals(DayOfWeek.SUNDAY)) {
            return true;
        }


        // DBから取得した祝日情報のリストをチェック対象のカレンダー種別でフィルタリングし、祝日のリストを取得する
        List<LocalDate> holidayList = publicHolidayList.stream()
                .filter(publicHoliday -> publicHoliday.getCalendarType().equals(calendarType))
                .map(s -> s.getPublicHoliday())
                .collect(Collectors.toList());

        // 日付が祝日リストにあればtrueを返却する
        return holidayList.contains(date);
    }

}
