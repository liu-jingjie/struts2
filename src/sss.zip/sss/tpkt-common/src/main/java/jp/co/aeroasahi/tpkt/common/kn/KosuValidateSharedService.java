package jp.co.aeroasahi.tpkt.common.kn;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import jp.co.aeroasahi.tpkt.common.kn.check.CheckTargetPesonal;
import jp.co.aeroasahi.tpkt.common.model.fw.Personal;
import jp.co.aeroasahi.tpkt.common.model.kn.CheckList;
import jp.co.aeroasahi.tpkt.common.model.kn.KosuData;

public interface KosuValidateSharedService {

    /**
     * 工数入力画面登録押下時のチェック処理
     *
     * @param emp 社員情報
     * @param date 登録対象日付
     * @param kosuDtl 工数情報
     * @param loginEmpCd ログイン社員CD
     * @return エラー情報リスト
     */
    List<ValidateError> executeRegisterCheck(Personal emp, LocalDate date, List<KosuData> kosuDtl, String loginEmpCd);

    /**
     * 工数入力チェックバッチのチェック処理
     *
     * @param target チェック対象の日付と社員
     * @param sysDate システム日時
     * @param startDate チェック期間の開始日
     * @param lastDate チェック期間の終了日
     * @param isManual 手動チェックフラグ
     * @return チェック一覧
     */
    List<CheckList> executeBatchCheck(List<CheckTargetPesonal> target, LocalDateTime sysDateTime, LocalDate startDate,
            LocalDate lastDate, boolean isManual);
}
