package jp.co.aeroasahi.tpkt.common.kn.check;

import java.util.List;
import jp.co.aeroasahi.tpkt.common.model.kn.KosuData;

/**
 * プロジェクトIDが利用可能であるか判定するCheck.
 */
public class PjStatusCheck implements FlgCheck {

    /** オープンプロジェクトIDのリスト */
    private List<String> openPjIdList;

    /**
     * プロジェクトステータスチェックのコンストラクタ
     *
     * @param pjIdList オープンプロジェクトIDのリスト
     */
    public PjStatusCheck(List<String> openPjIdList) {
        this.openPjIdList = openPjIdList;
    }

    /**
     * プロジェクトIDがクローズであればtrueを返却する
     *
     * @param kosuData 工数データ
     * @return true:対象のプロジェクトIDがクローズしている場合
     */
    @Override
    public boolean matches(KosuData kosuData) {
        // PJIDがnull即ち、バッチの場合かつ工数入力されていない場合はチェック対象外
        if(kosuData.getPjId() == null) {
            return false;
        }
        return !openPjIdList.contains(kosuData.getPjId());
    }


}
