package jp.co.aeroasahi.tpkt.common.kn.check;

import java.util.List;
import jp.co.aeroasahi.tpkt.common.model.kn.KosuData;

/**
 * 工程CDが存在するか判定するCheck.
 */
public class KoteiDelCheck implements FlgCheck {

    /** 削除されていない工程CDのリスト */
    private List<String> koteiCdList;

    /**
     * 工程存在チェックのコンストラクタ
     *
     * @param koteiCdList 削除されていない工程CDのリスト
     */
    public KoteiDelCheck(List<String> koteiCdList) {
        this.koteiCdList = koteiCdList;
    }

    /**
     * 対象の工程CDの存在チェックを実施する
     *
     * @param kosuData 工数データ
     * @return true:対象の工程CDが存在しない場合
     */
    @Override
    public boolean matches(KosuData kosuData) {
        // 登録押下時は事前に工程CDの存在チェックを実施しているため、チェック不要
        if (koteiCdList == null) {
            return false;
        }
        // 工程CDがnull即ち、バッチの場合かつ工数入力がされていない場合はチェック不要
        if(kosuData.getKoteiCd() == null) {
            return false;
        }

        return !koteiCdList.contains(kosuData.getKoteiCd());
    }


}
