package jp.co.aeroasahi.tpkt.batch.mdb0003.job4;

import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.fw.CommonLog;
import jp.co.aeroasahi.tpkt.batch.mdb0003.MDB0003DataCopyRepository;

/**
 * 表示用テーブルの本体の内容をtempへ反映させるTasklet
 */
@Component
@Scope("step")
public class MDB0003Tasklet154 implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0003Tasklet154.class);

    // 日次処理の場合は「D」、月次確定処理の場合は「M」
    @Value("#{jobParameters['shorikbn']}")
    public String shorikbn;

    // 処理年月：日次処理の場合は空白を設定、バッチ実行画面の指定した月次確定対象年月を「YYYYMM」形式
    @Value("#{jobParameters['ym']}")
    public String ym;

    @Inject
    MDB0003DataCopyRepository mainDataCopyRepository;

    /**
     *
     * 表示用テーブルの本体の内容をtempへ反映させる
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return ステータス
     */
    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

        try {

            // テーブル＜【TEMP】物件管理＞に登録する。
            mainDataCopyRepository.dataCopy("md_disp_property", "temp_md_disp_property");
            // テーブル＜【TEMP】外注管理＞に登録する。
            mainDataCopyRepository.dataCopy4("md_disp_outsourcing", "temp_md_disp_outsourcing");
            // テーブル＜【TEMP】部門経費管理＞に登録する。
            mainDataCopyRepository.dataCopy("md_disp_dept_cost", "temp_md_disp_dept_cost");
            // テーブル＜【TEMP】操業度管理＞に登録する。
            mainDataCopyRepository.dataCopy("md_disp_operation", "temp_md_disp_operation");

            logger.info("本体テーブルからtempテーブルへの書き込みが完了しました。");

        } catch (DuplicateKeyException e) {
            CommonLog.setBatchErrorLog(logger, "本体テーブルから、tempテーブルに更新");
            logger.error("stackTrace：", e);
        }
        return RepeatStatus.FINISHED;
    }
}
