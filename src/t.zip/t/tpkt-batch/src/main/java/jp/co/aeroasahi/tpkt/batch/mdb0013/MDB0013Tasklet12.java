package jp.co.aeroasahi.tpkt.batch.mdb0013;

import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * 各ジョブを実行するTasklet
 */
@Component
@Scope("step")
public class MDB0013Tasklet12 implements Tasklet {

    /** 工数取込 */
    private static final String KOSU_JOB_NAME = "mdb0101Job";
    /** 受注・売上額取込 */
    private static final String RECIEVE_AND_SOLD_JOB_NAME = "mdb0201Job";
    /** 発注費取込 */
    private static final String ORDER_JOB_NAME = "mdb0401Job";
    /** 部門別経費取込 */
    private static final String DEPT_COST_JOB_NAME = "mdb0404Job";

    @Inject
    MDB0013SharedServiceImpl mdb0013SharedService;

    @Autowired
    private BatchDataHolder batchDataHolder;

    List<Integer> jobExecutionIds = new ArrayList<Integer>();

    /**
     *
     * マインバッチ処理
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return 一括で各ジョブを実行した状態
     */
    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        String jobStartDateTime = batchDataHolder.getJobStartDateTime();

        // 外注情報取込の終了まで待つ (規定時間を待っても終わらない or 異常終了していた場合は例外をスロー)
        mdb0013SharedService.checkAllExecuteResult(setTargetJobNames(), jobStartDateTime);

        return RepeatStatus.FINISHED;
    }

    private List<String> setTargetJobNames() {
        List<String> resultList = new ArrayList<>();

        resultList.add(KOSU_JOB_NAME);
        resultList.add(RECIEVE_AND_SOLD_JOB_NAME);
        resultList.add(ORDER_JOB_NAME);
        resultList.add(DEPT_COST_JOB_NAME);

        return resultList;
    }
}
