package jp.co.aeroasahi.tpkt.batch.cm.task.fbfw005;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.Locale;
import javax.inject.Inject;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.common.cm.task.BatchStatus;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;
import jp.co.aeroasahi.tpkt.common.util.CommonUtils;

@Component
@Scope("step")
public class FBFW005Tasklet implements Tasklet {


    private static final String COMAND_PREFIX = "java -cp \"";

    private static final String COMAND_SUFFIX =
            "\" org.springframework.batch.core.launch.support.CommandLineJobRunner META-INF/jobs/mdb0003.xml mdb0003Job ";

    private static final String COMAND_SUFFIX2 =
            "\" org.springframework.batch.core.launch.support.CommandLineJobRunner META-INF/jobs/aysnc/sbb0202.xml sbb0202Job ";

    private static final Logger logger = LoggerFactory.getLogger(FBFW005Tasklet.class);

    private static final String JOB_ID = "fbfw005";

    @Inject
    FBFW005Repository fbfw005Repository;

    @Inject
    DateFactory dateFactory;

    @Inject
    MessageSource message;

    @Value("#{jobParameters['timeKey']}")
    public String timeKey;

    // create:新規タスク作成、delete:既存タスク削除
    @Value("#{jobParameters['changeIndicator']}")
    public String changeIndicator;

    @Value("#{jobParameters['taskName']}")
    public String taskName;

    @Value("#{jobParameters['cmdLine']}")
    public String cmdLine;

    @Value("#{jobParameters['startDate']}")
    public String startDate;

    @Value("#{jobParameters['startTime']}")
    public String startTime;

    @Value("${batch.classpath}")
    String classpath;

    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

        String startDateTime = startDate + " " + startTime;
        Object[] messageArgs = CommonUtils.getMessageArgs(JOB_ID, startDateTime, taskName);

        FBFW005Output output = new FBFW005Output();
        boolean dosCmdCheckFlag = false;

        if (changeIndicator.equals("create")) {
            logger.info(message.getMessage("i.bat.cm.005", messageArgs, Locale.getDefault()));
            String cmdLineBefore = "";

            if (taskName.startsWith("月次確定処理_")) {
                cmdLineBefore = COMAND_PREFIX + classpath + COMAND_SUFFIX;
            } else if (taskName.startsWith("積算原価反映_")) {
                cmdLineBefore = COMAND_PREFIX + classpath + COMAND_SUFFIX2;
            }

            // 新規タスク作成
            dosCmdCheckFlag = createOnceTask(taskName, cmdLineBefore + cmdLine, startDate, startTime);

            if (dosCmdCheckFlag) {
                // タスクの登録に成功した場合
                output.setMessage(BatchStatus.SUCCESS_REGIST.getCode());
                logger.info(message.getMessage("i.bat.cm.007", messageArgs, Locale.getDefault()));
            } else {
                // タスクの登録に失敗した場合
                output.setMessage(BatchStatus.FAIL_REGIST.getCode());
                logger.error(message.getMessage("e.bat.cm.001", messageArgs, Locale.getDefault()));
            }

            // 日時キー
            output.setTimeKey(timeKey);

            fbfw005Repository.update(output);

        } else if (changeIndicator.equals("delete")) {
            logger.info(message.getMessage("i.bat.cm.006", messageArgs, Locale.getDefault()));
            // 既存タスク削除
            dosCmdCheckFlag = deleteTask(taskName);

            if (dosCmdCheckFlag) {
                // タスクの削除に成功した場合
                output.setMessage(BatchStatus.SUCCESS_DELETE.getCode());
                output.setDeleted(true);
                logger.info(message.getMessage("i.bat.cm.008", messageArgs, Locale.getDefault()));
            } else {
                // タスクの削除に失敗した場合
                output.setMessage(BatchStatus.FAIL_DELETE.getCode());
                output.setDeleted(false);
                logger.error(message.getMessage("e.bat.cm.002", messageArgs, Locale.getDefault()));
            }
            output.setTaskName(taskName);

            fbfw005Repository.updateD(output);
        } else {
            throw new RuntimeException("引数changeIndicatorが誤っています。changeIndicator：" + changeIndicator);
        }

        return RepeatStatus.FINISHED;
    }

    private boolean createOnceTask(String taskName, String cmdLine, String startDate, String startTime) {

        String cmd = "schtasks /create /tn \"" + taskName + "\" /tr \"" + cmdLine + "\" /sc ONCE /st " + startTime
                + " /sd " + startDate + " /ru system /rl highest";
        String checkCreateStr = "正しく作成されました";

        return getExecuteResult(cmd, checkCreateStr);
    }

    private boolean deleteTask(String taskName) {

        String cmd = "cmd /c SCHTASKS /Delete /TN  \"" + taskName + "\" /F";
        String checkDeleteStr = "正しく削除されました";

        return getExecuteResult(cmd, checkDeleteStr);
    }

    private boolean getExecuteResult(String cmd, String checkStr) {

        String charset = "SHIFT-JIS";

        logger.debug("Runtime.getRuntime()");
        Runtime rt = Runtime.getRuntime();
        logger.debug("実行コマンド：" + cmd);
        Process proc;

        // コマンド実行
        try {
            proc = rt.exec(cmd);
        } catch (IOException e) {
            logger.error("stackTrace：", e);
            return false;
        }

        try {
            // プロセスの正常終了まで待機させる
            proc.waitFor();
        } catch (InterruptedException e) {
            logger.error("stackTrace：", e);
            return false;
        }

        if (proc.exitValue() != 0) {
            // エラーが発生した場合はログを出力し、falseをreturn
            InputStream errorIsr = proc.getErrorStream();
            try {
                logger.error("エラーの文字列：" + IOUtils.toString(errorIsr, Charset.forName(charset)));
            } catch (IOException e) {
                logger.error("エラー文字列の取得に失敗 stackTrace：", e);
            }
            return false;
        } else {
            // 正常終了
            return true;
        }
    }
}
