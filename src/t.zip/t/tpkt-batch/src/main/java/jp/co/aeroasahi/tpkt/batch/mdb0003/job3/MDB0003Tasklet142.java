package jp.co.aeroasahi.tpkt.batch.mdb0003.job3;

import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.mdb0003.BatchDataHolder;
import jp.co.aeroasahi.tpkt.batch.mdb0003.MDB0003SharedServiceImpl;

/**
 * 月次確定の表示用テーブル更新の実行結果を確認するTasklet
 */
@Component
@Scope("step")
public class MDB0003Tasklet142 implements Tasklet {

    /** 【表示用】物件管理更新ジョブ名 */
    private static final String DISP_PROPERTY_JOB_NAME = "mdb0801Job";
    /** 【表示用】外注管理更新ジョブ名 */
    private static final String DISP_OUTSOURCING_JOB_NAME = "mdb0802Job";

    /** ジョブ番号 */
    private static final int TARGET_JOB_NUMBER = 3;

    @Inject
    MDB0003SharedServiceImpl mdb0003SharedService;

    @Autowired
    private BatchDataHolder batchDataHolder;

    /**
     * 月次確定の表示用テーブル更新の実行結果を確認する
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return ステータス
     * @throws InterruptedException スレッドスリープの際に異常があった場合(基本的に発生しないはず)
     */
    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws InterruptedException {

        String jobStartDateTime = batchDataHolder.getJobStartDateTime();

        // 全ての処理の終了まで待つ (規定時間を待っても終わらない or 異常終了していた場合は例外をスロー)
        mdb0003SharedService.checkAllExecuteResult(setTargetJobNames(), jobStartDateTime, TARGET_JOB_NUMBER);

        return RepeatStatus.FINISHED;
    }

    private List<String> setTargetJobNames() {
        List<String> resultList = new ArrayList<>();

        resultList.add(DISP_PROPERTY_JOB_NAME);
        resultList.add(DISP_OUTSOURCING_JOB_NAME);

        return resultList;
    }
}
