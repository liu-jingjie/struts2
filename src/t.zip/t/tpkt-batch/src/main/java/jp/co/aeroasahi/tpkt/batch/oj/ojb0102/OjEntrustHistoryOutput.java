package jp.co.aeroasahi.tpkt.batch.oj.ojb0102;

import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

/**
 * 委託履歴のOutputBean.
 * <p>
 * 委託履歴のOutputBean.
 * </p>
 */

@Getter
@Setter
public class OjEntrustHistoryOutput {
    /**
     * 申請番号.
     */
    private String applyNum;
    /**
     * 委託先枝番.
     */
    private int entrustBranchNum;
    /**
     * 委託先の評価点数.
     */
    private BigDecimal vendorEvaluatePoints;

}
