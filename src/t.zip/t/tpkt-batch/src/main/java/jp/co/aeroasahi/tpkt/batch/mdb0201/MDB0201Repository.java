package jp.co.aeroasahi.tpkt.batch.mdb0201;

import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 * テーブル＜SAP受注＞＜ビジネスユニットコード変換＞＜【TEMP】受注＞＜SAP勘定明細＞＜【TEMP】売上＞に操作
 */
public interface MDB0201Repository {

    /**
     * 条件によって、テーブル＜【TEMP】売上＞の情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0201SaleOutput> findAllBySaleCompar(@Param("pjIdList") String pjIdList);

    /**
     * 条件によって、テーブル＜【TEMP】受注＞の情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0201OrderOutput> findAllByOrderCompar();

    /**
     * テーブル＜【TEMP】受注＞に更新する。
     *
     * @param output MDB0201OrderOutput
     * @return
     */
    void updateOrder(MDB0201OrderOutput output);

    /**
     * テーブル＜【TEMP】受注＞(売上日は設定後)に更新する。
     *
     * @param output MDB0201OrderOutput
     * @return
     */
    void updateOrderSoldOn(MDB0201OrderOutput output);

    /**
     * 条件によって、テーブル＜【TEMP】受注＞の情報を取得する。
     *
     * @param 対象のプロジェクトIDリストの文字列
     * @return データ情報
     */
    List<MDB0201OrderOutput> findAllByOrderUpdate(@Param("pjidListStr") String pjidListStr);

    /**
     * 条件によって、テーブル＜SAP受注＞＜ビジネスユニットコード変換＞の情報を取得する。
     *
     * @param systemYMD システム日付（バッチ実行日、もしくはシステム日付から見て一番最新の日付）
     * @return データ情報
     */
    List<MDB0201OrderInput> findAllOrder(@Param("systemYMD") String systemYMD);

    /**
     * テーブル＜【TEMP】受注＞に削除する。
     *
     * @param systemYMD システム日付（バッチ実行日、もしくはシステム日付から見て一番最新の日付）
     * @return
     */
    void deleteOrder(@Param("systemYMD") String systemYMD);

    /**
     * テーブル＜【TEMP】受注＞に登録する。
     *
     * @param output MDB0201Output
     * @return
     */
    void createOrder(MDB0201OrderOutput output);

    /**
     * 条件によって、テーブル＜SAP勘定明細＞＜ビジネスユニットコード変換＞の情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0201SaleInput> findAllSale(MDB0201SaleInput input);

    /**
     * テーブル＜【TEMP】売上＞に削除する。
     *
     * @return
     */
    void deleteSale(MDB0201SaleInput input);

    /**
     * テーブル＜【TEMP】売上＞に登録する。
     *
     * @param output MDB0201SaleOutput
     * @return
     */
    void createSale(MDB0201SaleOutput output);

    /**
     * 条件によって、テーブル＜【TEMP】売上＞の情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0201SaleOutput> findAllByPjIds(@Param("pjIdList") List<String> pjIdList);

    /**
     * テーブル＜【TEMP】売上＞に更新する。
     *
     * @param output MDB0201SaleOutput
     * @return
     */
    void updateSale(MDB0201SaleOutput output);

    /**
     * テーブル＜SAP受注＞のMax更新日を取得する
     *
     * @return Max更新日
     */
    String findAllByMaxUpdDt();

    /**
     * （事前処理）,［【TEMP】受注．売上日］を全てNULLに更新する。
     *
     * @return
     */
    void updateBySoldOn();

}