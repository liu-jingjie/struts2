package jp.co.aeroasahi.tpkt.batch.fwb0111;

import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.batch.item.ItemCountAware;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】SAP仕入先マスタ＞のOutputBean。
 */
@Setter
@Getter
public class FWB0111Output implements ItemCountAware{

    private int count;

    /** 処理区分 */
    @Size(min = 0, max = 1)
    private String KBN;

    /** 共通転記ブロック */
    @Size(min = 0, max = 1)
    private String SPERR;

    /** 仕入先または債権者の勘定コード */
    @NotBlank
    @Size(min = 1, max = 10)
    private String LIFNR;

    /** 会社コード */
    @Size(min = 0, max = 4)
    private String BUKRS;

    /** 勘定グループ */
    @Size(min = 0, max = 4)
    private String KTOKK;

    /** 名称１ */
    @Size(min = 0, max = 40)
    private String NAME1;

    /** 名称２ */
    @Size(min = 0, max = 40)
    private String NAME2;

    /** 名称３ */
    @Size(min = 0, max = 40)
    private String NAME3;

    /** 名称４ */
    @Size(min = 0, max = 40)
    private String NAME4;

    /** 検索用語1 */
    @Size(min = 0, max = 20)
    private String SORT1;

    /** 検索用語2 */
    @Size(min = 0, max = 20)
    private String SORT2;

    /** 地域（都道府県） */
    @Size(min = 0, max = 3)
    private String REGION;

    /** 地名 */
    @Size(min = 0, max = 60)
    private String STREET;

    /** 市区町村の郵便番号 */
    @Size(min = 0, max = 10)
    private String POST_CODE1;

    /** 市区町村 */
    @Size(min = 0, max = 40)
    private String CITY1;

    /** 所在地 */
    @Size(min = 0, max = 40)
    private String CITY2;

    /** 地名２ */
    @Size(min = 0, max = 40)
    private String STR_SUPPL1;

    /** 地名３ */
    @Size(min = 0, max = 40)
    private String STR_SUPPL2;

    /** 国コード */
    @Size(min = 0, max = 3)
    private String COUNTRY;

    /** 電話番号: コード + 番号をダイアル */
    @Size(min = 0, max = 30)
    private String TEL_NUMBER;

    /** 電話番号: 内線 */
    @Size(min = 0, max = 10)
    private String TEL_EXTENS;

    /** FAX 番号: 局番 + 番号 */
    @Size(min = 0, max = 30)
    private String FAX_NUMBER;

    /** 電子メールアドレス */
    @Size(min = 0, max = 241)
    private String SMTP_ADDR;

    /** 通信方法 (キー) (ビジネスアドレスサービス) */
    @Size(min = 0, max = 3)
    private String DEFLT_COMM;

    /** 住所注記 */
    @Size(min = 0, max = 50)
    private String REMARK;

    /** 名称１ */
    @Size(min = 0, max = 40)
    private String NAME1_B;

    /** 名称２ */
    @Size(min = 0, max = 40)
    private String NAME2_B;

    /** 名称３ */
    @Size(min = 0, max = 40)
    private String NAME3_B;

    /** 名称４ */
    @Size(min = 0, max = 40)
    private String NAME4_B;

    /** 検索語句 1 */
    @Size(min = 0, max = 20)
    private String SORT1_B;

    /** 検索語句 2 */
    @Size(min = 0, max = 20)
    private String SORT2_B;

    /** 地域（都道府県） */
    @Size(min = 0, max = 3)
    private String REGION_B;

    /** 地名 */
    @Size(min = 0, max = 60)
    private String STREET_B;

    /** 市区町村 */
    @Size(min = 0, max = 40)
    private String CITY1_B;

    /** 所在地 */
    @Size(min = 0, max = 40)
    private String CITY2_B;

    /** 地名２ */
    @Size(min = 0, max = 40)
    private String STR_SUPPL1_B;

    /** 地名３ */
    @Size(min = 0, max = 40)
    private String STR_SUPPL2_B;

    /** 部屋/アパート番号 */
    @Size(min = 0, max = 10)
    private String ROOMNUMBER_B;

    /** 住所注記 */
    @Size(min = 0, max = 50)
    private String REMARK_B;

    /** 名称１ */
    @Size(min = 0, max = 40)
    private String NAME1_C;

    /** 名称２ */
    @Size(min = 0, max = 40)
    private String NAME2_C;

    /** 名称３ */
    @Size(min = 0, max = 40)
    private String NAME3_C;

    /** 名称４ */
    @Size(min = 0, max = 40)
    private String NAME4_C;

    /** 検索語句 1 */
    @Size(min = 0, max = 20)
    private String SORT1_C;

    /** 検索語句 2 */
    @Size(min = 0, max = 20)
    private String SORT2_C;

    /** 地域（都道府県） */
    @Size(min = 0, max = 3)
    private String REGION_C;

    /** 地名 */
    @Size(min = 0, max = 60)
    private String STREET_C;

    /** 市区町村 */
    @Size(min = 0, max = 40)
    private String CITY1_C;

    /** 所在地 */
    @Size(min = 0, max = 40)
    private String CITY2_C;

    /** 地名２ */
    @Size(min = 0, max = 40)
    private String STR_SUPPL1_C;

    /** 地名３ */
    @Size(min = 0, max = 40)
    private String STR_SUPPL2_C;

    /** 部屋/アパート番号 */
    @Size(min = 0, max = 10)
    private String ROOMNUMBER_C;

    /** 住所注記 */
    @Size(min = 0, max = 50)
    private String REMARK_C;

    /** 得意先コード */
    @Size(min = 0, max = 10)
    private String KUNNR;

    /** 取引先の会社 ID */
    @Size(min = 0, max = 6)
    private String VBUND;

    /** グループキー */
    @Size(min = 0, max = 10)
    private String KONZS;

    /** 標準キャリアコード */
    @Size(min = 0, max = 4)
    private String SCACD;

    /** 源泉徴収税対象者の出生地 */
    @Size(min = 0, max = 25)
    private String GBORT;

    /** 銀行国コード */
    @Size(min = 0, max = 3)
    private String BANKS;

    /** 銀行コード */
    @Size(min = 0, max = 15)
    private String BANKL;

    /** 口座番号 */
    @Size(min = 0, max = 18)
    private String BANKN;

    /** 口座名義人名 */
    @Size(min = 0, max = 60)
    private String KOINH;

    /** 預金種別 */
    @Size(min = 0, max = 2)
    private String BKONT;

    /** 銀行手数料負担コード */
    @Size(min = 0, max = 2)
    private String DTAWS;

    /** 総勘定元帳の統制勘定 */
    @Size(min = 0, max = 10)
    private String AKONT;

    /** 本店勘定コード */
    @Size(min = 0, max = 10)
    private String LNRZE;

    /** 計画グループ */
    @Size(min = 0, max = 10)
    private String FDGRV;

    /** 旧マスタレコードのコード */
    @Size(min = 0, max = 10)
    private String ALTKN;

    /** 少数コード */
    @Size(min = 0, max = 3)
    private String MINDK;

    /** 従業員番号 */
    @Size(min = 0, max = 8)
    private String PERNR;

    /** 支払条件キー */
    @Size(min = 0, max = 4)
    private String ZTERM;

    /** 考慮される支払方法一覧 */
    @Size(min = 0, max = 10)
    private String ZWELS;

    /** フラグ: 得意先と仕入先間の相殺決済 */
    @Size(min = 0, max = 1)
    private String XVERR;

    /** 下請法対象候補区分 */
    @Size(min = 0, max = 2)
    private String MGRUP;

    /** 記帳担当者 */
    @Size(min = 0, max = 2)
    private String BUSAB;

    /** 関係会社担当者のインターネットアドレス */
    @Size(min = 0, max = 130)
    private String INTAD;

    /** コメント */
    @Size(min = 0, max = 30)
    private String KVERM;

    /** 源泉徴収税国コード */
    @Size(min = 0, max = 3)
    private String QLAND;

    /** 源泉徴収税タイプコード */
    @Size(min = 0, max = 2)
    private String WITHT;

    /** 源泉徴収税コード */
    @Size(min = 0, max = 2)
    private String WT_WITHCD;

    /** フラグ:源泉税課税対象 */
    @Size(min = 0, max = 1)
    private String WT_SUBJCT;

    /** 処理ステータス */
    @Size(min = 0, max = 2)
    private String STATUS;

    /** メッセージテキスト */
    @Size(min = 0, max = 255)
    private String MSG_TEXT;

    /** 作成日 */
    @Size(min = 23, max = 23)
    private String INS_DT;

    /** 更新日 */
    @Size(min = 23, max = 23)
    private String UPD_DT;

    @Override
    public void setItemCount(int count) {
        this.count = count;
    }
}
