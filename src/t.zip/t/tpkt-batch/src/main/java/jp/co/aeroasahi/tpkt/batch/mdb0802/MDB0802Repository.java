package jp.co.aeroasahi.tpkt.batch.mdb0802;

import java.util.List;

/**
 * テーブルに操作
 */
public interface MDB0802Repository {

    /**
     * テーブル＜受注＞の中に、レコードの削除フラグは全て１のレコード情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0802Output> findAllByCanceled();

    /**
     * (日次)(支払日がNULL以外の場合)条件によって、テーブル＜外注情報＞＜プロジェクト＞＜プロジェクト属性＞＜委託先マスタ＞＜応受援基本情報＞
     * ＜応受援委託先枝番情報＞＜金額＞＜社員＞＜部門マスタ＞＜部門表示順マスタ＞＜受注＞の情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0802Input> findAllDay1(MDB0802Input input);

    /**
     * (日次)(支払日がNULLの場合)条件によって、テーブル＜外注情報＞＜プロジェクト＞＜プロジェクト属性＞＜委託先マスタ＞＜応受援基本情報＞
     * ＜応受援委託先枝番情報＞＜金額＞＜社員＞＜部門マスタ＞＜部門表示順マスタ＞＜受注＞の情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0802Input> findAllDay2(MDB0802Input input);

    /**
     * (月次)(支払日がNULL以外かつ指定月以前の日付の場合)条件によって、テーブル＜外注情報＞＜プロジェクト＞＜プロジェクト属性＞＜委託先マスタ＞＜応受援基本情報＞
     * ＜応受援委託先枝番情報＞＜金額＞＜社員＞＜部門マスタ＞＜部門表示順マスタ＞＜受注＞の情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0802Input> findAllMonth1(MDB0802Input input);

    /**
     * (月次)(支払日がNULL以外かつ指定月より未来日、または、支払日がNULLの場合)条件によって、テーブル＜外注情報＞＜プロジェクト＞＜プロジェクト属性＞＜委託先マスタ＞＜応受援基本情報＞
     * ＜応受援委託先枝番情報＞＜金額＞＜社員＞＜部門マスタ＞＜部門表示順マスタ＞＜受注＞の情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0802Input> findAllMonth2(MDB0802Input input);

    /**
     * テーブル＜【TEMP】外注管理＞に登録する。
     *
     * @param output MDB0802Output
     * @return
     */
    void create(MDB0802Output output);

    /**
     * テーブル＜【TEMP】外注管理＞に削除する。
     *
     * @return
     */
    void delete();

}