package jp.co.aeroasahi.tpkt.batch.fwb0108;

import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】SAP受注＞のInputBean。
 */
@Setter
@Getter
public class FWB0108Input {

    /** 受注伝票番号 */
    private String VBELN;

    /** 得意先コード */
    private String KUNNR;

    /** プロジェクトID */
    private String PS_PSP_PNR;

    /** 受注日 */
    private String AUDAT;

    /** 受注明細番号 */
    private String POSNR;

    /** 受注金額（税抜き） */
    private String NETWR;

    /** 売上予定日 */
    private String FKDAT;

    /** 積算原価額 */
    private String ZSEKISANA3;

    /** 個人情報 */
    private String ZKOJIN;

    /** 高原価・政策受注フラグ */
    private String ZKOUFLAG;

    /** 受注申請時積算原価率 */
    private String ZSEKISANR3;

    /** 作成日 */
    private String INS_DT;

    /** 更新日 */
    private String UPD_DT;

}
