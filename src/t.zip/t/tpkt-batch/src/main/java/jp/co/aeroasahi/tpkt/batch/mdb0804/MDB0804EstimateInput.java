package jp.co.aeroasahi.tpkt.batch.mdb0804;

import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜積算月別展開データ＞＜プロジェクト＞＜部門マスタ＞＜部門表示順マスタ＞のInputBean。
 */
@Setter
@Getter
public class MDB0804EstimateInput {

    /** プロジェクト．生産・営業担当の部門CD */
    private String proSalesDeptCd;

    /** 部門マスタの部門名称 */
    private String deptName;

    /** 部門マスタの会社名 */
    private String corpName;

    /** 部門マスタの支社コード */
    private String branchCd;

    /** 部門マスタの支社名 */
    private String branchName;

    /** 部門マスタの中部門CD */
    private String deptMCd;

    /** 部門マスタの中部門名称 */
    private String deptMName;

    /** 部門マスタの小部門CD */
    private String deptSCd;

    /** 部門マスタの小部門名称 */
    private String deptSName;

    /** 部門マスタの部門種別 */
    private String deptType;

    /** 積算月別展開データの作業年月 */
    private String workYm;

    /** 積算月別展開データの費目CD */
    private String himokuCd;

    /** 積算月別展開データの数量の合計 */
    private BigDecimal quantity;

    /** 部門表示順マスタの表示順 */
    private BigDecimal dispOrder;

    /** 年度 検索用*/
    private String ym3;

    /** システム日付（YYYY-MM-DD）*/
    private String systemDate;
}
