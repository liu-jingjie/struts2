package jp.co.aeroasahi.tpkt.batch.oj.ojb0102;

import lombok.Getter;
import lombok.Setter;

/**
 * 応受援帳票登録のOutputBean.
 * <p>
 * 応受援帳票登録のOutputBean.
 * </p>
 */
@Getter
@Setter
public class OjDocRegInfoOutput {
    /**
     * 申請番号.
     */
    private String applyNum;
    /**
     * 委託先枝番.
     */
    private int entrustBranchNum;
    /**
     * 応受援帳票種別.
     */
    private String ojuenDocType;
    /**
     * ファイルパス.
     */
    private String filePath;

    /**
     * ファイルパス(一時).
     */
    private String filePathTemp;
    /**
     * ファイル名.
     */
    private String fileName;
    /**
     * 作成日付.
     */
    private String createdAt;
    /**
     * 更新日付.
     */
    private String updatedAt;

}
