package jp.co.aeroasahi.tpkt.batch.sbb0201;

import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

/**
 * SAP金額抽出Bean。
 */
@Setter
@Getter
public class SBB0201SapCost {

    /** プロジェクトID */
    private String pjId;

    /** 応札積算額 */
    private BigDecimal osatsuPlanedAmount;

    /** 総原価 */
    private BigDecimal allCost;

    /** 発生原価 */
    private BigDecimal occuredCost;

}
