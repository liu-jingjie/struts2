package jp.co.aeroasahi.tpkt.batch.oj.ojb0101;

import lombok.Getter;
import lombok.Setter;

/**
 * 承認リマインド用Bean
 *
 */
@Setter
@Getter
public class OJB0101AdmitRemindInfor {

    /** 申請番号 */
    private String applyNum;
    /** プロジェクトID */
    private String pjId;
    /** 申請方法 */
    private String applyWay;
    /** 現承認者コード */
    private String currentApprovedBy;
    /** 社員名 */
    private String empName;
    /** メールアドレス */
    private String mailAddress;
}
