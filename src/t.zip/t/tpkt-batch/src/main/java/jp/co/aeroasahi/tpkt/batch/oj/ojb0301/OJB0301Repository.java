package jp.co.aeroasahi.tpkt.batch.oj.ojb0301;

import java.sql.Date;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;

/**
 * 支払処理日反映
 *
 */
public interface OJB0301Repository {



    /**
     * 応受援基本情報を更新。
     *
     * @param kbn
     * @param date
     * @param today
     */

    int updateBaseInfor(@Param("kbn") String kbn, @Param("date") String date, @Param("today") Date today);

    /**
     * 応受援委託先枝番情報のステータスを更新。
     *
     * @param kbn
     * @param date
     * @param today
     */
    int updateEntrustStatus(@Param("kbn") String kbn, @Param("date") String date, @Param("today") Date today);

    /**
     * メール情報を取得。
     *
     * @param kbn
     * @param date
     * @param today
     *
     */
    List<MailInforOutput> findMailInfor(@Param("kbn") String kbn, @Param("date") String date,
            @Param("today") Date today);

    /**
     * 応受援承認の現承認者CDを更新。
     *
     * @param kbn
     * @param date
     * @param today
     */
    int updateApprove(@Param("kbn") String kbn, @Param("date") String date, @Param("today") Date today);
    /**
     * 応受援委託先枝番情報を更新。
     *
     * @param kbn
     * @param date
     * @param today
     */
    int updateEntrustBranch(@Param("kbn") String kbn, @Param("date") String date, @Param("today") Date today);
    /**
     * 申請番号リストによって応受援委託先枝番情報を更新
     *
     * @param kbn
     * @param date
     * @param ablad
     * @param today
     */
    int updateEntrustBranchByList(@Param("kbn") String kbn, @Param("date") String date,
            @Param("ablad") String ablad, @Param("today") Date today);

    /**
     * 勘定明細に同一の申請番号のデータが存在するかつ
     * ［勘定明細．金額］を加算して０になる場合、申請番号を取得
     *
     * @param kbn
     * @param date
     * @param today
     * @return
     */
    List<Map<String, String>> findAppliedNum(@Param("kbn") String kbn, @Param("date") String date,
            @Param("today") Date today);
}
