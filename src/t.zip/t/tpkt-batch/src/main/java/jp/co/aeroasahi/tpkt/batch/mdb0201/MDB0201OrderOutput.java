package jp.co.aeroasahi.tpkt.batch.mdb0201;

import java.math.BigDecimal;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.batch.item.ItemCountAware;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】受注＞のOutputBean。
 */
@Setter
@Getter
public class MDB0201OrderOutput implements ItemCountAware {

    private int count;

    /** ビジネスユニット */
    @NotBlank
    @Size(min = 0, max = 5)
    private String bu;

    /** 受注番号 */
    @NotBlank
    @Size(min = 0, max = 10)
    private String receiveNum;

    /** 受注明細番号 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal receiveDtlNum;

    /** プロジェクト属性ID */
    @Size(min = 0, max = 8)
    private String pjAttId;

    /** プロジェクトID */
    @NotBlank
    @Size(min = 0, max = 12)
    private String pjId;

    /** 受注日 */
    @Size(min = 0, max = 10)
    private String receivedOn;

    /** 受注金額 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal receivedAmount;

    /** 売上予定日 */
    @Size(min = 0, max = 10)
    private String planedSellingOn;

    /** 売上日 */
    @Size(min = 0, max = 10)
    private String soldOn;

    /** 応札積算額 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal osatsuPlanedAmount;

    /** 高原価・政策受注フラグ */
    @Size(min = 0, max = 1)
    private String highCostReceive;

    /** 受注申請時積算原価率 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal receivedPlanedRate;

    /** キャンセルフラグ */
    @Size(min = 1, max = 1)
    private String canceled;

    /** 作成日 */
    @Size(min = 0, max = 23)
    private String createdAt;

    /** 更新日 */
    @Size(min = 0, max = 23)
    private String updatedAt;

    @Override
    public void setItemCount(int count) {
        this.count = count;
    }
}
