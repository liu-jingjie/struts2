package jp.co.aeroasahi.tpkt.batch.oj.ojb0101;

import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.inject.Inject;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;
import jp.co.aeroasahi.tpkt.common.fw.mail.MailRequestSharedService;
import jp.co.aeroasahi.tpkt.common.fw.template.TemplateService;
import jp.co.aeroasahi.tpkt.common.model.fw.MailManagement;

/**
 *
 * 承認リマインドを作成する
 *
 */
@Component
@Scope("step")
public class OJB0101Tasklet implements Tasklet {

    @Inject
    DateFactory dateFactory;

    @Inject
    MailRequestSharedService mailRequestSharedService;

    @Inject
    OJB0101Repository ojb0101Repository;

    @Inject
    TemplateService templateService;

    @Value("${baseUrl}")
    String baseUrl;

    /** DateFormatterのパターン yyyy-MM-dd */
    private static final DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    @Transactional
    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
        // システム日を作成
        String sysdate = dateFactory.newDate().format(dateFormat);

        // 承認リマインドデータを取得
        List<OJB0101AdmitRemindInfor> oJB0101AdmitRemindInfor = ojb0101Repository.findAdmitInfor(sysdate);

        for (OJB0101AdmitRemindInfor ojb0101AdmitRemindInfor : oJB0101AdmitRemindInfor) {
            // 承認リマインドごとに送信
            sendMail(ojb0101AdmitRemindInfor);
        }

        return RepeatStatus.FINISHED;
    }

    /**
     * 送信機能
     * <p>
     * 承認リマインド情報からユーザーへ送信する
     * </p>
     *
     * @param oJB0101AdmitRemindInfor 承認リマインド情報
     */
    private void sendMail(OJB0101AdmitRemindInfor oJB0101AdmitRemindInfor) {
        // メール本文作成
        Map<String, String> mailBodyParameter = new HashMap<String, String>();

        String applyWay = oJB0101AdmitRemindInfor.getApplyWay();
        String pjId = oJB0101AdmitRemindInfor.getPjId();

        String applyNum = oJB0101AdmitRemindInfor.getApplyNum();
        String resourcePath = "";
        // 一般・G間
        if (ApplyWayEnum.GENERAL_GKAN.getOjuenApplyWay().equals(applyWay)) {
            resourcePath = "/oj/apply/approve/" + applyNum + "/" + pjId;
            // 上記以外の場合
        } else {
            resourcePath = "/oj/asahi/approve/" + applyNum;
        }
        mailBodyParameter.put("userName", oJB0101AdmitRemindInfor.getEmpName());
        mailBodyParameter.put("urlParam", baseUrl + resourcePath);

        String approveRequestMailBody = templateService.create("t_oj_005", mailBodyParameter);

        // メール送信機能呼び出し
        MailManagement approveRequestMailManagement = new MailManagement();
        approveRequestMailManagement.setMailAddressTo(oJB0101AdmitRemindInfor.getMailAddress());
        approveRequestMailManagement.setMailAddressCc("");
        approveRequestMailManagement.setSubject("承認リマインド");
        approveRequestMailManagement.setBody(approveRequestMailBody);
        mailRequestSharedService.requestNoAttachmentMail(approveRequestMailManagement);
    }


    /**
     * 申請方法
     * <p>
     * 応受援申請方法の定数を設定する。
     * </p>
     */
    public enum ApplyWayEnum {
        // 一般・G間
        GENERAL_GKAN("1"),
        // 朝日航空等
        ASAHI_AIR_ETC("2");

        private String ojuenApplyWay = "";

        private ApplyWayEnum(String ojuenApplyWay) {
            this.ojuenApplyWay = ojuenApplyWay;
        }

        public String getOjuenApplyWay() {
            return this.ojuenApplyWay;
        }
    }

}

