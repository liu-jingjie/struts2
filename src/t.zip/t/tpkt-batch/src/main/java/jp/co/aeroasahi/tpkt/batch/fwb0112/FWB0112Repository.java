package jp.co.aeroasahi.tpkt.batch.fwb0112;

import java.util.List;

/**
 * テーブル＜【TEMP】SAPプロジェクト属性＞に操作
 */
public interface FWB0112Repository {

    /**
     * テーブル＜【TEMP】SAPプロジェクト属性＞情報を取得する。
     *
     * @return データ情報
     */
    List<FWB0112Output> findAll();

    /**
     * テーブル＜汎用マスタ＞情報を取得する。
     *
     * @return データ情報
     */
    List<FWB0112Output> findAllByTypeId();

    /**
     * テーブル＜【TEMP】SAPプロジェクト属性＞に登録する。
     *
     * @param output FWB0112Output
     * @return
     */
    void create(FWB0112Output output);

    /**
     * テーブル＜【TEMP】SAPプロジェクト属性＞に更新する。
     *
     * @param output FWB0112Output
     * @return
     */
    void update(FWB0112Output output);

    /**
     * テーブル＜【TEMP】プロジェクト属性＞情報を取得する。
     *
     * @return データ情報
     */
    List<FWB0112TpktOutput> findAllTpkt();

    /**
     * テーブル＜【TEMP】プロジェクト属性＞に登録する。
     *
     * @param output FWB0112TpktOutput
     * @return
     */
    void tpktCreate(FWB0112TpktOutput output);

    /**
     * テーブル＜【TEMP】プロジェクト属性＞に更新する。
     *
     * @param output FWB0112TpktOutput
     * @return
     */
    void tpktUpdate(FWB0112TpktOutput output);
}
