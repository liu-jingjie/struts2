package jp.co.aeroasahi.tpkt.batch.mdb0004;

import org.springframework.stereotype.Component;
import lombok.Getter;
import lombok.Setter;

@Component
@Setter
@Getter
public class BatchDataHolder {

    private boolean CheckResult;

    private String systemDateTime;

}
