package jp.co.aeroasahi.tpkt.batch.mdb0003.job1;

import javax.inject.Inject;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.mdb0003.BatchDataHolder;
import jp.co.aeroasahi.tpkt.batch.mdb0003.MDB0003Repository;
import jp.co.aeroasahi.tpkt.batch.mdb0003.MDB0003SharedServiceImpl;

/**
 * 発注書番号取込の実行結果を確認するTasklet
 */
@Component
@Scope("step")
public class MDB0003Tasklet12 implements Tasklet {

    /** 発注書番号取込ジョブ名 */
    private static final String ORDER_NUM_JOB_NAME = "ojb0201Job";

    /** ジョブ番号 */
    private static final int TARGET_JOB_NUMBER = 1;

    @Inject
    MDB0003SharedServiceImpl mdb0003SharedService;

    @Inject
    MDB0003Repository mdb0003Repository;

    @Autowired
    private BatchDataHolder batchDataHolder;


    /**
     *
     * 発注書番号取込の実行結果を確認する
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return 一括で各ジョブを実行した状態
     * @throws InterruptedException スレッドスリープの際に異常があった場合(基本的に発生しないはず)
     */
    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws InterruptedException {


        String jobStartDateTimeStr = batchDataHolder.getJobStartDateTime();

        // 発注書番号取込の終了まで待つ (規定時間を待っても終わらない or 異常終了していた場合は例外をスロー)
        mdb0003SharedService.checkExecuteResult(ORDER_NUM_JOB_NAME, jobStartDateTimeStr, TARGET_JOB_NUMBER);

        return RepeatStatus.FINISHED;
    }
}
