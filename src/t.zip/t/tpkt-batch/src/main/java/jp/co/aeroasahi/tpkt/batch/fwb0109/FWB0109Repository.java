package jp.co.aeroasahi.tpkt.batch.fwb0109;

/**
 * テーブル＜【TEMP】SAP発注番号＞に操作
 */
public interface FWB0109Repository {

    /**
     * テーブル＜【TEMP】SAP発注番号＞に登録する。
     *
     * @param output FWB0109Output
     * @return
     */
    void create(FWB0109Output output);

    /**
     * テーブル＜【TEMP】SAP発注番号＞に更新する。
     *
     * @param output FWB0109Output
     * @return
     */
    void delete(FWB0109Output output);
}
