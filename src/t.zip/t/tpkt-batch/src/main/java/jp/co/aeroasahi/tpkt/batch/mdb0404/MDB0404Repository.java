package jp.co.aeroasahi.tpkt.batch.mdb0404;

import java.util.List;

/**
 * テーブル＜【TEMP】部門別経費＞＜SAP勘定明細＞＜SAP勘定残高＞に操作
 */
public interface MDB0404Repository {

    /**
     * 条件によって、テーブル＜SAP勘定明細＞の情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0404Input> findAllDetailDay(MDB0404Input input);

    /**
     * 条件によって、テーブル＜SAP勘定残高＞の実績情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0404Input> findAllBalanceAchievementDay(MDB0404Input input);

    /**
     * 条件によって、テーブル＜SAP勘定残高＞の積算情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0404Input> findAllBalanceEstimateDay(MDB0404Input input);

    /**
     * 条件によって、テーブル＜SAP勘定明細＞の情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0404Input> findAllDetailMonth(MDB0404Input input);

    /**
     * 条件によって、テーブル＜SAP勘定残高＞の実績情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0404Input> findAllBalanceAchievementMonth(MDB0404Input input);

    /**
     * 条件によって、テーブル＜SAP勘定残高＞の積算情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0404Input> findAllBalanceEstimateMonth(MDB0404Input input);

    /**
     * テーブル＜【TEMP】部門別経費＞に削除する。
     *
     * @param output MDB0404Output
     * @return
     */
    void deleteDay(MDB0404Output output);

    /**
     * テーブル＜【TEMP】部門別経費＞に削除する。
     *
     * @param output MDB0404Output
     * @return
     */
    void deleteMonth(MDB0404Output output);

    /**
     * テーブル＜【TEMP】部門別経費＞に登録する。
     *
     * @param output MDB0404Output
     * @return
     */
    void create(MDB0404Output output);
}