package jp.co.aeroasahi.tpkt.batch.mdb0801;

import java.math.BigDecimal;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.batch.item.ItemCountAware;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】物件管理＞のOutputBean。
 */
@Setter
@Getter
public class MDB0801Output implements ItemCountAware, Cloneable {

    private int count;

    /** 売上年度 */
    @NotNull
    @DecimalMin("1900")
    @DecimalMax("9999")
    private BigDecimal soldFiscalYear;

    /** プロジェクトID */
    @NotBlank
    @Size(min = 1, max = 12)
    private String pjId;

    /** プロジェクト名称 */
    @Size(min = 0, max = 160)
    private String pjName;

    /** 物件区分 */
    @Size(min = 0, max = 1)
    private String pjKbn;

    /** 名義会社 */
    @Size(min = 0, max = 5)
    private String meigiCorpCd;

    /** 顧客名称 */
    @Size(min = 0, max = 40)
    private String customerName;

    /** BU */
    @Size(min = 0, max = 2)
    private String bu;

    /** プロジェクト属性ID */
    @Size(min = 0, max = 8)
    private String pjAttId;

    /** 枝番 */
    @Size(min = 0, max = 2)
    private String branchNum;

    /** 契約件名 */
    @Size(min = 0, max = 160)
    private String contractName;

    /** 契約工期(FROM) */
    @Size(min = 0, max = 10)
    private String contractFrom;

    /** 契約工期(TO) */
    @Size(min = 0, max = 10)
    private String contractTo;

    /** 取引種別 */
    @Size(min = 0, max = 1)
    private String dealType;

    /** 案件情報 */
    @Size(min = 0, max = 2)
    private String pjInfo;

    /** 分野コード */
    @Size(min = 0, max = 2)
    private String fieldCd;

    /** 分野コード名称 */
    @Size(min = 0, max = 30)
    private String fieldName;

    /** 業務コード */
    @Size(min = 0, max = 3)
    private String businessCd;

    /** 業務コード名称 */
    @Size(min = 0, max = 30)
    private String businessName;

    /** 顧客種別 */
    @Size(min = 0, max = 6)
    private String customerCategoryCd;

    /** 物件管理責任者部門支社ＣＤ */
    @Size(min = 0, max = 6)
    private String pjManageRespDeptBranchCd;

    /** 物件管理責任者部門支社名称 */
    @Size(min = 0, max = 30)
    private String pjManageRespDeptBranchName;

    /** 物件管理責任者部門部ＣＤ */
    @Size(min = 0, max = 6)
    private String pjManageRespMDeptCd;

    /** 物件管理責任者部門部名称 */
    @Size(min = 0, max = 30)
    private String pjManageRespMDeptName;

    /** 物件管理責任者部門部署ＣＤ */
    @Size(min = 0, max = 6)
    private String pjManageRespDeptCd;

    /** 物件管理責任者部門部署名称 */
    @Size(min = 0, max = 30)
    private String pjManageRespDeptName;

    /** 物件管理責任者ＣＤ */
    @Size(min = 0, max = 5)
    private String pjManageRespEmpCd;

    /** 物件管理責任者名 */
    @Size(min = 0, max = 50)
    private String pjManageRespEmpName;

    /** 生産主管部門支社ＣＤ */
    @Size(min = 0, max = 6)
    private String productMainDeptBranchCd;

    /** 生産主管部門支社名称 */
    @Size(min = 0, max = 30)
    private String productMainDeptBranchName;

    /** 生産主管部門部ＣＤ */
    @Size(min = 0, max = 6)
    private String productMainMDeptCd;

    /** 生産主管部門部名称 */
    @Size(min = 0, max = 30)
    private String productMainMDeptName;

    /** 生産主管部門ＣＤ */
    @Size(min = 0, max = 6)
    private String productMainDeptCd;

    /** 生産主管部門名称 */
    @Size(min = 0, max = 30)
    private String productMainDeptName;

    /** 生産プロデューサーＣＤ */
    @Size(min = 0, max = 5)
    private String productProducerEmpCd;

    /** 生産プロデューサー名 */
    @Size(min = 0, max = 50)
    private String productProducerName;

    /** 営業主管部門支社ＣＤ */
    @Size(min = 0, max = 6)
    private String salesMainDeptBranchCd;

    /** 営業主管部門支社名称 */
    @Size(min = 0, max = 30)
    private String salesMainDeptBranchName;

    /** 営業主管部門部ＣＤ */
    @Size(min = 0, max = 6)
    private String salesMainMDeptCd;

    /** 営業主管部門部名称 */
    @Size(min = 0, max = 30)
    private String salesMainMDeptName;

    /** 営業主管部門ＣＤ */
    @Size(min = 0, max = 6)
    private String salesMainDeptCd;

    /** 営業主管部門名称 */
    @Size(min = 0, max = 30)
    private String salesMainDeptName;

    /** 営業担当者ＣＤ */
    @Size(min = 0, max = 5)
    private String salesEmpCd;

    /** 営業担当者名 */
    @Size(min = 0, max = 50)
    private String salesEmpName;

    /** 生産担当部門支社ＣＤ */
    @Size(min = 0, max = 6)
    private String productDeptBranchCd;

    /** 生産担当部門支社名称 */
    @Size(min = 0, max = 30)
    private String productDeptBranchName;

    /** 生産担当部門部ＣＤ */
    @Size(min = 0, max = 6)
    private String productMDeptCd;

    /** 生産担当部門部名称 */
    @Size(min = 0, max = 30)
    private String productMDeptName;

    /** 生産担当部門ＣＤ */
    @Size(min = 0, max = 6)
    private String productDeptCd;

    /** 生産担当部門名称 */
    @Size(min = 0, max = 30)
    private String productDeptName;

    /** 生産担当者ＣＤ */
    @Size(min = 0, max = 5)
    private String productEmpCd;

    /** 生産担当者名 */
    @Size(min = 0, max = 50)
    private String productEmpName;

    /** 受注区分 */
    @Size(min = 0, max = 1)
    private String receiveKbn;

    /** 受注日 */
    @Size(min = 0, max = 10)
    private String receivedOn;

    /** 受注額 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal receivedMoney;

    /** 受注原価率 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal receivedCostRate;

    /** 売上種別 */
    @Size(min = 0, max = 2)
    private String salesType;

    /** 当該年度売上予定日 */
    @Size(min = 0, max = 10)
    private String thisFiscalYearPlanedSellingOn;

    /** 当該年度売上日 */
    @Size(min = 0, max = 10)
    private String thisFiscalYearSoldOn;

    /** 最終売上予定日 */
    @Size(min = 0, max = 10)
    private String lastPlanedSellingOn;

    /** 最終売上完了日 */
    @Size(min = 0, max = 10)
    private String lastSoldOn;

    /** 完了フラグ */
    @Size(min = 1, max = 1)
    private String pjEnded;

    /** ステータス */
    @Size(min = 0, max = 1)
    private String pjStatus;

    /** 売上種別区分 */
    @Size(min = 0, max = 1)
    private String salesTypeKbn;

    /** 高原価・政策受注フラグ */
    @Size(min = 1, max = 1)
    private String highCostReceive;

    /** 応札時積算額 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal osatsuPlanedAmount;

    /** 応札時積算率 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal osatsuPlanedRate;

    /** 生産高 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal seisandaka;

    /** 一般売上 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal outsideSoldAmount;

    /** 関係会社売上額 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal groupSoldAmount;

    /** 売上物件原価率 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal soldPjCostRate;

    /** 期首仕掛原価 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal kisyuWorkingCost;

    /** 期首仕掛品原価差異 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal kisyuWorkingCostDifference;

    /** 社員工数 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal empKosu;

    /** 積算社員工数 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal planedEmpKosu;

    /** 人件費（直・間接合計） */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal laborCost;

    /** 積算人件費（直・間接合計） */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal planedLaborCost;

    /** 人件費（直接） */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal directLaborCost;

    /** 積算人件費（直接） */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal planedDirectLaborCost;

    /** 臨時時間 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal tempEmpKosu;

    /** 積算臨時時間 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal planedTempEmpKosu;

    /** 臨時人件費 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal tempLaborCost;

    /** 積算臨時人件費 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal planedTempLaborCost;

    /** 外注費（一般）発注ベース */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal outsideOrderedCost;

    /** 積算外注費（一般）発注ベース */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal planedOutsideOrderingCost;

    /** 外注費（一般）支払ベース */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal outsidePaidCost;

    /** 積算外注費（一般）支払ベース */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal planedOutsidePayingCost;

    /** 外注費（関係）発注ベース */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal groupOrderedCost;

    /** 積算外注費（関係）発注ベース */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal planedGroupOrderingCost;

    /** 外注費（関係）支払ベース */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal groupPaidCost;

    /** 積算外注費（関係）支払ベース */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal planedGroupPayingCost;

    /** 業務委託費発注ベース */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal entrustOrderedCost;

    /** 積算業務委託費 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal planedEntrustCost;

    /** 業務委託費支払ベース */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal entrustPaidCost;

    /** 未発注外注費（一般）支払ベース */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal nonOrderedOutsidePaidCost;

    /** 未発注外注費（関係）支払ベース */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal nonOrderedGroupPaidCost;

    /** 材料費 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal materialCost;

    /** 積算材料費 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal planedMaterialCost;

    /** 印刷製本費 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal printingBindingCost;

    /** 積算印刷製本費 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal planedPrintingBindingCost;

    /** 旅費交通費 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal travelingCarfareCost;

    /** 積算旅費交通費 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal planedTravelingCarfareCost;

    /** 車両費 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal carCost;

    /** 積算車両費 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal planedCarCost;

    /** 大型機材 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal largeMachine;

    /** 積算大型機材 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal planedLargeMachine;

    /** 直接作業経費 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal directWorkCost;

    /** 積算直接作業経費 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal planedDirectWorkCost;

    /** 直接費合計 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal directCost;

    /** 積算直接費合計 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal planedDirectCost;

    /** 大型機材間接費 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal largeMachineIndirectCost;

    /** 間接費 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal indirectCost;

    /** 積算間接費 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal planedIndirectCost;

    /** その他事業部間取引 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal otherCost;

    /** 積算その他事業部間取引 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal planedOtherCost;

    /** 総原価 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal sogenka;

    /** 積算総原価 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal planedSogenka;

    /** 他勘定振替 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal accountTransaction;

    /** 今期発生原価 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal thisFiscalYearCost;

    /** 今期原価差異 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal thisFiscalYearCostDifference;

    /** 原価合計 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal genkagokei;

    /** 積算原価合計 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal planedGenkagokei;

    /** 追加原価 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal addCost;

    /** 売上原価 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal salesCost;

    /** 期末仕掛原価 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal kimatsuWorkingCost;

    /** 進捗率 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal progressRate;

    /** 初回積算日 */
    @Size(min = 0, max = 10)
    private String firstPlanedOn;

    /** 当該年度初回積算額 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal thisFiscalYearFirstPlanedAmount;

    /** 当該年度初回積算原価率 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal thisFiscalYearFirstPlanedCostRate;

    /** 全年度初回積算額 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal firstPlanedAmount;

    /** 全年度初回積算原価率 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal firstPlanedAmountRate;

    /** 更新積算日 */
    @Size(min = 0, max = 10)
    private String updatePlanedOn;

    /** 当該年度積算額 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal thisFiscalYearPlanedAmount;

    /** 当該年度積算原価率 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal thisFiscalYearPlanedCostRate;

    /** 全年度積算額 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal planedAmount;

    /** 全年度積算原価率 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal planedAmountRate;

    /** 見込み原価 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal planedCost;

    /** 見込み原価率 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal planedCostRate;

    /** 並び順_物件管理責任者部門 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal sortNumPjManageRespDept;

    /** 並び順_生産主管部門 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal sortNumProductMainDept;

    /** 並び順_営業主管部門 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal sortNumSalesMainDept;

    /** 並び順_生産担当部門 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal sortNumProductDept;

    /** 全年度の⑭ */
    private BigDecimal previousYear;

    @Override
    public void setItemCount(int count) {
        this.count = count;
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        Object object = super.clone();
        return object;
    }
}
