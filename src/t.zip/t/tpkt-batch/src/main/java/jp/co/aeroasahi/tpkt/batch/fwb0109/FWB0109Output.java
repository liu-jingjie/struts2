package jp.co.aeroasahi.tpkt.batch.fwb0109;

import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.batch.item.ItemCountAware;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】SAP発注番号＞のOutputBean。
 */
@Setter
@Getter
public class FWB0109Output implements ItemCountAware {

    private int count;

    /** 申請番号 */
    @Size(min = 0, max = 13)
    private String ABLAD;

    /** 委託先枝番 */
    @Size(min = 0, max = 2)
    private String WEMPF;

    /** 発注番号 */
    @NotBlank
    @Size(min = 1, max = 10)
    private String EBELN;

    /** 注文日 */
    @Size(min = 0, max = 23)
    private String BEDAT;

    /** 作成日 */
    @Size(min = 23, max = 23)
    private String INS_DT;

    /** 更新日 */
    @Size(min = 23, max = 23)
    private String UPD_DT;

    @Override
    public void setItemCount(int count) {
        this.count = count;
    }
}
