package jp.co.aeroasahi.tpkt.batch.sbb0201;

import lombok.Getter;
import lombok.Setter;

/**
 * MAX並び順Bean。
 */
@Setter
@Getter
public class SbDataMaxSort {

    /** プロジェクトID */
    private String pjId;

    /** MAX並び順 */
    private Integer maxSortNum;

}
