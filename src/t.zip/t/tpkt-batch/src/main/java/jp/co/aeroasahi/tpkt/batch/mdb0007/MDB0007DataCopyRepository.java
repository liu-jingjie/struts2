package jp.co.aeroasahi.tpkt.batch.mdb0007;

import org.apache.ibatis.annotations.Param;

/**
 * 一時テーブルから本体テーブルにデータを登録する
 */
public interface MDB0007DataCopyRepository {

    int dataCopy(@Param("fromTable") String fromTable, @Param("toTable") String toTable);

    void dataCopy2(@Param("fromTable") String fromTable, @Param("toTable") String toTable,
            @Param("condition") DataCopyCondition condition);
}
