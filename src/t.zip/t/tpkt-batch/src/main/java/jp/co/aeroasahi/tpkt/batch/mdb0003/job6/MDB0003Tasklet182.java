package jp.co.aeroasahi.tpkt.batch.mdb0003.job6;

import java.util.Locale;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import jp.co.aeroasahi.tpkt.batch.mdb0003.BatchDataHolder;
import jp.co.aeroasahi.tpkt.batch.mdb0003.MDB0003Repository;
import jp.co.aeroasahi.tpkt.batch.mdb0003.MDB0003SharedServiceImpl;
import jp.co.aeroasahi.tpkt.batch.mdb0003.SyBatchCompleteInfoOutput;

/**
 * 支払処理日反映の実行結果を確認するTasklet
 */
@Component
@Scope("step")
public class MDB0003Tasklet182 implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0003Tasklet182.class);

    /** 支払処理日反映ジョブ名 */
    private static final String PREPARE_JOB_NAME = "ojb0301Job";

    /** ジョブ番号 */
    private static final int TARGET_JOB_NUMBER = 6;

    @Autowired
    private BatchDataHolder batchDataHolder;

    @Inject
    MDB0003SharedServiceImpl mdb0003SharedService;

    @Inject
    MessageSource messageSource;

    @Inject
    MDB0003Repository mdb0003Repository;

    // 日次処理の場合は「D」、月次確定処理の場合は「M」
    @Value("#{jobParameters['shorikbn']}")
    public String shorikbn;

    // 処理年月：日次処理の場合は空白を設定、バッチ実行画面の指定した月次確定対象年月を「YYYYMM」形式
    @Value("#{jobParameters['ym']}")
    public String ym;

    /**
     *
     * 支払処理日反映の実行結果を確認する
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return ステータス
     * @throws InterruptedException スレッドスリープの際に異常があった場合(基本的に発生しないはず)
     */
    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws InterruptedException {

        String jobStartDateTime = batchDataHolder.getJobStartDateTime();

        // 処理の終了まで待つ (規定時間を待っても終わらない or 異常終了していた場合は例外をスロー)
        mdb0003SharedService.checkExecuteResult(PREPARE_JOB_NAME, jobStartDateTime, TARGET_JOB_NUMBER);

        // 正常の場合、バッチ完了情報テーブルを更新する処理
        updatedSyBatchCompleteInfoTable(jobStartDateTime);

        logger.info(messageSource.getMessage("i.bat.fw.003", null, Locale.getDefault()));

        return RepeatStatus.FINISHED;
    }

    private void updatedSyBatchCompleteInfoTable(String systemDateTime) {

        // ④バッチ完了情報テーブルを更新する
        SyBatchCompleteInfoOutput output = new SyBatchCompleteInfoOutput();

        if(shorikbn.equals("D")) {

            // 前回日次処理完了日時
            output.setLastDailyBatchCompleteDateTime(systemDateTime);

            // 更新日
            output.setUpdatedAt(systemDateTime);

            mdb0003Repository.createDayCompleteInfo(output);

        }else if(shorikbn.equals("M")) {

            // 前回日次処理完了日時
            output.setLastDailyBatchCompleteDateTime(systemDateTime);

            // 前回月次確定処理完了日時
            output.setLastMonthlyConfirmCompleteDateTime(systemDateTime);

            // 前回月次確定処理年月
            output.setLastMonthlyConfirmYm(ym);

            // 更新日
            output.setUpdatedAt(systemDateTime);

            mdb0003Repository.createMonthCompleteInfo(output);
        }
    }
}
