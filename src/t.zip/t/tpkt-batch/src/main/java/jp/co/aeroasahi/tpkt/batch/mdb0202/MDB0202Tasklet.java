package jp.co.aeroasahi.tpkt.batch.mdb0202;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.fw.CommonLog;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

@Component
@Scope("step")
public class MDB0202Tasklet implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0202Tasklet.class);

    @Inject
    MDB0202Repository mdb0202Repository;

    @Inject
    DateFactory dateFactory;

    /** DateTimeFormatterのパターン yyyy-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        // SAPプロジェクト属性などのデータを取得する
        List<MDB0202Input> inputList = mdb0202Repository.findAll();

        // 【TEMP】プロジェクト属性に登録する前に、データを編集する。
        List<MDB0202Output> outItems = setItemOutput(inputList);

        // 【TEMP】プロジェクト属性のデータを削除する
        mdb0202Repository.delete();

        // 【TEMP】プロジェクト属性のデータを登録する
        if (outItems.size() > 0) {
            for (MDB0202Output output : outItems) {
                mdb0202Repository.create(output);
            }
        }
        CommonLog.setInsertRecordeCountLog(logger, "【TEMP】プロジェクト属性(temp_project_attribute)", outItems.size());

        outItems.clear();

        return RepeatStatus.FINISHED;
    }

    private List<MDB0202Output> setItemOutput(List<MDB0202Input> inputList) {

        List<MDB0202Output> outputItems = new ArrayList<>();

        MDB0202Output item = new MDB0202Output();

        String systemDateTime = dateFactory.newDateTime().format(dtf);

        for (MDB0202Input mdb0202Input : inputList) {
            item = new MDB0202Output();

            // プロジェクト属性ID
            item.setPjAttId(mdb0202Input.getZPSPID());

            // プロジェクト属性名称
            item.setPjAttName(getString(mdb0202Input.getZPSPNAME()));

            // 営業主管部門CD
            item.setSalesMainDeptCd(getString(mdb0202Input.getZEIGYOSHUKANBUMON()));

            // 営業主管担当者CD
            item.setSalesMainDeptEmpCd(getString(mdb0202Input.getZEIGYOTANTO()));

            // 生産主管部門CD
            item.setProductDeptCd(getString(mdb0202Input.getZSEISANSHUKANBUMON()));

            // 生産プロデューサーCD
            item.setProductEmpCd(getString(mdb0202Input.getZPRODUCER()));

            // 物件管理責任者部門CD
            item.setPjManageRespDeptCd(getString(mdb0202Input.getZBUKKENTANTO()));

            // 物件管理責任者CD
            item.setPjManageRespEmpCd(getString(mdb0202Input.getZBUKKENTANTOBUMON()));

            // 顧客CD
            item.setCustomerCd(getString(mdb0202Input.getZTOKUISAKI()));

            // 分野CD
            item.setFieldCd(getString(mdb0202Input.getZBUNYACD()));

            // 業務CD
            item.setBusinessCd(getString(mdb0202Input.getZGYOUMUCD()));

            // PJステータス
            item.setPjStatus(null == mdb0202Input.getVALUE() ? "" : mdb0202Input.getVALUE());

            // 今期仕掛中区分
            item.setWorkingKbn(null == mdb0202Input.getDATEFLG() ? "0" : mdb0202Input.getDATEFLG().equals("X") ? "1" : "0");

            // リースフラグ
            item.setLease(null == mdb0202Input.getZLEASEFLAG() ? "0" : mdb0202Input.getZLEASEFLAG().equals("X") ? "1" : "0");

            // 契約件名
            item.setContractName(getString(mdb0202Input.getZKEIYAKUMEI()));

            // 名義会社
            item.setMeigiCorpCd(getString(mdb0202Input.getBU()));

            // 契約工期(FROM)
            item.setContractFrom(getString(mdb0202Input.getZKEYAKUKOKIB()));

            // 契約工期(TO)
            item.setContractTo(getString(mdb0202Input.getZKEYAKUKOKIE()));

            // 個人情報CD
            item.setPersonalInfoCd(mdb0202Input.getZKOJIN());

            // 作成日
            item.setCreatedAt(systemDateTime);

            // 更新日
            item.setUpdatedAt(systemDateTime);

            outputItems.add(item);
        }

        return outputItems;
    }

    private String getString(String inputStr) {
        return null == inputStr ? null : inputStr;
    }
}
