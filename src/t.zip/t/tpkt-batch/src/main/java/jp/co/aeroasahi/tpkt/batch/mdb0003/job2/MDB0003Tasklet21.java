package jp.co.aeroasahi.tpkt.batch.mdb0003.job2;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.mdb0003.BatchDataHolder;
import jp.co.aeroasahi.tpkt.batch.mdb0003.BatchJobRequestInput;
import jp.co.aeroasahi.tpkt.batch.mdb0003.MDB0003Repository;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

/**
 * 工数取込の実行を要求するTasklet
 */
@Component
@Scope("step")
public class MDB0003Tasklet21 implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0003Tasklet21.class);

    /** メインバッチジョブID */
    private static final String JOB_ID = "mdb0003Job";

    /** 工数取込ジョブ名 */
    private static final String KOSU_JOB_NAME = "mdb0101Job";

    /** DateTimeFormatterのパターン uuuu-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.SSS");

    @Inject
    DateFactory dateFactory;

    @Inject
    MDB0003Repository mdb0003Repository;

    @Autowired
    private BatchDataHolder batchDataHolder;

    // 日次処理の場合は「D」、月次確定処理の場合は「M」
    @Value("#{jobParameters['shorikbn']}")
    public String shorikbn;

    // 処理年月：日次処理の場合は空白を設定、バッチ実行画面の指定した月次確定対象年月を「YYYYMM」形式
    @Value("#{jobParameters['ym']}")
    public String ym;

    @Value("#{jobParameters['jobNum']}")
    public String jobNum;

    /**
     *
     * 工数取込の実行を要求する
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return ステータス
     */
    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

        // jobNumが2以上の場合は、jobNum3の処理までスキップする
        if (isSkip()) {
            logger.info("リランジョブ番号が3以上であるため、中間テーブル更新処理をスキップします。");
            contribution.setExitStatus(new ExitStatus("SKIP"));
            return RepeatStatus.FINISHED;
        }

        // ジョブ番号単位でシステム日時を取得
        String jobStartDateTime = dateFactory.newDateTime().format(dtf);
        batchDataHolder.setJobStartDateTime(jobStartDateTime);

        BatchJobRequestInput input = new BatchJobRequestInput();

        input.setJobName(KOSU_JOB_NAME);
        input.setJobParameter(getParameter(jobStartDateTime));
        input.setPriority(1);
        input.setPollingStatus("INIT");
        input.setCreateDate(jobStartDateTime);

        // ジョブの実行要求
        mdb0003Repository.create(input);

        return RepeatStatus.FINISHED;
    }


    private String getParameter(String systemDateTime) {
        String tempYyyyMm = shorikbn.equals("D") ? "" : ym;

        List<String> params = new ArrayList<>();
        params.add("kbn=" + shorikbn);
        params.add("yyyymm=" + tempYyyyMm);
        params.add("systemDateTime=" + systemDateTime);
        params.add("jobId=" + JOB_ID);
        return String.join(",", params);
    }

    // jobNumが2以上の場合はSAP取込をスキップする
    private boolean isSkip() {
        if (StringUtils.isNoneEmpty(jobNum)) {
            if (Integer.parseInt(jobNum) > 2) {
                return true;
            }
        }
        return false;
    }
}
