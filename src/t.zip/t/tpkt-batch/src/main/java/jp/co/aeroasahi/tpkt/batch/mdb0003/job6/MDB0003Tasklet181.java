package jp.co.aeroasahi.tpkt.batch.mdb0003.job6;

import javax.inject.Inject;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.mdb0003.BatchDataHolder;
import jp.co.aeroasahi.tpkt.batch.mdb0003.BatchJobRequestInput;
import jp.co.aeroasahi.tpkt.batch.mdb0003.MDB0003Repository;

/**
 * 支払処理日反映の実行要求をするTasklet
 */
@Component
@Scope("step")
public class MDB0003Tasklet181 implements Tasklet {

    /** 支払処理日反映ジョブ名 */
    private static final String PREPARE_JOB_NAME = "ojb0301Job";

    @Inject
    MDB0003Repository mdb0003Repository;

    @Autowired
    private BatchDataHolder batchDataHolder;

    // 日次処理の場合は「D」、月次確定処理の場合は「M」
    @Value("#{jobParameters['shorikbn']}")
    public String shorikbn;

    // 処理年月：日次処理の場合は空白を設定、バッチ実行画面の指定した月次確定対象年月を「YYYYMM」形式
    @Value("#{jobParameters['ym']}")
    public String ym;

    /**
     *
     * 支払処理日反映の実行要求をする
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return ステータス
     */
    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

        String jobStartDateTime = batchDataHolder.getJobStartDateTime();

        BatchJobRequestInput input = new BatchJobRequestInput();

        input.setJobName(PREPARE_JOB_NAME);
        input.setJobParameter(getParameter(jobStartDateTime));
        input.setPriority(1);
        input.setPollingStatus("INIT");
        input.setCreateDate(jobStartDateTime);

        // 実行要求
        mdb0003Repository.create(input);

        return RepeatStatus.FINISHED;
    }

    private String getParameter(String jobStartDateTime) {

        String dateTime = jobStartDateTime.replaceAll("-", "/");

        String tempYyyyMm = shorikbn.equals("D") ? "" : ym;

        return "kbn=" + shorikbn + ",date=" + tempYyyyMm + ",dateTime=" + dateTime + ",systemDateTime="
                + jobStartDateTime;
    }
}
