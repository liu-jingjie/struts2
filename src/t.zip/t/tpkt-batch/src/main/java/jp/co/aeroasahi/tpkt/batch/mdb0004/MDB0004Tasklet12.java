package jp.co.aeroasahi.tpkt.batch.mdb0004;

import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

/**
 * 各ジョブのデータ登録を実行するTasklet
 */
@Component
@Scope("step")
public class MDB0004Tasklet12 implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0004Tasklet12.class);

    @Inject
    DateFactory dateFactory;

    @Inject
    MDB0004Repository mdb0004Repository;

    @Autowired
    private BatchDataHolder batchDataHolder;

    @Value("#{jobParameters['type']}")
    public String type;

    /**
    *
    * マインバッチデータ登録処理
    *
    * @param contribution StepContribution
    * @param chunkContext ChunkContext
    *
    * @return データ登録を実行した状態
    */
    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        String systemDateTime = batchDataHolder.getSystemDateTime();

        batchDataHolder.setCheckResult(true);

        if (checkJobExecuteResultIsExecution(1, systemDateTime)) {
            batchDataHolder.setCheckResult(false);
            logger.error("{}{}処理でエラーが発生しました。","knb0102","勤怠データ取込");
        }

        return RepeatStatus.FINISHED;
    }

    /**
     * 各ジョブ実行結果をチェックする
     *
     * @param number ジョブ件数
     * @param systemDateTime タスク実行時間
     *
     * @return 各ジョブ実行結果をチェックする結果
     */
    private boolean checkJobExecuteResultIsExecution(int number, String systemDateTime) {
        boolean rtnIsExecution = false;

        while (true) {
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                logger.error("stackTrace：", e);
            }

            boolean isAllExecuted = true;

            List<Integer> jobExecutionIds = new ArrayList<Integer>();
            jobExecutionIds.clear();
            int count = 0;
            List<BatchJobRequestOutput> jobRequestOutputList= mdb0004Repository.findByTopNum(number, "%"+systemDateTime);

            for (BatchJobRequestOutput batchJobRequestOutput : jobRequestOutputList) {

                count++;
                jobExecutionIds.add(batchJobRequestOutput.getJobExecutionId());

                if(!batchJobRequestOutput.getPollingStatus().equals("EXECUTED")) {

                    isAllExecuted = false;
                }
            }

            if(number != count) {
                isAllExecuted = false;
            }

            if (isAllExecuted) {
                List<BatchJobExecutionOutput> jobExecutionOutputList= mdb0004Repository.findByExecutionIds(jobExecutionIds);

                for (BatchJobExecutionOutput batchJobExecutionOutput : jobExecutionOutputList) {

                    if(!(batchJobExecutionOutput.getStatus().equals("COMPLETED") && batchJobExecutionOutput.getExitCode().equals("COMPLETED"))) {

                        rtnIsExecution = true;
                    }
                }
                break;
            }
        }

        return rtnIsExecution;
    }

}
