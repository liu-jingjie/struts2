package jp.co.aeroasahi.tpkt.batch.mdb0003.job3;

import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.fw.CommonLog;
import jp.co.aeroasahi.tpkt.batch.mdb0003.MDB0003DataCopyRepository;

/**
 * 月次確定の表示用テーブル更新の本体をtempへ反映するTasklet
 */
@Component
@Scope("step")
public class MDB0003Tasklet144 implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0003Tasklet144.class);

    @Inject
    MDB0003DataCopyRepository mainDataCopyRepository;

    /**
     *
     * 月次確定の表示用テーブル更新の本体をtempへ反映する
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return 一括で各ジョブを実行した状態
     */
    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

        try {
            logger.info("本体テーブルからtempテーブルへの書き込みを実施します。");

            // テーブル＜【TEMP】物件管理＞に登録する。
            mainDataCopyRepository.dataCopy("md_disp_property_monthly", "temp_md_disp_property");
            // テーブル＜【TEMP】外注管理＞に登録する。
            mainDataCopyRepository.dataCopy4("md_disp_outsourcing_monthly", "temp_md_disp_outsourcing");

            logger.info("本体テーブルからtempテーブルへの書き込みが完了しました。");

        } catch (Exception e) {
            CommonLog.setBatchErrorLog(logger, "tempテーブルから、本体テーブルに更新");
            throw new RuntimeException(e);
        }

        return RepeatStatus.FINISHED;
    }
}
