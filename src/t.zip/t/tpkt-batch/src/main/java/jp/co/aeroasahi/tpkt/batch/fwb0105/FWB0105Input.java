package jp.co.aeroasahi.tpkt.batch.fwb0105;

import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】SAP勘定明細＞のInputBean。
 */
@Setter
@Getter
public class FWB0105Input {

    /** 会社コード */
    private String BUKRS;

    /** 伝票番号 */
    private String BELNR;

    /** 会計年度 */
    private String GJAHR;

    /** 会計期間 */
    private String MONAT;

    /** 転記日付 */
    private String BUDAT;

    /** 請求書伝票番号 */
    private String RBUKRS;

    /** 勘定コード */
    private String HKONT;

    /** 部門 */
    private String PRCTR;

    /** プロジェクトID */
    private String PROJK;

    /** 発注番号 */
    private String EBELN;

    /** 申請番号 */
    private String ABLAD;

    /** 委託先枝番 */
    private String WEMPF;

    /** 支払予定日 */
    private String ZFBDT;

    /** 金額 */
    private String DMBTR;

    /** 作成日 */
    private String INS_DT;

    /** 更新日 */
    private String UPD_DT;

}
