package jp.co.aeroasahi.tpkt.batch.ckb0101;

import org.springframework.batch.item.ItemCountAware;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜未登録状況＞のInputBean。
 */
@Setter
@Getter
public class CKB0101UnregStatusInput implements ItemCountAware {

    private int count;

    /** プロジェクトID */
    private String pjId;

    /** 帳票種別 */
    private String docType;

    /** 帳票名称 */
    private String docName;

    /** 未登録対象 */
    private String unregTarget;

    /** 未登録対象確認日 */
    private Integer unregTargetDate;

    /** 登録日(初回受注日/初回売上予定日) */
    private String regDate;

    @Override
    public void setItemCount(int count) {
        this.count = count;
    }
}
