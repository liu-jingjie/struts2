package jp.co.aeroasahi.tpkt.batch.mdb0601;

import java.util.List;

/**
 * テーブル＜【TEMP】金額＞＜SAP勘定残高＞＜勘定科目マスタ＞に操作
 */
public interface MDB0601Repository {

    /**
     * (1_原価集計)条件によって、テーブル＜SAP勘定残高＞＜勘定科目マスタ＞＜積算基本情報＞＜積算データ＞＜積算月別展開データ＞＜汎用マスタ＞の情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0601Input> findAll1(MDB0601Input input);

    /**
     * (1_原価集計)条件によって、テーブル＜SAP勘定残高＞＜勘定科目マスタ＞＜積算基本情報＞＜積算データ＞＜積算月別展開データ＞＜汎用マスタ＞の情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0601Input> findAll2(MDB0601Input input);

    /**
     * (1_原価集計)条件によって、テーブル＜SAP勘定残高＞＜勘定科目マスタ＞＜積算基本情報＞＜初回積算データ＞＜初回積算月別展開データ］＞＜汎用マスタ＞の情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0601Input> findAll3(MDB0601Input input);

    /**
     * (2_人材派遣費)条件によって、テーブル＜SAP勘定残高＞＜勘定科目マスタ＞＜積算基本情報＞＜初回積算データ＞＜初回積算月別展開データ］＞＜汎用マスタ＞の情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0601Input> findAll4(MDB0601Input input);

    /**
     * (2_人材派遣費)条件によって、テーブル＜SAP勘定残高＞＜勘定科目マスタ＞＜積算基本情報＞＜初回積算データ＞＜初回積算月別展開データ］＞＜汎用マスタ＞の情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0601Input> findAll5(MDB0601Input input);

    /**
     * (3_大型機材間接費)条件によって、テーブル＜SAP勘定残高＞＜勘定科目マスタ＞の情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0601Input> findAll6(MDB0601Input input);

    /**
     * 条件によって、テーブル＜【TEMP】金額＞の情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0601Output> findAllByKey();

    /**
     * テーブル＜【TEMP】金額＞に更新する。
     *
     * @param output MDB0601Output
     * @return
     */
    void update(MDB0601Output output);

    /**
     * テーブル＜【TEMP】金額＞に登録する。
     *
     * @param output MDB0601Output
     * @return
     */
    void create(MDB0601Output output);

    /**
     * テーブル＜【TEMP】金額＞に(実績データ)削除する。
     *
     * @param input MDB0601Input
     * @return
     */
    void deletePerformance(MDB0601Input input);

    /**
     * テーブル＜【TEMP】金額＞に(積算データ)削除する。
     *
     * @param input MDB0601Input
     * @return
     */
    void deleteIntegration(MDB0601Input input);

    /**
     * テーブル＜【TEMP】金額＞に(初回積算)削除する。
     *
     * @param input MDB0601Input
     * @return
     */
    void deleteInitialIntegration(MDB0601Input input);
}