package jp.co.aeroasahi.tpkt.batch.mdb0803;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.validator.ValidationException;
import org.springframework.batch.item.validator.Validator;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.fw.CommonLog;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

@Component
@Scope("step")
public class MDB0803Tasklet implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0803Tasklet.class);

    @Inject
    MDB0803Repository mdb0803Repository;

    @Inject
    DateFactory dateFactory;

    @Inject
    Validator<MDB0803Output> validator;

    @Value("#{jobParameters['kbn']}")
    public String kbn;

    @Value("#{jobParameters['yyyymm']}")
    public String yyyymm;

    boolean isErrFlag = false;

    /** DateTimeFormatterのパターン uuuu-MM-dd */
    private static final DateTimeFormatter dtfUUUUMMDD = DateTimeFormatter.ofPattern("uuuu-MM-dd");

    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        LocalDateTime systemDateTime = dateFactory.newDateTime();
        String systemDate = systemDateTime.format(dtfUUUUMMDD);
        String specifiedMonth = "";

        // ２年前の会計年度
        String year1 = yearMonthToBeginOfFiscalYearMonth(systemDateTime).substring(0, 4);

        // ２年前の会計期間
        String month1 = yearMonthToBeginOfFiscalYearMonth(systemDateTime).substring(4, 6);

        // 月次確定処理の場合
        if (kbn.equals("M")) {
            LocalDateTime yyyymmP = LocalDateTime.of(Integer.parseInt(yyyymm.substring(0, 4)), Integer.parseInt(yyyymm.substring(4, 6)), 1, 1, 1);
            specifiedMonth = yyyymmP.plusMonths(1).minusDays(1).format(dtfUUUUMMDD);
        }

        List<MDB0803Output> outItems = setItemOutput(year1, month1, systemDate, specifiedMonth);

        if (!isErrFlag) {
            for (int i = 0; i < outItems.size(); i++) {
                try {
                    validator.validate(outItems.get(i));
                } catch (ValidationException e) {
                    isErrFlag = true;
                    CommonLog.setFromDbErrorLog(logger, e, "【TEMP】部門経費管理(temp_md_disp_dept_cost)");
                }
            }

            if (!isErrFlag) {

                if(outItems.size() > 0) {

                    // データを削除
                    mdb0803Repository.delete();

                    // データを登録
                    for (MDB0803Output output : outItems) {
                        mdb0803Repository.create(output);
                    }
                }
                CommonLog.setInsertRecordeCountLog(logger, "【TEMP】部門経費管理(temp_md_disp_dept_cost)", outItems.size());

            } else {
                logger.error("登録データでエラーが発生しました。");
            }
            outItems.clear();
        }

        if (isErrFlag) {
            throw new RuntimeException("mdb0803【表示用】部門経費管理更新処理実行に異常が発生しました。");
        }

        return RepeatStatus.FINISHED;
    }

    private List<MDB0803Output> setItemOutput(String year1, String month1, String systemDate, String specifiedMonth) {

        List<MDB0803Output> outputItems = new ArrayList<MDB0803Output>();
        MDB0803Output itemOutput = null;

        MDB0803Input itemInput = new MDB0803Input();
        itemInput.setGJAHR1(year1);
        itemInput.setMONAT1(month1);
        itemInput.setSystemDate(systemDate);
        itemInput.setSpecifiedMonth(specifiedMonth);
        itemInput.setFiscalYear(new BigDecimal(year1.substring(0, 4)));

        // 検索結果
        List<MDB0803Input> detailList = mdb0803Repository.findAllByFiscalYearMonth(itemInput);

        // 部門別経費マスタから、Kindで取得する費目コードリスト
        List<MDB0803Output> deptCostList = mdb0803Repository.findAllByKind();

        // 部門表示順マスタから、FiscalYearで取得する部門と会計年度リスト
        List<MDB0803Output> dispOrderList = mdb0803Repository.findAllByFiscalYear(itemInput);

        for (MDB0803Input mdb0803Input : detailList) {

            itemOutput = new MDB0803Output();

            // 部門ＣＤ
            itemOutput.setDeptCd(mdb0803Input.getDeptCd());

            // 部門名称
            itemOutput.setDeptName(mdb0803Input.getDeptName());

            // 費目ＣＤ
            itemOutput.setHimokuCd(mdb0803Input.getHimokuCd());

            // 費目名
            itemOutput.setHimokuName(mdb0803Input.getHimokuName());

            // 勘定科目ＣＤ
            itemOutput.setKamokuCd(mdb0803Input.getKamokuCd());

            // 勘定科目名称
            itemOutput.setKamokuName(mdb0803Input.getKamokuName());

            // 部門支社ＣＤ
            itemOutput.setDeptBranchCd(mdb0803Input.getBranchCd());

            // 部門支社名称
            itemOutput.setDeptBranchName(mdb0803Input.getBranchName());

            // 部門部ＣＤ
            itemOutput.setMDeptCd(mdb0803Input.getDeptMCd());

            // 部門部名称
            itemOutput.setMDeptName(mdb0803Input.getDeptMName());

            // 部門小部門ＣＤ
            itemOutput.setSDeptCd(mdb0803Input.getDeptSCd());

            // 部門小部門名称
            itemOutput.setSDeptName(mdb0803Input.getDeptSName());

            // 経費種類
            itemOutput.setCostKind(mdb0803Input.getDeptType());

            // 会計年度
            itemOutput.setFiscalYear(mdb0803Input.getFiscalYear());

            // 会計期間
            itemOutput.setFiscalMonth(mdb0803Input.getFiscalMonth());

            // 実績積算区分
            itemOutput.setResultPlanedKbn(mdb0803Input.getResultPlanedKbn());

            // 原価
            itemOutput.setCost(null == mdb0803Input.getCost()? BigDecimal.ZERO : mdb0803Input.getCost());

            // 並び順_部門
            itemOutput.setSortNumDept(mdb0803Input.getDispOrder());

            outputItems.add(itemOutput);
        }

        // 検索した部門と会計年度のリスト
        for (MDB0803Output dispOrderItem : dispOrderList) {

            // 部門ＣＤ
            String deptCd = dispOrderItem.getDeptCd();

            // 会計年度
            String fiscalYear = String.valueOf(dispOrderItem.getFiscalYear());

            // 検索したリストの中に、存在するかどうか
            boolean isExistence = false;
            for (MDB0803Output outputItem : outputItems) {
                if(deptCd.equals(outputItem.getDeptCd()) && fiscalYear.equals(String.valueOf(outputItem.getFiscalYear()))) {
                    isExistence = true;
                    break;
                }
            }

            if (isExistence) {

                for (MDB0803Output deptCost : deptCostList) {

                    boolean isExistenceKamokuCd = false;

                    for (MDB0803Output outputItem : outputItems) {
                        if(deptCd.equals(outputItem.getDeptCd()) && fiscalYear.equals(String.valueOf(outputItem.getFiscalYear()))
                                && deptCost.getKamokuCd().equals(outputItem.getKamokuCd())) {
                            isExistenceKamokuCd = true;
                            break;
                        }
                    }

                    if(!isExistenceKamokuCd) {
                        itemOutput = new MDB0803Output();

                        // 部門ＣＤ
                        itemOutput.setDeptCd(deptCd);

                        // 勘定科目ＣＤ
                        itemOutput.setKamokuCd(deptCost.getKamokuCd());

                        // 会計年度
                        itemOutput.setFiscalYear(dispOrderItem.getFiscalYear());

                        // 会計期間
                        itemOutput.setFiscalMonth(new BigDecimal("1"));

                        // 実績積算区分
                        itemOutput.setResultPlanedKbn("1");

                        // 原価
                        itemOutput.setCost(null);

                        outputItems.add(itemOutput);
                    }
                }
            }else {
                for (MDB0803Output deptCost : deptCostList) {

                    itemOutput = new MDB0803Output();

                    // 部門ＣＤ
                    itemOutput.setDeptCd(deptCd);

                    // 勘定科目ＣＤ
                    itemOutput.setKamokuCd(deptCost.getKamokuCd());

                    // 会計年度
                    itemOutput.setFiscalYear(dispOrderItem.getFiscalYear());

                    // 会計期間
                    itemOutput.setFiscalMonth(new BigDecimal("1"));

                    // 実績積算区分
                    itemOutput.setResultPlanedKbn("1");

                    // 原価
                    itemOutput.setCost(null);

                    outputItems.add(itemOutput);
                }
            }
        }

        return outputItems;
    }

    private String yearMonthToBeginOfFiscalYearMonth(LocalDateTime systemDateTime) {

        int year = systemDateTime.getYear();
        int month = systemDateTime.getMonthValue();

        if (month < 4) {
            year--;
        }

        // 直近2年前の年度開始月
        year--;

        return String.valueOf(year + "01");

    }

}
