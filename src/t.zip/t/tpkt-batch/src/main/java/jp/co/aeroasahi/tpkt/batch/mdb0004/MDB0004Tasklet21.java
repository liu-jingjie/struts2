package jp.co.aeroasahi.tpkt.batch.mdb0004;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.inject.Inject;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

/**
 * 各ジョブを実行するTasklet
 */
@Component
@Scope("step")
public class MDB0004Tasklet21 implements Tasklet {

    @Inject
    DateFactory dateFactory;

    @Inject
    MDB0004Repository mdb0004Repository;

    @Autowired
    private BatchDataHolder batchDataHolder;

    @Value("#{jobParameters['type']}")
    public String type;

    /** DateTimeFormatterのパターン uuuu-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.SSS");

    /** DateTimeFormatterのパターン uuuuMM */
    private static final DateTimeFormatter dtfUuuuMM = DateTimeFormatter.ofPattern("uuuuMM");

    /**
     *
     * マインバッチ処理
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return 一括で各ジョブを実行した状態
     */
    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        boolean checkResult = batchDataHolder.isCheckResult();

        LocalDateTime dateTime = dateFactory.newDateTime();

        String systemDateTime = dateTime.format(dtf);
        String yearMonth = dateTime.format(dtfUuuuMM);

        if (type.equals("0") && checkResult) {
            executeJob("knb0101Job", "isManual=0,yearMonth=" + yearMonth + ",deptCd=,isRetry=0,systemDateTime=" + systemDateTime);
        }

        batchDataHolder.setSystemDateTime(systemDateTime);

        return RepeatStatus.FINISHED;
    }

    /**
     * ジョブ実行処理
     *
     * @return 無し
     */
    private void executeJob(String jobName, String jobParameter) throws Exception {

        BatchJobRequestInput input = new BatchJobRequestInput();

        input.setJobName(jobName);
        input.setJobParameter(jobParameter);
        input.setPriority(1);
        input.setPollingStatus("INIT");

        mdb0004Repository.create(input);
    }
}
