package jp.co.aeroasahi.tpkt.batch.mdb0804;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.validator.ValidationException;
import org.springframework.batch.item.validator.Validator;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.fw.CommonLog;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

@Component
@Scope("step")
public class MDB0804Tasklet implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0804Tasklet.class);

    @Inject
    MDB0804Repository mdb0804Repository;

    @Inject
    DateFactory dateFactory;

    @Inject
    Validator<MDB0804Output> validator;

    @Value("#{jobParameters['kbn']}")
    public String kbn;

    @Value("#{jobParameters['yyyymm']}")
    public String yyyymm;

    boolean isErrFlag = false;

    /** DateTimeFormatterのパターン uuuuMM */
    private static final DateTimeFormatter dtfUUUUMM = DateTimeFormatter.ofPattern("uuuuMM");

    /** DateTimeFormatterのパターン uuuu */
    private static final DateTimeFormatter dtfUUUU = DateTimeFormatter.ofPattern("uuuu");

    /** DateTimeFormatterのパターン uuuu-MM-dd */
    private static final DateTimeFormatter dtfUUUUMMDD = DateTimeFormatter.ofPattern("uuuu-MM-dd");

    int insertCount = 0;
    int updateCount = 0;

    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        LocalDateTime systemDateTime = dateFactory.newDateTime();
        String systemDate = systemDateTime.format(dtfUUUUMMDD);
        String systemDate2 = "";

        // 年(当月の年)
        String year1 = getCurrentMonth(systemDateTime).substring(0, 4);

        // 月(当月)
        String month1 = getCurrentMonth(systemDateTime).substring(4, 6);

        // 年(前月或は指定した月の年)
        String year2 = "";

        // 月(前月或は指定した月)
        String month2 = "";

        // 年度
        String year3 = "";

        // 年度 指定月
        String year4 = "";

        // 日次処理の場合
        if (kbn.equals("D")) {
            year2 = getPreviousMonth(systemDateTime).substring(0, 4);
            month2 = getPreviousMonth(systemDateTime).substring(4, 6);

        // 月次確定処理の場合
        } else if (kbn.equals("M")) {
            LocalDateTime yyyymmP = LocalDateTime.of(Integer.parseInt(yyyymm.substring(0, 4)),
                    Integer.parseInt(yyyymm.substring(4, 6)), 1, 1, 1);
            year2 = getCurrentMonth(yyyymmP).substring(0, 4);
            month2 = getCurrentMonth(yyyymmP).substring(4, 6);
            systemDate2 = yyyymmP.plusMonths(1).minusDays(1).format(dtfUUUUMMDD);
            year4= getFiscalYear(yyyymmP);
        }

        year3 = getFiscalYear(systemDateTime);

        // ■実績データを設定
        List<MDB0804Output> outPerformanceDataItems = getEditList(setPerformanceData(year1, month1, year2, month2, year3, systemDate, systemDate2, year4));

        // ■計画データを設定
        List<MDB0804Output> outPlanDataItems = getEditList(setPlanData(year3, systemDate));

        // ■積算データを設定
        List<MDB0804Output> outEstimateDataItems = getEditList(setEstimateData(year3, systemDate));

        if (!isErrFlag) {

            // ■実績データを登録
            isErrFlag = insertOrUpdateData(outPerformanceDataItems);

            // ■計画データを登録
            if (!isErrFlag) {
                isErrFlag = insertOrUpdateData(outPlanDataItems);
            }

            // ■積算データを登録
            if (!isErrFlag) {
                isErrFlag = insertOrUpdateData(outEstimateDataItems);
            }
        }

        if (isErrFlag) {
            throw new RuntimeException("mdb0804【表示用】操業度管理更新処理実行に異常が発生しました。");
        } else {
            CommonLog.setInsertRecordeCountLog(logger, "【TEMP】操業度管理(temp_md_disp_operation)", insertCount);
            CommonLog.setUpdateRecordeCountLog(logger, "【TEMP】操業度管理(temp_md_disp_operation)", updateCount);
        }

        return RepeatStatus.FINISHED;
    }

    private boolean insertOrUpdateData(List<MDB0804Output> outItems) {

        boolean isErrFlag = false;

        for (int i = 0; i < outItems.size(); i++) {
            try {
                validator.validate(outItems.get(i));
            } catch (ValidationException e) {
                isErrFlag = true;
                CommonLog.setFromDbErrorLog(logger, e, "【TEMP】操業度管理(temp_md_disp_operation)");
            }
        }

        if (!isErrFlag) {

            // 操業度管理の既存データを取得する
            List<MDB0804Output> checkList = mdb0804Repository.findAllByKey();
            Map<String, MDB0804Output> checkListMap =
                    checkList.stream().collect(Collectors.toMap(MDB0804Output::concat, Function.identity()));

            List<MDB0804Output> insertRecordList = new ArrayList<MDB0804Output>();
            List<MDB0804Output> updateRecordList = new ArrayList<MDB0804Output>();

            for (MDB0804Output mdb0804Output : outItems) {

                // 更新
                if (checkListMap.containsKey(mdb0804Output.concat())) {
                    updateRecordList.add(mdb0804Output);
                    updateCount++;
                    // 登録
                } else {
                    insertRecordList.add(mdb0804Output);
                    insertCount++;
                }
            }

            // 操業度管理のデータを更新する
            if (updateRecordList.size() > 0) {
                for (MDB0804Output output : updateRecordList) {
                    mdb0804Repository.update(output);
                }
            }

            // 操業度管理のデータを登録する
            if (insertRecordList.size() > 0) {
                for (MDB0804Output output : insertRecordList) {
                    mdb0804Repository.create(output);
                }
            }

        } else {
            logger.error("登録データでエラーが発生しました。");
        }

        return isErrFlag;
    }

    private List<MDB0804Output> setPerformanceData(String year1, String month1, String year2, String month2,
            String year3, String systemDate, String systemDate2, String year4) {

        List<MDB0804Output> outputItems = new ArrayList<MDB0804Output>();
        MDB0804Output itemOutput = new MDB0804Output();
        HashMap<String, MDB0804Output> dateMap = new HashMap<String, MDB0804Output>();

        MDB0804PerformanceInput itemInput = new MDB0804PerformanceInput();
        itemInput.setYm1(year1 + month1);
        itemInput.setYm2(year2 + month2);
        itemInput.setYm3(year3);
        itemInput.setKbn(kbn);
        itemInput.setSystemDate(systemDate);
        itemInput.setSystemDate2(systemDate2);
        itemInput.setYm4(year4);

        List<MDB0804PerformanceInput> detailList = new ArrayList<MDB0804PerformanceInput>();

        if(kbn.equals("D")) {
            detailList = mdb0804Repository.findAllByDayPerformance(itemInput);
        }else if(kbn.equals("M")) {
            detailList = mdb0804Repository.findAllByMonthPerformance(itemInput);
        }

        for (int i = 0; i < detailList.size(); i++) {

            MDB0804PerformanceInput mdb0804PerformanceInput = detailList.get(i);

            MDB0804Output mapData = dateMap.get(mdb0804PerformanceInput.concat());

            // 該当レーコドの工数
            BigDecimal kosu = mdb0804PerformanceInput.getKosu();

            // 該当レーコドのプロジェクト種別
            boolean pjIdTypeP = mdb0804PerformanceInput.getPjId().startsWith("P", 2);
            boolean pjIdTypeR = mdb0804PerformanceInput.getPjId().startsWith("R", 2);
            boolean pjIdTypeO = mdb0804PerformanceInput.getPjId().startsWith("O", 2);

            // 該当レーコドの枝番
            boolean pjIdBranch = mdb0804PerformanceInput.getPjId().endsWith("01");

            // 該当レーコドの工程CD
            String koteiCd = mdb0804PerformanceInput.getKoteiCd();

            if (dateMap.containsKey(mdb0804PerformanceInput.concat())) {

                // 直接時間
                if ((pjIdTypeP || pjIdTypeR) && !pjIdBranch) {
                    mapData.setDirectTime(addBD(mapData.getDirectTime(), kosu));
                }

                // 直接の内【間機】時間
                if ((pjIdTypeP || pjIdTypeR) && !pjIdBranch
                        && mdb0804PerformanceInput.getPjName().indexOf("【間機】") == 0) {
                    mapData.setDirectMachineTime(addBD(mapData.getDirectMachineTime(), kosu));
                }

                // 有休時間
                if (pjIdTypeO && koteiCd.equals("ZCZ10")) {
                    mapData.setPaidHolidayTime(addBD(mapData.getPaidHolidayTime(), kosu));
                }

                // 販売時間
                if ((pjIdTypeP || pjIdTypeR) && pjIdBranch) {
                    mapData.setSaleTime(addBD(mapData.getSaleTime(), kosu));
                }

                // 他間接時間
                if (pjIdTypeO && !koteiCd.equals("ZCZ10")) {
                    mapData.setOtherIndirectTime(addBD(mapData.getOtherIndirectTime(), kosu));
                }

                // 他間接時間内訳（社内会議）
                if (pjIdTypeO && koteiCd.equals("ZCA10")) {
                    mapData.setOtherIndirectTimeZca10(addBD(mapData.getOtherIndirectTimeZca10(), kosu));
                }

                // 他間接時間内訳（社外活動）
                if (pjIdTypeO && koteiCd.equals("ZCA20")) {
                    mapData.setOtherIndirectTimeZca20(addBD(mapData.getOtherIndirectTimeZca20(), kosu));
                }

                // 他間接時間内訳（ISO9001）
                if (pjIdTypeO && koteiCd.equals("ZCA30")) {
                    mapData.setOtherIndirectTimeZca30(addBD(mapData.getOtherIndirectTimeZca30(), kosu));
                }

                // 他間接時間内訳（ISO14001）
                if (pjIdTypeO && koteiCd.equals("ZCA40")) {
                    mapData.setOtherIndirectTimeZca40(addBD(mapData.getOtherIndirectTimeZca40(), kosu));
                }

                // 他間接時間内訳（QDC活動）
                if (pjIdTypeO && koteiCd.equals("ZCA50")) {
                    mapData.setOtherIndirectTimeZca50(addBD(mapData.getOtherIndirectTimeZca50(), kosu));
                }

                // 他間接時間内訳（Pマーク）
                if (pjIdTypeO && koteiCd.equals("ZCA60")) {
                    mapData.setOtherIndirectTimeZca60(addBD(mapData.getOtherIndirectTimeZca60(), kosu));
                }

                // 他間接時間内訳（ISO27001）
                if (pjIdTypeO && koteiCd.equals("ZCA70")) {
                    mapData.setOtherIndirectTimeZca70(addBD(mapData.getOtherIndirectTimeZca70(), kosu));
                }

                // 他間接時間内訳（本部からの依頼）
                if (pjIdTypeO && koteiCd.equals("ZCA80")) {
                    mapData.setOtherIndirectTimeZca80(addBD(mapData.getOtherIndirectTimeZca80(), kosu));
                }

                // 他間接時間内訳（講習会、研修会）
                if (pjIdTypeO && koteiCd.equals("ZCC10")) {
                    mapData.setOtherIndirectTimeZcc10(addBD(mapData.getOtherIndirectTimeZcc10(), kosu));
                }

                // 他間接時間内訳（業務管理）
                if (pjIdTypeO && koteiCd.equals("ZCC20")) {
                    mapData.setOtherIndirectTimeZcc20(addBD(mapData.getOtherIndirectTimeZcc20(), kosu));
                }

                // 他間接時間内訳（2Wayｺﾐｭﾆｹｰｼｮﾝ）
                if (pjIdTypeO && koteiCd.equals("ZCC40")) {
                    mapData.setOtherIndirectTimeZcc40(addBD(mapData.getOtherIndirectTimeZcc40(), kosu));
                }

                // 他間接時間内訳（その他）
                if (pjIdTypeO && koteiCd.equals("ZCC50")) {
                    mapData.setOtherIndirectTimeZcc50(addBD(mapData.getOtherIndirectTimeZcc50(), kosu));
                }

                if (i == detailList.size() - 1) {
                    dateMap.put(mdb0804PerformanceInput.concat(), mapData);
                }

            } else {

                itemOutput = new MDB0804Output();

                // 部門ＣＤ
                itemOutput.setDeptCd(mdb0804PerformanceInput.getDeptCd());

                // 部門名称
                itemOutput.setDeptName(mdb0804PerformanceInput.getDeptName());

                // 会社名称
                itemOutput.setCorpName(mdb0804PerformanceInput.getCorpName());

                // 生産担当部門支社ＣＤ
                itemOutput.setProductDeptBranchCd(mdb0804PerformanceInput.getBranchCd());

                // 生産担当部門支社名称
                itemOutput.setProductDeptBranchName(mdb0804PerformanceInput.getBranchName());

                // 生産担当部門部ＣＤ
                itemOutput.setProductMDeptCd(mdb0804PerformanceInput.getDeptMCd());

                // 生産担当部門部名称
                itemOutput.setProductMDeptName(mdb0804PerformanceInput.getDeptMName());

                // 生産担当部門小部門ＣＤ
                itemOutput.setProductSDeptCd(mdb0804PerformanceInput.getDeptSCd());

                // 生産担当部門小部門名称
                itemOutput.setProductSDeptName(mdb0804PerformanceInput.getDeptSName());

                // 経費種類
                itemOutput.setCostKind(mdb0804PerformanceInput.getDeptType());

                // 会計年度
                String year = mdb0804PerformanceInput.getYm().substring(0, 4);
                String month = mdb0804PerformanceInput.getYm().substring(4, 6);

                if (month.equals("01") || month.equals("02") || month.equals("03")) {
                    itemOutput.setFiscalYear(new BigDecimal(Integer.parseInt(year) - 1));
                } else {
                    itemOutput.setFiscalYear(new BigDecimal(year));
                }

                // 会計期間
                if (month.equals("01") || month.equals("02") || month.equals("03")) {
                    itemOutput.setFiscalMonth(new BigDecimal(Integer.parseInt(month) + 9));
                } else {
                    itemOutput.setFiscalMonth(new BigDecimal(Integer.parseInt(month) - 3));
                }

                // 社員区分
                itemOutput.setEmpKbn(mdb0804PerformanceInput.getEmpKbn());

                // 稼働人数
                itemOutput.setActivePeople(null == mdb0804PerformanceInput.getActivePeople()?BigDecimal.ZERO:mdb0804PerformanceInput.getActivePeople());

                // 直接時間
                if ((pjIdTypeP || pjIdTypeR) && !pjIdBranch) {
                    itemOutput.setDirectTime(null == kosu?BigDecimal.ZERO:kosu);
                }else {
                    itemOutput.setDirectTime(BigDecimal.ZERO);
                }

                // 直接の内【間機】時間
                if ((pjIdTypeP || pjIdTypeR) && !pjIdBranch
                        && mdb0804PerformanceInput.getPjName().indexOf("【間機】") == 0) {
                    itemOutput.setDirectMachineTime(null == kosu?BigDecimal.ZERO:kosu);
                }else {
                    itemOutput.setDirectMachineTime(BigDecimal.ZERO);
                }

                // 有休時間
                if (pjIdTypeO && koteiCd.equals("ZCZ10")) {
                    itemOutput.setPaidHolidayTime(null == kosu?BigDecimal.ZERO:kosu);
                }else {
                    itemOutput.setPaidHolidayTime(BigDecimal.ZERO);
                }

                // 販売時間
                if ((pjIdTypeP || pjIdTypeR) && pjIdBranch) {
                    itemOutput.setSaleTime(null == kosu?BigDecimal.ZERO:kosu);
                }else {
                    itemOutput.setSaleTime(BigDecimal.ZERO);
                }

                // 他間接時間
                if (pjIdTypeO && !koteiCd.equals("ZCZ10")) {
                    itemOutput.setOtherIndirectTime(null == kosu?BigDecimal.ZERO:kosu);
                }else {
                    itemOutput.setOtherIndirectTime(BigDecimal.ZERO);
                }

                // 他間接時間内訳（社内会議）
                if (pjIdTypeO && koteiCd.equals("ZCA10")) {
                    itemOutput.setOtherIndirectTimeZca10(null == kosu?BigDecimal.ZERO:kosu);
                }else {
                    itemOutput.setOtherIndirectTimeZca10(BigDecimal.ZERO);
                }

                // 他間接時間内訳（社外活動）
                if (pjIdTypeO && koteiCd.equals("ZCA20")) {
                    itemOutput.setOtherIndirectTimeZca20(null == kosu?BigDecimal.ZERO:kosu);
                }else {
                    itemOutput.setOtherIndirectTimeZca20(BigDecimal.ZERO);
                }

                // 他間接時間内訳（ISO9001）
                if (pjIdTypeO && koteiCd.equals("ZCA30")) {
                    itemOutput.setOtherIndirectTimeZca30(null == kosu?BigDecimal.ZERO:kosu);
                }else {
                    itemOutput.setOtherIndirectTimeZca30(BigDecimal.ZERO);
                }

                // 他間接時間内訳（ISO14001）
                if (pjIdTypeO && koteiCd.equals("ZCA40")) {
                    itemOutput.setOtherIndirectTimeZca40(null == kosu?BigDecimal.ZERO:kosu);
                }else {
                    itemOutput.setOtherIndirectTimeZca40(BigDecimal.ZERO);
                }

                // 他間接時間内訳（QDC活動）
                if (pjIdTypeO && koteiCd.equals("ZCA50")) {
                    itemOutput.setOtherIndirectTimeZca50(null == kosu?BigDecimal.ZERO:kosu);
                }else {
                    itemOutput.setOtherIndirectTimeZca50(BigDecimal.ZERO);
                }

                // 他間接時間内訳（Pマーク）
                if (pjIdTypeO && koteiCd.equals("ZCA60")) {
                    itemOutput.setOtherIndirectTimeZca60(null == kosu?BigDecimal.ZERO:kosu);
                }else {
                    itemOutput.setOtherIndirectTimeZca60(BigDecimal.ZERO);
                }

                // 他間接時間内訳（ISO27001）
                if (pjIdTypeO && koteiCd.equals("ZCA70")) {
                    itemOutput.setOtherIndirectTimeZca70(null == kosu?BigDecimal.ZERO:kosu);
                }else {
                    itemOutput.setOtherIndirectTimeZca70(BigDecimal.ZERO);
                }

                // 他間接時間内訳（本部からの依頼）
                if (pjIdTypeO && koteiCd.equals("ZCA80")) {
                    itemOutput.setOtherIndirectTimeZca80(null == kosu?BigDecimal.ZERO:kosu);
                }else {
                    itemOutput.setOtherIndirectTimeZca80(BigDecimal.ZERO);
                }

                // 他間接時間内訳（講習会、研修会）
                if (pjIdTypeO && koteiCd.equals("ZCC10")) {
                    itemOutput.setOtherIndirectTimeZcc10(null == kosu?BigDecimal.ZERO:kosu);
                }else {
                    itemOutput.setOtherIndirectTimeZcc10(BigDecimal.ZERO);
                }

                // 他間接時間内訳（業務管理）
                if (pjIdTypeO && koteiCd.equals("ZCC20")) {
                    itemOutput.setOtherIndirectTimeZcc20(null == kosu?BigDecimal.ZERO:kosu);
                }else {
                    itemOutput.setOtherIndirectTimeZcc20(BigDecimal.ZERO);
                }

                // 他間接時間内訳（2Wayｺﾐｭﾆｹｰｼｮﾝ）
                if (pjIdTypeO && koteiCd.equals("ZCC40")) {
                    itemOutput.setOtherIndirectTimeZcc40(null == kosu?BigDecimal.ZERO:kosu);
                }else {
                    itemOutput.setOtherIndirectTimeZcc40(BigDecimal.ZERO);
                }

                // 他間接時間内訳（その他）
                if (pjIdTypeO && koteiCd.equals("ZCC50")) {
                    itemOutput.setOtherIndirectTimeZcc50(null == kosu?BigDecimal.ZERO:kosu);
                }else {
                    itemOutput.setOtherIndirectTimeZcc50(BigDecimal.ZERO);
                }

                // 積算値
                itemOutput.setPlanedKosu(BigDecimal.ZERO);

                // 計画稼働人数
                itemOutput.setPlanActivePeople(BigDecimal.ZERO);

                // 計画直接時間
                itemOutput.setPlanDirectTime(BigDecimal.ZERO);

                // 計画直接の内【間機】時間
                itemOutput.setPlanDirectMachineTime(BigDecimal.ZERO);

                // 計画有休時間
                itemOutput.setPlanPaidHolidayTime(BigDecimal.ZERO);

                // 計画販売時間
                itemOutput.setPlanSaleTime(BigDecimal.ZERO);

                // 計画他間接時間
                itemOutput.setPlanOtherIndirectTime(BigDecimal.ZERO);

                // 並び順_部門
                itemOutput.setSortNumDept(mdb0804PerformanceInput.getDispOrder());

                // 実績データ、計画データ、積算データのチェック区分
                itemOutput.setDataCheckKbn("performance");

                dateMap.put(mdb0804PerformanceInput.concat(), itemOutput);
            }
        }

        outputItems = new ArrayList<MDB0804Output>(dateMap.values());
        return outputItems;
    }

    private List<MDB0804Output> setPlanData(String year3, String systemDate) {

        List<MDB0804Output> outputItems = new ArrayList<MDB0804Output>();
        MDB0804Output itemOutput = null;

        MDB0804PlanInput itemInput = new MDB0804PlanInput();
        itemInput.setYm3(year3);
        itemInput.setSystemDate(systemDate);

        // ■計画データ
        List<MDB0804PlanInput> detailList = mdb0804Repository.findAllByPlan(itemInput);

        for (int i = 0; i < detailList.size(); i++) {

            MDB0804PlanInput mdb0804PlanInput = detailList.get(i);

            itemOutput = new MDB0804Output();

            // 部門ＣＤ
            itemOutput.setDeptCd(mdb0804PlanInput.getDeptCd());

            // 部門名称
            itemOutput.setDeptName(mdb0804PlanInput.getDeptName());

            // 会社名称
            itemOutput.setCorpName(mdb0804PlanInput.getCorpName());

            // 生産担当部門支社ＣＤ
            itemOutput.setProductDeptBranchCd(mdb0804PlanInput.getBranchCd());

            // 生産担当部門支社名称
            itemOutput.setProductDeptBranchName(mdb0804PlanInput.getBranchName());

            // 生産担当部門部ＣＤ
            itemOutput.setProductMDeptCd(mdb0804PlanInput.getDeptMCd());

            // 生産担当部門部名称
            itemOutput.setProductMDeptName(mdb0804PlanInput.getDeptMName());

            // 生産担当部門小部門ＣＤ
            itemOutput.setProductSDeptCd(mdb0804PlanInput.getDeptSCd());

            // 生産担当部門小部門名称
            itemOutput.setProductSDeptName(mdb0804PlanInput.getDeptSName());

            // 経費種類
            itemOutput.setCostKind(mdb0804PlanInput.getDeptType());

            // 会計年度
            String year = mdb0804PlanInput.getPlanYm().substring(0, 4);
            String month = mdb0804PlanInput.getPlanYm().substring(4, 6);

            if (month.equals("01") || month.equals("02") || month.equals("03")) {
                itemOutput.setFiscalYear(new BigDecimal(Integer.parseInt(year) - 1));
            } else {
                itemOutput.setFiscalYear(new BigDecimal(year));
            }

            // 会計期間
            if (month.equals("01") || month.equals("02") || month.equals("03")) {
                itemOutput.setFiscalMonth(new BigDecimal(Integer.parseInt(month) + 9));
            } else {
                itemOutput.setFiscalMonth(new BigDecimal(Integer.parseInt(month) - 3));
            }

            // 社員区分
            itemOutput.setEmpKbn("1");

            // 稼働人数
            itemOutput.setActivePeople(BigDecimal.ZERO);

            // 直接時間
            itemOutput.setDirectTime(BigDecimal.ZERO);

            // 直接の内【間機】時間
            itemOutput.setDirectMachineTime(BigDecimal.ZERO);

            // 有休時間
            itemOutput.setPaidHolidayTime(BigDecimal.ZERO);

            // 販売時間
            itemOutput.setSaleTime(BigDecimal.ZERO);

            // 他間接時間
            itemOutput.setOtherIndirectTime(BigDecimal.ZERO);

            // 他間接時間内訳（社内会議）
            itemOutput.setOtherIndirectTimeZca10(BigDecimal.ZERO);

            // 他間接時間内訳（社外活動）
            itemOutput.setOtherIndirectTimeZca20(BigDecimal.ZERO);

            // 他間接時間内訳（ISO9001）
            itemOutput.setOtherIndirectTimeZca30(BigDecimal.ZERO);

            // 他間接時間内訳（ISO14001）
            itemOutput.setOtherIndirectTimeZca40(BigDecimal.ZERO);

            // 他間接時間内訳（QDC活動）
            itemOutput.setOtherIndirectTimeZca50(BigDecimal.ZERO);

            // 他間接時間内訳（Pマーク）
            itemOutput.setOtherIndirectTimeZca60(BigDecimal.ZERO);

            // 他間接時間内訳（ISO27001）
            itemOutput.setOtherIndirectTimeZca70(BigDecimal.ZERO);

            // 他間接時間内訳（本部からの依頼）
            itemOutput.setOtherIndirectTimeZca80(BigDecimal.ZERO);

            // 他間接時間内訳（講習会、研修会）
            itemOutput.setOtherIndirectTimeZcc10(BigDecimal.ZERO);

            // 他間接時間内訳（業務管理）
            itemOutput.setOtherIndirectTimeZcc20(BigDecimal.ZERO);

            // 他間接時間内訳（2Wayｺﾐｭﾆｹｰｼｮﾝ）
            itemOutput.setOtherIndirectTimeZcc40(BigDecimal.ZERO);

            // 他間接時間内訳（その他）
            itemOutput.setOtherIndirectTimeZcc50(BigDecimal.ZERO);

            // 積算値
            itemOutput.setPlanedKosu(BigDecimal.ZERO);

            // 計画稼働人数
            itemOutput.setPlanActivePeople(null == mdb0804PlanInput.getPlanDeptPeople()?BigDecimal.ZERO:mdb0804PlanInput.getPlanDeptPeople());

            // 計画直接時間
            itemOutput.setPlanDirectTime(null == mdb0804PlanInput.getDirectKosu()?BigDecimal.ZERO:mdb0804PlanInput.getDirectKosu());

            // 計画直接の内【間機】時間
            itemOutput.setPlanDirectMachineTime(null == mdb0804PlanInput.getDirectMachineKosu()?BigDecimal.ZERO:mdb0804PlanInput.getDirectMachineKosu());

            // 計画有休時間
            itemOutput.setPlanPaidHolidayTime(null == mdb0804PlanInput.getPaidHolidayKosu()?BigDecimal.ZERO:mdb0804PlanInput.getPaidHolidayKosu());

            // 計画販売時間
            itemOutput.setPlanSaleTime(null == mdb0804PlanInput.getSaleKosu()?BigDecimal.ZERO:mdb0804PlanInput.getSaleKosu());

            // 計画他間接時間
            itemOutput.setPlanOtherIndirectTime(null == mdb0804PlanInput.getOtherIndirectKosu()?BigDecimal.ZERO:mdb0804PlanInput.getOtherIndirectKosu());

            // 並び順_部門
            itemOutput.setSortNumDept(mdb0804PlanInput.getDispOrder());

            // 実績データ、計画データ、積算データのチェック区分
            itemOutput.setDataCheckKbn("plan");

            outputItems.add(itemOutput);
        }

        return outputItems;
    }

    private List<MDB0804Output> setEstimateData(String year3, String systemDate) {

        List<MDB0804Output> outputItems = new ArrayList<MDB0804Output>();
        MDB0804Output itemOutput = null;

        MDB0804EstimateInput itemInput = new MDB0804EstimateInput();
        itemInput.setYm3(year3);
        itemInput.setSystemDate(systemDate);

        // ■計画データ
        List<MDB0804EstimateInput> detailList = mdb0804Repository.findAllByEstimate(itemInput);

        for (int i = 0; i < detailList.size(); i++) {

            MDB0804EstimateInput mdb0804EstimateInput = detailList.get(i);

            itemOutput = new MDB0804Output();

            // 部門ＣＤ
            itemOutput.setDeptCd(mdb0804EstimateInput.getProSalesDeptCd());

            // 部門名称
            itemOutput.setDeptName(mdb0804EstimateInput.getDeptName());

            // 会社名称
            itemOutput.setCorpName(mdb0804EstimateInput.getCorpName());

            // 生産担当部門支社ＣＤ
            itemOutput.setProductDeptBranchCd(mdb0804EstimateInput.getBranchCd());

            // 生産担当部門支社名称
            itemOutput.setProductDeptBranchName(mdb0804EstimateInput.getBranchName());

            // 生産担当部門部ＣＤ
            itemOutput.setProductMDeptCd(mdb0804EstimateInput.getDeptMCd());

            // 生産担当部門部名称
            itemOutput.setProductMDeptName(mdb0804EstimateInput.getDeptMName());

            // 生産担当部門小部門ＣＤ
            itemOutput.setProductSDeptCd(mdb0804EstimateInput.getDeptSCd());

            // 生産担当部門小部門名称
            itemOutput.setProductSDeptName(mdb0804EstimateInput.getDeptSName());

            // 経費種類
            itemOutput.setCostKind(mdb0804EstimateInput.getDeptType());

            // 会計年度
            String year = mdb0804EstimateInput.getWorkYm().substring(0, 4);
            String month = mdb0804EstimateInput.getWorkYm().substring(4, 6);

            if (month.equals("01") || month.equals("02") || month.equals("03")) {
                itemOutput.setFiscalYear(new BigDecimal(Integer.parseInt(year) - 1));
            } else {
                itemOutput.setFiscalYear(new BigDecimal(year));
            }

            // 会計期間
            if (month.equals("01") || month.equals("02") || month.equals("03")) {
                itemOutput.setFiscalMonth(new BigDecimal(Integer.parseInt(month) + 9));
            } else {
                itemOutput.setFiscalMonth(new BigDecimal(Integer.parseInt(month) - 3));
            }

            // 社員区分
            itemOutput.setEmpKbn(mdb0804EstimateInput.getHimokuCd().substring(1, 2));

            // 稼働人数
            itemOutput.setActivePeople(BigDecimal.ZERO);

            // 直接時間
            itemOutput.setDirectTime(BigDecimal.ZERO);

            // 直接の内【間機】時間
            itemOutput.setDirectMachineTime(BigDecimal.ZERO);

            // 有休時間
            itemOutput.setPaidHolidayTime(BigDecimal.ZERO);

            // 販売時間
            itemOutput.setSaleTime(BigDecimal.ZERO);

            // 他間接時間
            itemOutput.setOtherIndirectTime(BigDecimal.ZERO);

            // 他間接時間内訳（社内会議）
            itemOutput.setOtherIndirectTimeZca10(BigDecimal.ZERO);

            // 他間接時間内訳（社外活動）
            itemOutput.setOtherIndirectTimeZca20(BigDecimal.ZERO);

            // 他間接時間内訳（ISO9001）
            itemOutput.setOtherIndirectTimeZca30(BigDecimal.ZERO);

            // 他間接時間内訳（ISO14001）
            itemOutput.setOtherIndirectTimeZca40(BigDecimal.ZERO);

            // 他間接時間内訳（QDC活動）
            itemOutput.setOtherIndirectTimeZca50(BigDecimal.ZERO);

            // 他間接時間内訳（Pマーク）
            itemOutput.setOtherIndirectTimeZca60(BigDecimal.ZERO);

            // 他間接時間内訳（ISO27001）
            itemOutput.setOtherIndirectTimeZca70(BigDecimal.ZERO);

            // 他間接時間内訳（本部からの依頼）
            itemOutput.setOtherIndirectTimeZca80(BigDecimal.ZERO);

            // 他間接時間内訳（講習会、研修会）
            itemOutput.setOtherIndirectTimeZcc10(BigDecimal.ZERO);

            // 他間接時間内訳（業務管理）
            itemOutput.setOtherIndirectTimeZcc20(BigDecimal.ZERO);

            // 他間接時間内訳（2Wayｺﾐｭﾆｹｰｼｮﾝ）
            itemOutput.setOtherIndirectTimeZcc40(BigDecimal.ZERO);

            // 他間接時間内訳（その他）
            itemOutput.setOtherIndirectTimeZcc50(BigDecimal.ZERO);

            // 積算値
            itemOutput.setPlanedKosu(null == mdb0804EstimateInput.getQuantity()?BigDecimal.ZERO:mdb0804EstimateInput.getQuantity());

            // 計画稼働人数
            itemOutput.setPlanActivePeople(BigDecimal.ZERO);

            // 計画直接時間
            itemOutput.setPlanDirectTime(BigDecimal.ZERO);

            // 計画直接の内【間機】時間
            itemOutput.setPlanDirectMachineTime(BigDecimal.ZERO);

            // 計画有休時間
            itemOutput.setPlanPaidHolidayTime(BigDecimal.ZERO);

            // 計画販売時間
            itemOutput.setPlanSaleTime(BigDecimal.ZERO);

            // 計画他間接時間
            itemOutput.setPlanOtherIndirectTime(BigDecimal.ZERO);

            // 並び順_部門
            itemOutput.setSortNumDept(mdb0804EstimateInput.getDispOrder());

            // 実績データ、計画データ、積算データのチェック区分
            itemOutput.setDataCheckKbn("estimate");

            outputItems.add(itemOutput);
        }

        return outputItems;
    }

    private String getCurrentMonth(LocalDateTime systemDateTime) {
        return systemDateTime.format(dtfUUUUMM);
    }

    private String getPreviousMonth(LocalDateTime systemDateTime) {
        return systemDateTime.minusMonths(1).format(dtfUUUUMM);
    }

    private String getFiscalYear(LocalDateTime systemDateTime) {
        return systemDateTime.minusMonths(3).format(dtfUUUU);
    }

    private BigDecimal addBD(BigDecimal input1, BigDecimal input2) {

        BigDecimal rtn = null;

        if (input1 != null && input2 != null) {
            rtn = input1.add(input2);
        } else {

            if (input1 == null && input2 == null) {
                rtn = null;
            } else if (input1 == null) {
                rtn = input2;
            } else {
                rtn = input1;
            }
        }

        return rtn;
    }

    private List<MDB0804Output> getEditList(List<MDB0804Output> inputList){

        // 値に100を掛けてテーブルに格納する
        for (MDB0804Output fwb0804Output : inputList) {

            // 直接時間
            fwb0804Output.setDirectTime(multiply100BD(fwb0804Output.getDirectTime()));

            // 直接の内【間機】時間
            fwb0804Output.setDirectMachineTime(multiply100BD(fwb0804Output.getDirectMachineTime()));

            // 有休時間
            fwb0804Output.setPaidHolidayTime(multiply100BD(fwb0804Output.getPaidHolidayTime()));

            // 販売時間
            fwb0804Output.setSaleTime(multiply100BD(fwb0804Output.getSaleTime()));

            // 他間接時間
            fwb0804Output.setOtherIndirectTime(multiply100BD(fwb0804Output.getOtherIndirectTime()));

            // 他間接時間内訳（社内会議）
            fwb0804Output.setOtherIndirectTimeZca10(multiply100BD(fwb0804Output.getOtherIndirectTimeZca10()));

            // 他間接時間内訳（社外活動）
            fwb0804Output.setOtherIndirectTimeZca20(multiply100BD(fwb0804Output.getOtherIndirectTimeZca20()));

            // 他間接時間内訳（ISO9001）
            fwb0804Output.setOtherIndirectTimeZca30(multiply100BD(fwb0804Output.getOtherIndirectTimeZca30()));

            // 他間接時間内訳（ISO14001）
            fwb0804Output.setOtherIndirectTimeZca40(multiply100BD(fwb0804Output.getOtherIndirectTimeZca40()));

            // 他間接時間内訳（QDC活動）
            fwb0804Output.setOtherIndirectTimeZca50(multiply100BD(fwb0804Output.getOtherIndirectTimeZca50()));

            // 他間接時間内訳（Pマーク）
            fwb0804Output.setOtherIndirectTimeZca60(multiply100BD(fwb0804Output.getOtherIndirectTimeZca60()));

            // 他間接時間内訳（ISO27001）
            fwb0804Output.setOtherIndirectTimeZca70(multiply100BD(fwb0804Output.getOtherIndirectTimeZca70()));

            // 他間接時間内訳（本部からの依頼）
            fwb0804Output.setOtherIndirectTimeZca80(multiply100BD(fwb0804Output.getOtherIndirectTimeZca80()));

            // 他間接時間内訳（講習会、研修会）
            fwb0804Output.setOtherIndirectTimeZcc10(multiply100BD(fwb0804Output.getOtherIndirectTimeZcc10()));

            // 他間接時間内訳（業務管理）
            fwb0804Output.setOtherIndirectTimeZcc20(multiply100BD(fwb0804Output.getOtherIndirectTimeZcc20()));

            // 他間接時間内訳（2Wayｺﾐｭﾆｹｰｼｮﾝ）
            fwb0804Output.setOtherIndirectTimeZcc40(multiply100BD(fwb0804Output.getOtherIndirectTimeZcc40()));

            // 他間接時間内訳（その他）
            fwb0804Output.setOtherIndirectTimeZcc50(multiply100BD(fwb0804Output.getOtherIndirectTimeZcc50()));

            // 積算値
            fwb0804Output.setPlanedKosu(multiply100BD(fwb0804Output.getPlanedKosu()));

            // 計画直接時間
            fwb0804Output.setPlanDirectTime(multiply100BD(fwb0804Output.getPlanDirectTime()));

            // 計画直接の内【間機】時間
            fwb0804Output.setPlanDirectMachineTime(multiply100BD(fwb0804Output.getPlanDirectMachineTime()));

            // 計画有休時間
            fwb0804Output.setPlanPaidHolidayTime(multiply100BD(fwb0804Output.getPlanPaidHolidayTime()));

            // 計画販売時間
            fwb0804Output.setPlanSaleTime(multiply100BD(fwb0804Output.getPlanSaleTime()));

            // 計画他間接時間
            fwb0804Output.setPlanOtherIndirectTime(multiply100BD(fwb0804Output.getPlanOtherIndirectTime()));

        }

        return inputList;

    }

    private BigDecimal multiply100BD(BigDecimal input1) {

        BigDecimal rtn = new BigDecimal("0");
        BigDecimal input2 = new BigDecimal("100");

        if (input1 != null) {
            rtn = input1.multiply(input2);
        }

        return rtn;
    }

}
