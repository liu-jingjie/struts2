package jp.co.aeroasahi.tpkt.batch.fwb0111;

import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】委託先マスタ＞のOutputBean。
 */
@Setter
@Getter
public class FWB0111TpktOutput {

    /** 委託先CD */
    private String vendorCd;

    /** 業者CD */
    private String vendorSortCd;

    /** 委託先名称 */
    private String vendorName;

    /** ヨミガナ */
    private String vendorNameKana;

    /** 所在地 */
    private String address;

    /** 取引先フラグ */
    private String supplier;

    /** 郵便番号 */
    private String postalCode;

    /** 都道府県 */
    private String prefectures;

    /** 市区町村 */
    private String municipality;

    /** 地名 1 */
    private String street1;

    /** 地名 2 */
    private String street2;

    /** 地名 3 */
    private String street3;

    /** 電話番号 */
    private String telNum;

    /** 源泉対象有無 */
    private String withholding;

    /** 国CD */
    private String countryCd;

    /** 支払期日 */
    private String paymantLimit;

    /** 支払方法 */
    private String paymantMethod;

    /** 仕入先ブロック */
    private String supplierBlock;

    /** 作成者 */
    private String createdBy;

    /** 作成日 */
    private String createdAt;

    /** 更新者 */
    private String updatedBy;

    /** 更新日 */
    private String updatedAt;

    /** 削除フラグ */
    private String deleted;

    /** 通貨 */
    private String currency;

    /** 取引先の会社ID */
    private String supplierCorpId;

}
