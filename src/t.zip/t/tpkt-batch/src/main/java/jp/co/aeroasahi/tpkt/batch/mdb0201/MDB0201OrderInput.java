package jp.co.aeroasahi.tpkt.batch.mdb0201;

import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜ビジネスユニットコード変換＞とテーブル＜SAP受注＞のInputBean。
 */
@Setter
@Getter
public class MDB0201OrderInput {

    /** ビジネスユニットコード変換のビジネスユニット*/
    private String bu;

    /** SAP受注の受注伝票番号*/
    private String vbeln;

    /** SAP受注の受注明細番号*/
    private String posnr;

    /** SAP受注のプロジェクトID*/
    private String psPspPnr;

    /** SAP受注の受注日*/
    private String audat;

    /** SAP受注の受注金額（税抜き）*/
    private BigDecimal netwr;

    /** SAP受注の売上予定日*/
    private String fkdat;

    /** SAP受注の積算原価額*/
    private BigDecimal zsekisana3;

    /** SAP受注の高原価・政策受注フラグ*/
    private String zkouflag;

    /** SAP受注の受注申請時積算原価率*/
    private BigDecimal zsekisanr3;
}
