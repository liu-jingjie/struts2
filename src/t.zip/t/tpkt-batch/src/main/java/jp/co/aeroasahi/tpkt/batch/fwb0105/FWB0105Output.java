package jp.co.aeroasahi.tpkt.batch.fwb0105;

import java.math.BigDecimal;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.batch.item.ItemCountAware;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】SAP勘定明細＞のOutputBean。
 */
@Setter
@Getter
public class FWB0105Output implements ItemCountAware {

    private int count;

    /** 会社コード */
    @NotBlank
    @Size(min = 1, max = 2)
    private String BUKRS;

    /** 伝票番号 */
    @NotBlank
    @Size(min = 1, max = 10)
    private String BELNR;

    /** 会計年度 */
    @NotBlank
    @Size(min = 1, max = 4)
    private String GJAHR;

    /** 会計期間 */
    @Size(min = 0, max = 2)
    private String MONAT;

    /** 転記日付 */
    @Size(min = 0, max = 23)
    private String BUDAT;

    /** 請求書伝票番号 */
    @Size(min = 0, max = 16)
    private String RBUKRS;

    /** 勘定コード */
    @NotBlank
    @Size(min = 1, max = 8)
    private String HKONT;

    /** 部門 */
    @NotBlank
    @Size(min = 1, max = 6)
    private String PRCTR;

    /** プロジェクトID */
    @NotBlank
    @Size(min = 1, max = 12)
    private String PROJK;

    /** 発注番号 */
    @Size(min = 0, max = 10)
    private String EBELN;

    /** 申請番号 */
    @Size(min = 0, max = 13)
    private String ABLAD;

    /** 委託先枝番 */
    @Size(min = 0, max = 2)
    private String WEMPF;

    /** 支払予定日 */
    @Size(min = 0, max = 23)
    private String ZFBDT;

    /** 金額 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal DMBTR;

    /** 作成日 */
    @Size(min = 0, max = 23)
    private String INS_DT;

    /** 更新日 */
    @Size(min = 0, max = 23)
    private String UPD_DT;

    @Override
    public void setItemCount(int count) {
        this.count = count;
    }

    /**
     * 会社コードと伝票番号と会計年度と勘定コードと部門とプロジェクトIDを結合する
     * @return
     */
    public String concat() {
        return BUKRS + "," + BELNR + "," + GJAHR + "," + HKONT + "," + PRCTR + "," + PROJK;
    }
}
