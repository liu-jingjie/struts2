package jp.co.aeroasahi.tpkt.batch.cm.task.fbfw005;

import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜バッチ管理＞のOutputBean。
 */
@Setter
@Getter
public class FBFW005Output {

    /** 日時キー */
    private String timeKey;

    /** メッセージ */
    private String message;

    /** タスク名 */
    private String taskName;

    /** 削除フラグ */
    private boolean deleted;

}
