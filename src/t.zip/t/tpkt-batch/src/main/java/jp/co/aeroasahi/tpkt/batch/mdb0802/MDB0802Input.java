package jp.co.aeroasahi.tpkt.batch.mdb0802;

import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜外注情報＞＜プロジェクト＞＜プロジェクト属性＞＜委託先マスタ＞＜応受援基本情報＞＜応受援委託先枝番情報＞
 * ＜金額＞＜社員＞＜部門マスタ＞＜部門表示順マスタ＞＜受注＞のInputBean。
 */
@Setter
@Getter
public class MDB0802Input {

    /** 外注情報の発注書No */
    private String orderNum;

    /** 外注情報のプロジェクトID */
    private String pjId;

    /** プロジェクトのプロジェクト名称 */
    private String pjName;

    /** 部門マスタの支社コード */
    private String pjManageRespDeptBranchCd;

    /** 部門マスタの支社名 */
    private String pjManageRespDeptBranchName;

    /** 部門マスタの中部門CD */
    private String pjManageRespMiddleDeptCd;

    /** 部門マスタの中部門名称 */
    private String pjManageRespMiddleDeptName;

    /** プロジェクト属性の物件管理責任者部門CD */
    private String pjManageRespDeptCd;

    /** 部門マスタの小部門名称 */
    private String pjManageRespDeptName;

    /** プロジェクト属性の物件管理責任者CD */
    private String pjManageRespEmpCd;

    /** 社員の社員名 */
    private String pjManageRespEmpName;

    /** 部門マスタの支社コード */
    private String productMainDeptBranchCd;

    /** 部門マスタの支社名 */
    private String productMainDeptBranchName;

    /** 部門マスタの中部門CD */
    private String productMainMiddleDeptCd;

    /** 部門マスタの中部門名称 */
    private String productMainMiddleDeptName;

    /** プロジェクト属性の生産主管部門CD */
    private String productMainDeptCd;

    /** 部門マスタの小部門名称 */
    private String productMainDeptName;

    /** プロジェクト属性の生産プロデューサーCD */
    private String productProducerEmpCd;

    /** 社員の社員名 */
    private String productProducerName;

    /** 部門マスタの支社コード */
    private String productDeptBranchCd;

    /** 部門マスタの支社名 */
    private String productDeptBranchName;

    /** 部門マスタの中部門CD */
    private String productMiddleDeptCd;

    /** 部門マスタの中部門名称 */
    private String productMiddleDeptName;

    /** プロジェクトの生産・営業担当部門CD */
    private String productDeptCd;

    /** 部門マスタの小部門名称 */
    private String productDeptName;

    /** プロジェクトの生産・営業担当者CD */
    private String appliedEmpCd;

    /** 社員の社員名 */
    private String appliedEmpName;

    /** 応受援基本情報の申請日 */
    private String appliedAt;

    /** 応受援基本情報の申請番号 */
    private String applyNum;

    /** 応受援基本情報の再委託区分 */
    private String reentrustKbn;

    /** 金額の金額 */
    private BigDecimal planedOutsourcing;

    /** プロジェクトの最終売上完了日 */
    private String soldOn;

    /** プロジェクトの売上予定日 */
    private String plannedSalesOn;

    /** 外注情報の業者CD */
    private String vendorCd;

    /** 委託先マスタの委託先名称 */
    private String vendorName;

    /** 外注情報の注文日 */
    private String orderedOn;

    /** 外注情報の作業着手日 */
    private String workFrom;

    /** 外注情報の作業終了日 */
    private String workTo;

    /** 外注情報の納品予定日 */
    private String planedDeliveryOn;

    /** 外注情報の支払処理日 */
    private String paymentProcessedOn;

    /** 外注情報の外注費（一般）発生ベース */
    private BigDecimal outsideOrderedCost;

    /** 外注情報の外注費（一般）支払ベース */
    private BigDecimal outsidePaidCost;

    /** 外注情報の外注費（関係）発注ベース */
    private BigDecimal groupOrderedCost;

    /** 外注情報の外注費（関係）支払ベース */
    private BigDecimal groupPaidCost;

    /** 外注情報の業務委託費発注ベース */
    private BigDecimal entrustOrderedCost;

    /** 外注情報の業務委託費支払ベース */
    private BigDecimal entrustPaidCost;

    /** 外注情報の外注費（一般）発生ベース 外注費（関係）発注ベース */
    private BigDecimal totalOrderedCost;

    /** 外注情報の外注費（一般）支払ベース 外注費（関係）支払ベース */
    private BigDecimal totalPaidCost;

    /** 部門表示順マスタの表示順（物件管理責任者部門） */
    private BigDecimal sortNumPjManageRespDept;

    /** 部門表示順マスタの表示順（生産主管部門） */
    private BigDecimal sortNumProductMainDept;

    /** 部門表示順マスタの表示順（生産担当部門） */
    private BigDecimal sortNumProductDept;

    /** 年度開始月 検索用*/
    private String fiscalStartYearMonth;

    /** 年度終了月 検索用*/
    private String fiscalEndYearMonth;

    /** 年度 検索用*/
    private String fiscalYear;

    /** 日次 システム日付 */
    private String systemDate;

    /** 月次の場合用 （YYYY-MM-DD）指定月の末日 */
    private String specifiedMonth;

    /** 月次の場合用、指定年月 検索用*/
    private String designationYearMonth;

}
