package jp.co.aeroasahi.tpkt.batch.fwb0203;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.inject.Inject;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;
import jp.co.aeroasahi.tpkt.common.fw.mail.MailRequestSharedService;
import jp.co.aeroasahi.tpkt.common.model.fw.MailManagement;

/**
 * CIMよりデータが連携された際に管理者への通知を行う
 * →CIMの一時保管用フォルダに出力された社員情報連携時のログファイルが存在する場合に管理者へメールを送信する
 */
@Component
@Scope("step")
public class FWB0203Tasklet implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(FWB0203Tasklet.class);

    @Inject
    DateFactory dateFactory;

    @Inject
    MailRequestSharedService mailRequestSharedService;

    /** メールアドレスTO */
    @Value("${cim.address.to}")
    String cimAddressTo;

    /** ファイルの移動元フォルダ */
    @Value("${cim.path.temp}")
    String cimPathTemp;

    /** ファイルの移動先フォルダ */
    @Value("${cim.path.log}")
    String cimPathLog;

    /** メール件名 */
    private static final String MAILSUBJECT = "[JP1 INFO] CIM社員情報連携";

    /** メール本文 */
    private static final String MAILBODY =
            "<html><body><h3>CIMより社員情報が連携されました。</h3><br/>ログ情報: \\\\VSV0382\\AACTPKT\\CIMRelation\\LOG</body></html>";

    /** DateTimeFormatterのパターン uuuuMMdd */
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("uuuuMMdd");

    /** DateTimeFormatterのパターン uuuu-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.SSS");

    /**
     *
     * ID連携メール通知
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return バッチ終了ステータス
     */
    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        LocalDateTime systemDateTime = dateFactory.newDateTime();
        LocalDate sysDate = LocalDate.of(systemDateTime.getYear(), systemDateTime.getMonth(), systemDateTime.getDayOfMonth());

        String systemDateStr = sysDate.format(dtf);

        // ■社員情報連携状況確認

        // 一時保管用フォルダ内に、社員情報連携時に出力されたログファイルが存在するかを確認する
        // フォルダ内にログファイルが1ファイル以上存在する場合
        String[] inputFileArray = getFileName(cimPathTemp);

        if (inputFileArray.length > 0) {

            // 管理者へメールを送信する
            MailManagement mailManagement = createMailManagement(systemDateTime);
            mailRequestSharedService.requestNoAttachmentMail(mailManagement);

            // ■ログファイルの移動
            String outputFileName =
                    systemDateStr + inputFileArray[0].substring(8, inputFileArray[0].indexOf(".")) + ".log";
            mergeAndMoveFiles(cimPathLog + outputFileName, cimPathTemp, inputFileArray);
        }

        return RepeatStatus.FINISHED;
    }

    private MailManagement createMailManagement(LocalDateTime systemDate) {
        // メール管理情報を設定
        MailManagement mailManagement = new MailManagement();

        mailManagement.setMailAddressTo(cimAddressTo);
        mailManagement.setMailAddressCc("");
        mailManagement.setSubject(MAILSUBJECT);
        mailManagement.setCreatedAt(systemDate.format(dtf1));
        mailManagement.setBody(MAILBODY);

        return mailManagement;
    }

    @SuppressWarnings("resource")
    private void mergeAndMoveFiles(String outFile, String path, String[] files) {

        int BUFSIZE = 1024 * 8;
        FileChannel outChannel = null;
        try {
            outChannel = new FileOutputStream(outFile).getChannel();
            for (String f : files) {
                FileChannel fc = new FileInputStream(path + f).getChannel();
                ByteBuffer bb = ByteBuffer.allocate(BUFSIZE);
                while (fc.read(bb) != -1) {
                    bb.flip();
                    outChannel.write(bb);
                    bb.clear();
                }
                fc.close();
            }

            for (String f : files) {
                deleteFile(path + f);
            }
        } catch (IOException ioe) {
            logger.error("stackTrace：", ioe);
        } finally {
            try {
                if (outChannel != null) {
                    outChannel.close();
                }
            } catch (IOException ignore) {
                logger.error("stackTrace：", ignore);
            }
        }
    }

    private String[] getFileName(String path) {
        File file = new File(path);
        String[] fileName = file.list();
        return fileName;
    }

    private boolean deleteFile(String preFilePath) {

        boolean rtn = false;
        File target = new File(preFilePath);
        rtn = FileUtils.deleteQuietly(target);

        return rtn;
    }

}

