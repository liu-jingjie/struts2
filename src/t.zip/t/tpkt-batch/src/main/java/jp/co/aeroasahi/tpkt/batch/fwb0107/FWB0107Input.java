package jp.co.aeroasahi.tpkt.batch.fwb0107;

import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】SAP仕掛原価＞のInputBean。
 */
@Setter
@Getter
public class FWB0107Input {

    /** 会社コード */
    private String RBUKRS;

    /** 会計年度 */
    private String GJAHR;

    /** 会計期間 */
    private String MONAT;

    /** プロジェクトID */
    private String PROJK;

    /** 期首仕掛金額 */
    private String INPROCESS_COST;

    /** 期首仕掛原価差異金額 */
    private String INPROCESS_COST_BALANCE;

    /** 今期原価差異金額 */
    private String CURRENT_COST_BALANCE;

    /** 大型機材期首仕掛原価差異金額 */
    private String L_MACHINE_INPROCESS_COST_BALANCE;

    /** 大型機材今期原価差異金額 */
    private String L_MACHINE_CURRENT_COST_BALANCE;

    /** 作成日 */
    private String INS_DT;

    /** 更新日 */
    private String UPD_DT;

}
