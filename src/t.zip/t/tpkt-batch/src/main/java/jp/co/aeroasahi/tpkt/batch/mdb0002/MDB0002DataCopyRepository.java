package jp.co.aeroasahi.tpkt.batch.mdb0002;

import org.apache.ibatis.annotations.Param;

/**
 * 一時テーブルから本体テーブルにデータを登録する
 */
public interface MDB0002DataCopyRepository {

    int dataCopy(@Param("fromTable") String fromTable, @Param("toTable") String toTable);

    /**
     * テーブル＜委託先マスタ＞に登録する。
     *
     * @param
     * @return
     */
    void dataCopyOjMaVendor();

    /**
     * テーブル＜【TEMP】委託先マスタ＞に登録する。
     *
     * @param
     * @return
     */
    void dataReverseCopyOjMaVendor();
}
