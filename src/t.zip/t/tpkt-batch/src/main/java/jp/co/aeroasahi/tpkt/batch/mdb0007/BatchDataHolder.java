package jp.co.aeroasahi.tpkt.batch.mdb0007;

import java.time.LocalDateTime;
import org.springframework.stereotype.Component;
import lombok.Getter;
import lombok.Setter;

@Component
@Setter
@Getter
public class BatchDataHolder {

    // バッチ開始時間
    private LocalDateTime startDateTime;
}
