package jp.co.aeroasahi.tpkt.batch.mdb0204;

import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】顧客マスタ＞のOutputBean。
 */
@Setter
@Getter
public class MDB0204Output {

    /** 顧客CD */
    private String customerCd;

    /** 顧客略称 */
    private String customerShortName;

    /** 顧客名称 */
    private String customerName;

    /** 顧客分類CD */
    private String customerCategoryCd;

    /** 作成日 */
    private String createdAt;

    /** 更新日 */
    private String updatedAt;

}
