package jp.co.aeroasahi.tpkt.batch.oj.ojb0403;

import java.io.File;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * 滞留監視処理クラス.
 */
@Component
@Scope("step")
public class OJB0403Tasklet implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(OJB0403Tasklet.class);

    @Value("${local.pool.path}")
    String poolFielPath;

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        // チェックファイル数
        int checkCouont = 10;

        // 取得したファイル数
        int filesCount = getFilesCount(poolFielPath);

        if (filesCount >= checkCouont) {

            logger.error("POOLフォルダにファイルが10件以上滞留しています。");
        }

        return RepeatStatus.FINISHED;
    }

    private int getFilesCount(String path) {

        int fileCount = 0;
        File d = new File(path);
        File list[] = d.listFiles();
        if (list == null) {
            return 0;
        }
        for (int i = 0; i < list.length; i++) {
            if (list[i].isFile()) {
                fileCount++;
            }
        }
        return fileCount;
    }

}
