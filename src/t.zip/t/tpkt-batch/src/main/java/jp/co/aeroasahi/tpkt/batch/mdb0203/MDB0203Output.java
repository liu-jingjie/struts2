package jp.co.aeroasahi.tpkt.batch.mdb0203;

import java.math.BigDecimal;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】プロジェクト＞のOutputBean。
 */
@Setter
@Getter
public class MDB0203Output {

    /** プロジェクトID */
    private String pjId;

    /** BU+プロジェクト属性ID */
    private String buPjAttId;

    /** プロジェクト属性ID */
    private String pjAttId;

    /** プロジェクト種別 */
    private String pjType;

    /** プロジェクト名称 */
    private String pjName;

    /** 生産・営業担当部門CD */
    private String proSalesDeptCd;

    /** 生産・営業担当者CD */
    private String proSalesEmpCd;

    /** プロジェクト完了フラグ */
    private String pjEnded;

    /** PJステータス */
    private String pjStatus;

    /** 応札積算額 */
    private BigDecimal osatsuPlanedAmount;

    /** 受注金額 */
    private BigDecimal receivedAmount;

    /** 受注日 */
    private Date receivedOn;

    /** 売上予定日 */
    private String planedSellingOn;

    /** 最終売上完了日 */
    private Date lastSoldOn;

    /** 最終売上予定日 */
    private String lastPlannedSalesOn;

    /** 初回売上日 */
    private Date soldOn;

    /** 取引種別 */
    private String dealType;

    /** 作成日 */
    private String createdAt;

    /** 更新日 */
    private String updatedAt;

    /** 今年度期首月 検索用*/
    private String beginOfFiscalYearMonth;

    /** 今年度期末月 検索用*/
    private String endOfFiscalYearMonth;
}
