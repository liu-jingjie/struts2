package jp.co.aeroasahi.tpkt.batch.sbb0201;

import lombok.Getter;
import lombok.Setter;

/**
 * MAX枝番Bean。
 */
@Setter
@Getter
public class SbDataMaxBranch {

    /** プロジェクトID */
    private String pjId;

    /** 工程CD */
    private String koteiCd;

    /** MAX枝番 */
    private String maxBranchNum;

    /**
     * プロジェクトIDと工程CDを結合する
     * @return 結合Key
     */
    public String getConcat() {
        return pjId + koteiCd;
    }


}
