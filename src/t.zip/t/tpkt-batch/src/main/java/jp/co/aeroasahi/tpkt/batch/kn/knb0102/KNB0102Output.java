package jp.co.aeroasahi.tpkt.batch.kn.knb0102;

import java.math.BigDecimal;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.batch.item.ItemCountAware;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜勤怠データ＞のOutputBean。
 */
@Setter
@Getter
public class KNB0102Output implements ItemCountAware {

    private int count;

    /** 社員CD */
    @NotBlank
    @Size(min = 1, max = 5)
    private String empCd;

    /** 日付 */
    @NotBlank
    @Size(min = 1, max = 10)
    private String date;

    /** 就労所属CD */
    @Size(min = 0, max = 6)
    private String deptCd;

    /** 勤務種別CD */
    @Size(min = 0, max = 10)
    private String kinmuKbn;

    /** 勤怠CD */
    @Size(min = 0, max = 5)
    private String kintaiCd;

    /** 始業時刻 */
    @Size(min = 0, max = 5)
    private String openingTime;

    /** 終業時刻 */
    @Size(min = 0, max = 5)
    private String endingTime;

    /** 勤怠稼動時間 */
    @DecimalMin("-999.99")
    @DecimalMax("999.99")
    private BigDecimal inputTime;

    /** 休憩時間 */
    @DecimalMin("-999.99")
    @DecimalMax("999.99")
    private BigDecimal offTime;

    /** 遅刻早退時間 */
    @DecimalMin("-999.99")
    @DecimalMax("999.99")
    private BigDecimal cikokuSoutaiTime;

    /** 作成者 */
    private String insEmpCd;

    /** 作成日 */
    private String insDt;

    /** 更新者 */
    private String updEmpCd;

    /** 更新日 */
    private String updDt;

    @Override
    public void setItemCount(int count) {
        this.count = count;
    }

}
