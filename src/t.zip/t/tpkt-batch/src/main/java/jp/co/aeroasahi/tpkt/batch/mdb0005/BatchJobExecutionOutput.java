package jp.co.aeroasahi.tpkt.batch.mdb0005;

import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜ジョブ異常テーブル＞のOutputBean。
 */
@Setter
@Getter
public class BatchJobExecutionOutput {

    /** ジョブ実行ID */
    private int jobExecutionId;

    /** 状態 */
    private String status;

    /** 出口コード */
    private String exitCode;

}
