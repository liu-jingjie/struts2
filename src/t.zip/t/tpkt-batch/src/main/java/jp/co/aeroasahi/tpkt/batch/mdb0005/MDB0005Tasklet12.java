package jp.co.aeroasahi.tpkt.batch.mdb0005;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

/**
 * 各ジョブを実行するTasklet
 */
@Component
@Scope("step")
public class MDB0005Tasklet12 implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0005Tasklet12.class);

    @Inject
    DateFactory dateFactory;

    @Inject
    MDB0005Repository mdb0005Repository;

    @Autowired
    private BatchDataHolder batchDataHolder;

    /** DateTimeFormatterのパターン uuuu-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf4 = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.SSS");

    /** タイムアウト_分 */
    @Value("${main.timeout.minute}")
    long timeoutMinute;

    /**
     *
     * マインバッチ処理
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return 一括で各ジョブを実行した状態
     */
    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        if(!batchDataHolder.isCheckSkip1()) {

            String systemDateTime = batchDataHolder.getSystemDateTime();

            boolean isErrFlag = checkJobExecuteResultIsExecution(1, systemDateTime);

            if(isErrFlag) {
                logger.error("{} {}処理でエラーが発生しました。;ジョブ番号={}", "ojb0401", "発注転送", "1");
            }

            batchDataHolder.setCheckResult1(!isErrFlag);
        }else {
            batchDataHolder.setCheckResult1(true);
        }

        return RepeatStatus.FINISHED;
    }

    /**
     * 各ジョブ実行結果をチェックする
     *
     * @param number ジョブ件数
     * @param systemDateTime タスク実行時間
     *
     * @return 各ジョブ実行結果をチェックする結果
     */
    private boolean checkJobExecuteResultIsExecution(int number, String systemDateTime) {
        boolean rtnIsExecution = false;

        List<Integer> jobExecutionIds = new ArrayList<Integer>();

        while (true) {
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                logger.error("stackTrace：", e);
            }

            boolean isAllExecuted = true;

            jobExecutionIds.clear();
            int count = 0;
            List<BatchJobRequestOutput> jobRequestOutputList= mdb0005Repository.findByTopNum(number, "%"+systemDateTime);

            for (BatchJobRequestOutput batchJobRequestOutput : jobRequestOutputList) {

                count++;
                jobExecutionIds.add(batchJobRequestOutput.getJobExecutionId());

                if(!batchJobRequestOutput.getPollingStatus().equals("EXECUTED")) {

                    isAllExecuted = false;
                }
            }

            if(number != count) {
                isAllExecuted = false;
            }

            if (isAllExecuted) {
                List<BatchJobExecutionOutput> jobExecutionOutputList= mdb0005Repository.findByExecutionIds(jobExecutionIds);

                for (BatchJobExecutionOutput batchJobExecutionOutput : jobExecutionOutputList) {

                    if(!(batchJobExecutionOutput.getStatus().equals("COMPLETED") && batchJobExecutionOutput.getExitCode().equals("COMPLETED"))) {

                        rtnIsExecution = true;
                    }
                }
                break;
            }

            LocalDateTime systemDateTimeNow = dateFactory.newDateTime();
            LocalDateTime jobStartDateTime = LocalDateTime.parse(systemDateTime, dtf4);
            if (systemDateTimeNow.isAfter(jobStartDateTime.plusMinutes(timeoutMinute))) {

                logger.info("現在日時がこのjobの起動から1時間経過しているので、異常終了しました。");
                // 現在日時がこのjobの起動から1時間以上経過している場合はエラーとする
                return true;
            }
        }

        return rtnIsExecution;
    }
}
