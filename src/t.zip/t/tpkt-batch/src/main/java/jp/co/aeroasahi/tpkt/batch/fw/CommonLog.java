package jp.co.aeroasahi.tpkt.batch.fw;

import java.util.Map;
import org.slf4j.Logger;
import org.springframework.batch.item.validator.ValidationException;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;

public class CommonLog {

    public static void setFromFileErrorLog(Logger logger, ValidationException e, Map<String, String> tableItemInfo, String inputFile, int lineCount) {

        BindException errors = (BindException) e.getCause();

        for (FieldError fieldError : errors.getFieldErrors()) {

            // 桁数オーバー
            String msg1MatchKey = "size must be between";

            // 必須項目が未入力
            String msg2MatchKey = "may not be empty";

            // @DecimalMax
            String msg3MatchKey = "must be less than or equal to";

            // @DecimalMin
            String msg4MatchKey = "must be greater than or equal to";

            if (fieldError.getDefaultMessage().startsWith(msg1MatchKey)) {

                logger.error("桁数不整合;ファイル名={};行数={};項目={};値={}",
                        inputFile, lineCount+1, tableItemInfo.get(fieldError.getField()), null == fieldError.getRejectedValue()?"null":fieldError.getRejectedValue().toString());
            } else if (fieldError.getDefaultMessage().startsWith(msg2MatchKey)) {

                logger.error("必須項目が未入力;ファイル名={};行数={};項目={};値={}",
                        inputFile, lineCount+1, tableItemInfo.get(fieldError.getField()),null == fieldError.getRejectedValue()?"null":fieldError.getRejectedValue().toString());
            } else if (fieldError.getDefaultMessage().startsWith(msg3MatchKey) || fieldError.getDefaultMessage().startsWith(msg4MatchKey)) {

                logger.error("桁数不整合;ファイル名={};行数={};項目={};値={}",
                        inputFile, lineCount+1, tableItemInfo.get(fieldError.getField()), null == fieldError.getRejectedValue()?"null":fieldError.getRejectedValue().toString());
            } else {
                // size と NotBlank以外の場合
                logger.error(fieldError.getDefaultMessage());
            }
        }
    }

    public static void setFromDbErrorLog(Logger logger, ValidationException e, String table) {

        BindException errors = (BindException) e.getCause();

        for (FieldError fieldError : errors.getFieldErrors()) {

            // 桁数オーバー
            String msg1MatchKey = "size must be between";

            // 必須項目が未入力
            String msg2MatchKey = "may not be empty";

            if (fieldError.getDefaultMessage().startsWith(msg1MatchKey)) {

                logger.error("桁数不整合;テーブル名={};値={}",
                        table, null == fieldError.getRejectedValue()?"null":fieldError.getRejectedValue().toString());
            } else if (fieldError.getDefaultMessage().startsWith(msg2MatchKey)) {
                logger.error("必須項目が未入力;テーブル名={};値={}",
                        table, null == fieldError.getRejectedValue()?"null":fieldError.getRejectedValue().toString());
            } else {
                // size と NotBlank以外の場合
                logger.error(fieldError.getDefaultMessage());
            }
        }
    }

    public static void setInsertRecordeCountLog(Logger logger, String table, int count) {

        logger.info("{}にデータの登録完了;件数={}件", table, count);
    }

    public static void setUpdateRecordeCountLog(Logger logger, String table, int count) {

        logger.info("{}にデータの更新完了;件数={}件", table, count);
    }

    public static void setDeleteRecordeCountLog(Logger logger, String table) {

        logger.info("{}にデータの削除完了", table);
    }

    public static void setParametersLog(Logger logger, String kbn, String ym, String jobNum) {

        logger.info("起動パラメータ;処理区分={};処理年月={};リランジョブ番号={}", kbn, ym, jobNum);
    }

    public static void setBatchErrorLog(Logger logger, String jobName) {

        logger.error("メインバッチ処理の{}ジョブでエラーが発生しました。", jobName);
    }

    public static void setNormalLog(Logger logger) {

        logger.info("処理結果:正常終了");
    }

    public static void setFaultLog(Logger logger) {

        logger.error("処理結果:異常終了");
    }

}
