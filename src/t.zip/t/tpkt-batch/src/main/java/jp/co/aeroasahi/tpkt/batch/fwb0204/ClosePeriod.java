package jp.co.aeroasahi.tpkt.batch.fwb0204;

import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ClosePeriod implements Serializable {

    /** 開始時 */
    private int fromHour;

    /** 開始分 */
    private int fromMinute;

    /** 終了時 */
    private int toHour;

    /** 終了分 */
    private int toMinute;
}
