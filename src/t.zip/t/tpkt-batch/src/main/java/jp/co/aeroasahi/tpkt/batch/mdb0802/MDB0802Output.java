package jp.co.aeroasahi.tpkt.batch.mdb0802;

import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】外注管理＞のOutputBean。
 */
@Setter
@Getter
public class MDB0802Output {

    /** 発注書番号 */
    private String orderNum;

    /** プロジェクトID */
    private String pjId;

    /** プロジェクト名称 */
    private String pjName;

    /** 物件管理責任者部門支社ＣＤ */
    private String pjManageRespDeptBranchCd;

    /** 物件管理責任者部門支社名称 */
    private String pjManageRespDeptBranchName;

    /** 物件管理責任者部門部ＣＤ */
    private String pjManageRespMiddleDeptCd;

    /** 物件管理責任者部門部名称 */
    private String pjManageRespMiddleDeptName;

    /** 物件管理責任者部門ＣＤ */
    private String pjManageRespDeptCd;

    /** 物件管理責任者部門名称 */
    private String pjManageRespDeptName;

    /** 物件管理責任者ＣＤ */
    private String pjManageRespEmpCd;

    /** 物件管理責任者名 */
    private String pjManageRespEmpName;

    /** 生産主管部門支社ＣＤ */
    private String productMainDeptBranchCd;

    /** 生産主管部門支社名称 */
    private String productMainDeptBranchName;

    /** 生産主管部門部ＣＤ */
    private String productMainMiddleDeptCd;

    /** 生産主管部門部名称 */
    private String productMainMiddleDeptName;

    /** 生産主管部門ＣＤ */
    private String productMainDeptCd;

    /** 生産主管部門名称 */
    private String productMainDeptName;

    /** 生産プロデューサーＣＤ */
    private String productProducerEmpCd;

    /** 生産プロデューサー名 */
    private String productProducerName;

    /** 生産担当部門支社ＣＤ */
    private String productDeptBranchCd;

    /** 生産担当部門支社名称 */
    private String productDeptBranchName;

    /** 生産担当部門部ＣＤ */
    private String productMiddleDeptCd;

    /** 生産担当部門部名称 */
    private String productMiddleDeptName;

    /** 生産担当部門ＣＤ */
    private String productDeptCd;

    /** 生産担当部門名称 */
    private String productDeptName;

    /** 起案者ＣＤ */
    private String appliedEmpCd;

    /** 起案者名 */
    private String appliedEmpName;

    /** 申請日 */
    private String appliedAt;

    /** 申請番号 */
    private String applyNum;

    /** 再委託条件 */
    private BigDecimal reentrustKbn;

    /** 外注費積算額 */
    private BigDecimal planedOutsourcing;

    /** 売上完了日 */
    private String soldOn;

    /** 売上予定日 */
    private String plannedSalesOn;

    /** 業者コード */
    private String vendorCd;

    /** 委託業者 */
    private String vendorName;

    /** 発注日 */
    private String orderedOn;

    /** 作業期間FROM */
    private String workFrom;

    /** 作業期間TO */
    private String workTo;

    /** 納品予定日 */
    private String planedDeliveryOn;

    /** 支払処理日 */
    private String paymentProcessedOn;

    /** 外注費（一般）発注ベース */
    private BigDecimal outsideOrderedCost;

    /** 外注費（一般）支払ベース */
    private BigDecimal outsidePaidCost;

    /** 外注費（関係）発注ベース */
    private BigDecimal groupOrderedCost;

    /** 外注費（関係）支払ベース */
    private BigDecimal groupPaidCost;

    /** 業務委託費発注ベース */
    private BigDecimal entrustOrderedCost;

    /** 業務委託費支払ベース */
    private BigDecimal entrustPaidCost;

    /** 合計発注ベース */
    private BigDecimal totalOrderedCost;

    /** 合計支払ベース */
    private BigDecimal totalPaidCost;

    /** 並び順_物件管理責任者部門 */
    private BigDecimal sortNumPjManageRespDept;

    /** 並び順_生産主管部門 */
    private BigDecimal sortNumProductMainDept;

    /** 並び順_生産担当部門 */
    private BigDecimal sortNumProductDept;

    /** BU+プロジェクト属性ID */
    private String buPjAttId;

}
