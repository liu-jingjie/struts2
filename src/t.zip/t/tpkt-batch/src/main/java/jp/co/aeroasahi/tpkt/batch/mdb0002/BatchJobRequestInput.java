package jp.co.aeroasahi.tpkt.batch.mdb0002;

import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜ジョブ要求テーブル＞のInputBean。
 */
@Setter
@Getter
public class BatchJobRequestInput {

    /** ジョブ名 */
    private String jobName;

    /** ジョブパラメータ */
    private String jobParameter;

    /** 優先 */
    private int priority;

    /** ポーリング状態 */
    private String pollingStatus;

    /** メインバッチジョブ開始時間文字列 */
    private String jobStartDateTimeStr;

}
