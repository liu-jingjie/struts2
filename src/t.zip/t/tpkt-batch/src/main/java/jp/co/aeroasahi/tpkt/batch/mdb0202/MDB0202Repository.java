package jp.co.aeroasahi.tpkt.batch.mdb0202;

import java.util.List;

/**
 * テーブル＜テーブル＜SAPプロジェクト属性＞＜SAP受注＞＜汎用マスタ＞＜ビジネスユニットコード変換＞に操作
 */
public interface MDB0202Repository {

    /**
     * 全てのテーブル＜SAPプロジェクト属性＞＜SAP受注＞＜汎用マスタ＞＜ビジネスユニットコード変換＞情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0202Input> findAll();

    /**
     * テーブル＜【TEMP】プロジェクト属性＞に登録する。
     *
     * @param output MDB0202Output
     * @return
     */
    void create(MDB0202Output output);

    /**
     * テーブル＜【TEMP】プロジェクト属性＞に削除する。
     *
     * @return
     */
    void delete();
}
