package jp.co.aeroasahi.tpkt.batch.fwb0204;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;
import jp.co.aeroasahi.tpkt.common.fw.message.MessageSharedService;

/**
 * 保持期間外のログファイルとゴミファイルの削除を実施する
 */
@Component
@Scope("step")
public class FWB0204Tasklet implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(FWB0204Tasklet.class);

    /** SAP正常終了フォルダパス */
    @Value("${sap.output.dirpath}")
    String sapOutputDirPath;
    /** SAP異常終了フォルダパス */
    @Value("${sap.error.dirpath}")
    String sapErrorDirPath;
    /** SAPファイル保持日数 */
    @Value("${retention.days.sap}")
    String retentionDaysSap;

    /** SAP顧客フォルダパス */
    @Value("${sap.dirname.customer}")
    String customerDirname;
    /** SAP委託先フォルダパス */
    @Value("${sap.dirname.vendor}")
    String vendorDirname;
    /** SAPプロジェクト属性フォルダパス */
    @Value("${sap.dirname.projectatt}")
    String projectAttDirname;
    /** SAPプロジェクトフォルダパス */
    @Value("${sap.dirname.project}")
    String projectDirname;
    /** SAP勘定明細フォルダパス */
    @Value("${sap.dirname.accountdetail}")
    String accountDetailDirname;
    /** SAP勘定残高フォルダパス */
    @Value("${sap.dirname.accountbalance}")
    String accountBalanceDirname;
    /** SAP仕掛原価フォルダパス */
    @Value("${sap.dirname.inprocesscost}")
    String inProcessCostDirname;
    /** SAP受注フォルダパス */
    @Value("${sap.dirname.receiveorder}")
    String receiveOrderDirname;
    /** SAP発注番号フォルダパス */
    @Value("${sap.dirname.orderno}")
    String orderNoDirname;
    /** SAP発注フォルダパス */
    @Value("${sap.dirname.order}")
    String orderDirname;
    /** SAPファイル名パターン */
    @Value("${filename.pattern.sap}")
    String sapPattern;

    /** CIMログフォルダパス */
    @Value("${cim.path.log}")
    String cimLogDirPath;
    /** CIMログファイル保持日数 */
    @Value("${retention.days.cim}")
    String retentionDaysCim;
    /** CIM社員ファイル名パターン */
    @Value("${filename.pattern.cim.personal}")
    String personalFilenamePattern;
    /** CIMパスワードファイル名パターン */
    @Value("${filename.pattern.cim.password}")
    String passwordFilenamePattern;

    /** キューブデプロイログフォルダパス */
    @Value("${cube.log.path}")
    String cubeLogDirPath;
    /** キューブデプロイログファイル保持日数 */
    @Value("${retention.days.cube}")
    String retentionDaysCube;
    /** キューブ部門経費管理ファイル名パターン */
    @Value("${filename.pattern.cim.password}")
    String dcmFilenamePattern;
    /** キューブ部門経費管理_管理者用ファイル名パターン */
    @Value("${filename.pattern.cim.password}")
    String dcmmFilenamePattern;
    /** 操業度管理ファイル名パターン */
    @Value("${filename.pattern.cim.password}")
    String siFilenamePattern;

    /** セッションファイルのフォルダパス */
    @Value("${sessiondir.basepath}")
    String sessiondirBasepath;

    @Inject
    DateFactory dateFactory;

    @Inject
    MessageSharedService messageService;

    @Inject
    FWB0204Repository repository;

    /**
     * ゴミファイル削除
     *
     * <p>
     * ・指定フォルダ配下の保持期間外を過ぎたファイルを削除する
     * ・sessionフォルダ配下のファイルを削除する
     * </p>
     *
     * @throws IOException
     */
    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws IOException {

        LocalDateTime sysDateTime = dateFactory.newDateTime();
        LocalDate sysDate = sysDateTime.toLocalDate();

        /*
         * ■保持期間外ファイル削除
         * 〇以下の条件全てに当てはまるファイルを削除する
         * ・プロパティで定義されたディレクトリパス配下
         * ・プロパティで定義されたパターン文字列にファイル名の固定部分が正規表現で一致する
         * ・プロパティで定義された保存期間をファイルの作成日時が超過している
         */
        logger.info(messageService.getMessage("i.bat.fw.004", "保持期間外ファイル削除"));
        deleteOverRetentionDays(sysDate);
        logger.info(messageService.getMessage("i.bat.fw.005", "保持期間外ファイル削除"));

        /*
         * ■セッションファイル削除
         * 〇閉塞期間判定を実施し、閉塞期間である場合は以下の処理を実施する
         * ・プロパティで定義されたディレクトリ配下のファイルを全て削除する
         */
        logger.info(messageService.getMessage("i.bat.fw.004", "セッションファイル削除"));
        deleteSessionFile(sysDateTime);
        logger.info(messageService.getMessage("i.bat.fw.005", "セッションファイル削除"));

        return RepeatStatus.FINISHED;
    }


    private void deleteOverRetentionDays(LocalDate sysDate) throws IOException {

        List<DeleteTarget> deleteTargets = createTargets();

        for (DeleteTarget deleteTarget : deleteTargets) {
            // 対象フォルダに存在するファイルを全て取得
            File rootDir = new File(deleteTarget.getDirPath());
            File[] files = rootDir.listFiles();
            if (files == null) {
                continue;
            }
            List<File> fileList = Arrays.asList(files);

            // ファイル名がパターンにマッチすることを条件にフィルタリング
            List<File> filteredFileList = fileList.stream()
                    .filter(each -> match(each.getName(), deleteTarget.getFileNamePattern()))
                    .collect((Collectors.toList()));

            // 削除判定用の日付
            LocalDate targetDatetime = sysDate.minusDays(Long.parseLong(deleteTarget.getRetentionDays()));

            // 保持期間外のファイルを削除
            for (int i = 0; i < filteredFileList.size(); i++) {
                File targetFile = filteredFileList.get(i);
                if (needDelete(targetFile, targetDatetime)) {
                    targetFile.delete();
                    logger.info(messageService.getMessage("i.bat.fw.007", targetFile.getName()));
                }
            }
        }
    }

    private List<DeleteTarget> createTargets() {
        List<DeleteTarget> deleteTargets = new ArrayList<>();

        // SAP
        deleteTargets.addAll(createSAPTargets());
        // CIM
        deleteTargets.addAll(createCimTargets());
        // Cube
        deleteTargets.addAll(createCubeTargets());

        return deleteTargets;
    }

    private List<DeleteTarget> createSAPTargets() {
        List<DeleteTarget> deleteTargets = new ArrayList<>();

        // backupディレクトリ配下の各フォルダを指定して削除対象情報を生成
        deleteTargets.add(new DeleteTarget(sapOutputDirPath + customerDirname, sapPattern, retentionDaysSap));
        deleteTargets.add(new DeleteTarget(sapOutputDirPath + vendorDirname, sapPattern, retentionDaysSap));
        deleteTargets.add(new DeleteTarget(sapOutputDirPath + projectAttDirname, sapPattern, retentionDaysSap));
        deleteTargets.add(new DeleteTarget(sapOutputDirPath + projectDirname, sapPattern, retentionDaysSap));
        deleteTargets.add(new DeleteTarget(sapOutputDirPath + accountDetailDirname, sapPattern, retentionDaysSap));
        deleteTargets.add(new DeleteTarget(sapOutputDirPath + accountBalanceDirname, sapPattern, retentionDaysSap));
        deleteTargets.add(new DeleteTarget(sapOutputDirPath + inProcessCostDirname, sapPattern, retentionDaysSap));
        deleteTargets.add(new DeleteTarget(sapOutputDirPath + receiveOrderDirname, sapPattern, retentionDaysSap));
        deleteTargets.add(new DeleteTarget(sapOutputDirPath + orderNoDirname, sapPattern, retentionDaysSap));
        deleteTargets.add(new DeleteTarget(sapOutputDirPath + orderDirname, sapPattern, retentionDaysSap));

        // errorディレクトリ配下を指定して削除対象情報を生成
        deleteTargets.add(new DeleteTarget(sapErrorDirPath, sapPattern, retentionDaysSap));

        return deleteTargets;
    }

    private List<DeleteTarget> createCimTargets() {
        List<DeleteTarget> deleteTargets = new ArrayList<>();

        deleteTargets.add(new DeleteTarget(cimLogDirPath, personalFilenamePattern, retentionDaysCim));
        deleteTargets.add(new DeleteTarget(cimLogDirPath, passwordFilenamePattern, retentionDaysCim));

        return deleteTargets;
    }

    private List<DeleteTarget> createCubeTargets() {
        List<DeleteTarget> deleteTargets = new ArrayList<>();

        deleteTargets.add(new DeleteTarget(cubeLogDirPath, dcmFilenamePattern, retentionDaysCube));
        deleteTargets.add(new DeleteTarget(cubeLogDirPath, dcmmFilenamePattern, retentionDaysCube));
        deleteTargets.add(new DeleteTarget(cubeLogDirPath, siFilenamePattern, retentionDaysCube));

        return deleteTargets;
    }

    private boolean match(String targetFileName, String pattern) {
        if (targetFileName.length() < pattern.length()) {
            return false;
        }

        String targetStr = targetFileName.substring(targetFileName.length() - pattern.length());
        return targetStr.matches(pattern);
    }

    private boolean needDelete(File target, LocalDate targetDate) throws IOException {
        // 対象のの作成日時を取得し、日付比較
        BasicFileAttributes fileAttributes = Files.readAttributes(target.toPath(), BasicFileAttributes.class);
        LocalDateTime createdAt =
                LocalDateTime.ofInstant(fileAttributes.creationTime().toInstant(), ZoneId.systemDefault());
        if (createdAt.toLocalDate().isBefore(targetDate)) {
            return true;
        }
        return false;
    }

    private void deleteSessionFile(LocalDateTime sysDateTime) {

        // 日次フラグが立っている閉塞情報を全て取得
        List<ClosePeriod> closeInfos = repository.findAllIsDaily();

        // 閉塞期間判定
        for (ClosePeriod each : closeInfos) {
            LocalTime fromTime = LocalTime.of(each.getFromHour(), each.getFromMinute());
            LocalTime toTime = LocalTime.of(each.getToHour(), each.getToMinute());

            LocalTime sysTime = sysDateTime.toLocalTime();
            // 閉塞期間外の場合、
            if (!fromTime.equals(toTime)) {
                if (isTimeInRange(sysTime, fromTime, toTime)) {
                    // セッションディレクトリのルートパス配下のファイルを全て削除
                    File rootDir = new File(sessiondirBasepath);
                    File[] files = rootDir.listFiles();
                    for (int i = 0; i < files.length; i++) {
                        File targetFile = files[i];
                        targetFile.delete();
                        logger.info(messageService.getMessage("i.bat.fw.007", targetFile.getName()));
                    }
                    return;
                }
            }
        }

        logger.info(messageService.getMessage("i.bat.fw.006"));

        return;
    }

    private boolean isTimeInRange(LocalTime sysTime, LocalTime timeFrom, LocalTime timeTo) {
        if (timeTo.isAfter(timeFrom)) {
            return !sysTime.isBefore(timeFrom) && timeTo.isAfter(sysTime);
        }
        return !sysTime.isBefore(timeFrom) || timeTo.isAfter(sysTime);
    }
}
