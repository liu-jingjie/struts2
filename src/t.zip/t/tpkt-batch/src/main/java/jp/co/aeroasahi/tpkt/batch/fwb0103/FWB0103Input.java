package jp.co.aeroasahi.tpkt.batch.fwb0103;

import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】SAPプロジェクト属性＞のInputBean。
 */
@Setter
@Getter
public class FWB0103Input {

    /** プロジェクト属性ID */
    private String ZPSPID;

    /** プロジェクト属性名称 */
    private String ZPSPNAME;

    /** 営業主管部門 */
    private String ZEIGYOSHUKANBUMON;

    /** 営業主管担当者 */
    private String ZEIGYOTANTO;

    /** 生産主管部門 */
    private String ZSEISANSHUKANBUMON;

    /** 生産プロデューサー */
    private String ZPRODUCER;

    /** 物件管理責任者部門 */
    private String ZBUKKENTANTO;

    /** 物件管理責任者 */
    private String ZBUKKENTANTOBUMON;

    /** 顧客 */
    private String ZTOKUISAKI;

    /** 分野コード */
    private String ZBUNYACD;

    /** 業務コード */
    private String ZGYOUMUCD;

    /** 属性 */
    private String STAT;

    /** 今期仕掛中フラグ */
    private String DATEFLG;

    /** 賃貸PJ区分 */
    private String ZLEASEFLAG;

    /** 契約件名 */
    private String ZKEIYAKUMEI;

    /** 名義会社 */
    private String ZMEIGIKAISHA;

    /** 契約工期（FROM） */
    private String ZKEYAKUKOKIB;

    /** 契約工期(TO） */
    private String ZKEYAKUKOKIE;

    /** 作成日 */
    private String INS_DT;

    /** 更新日 */
    private String UPD_DT;

}
