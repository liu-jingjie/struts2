package jp.co.aeroasahi.tpkt.batch.fwb0204;

import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class DeleteTarget implements Serializable {

    /** ディレクトリパス */
    private String dirPath;

    /** ファイル名のパターン */
    private String fileNamePattern;

    /** 保持日数 */
    private String retentionDays;
}
