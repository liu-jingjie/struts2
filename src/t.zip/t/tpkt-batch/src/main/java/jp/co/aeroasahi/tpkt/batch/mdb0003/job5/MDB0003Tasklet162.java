package jp.co.aeroasahi.tpkt.batch.mdb0003.job5;

import javax.inject.Inject;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.mdb0003.BatchDataHolder;
import jp.co.aeroasahi.tpkt.batch.mdb0003.MDB0003SharedServiceImpl;

/**
 * キューブデプロイの実行結果を確認するTasklet
 */
@Component
@Scope("step")
public class MDB0003Tasklet162 implements Tasklet {

    /** キューブデプロイジョブ名 */
    private static final String CUBE_DEPLOY_JOB_NAME = "mdb0901Job";

    /** ジョブ番号 */
    private static final int TARGET_JOB_NUMBER = 5;

    @Autowired
    private BatchDataHolder batchDataHolder;

    @Inject
    MDB0003SharedServiceImpl mdb0003SharedService;

    /**
     *
     * キューブデプロイの実行結果を確認する
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return ステータス
     * @throws InterruptedException スレッドスリープの際に異常があった場合(基本的に発生しないはず)
     */
    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws InterruptedException {

        String jobStartDateTime = batchDataHolder.getJobStartDateTime();

        // 処理の終了まで待つ (規定時間を待っても終わらない or 異常終了していた場合は例外をスロー)
        mdb0003SharedService.checkExecuteResult(CUBE_DEPLOY_JOB_NAME, jobStartDateTime, TARGET_JOB_NUMBER);
        return RepeatStatus.FINISHED;
    }
}
