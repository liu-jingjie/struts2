package jp.co.aeroasahi.tpkt.batch.oj.ojb0102;

import lombok.Getter;
import lombok.Setter;

/**
 * 応受援帳票登録日のOutputBean.
 * <p>
 * 応受援帳票登録日のOutputBean.
 * </p>
 */
@Getter
@Setter
public class OjDocRegDateOutPut {
    /**
     * ファイル名.
     */
    private String fileName ;
    /**
     * 登録日.
     */
    private String regedOn ;
    /**
     * 作成日付.
     */
    private String createdAt ;
    /**
     * 更新日付.
     */
    private String updatedAt ;
}
