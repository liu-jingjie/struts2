package jp.co.aeroasahi.tpkt.batch.mdb0205;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.fw.CommonLog;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

@Component
@Scope("step")
public class MDB0205Tasklet implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0205Tasklet.class);

    @Inject
    MDB0205Repository mdb0205Repository;

    @Inject
    DateFactory dateFactory;

    /** DateTimeFormatterのパターン yyyy-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        // SAP仕入先マスタのデータを取得する
        List<MDB0205Input> inputList = mdb0205Repository.findAllBySAPVendor();

        // 【TEMP】委託先マスタの既存データを取得する
        List<MDB0205Output> checkList = mdb0205Repository.findAllByOjMaVendor();
        Map<String, MDB0205Output> checkListMap =
                checkList.stream().collect(Collectors.toMap(MDB0205Output::getVendorCd, Function.identity()));

        // 【TEMP】委託先マスタに登録する前に、データを編集する。
        List<MDB0205Output> outItems = setItemOutput(inputList);

        List<MDB0205Output> insertRecordList = new ArrayList<MDB0205Output>();
        List<MDB0205Output> updateRecordList = new ArrayList<MDB0205Output>();

        for (MDB0205Output mdb0205Output : outItems) {

            // 更新
            if (checkListMap.containsKey(mdb0205Output.getVendorCd())) {

                updateRecordList.add(mdb0205Output);
            // 登録
            } else {
                insertRecordList.add(mdb0205Output);
            }

        }

        // 【TEMP】委託先マスタのデータを更新する
        if (updateRecordList.size() > 0) {
            for (MDB0205Output mdb0205Output : updateRecordList) {
                mdb0205Repository.update(mdb0205Output);
            }
        }

        // 【TEMP】委託先マスタのデータを登録する
        if (insertRecordList.size() > 0) {
            for (MDB0205Output mdb0205Output : insertRecordList) {
                mdb0205Repository.create(mdb0205Output);
            }
        }

        CommonLog.setInsertRecordeCountLog(logger, "【TEMP】委託先マスタ(temp_oj_ma_vendor)", insertRecordList.size());
        CommonLog.setUpdateRecordeCountLog(logger, "【TEMP】委託先マスタ(temp_oj_ma_vendor)", updateRecordList.size());

        outItems.clear();

        return RepeatStatus.FINISHED;
    }

    private List<MDB0205Output> setItemOutput(List<MDB0205Input> inputList) {

        List<MDB0205Output> outputItems = new ArrayList<>();

        MDB0205Output item = new MDB0205Output();

        String systemDateTime = dateFactory.newDateTime().format(dtf);

        for (MDB0205Input mdb0205Input : inputList) {
            item = new MDB0205Output();

            // 委託先CD
            item.setVendorCd(mdb0205Input.getLifnr().replaceFirst("^0*", ""));

            // 業者CD
            item.setVendorSortCd("000" + mdb0205Input.getLifnr().substring(0, mdb0205Input.getLifnr().length() - 3));

            // 委託先名称
            item.setVendorName(mdb0205Input.getName1());

            // ヨミガナ
            item.setVendorNameKana(mdb0205Input.getName2());

            // 所在地
            item.setAddress(mdb0205Input.getName3());

            // 取引先フラグ 登録用
            item.setSupplier("0");

            // 郵便番号
            item.setPostalCode(getPostalCodeFormat(mdb0205Input.getPostCode1()));

            // 都道府県
            item.setPrefectures(mdb0205Input.getStreet());

            // 市区町村
            item.setMunicipality(mdb0205Input.getCity1());

            // 地名 1
            item.setStreet1(mdb0205Input.getCity2());

            // 地名 2
            item.setStreet2(mdb0205Input.getStrSuppl1());

            // 地名 3
            item.setStreet3(mdb0205Input.getStrSuppl2());

            // 電話番号
            item.setTelNum(mdb0205Input.getTelNumber());

            // 源泉対象有無
            item.setWithholding(mdb0205Input.getWtSubjct() == null ? "0" : mdb0205Input.getWtSubjct().equals("X") ? "1" : "0");

            // 国CD
            item.setCountryCd(mdb0205Input.getCountry());

            // 支払期日
            item.setPaymantLimit(mdb0205Input.getSort1B());

            // 通貨
            item.setCurrency(null == mdb0205Input.getSort2c() ? "JPY"
                    : mdb0205Input.getSort2c().length() == 3 && !haveFullStr(mdb0205Input.getSort2c())
                            ? mdb0205Input.getSort2c()
                            : "JPY");

            // 支払方法
            item.setPaymantMethod(null == mdb0205Input.getDtaws() ? ""
                    : mdb0205Input.getDtaws().equals("01") ? "発注者負担"
                            : mdb0205Input.getDtaws().equals("02") ? "請負者負担" : "");

            // 取引先の会社 ID
            String vbund = "  ";

            // それ以外の場合は空白埋め（半角スペース2桁）を格納
            if(null == mdb0205Input.getVbund()) {
                vbund = "  ";

            // 半角2桁の場合はそのままの値を格納、
            }else if(mdb0205Input.getVbund().length() == 2 && !haveFullStr(mdb0205Input.getVbund())) {
                vbund = mdb0205Input.getVbund();

            // 半角かつ2桁以外の場合は値の下2桁の値を格納、
            }else if(mdb0205Input.getVbund().length() > 2 && !haveFullStr(mdb0205Input.getVbund())) {
                vbund = mdb0205Input.getVbund().substring(mdb0205Input.getVbund().length() - 2, mdb0205Input.getVbund().length());
            }
            item.setSupplierCorpId(vbund);

            // 仕入先ブロック
            item.setSupplierBlock(
                    null == mdb0205Input.getSperr() ? "0" : mdb0205Input.getSperr().equals("X") ? "1" : "0");

            // 作成者
            item.setCreatedBy("SAP  ");

            // 作成日
            item.setCreatedAt(systemDateTime);

            // 更新者
            item.setUpdatedBy("SAP  ");

            // 更新日
            item.setUpdatedAt(systemDateTime);

            // 削除フラグ 登録用
            item.setDeleted("1");

            outputItems.add(item);
        }

        return outputItems;
    }

    private String getPostalCodeFormat(String input) {

        String rtn = input;
        Pattern pattern = Pattern.compile("[0-9]*");

        if (null == input) {
            rtn = null;
        } else if (input.length() == 7 && (pattern.matcher(input).matches())) {
            rtn = input.substring(0, 3) + "-" + input.substring(3, 7);
        }
        return rtn;
    }

    private boolean haveFullStr(String s) {

        byte[] bytes = s.getBytes();

        if (s.length() != bytes.length) {
            return true;

        } else {
            return false;
        }
    }
}
