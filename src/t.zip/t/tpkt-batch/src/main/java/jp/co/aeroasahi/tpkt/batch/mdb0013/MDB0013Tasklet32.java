package jp.co.aeroasahi.tpkt.batch.mdb0013;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.common.util.DateUtil;

/**
 * 各ジョブを実行するTasklet
 */
@Component
@Scope("step")
public class MDB0013Tasklet32 implements Tasklet {

    /** DateTimeFormatterのパターン uuuu-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.SSS");

    /** DateTimeFormatterのパターン uuuuMM */
    private static final DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("uuuuMM");

    private static final Logger logger = LoggerFactory.getLogger(MDB0013Tasklet32.class);

    /** 原価取込 */
    private static final String COST_JOB_NAME = "mdb0601Job";

    /** ■対象年月 */
    @Value("#{jobParameters['ym']}")
    String ym;

    @Inject
    MDB0013SharedServiceImpl mdb0013SharedService;

    @Inject
    MDB0013DataCopyRepository mainDataCopyRepository;

    @Autowired
    private BatchDataHolder batchDataHolder;


    /**
     *
     * マインバッチ処理
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return 一括で各ジョブを実行した状態
     */
    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        String jobStartDateTime = batchDataHolder.getJobStartDateTime();

        String currentYm = DateUtil.getYearMonth((LocalDate.parse(jobStartDateTime, dtf)));

        String currentFiscalYear = DateUtil.getFiscalYear(LocalDate.parse(jobStartDateTime, dtf));
        String currentFiscalMonth = DateUtil.getFiscalMonth(LocalDate.parse(jobStartDateTime, dtf));

        String targetFiscalYear = DateUtil.getFiscalYear(ym);
        String targetFiscalMonth = DateUtil.getFiscalMonth(ym);

        // 外注情報取込の終了まで待つ (規定時間を待っても終わらない or 異常終了していた場合は例外をスロー)
        mdb0013SharedService.checkExecuteResult(COST_JOB_NAME, jobStartDateTime);

        logger.info("temp -> 本体へのコピー処理開始");

        mainDataCopyRepository.dataCopyMdKosuCost(currentYm, ym);
        mainDataCopyRepository.dataCopyMdDeptPersonalKosu(currentYm, ym);
        mainDataCopyRepository.dataCopyMdReceive();
        mainDataCopyRepository.dataCopyMdSoldAmount(currentYm, ym);
        mainDataCopyRepository.dataCopyMdDeptCost(currentFiscalYear, currentFiscalMonth, targetFiscalYear,
                targetFiscalMonth);

        // テーブル＜金額＞に登録する前にデータを削除する
        LocalDateTime jobLocalDateTime = LocalDateTime.parse(batchDataHolder.getJobStartDateTime(), dtf);
        // 当月の年月
        String ym1 = getCurrentMonth2(jobLocalDateTime);

        // 指定した月の年月
        LocalDateTime yyyymmP = LocalDateTime.of(Integer.parseInt(ym.substring(0, 4)), Integer.parseInt(ym.substring(4, 6)), 1, 1, 1);
        String ym2 = getCurrentMonth2(yyyymmP);

        // 当月
        String inputYm1 = (getFormatedYearMonth(ym1));

        // 指定した月の年月
        String inputYm2 = (getFormatedYearMonth(ym2));

        // 前月
        String inputYm4 = (getFormatedYearMonth2(ym1));

        // 実績データ削除
        mainDataCopyRepository.deletePerformance(inputYm1, inputYm2);

        // 積算データ削除
        mainDataCopyRepository.deleteIntegration(inputYm1, inputYm4);

        // 初回積算データ削除
        mainDataCopyRepository.deleteInitialIntegration(inputYm1, inputYm4);

        mainDataCopyRepository.dataCopyMdCost(currentYm, ym);

        logger.info("temp -> 本体へのコピー処理終了");

        return RepeatStatus.FINISHED;
    }

    private String getCurrentMonth2(LocalDateTime systemDateTime) {

        return systemDateTime.plusMonths(-3).format(dtf2);
    }

    private String getFormatedYearMonth(String input) {
        LocalDate ld = LocalDate.of(Integer.parseInt(input.substring(0, 4)), Integer.parseInt(input.substring(4, 6)), 1) ;
        return ld.plusMonths(3).format(dtf2);
    }

    private String getFormatedYearMonth2(String input) {
        LocalDate ld = LocalDate.of(Integer.parseInt(input.substring(0, 4)), Integer.parseInt(input.substring(4, 6)), 1) ;
        return ld.plusMonths(2).format(dtf2);
    }

}
