package jp.co.aeroasahi.tpkt.batch.ckb0101;

import java.math.BigDecimal;
import org.springframework.batch.item.ItemCountAware;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜プロジェクト＞のOutputBean。
 */
@Setter
@Getter
public class CKB0101ProjectOutput implements ItemCountAware {

    private int count;

    /** プロジェクトID */
    private String pjId;

    /** BU+プロジェクト属性ID */
    private String buPjAttId;

    /** プロジェクト属性ID */
    private String pjAttId;

    /** プロジェクト種別 */
    private String pjType;

    /** プロジェクト名称 */
    private String pjName;

    /** 生産・営業担当部門CD */
    private String proSalesDeptCd;

    /** 生産・営業担当者CD */
    private String proSalesEmpCd;

    /** プロジェクト完了フラグ */
    private String pjEnded;

    /** PJステータス */
    private String pjStatus;

    /** 応札積算額 */
    private BigDecimal osatsuPlanedAmount;

    /** 受注金額 */
    private BigDecimal receivedAmount;

    /** 受注日 */
    private String receivedOn;

    /** 売上予定日 */
    private String planedSellingOn;

    /** 最終売上完了日 */
    private String lastSoldOn;

    /** 最終売上予定日 */
    private String lastPlannedSalesOn;

    /** 初回売上日 */
    private String soldOn;

    /** 作成日 */
    private String createdAt;

    /** 更新日 */
    private String updatedAt;

    @Override
    public void setItemCount(int count) {
        this.count = count;
    }
}
