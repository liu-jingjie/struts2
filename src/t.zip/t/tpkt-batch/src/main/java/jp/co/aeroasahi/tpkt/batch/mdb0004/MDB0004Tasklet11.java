package jp.co.aeroasahi.tpkt.batch.mdb0004;

import java.time.format.DateTimeFormatter;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

/**
 * 各ジョブを実行するTasklet
 */
@Component
@Scope("step")
public class MDB0004Tasklet11 implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0004Tasklet11.class);

    @Inject
    DateFactory dateFactory;

    @Inject
    MDB0004Repository mdb0004Repository;

    @Autowired
    private BatchDataHolder batchDataHolder;

    @Value("#{jobParameters['type']}")
    public String type;

    /** DateTimeFormatterのパターン yyyy-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    /**
     *
     * マインバッチ処理
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return 一括で各ジョブを実行した状態
     */
    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        // メインバッチ開始時に渡されたパラメータ
        logger.info("起動パラメータ;処理タイプ={}", type);

        String systemDateTime = dateFactory.newDateTime().format(dtf);

        // 第一パラメータが「0」の場合　：ファイルコピー処理から実行する
        if (type.equals("0")) {
            executeJob("knb0102Job", "type=0,systemDateTime=" + systemDateTime);

        // 第一パラメータが「1」の場合　：ファイル取込処理から実行する
        }else {
            executeJob("knb0102Job", "type=1,systemDateTime=" + systemDateTime);
        }

        batchDataHolder.setSystemDateTime(systemDateTime);

        return RepeatStatus.FINISHED;
    }

    /**
     * ジョブ実行処理
     *
     * @return 無し
     */
    private void executeJob(String jobName, String jobParameter) throws Exception {

        BatchJobRequestInput input = new BatchJobRequestInput();

        input.setJobName(jobName);
        input.setJobParameter(jobParameter);
        input.setPriority(1);
        input.setPollingStatus("INIT");

        mdb0004Repository.create(input);
    }
}
