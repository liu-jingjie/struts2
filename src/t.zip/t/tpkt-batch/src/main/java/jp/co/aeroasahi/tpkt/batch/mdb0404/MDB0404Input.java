package jp.co.aeroasahi.tpkt.batch.mdb0404;

import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜SAP勘定残高＞とテーブル＜SAP勘定明細＞のInputBean。
 */
@Setter
@Getter
public class MDB0404Input {

    /** 部門 */
    private String PRCTR;

    /** 勘定コード SAP勘定残高*/
    private String RACCT;

    /** 勘定コード SAP勘定明細*/
    private String HKONT;

    /** 会計年度 */
    private String GJAHR;

    /** 会計期間 */
    private String MONAT;

    /** 金額 SAP勘定残高(合計)*/
    private String HSLXX;

    /** 金額 SAP勘定明細(合計)*/
    private String DMBTR;

    /** 会計年度 検索用(当月)*/
    private String GJAHR1;

    /** 会計期間 検索用(当月)*/
    private String MONAT1;

    /** 会計年度 検索用(前月或は指定した月)*/
    private String GJAHR2;

    /** 会計期間 検索用(前月或は指定した月)*/
    private String MONAT2;

}
