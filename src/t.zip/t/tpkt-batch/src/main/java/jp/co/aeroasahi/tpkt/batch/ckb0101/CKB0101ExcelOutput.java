package jp.co.aeroasahi.tpkt.batch.ckb0101;

import org.springframework.batch.item.ItemCountAware;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜プロジェクト＞のOutputBean。
 */
@Setter
@Getter
public class CKB0101ExcelOutput implements ItemCountAware {

    private int count;

    /** カラム_a */
    private Integer colA;

    /** 作成日 */
    private String createdAt;

    /** プロジェクトID */
    private String pjId;


    @Override
    public void setItemCount(int count) {
        this.count = count;
    }
}
