package jp.co.aeroasahi.tpkt.batch.mdb0013;

import org.apache.ibatis.annotations.Param;

/**
 * 一時テーブルから本体テーブルにデータを登録する
 */
public interface MDB0013DataCopyRepository {

    /**
     * テーブル＜工数金額＞に登録する。
     *
     * @param currentYm システム日付に紐づく年月
     * @param targetYm バッチパラメータに紐づく年月
     * @return
     */
    void dataCopyMdKosuCost(@Param("currentYm") String currentYm, @Param("targetYm") String targetYm);

    /**
     * テーブル＜部門別社員工数＞に登録する。
     *
     * @param
     * @return
     */
    void dataCopyMdDeptPersonalKosu(@Param("currentYm") String currentYm, @Param("targetYm") String targetYm);


    /**
     * テーブル＜受注＞に登録する。
     *
     * @param
     * @return
     */
    void dataCopyMdReceive();

    /**
     * テーブル＜売上＞に登録する。
     *
     * @param
     * @return
     */
    void dataCopyMdSoldAmount(@Param("currentYm") String currentYm, @Param("targetYm") String targetYm);

    /**
     * テーブル＜部門別経費＞に登録する。
     *
     * @param
     * @return
     */
    void dataCopyMdDeptCost(@Param("currentFiscalYear") String currentFiscalYear,
            @Param("currentFiscalMonth") String currentFiscalMonth, @Param("targetFiscalYear") String targetFiscalYear,
            @Param("targetFiscalMonth") String targetFiscalMonth);

    /**
     * テーブル＜金額＞に登録する。
     *
     * @param
     * @return
     */
    void dataCopyMdCost(@Param("currentYm") String currentYm, @Param("targetYm") String targetYm);

    /**
     * テーブル＜部門経費管理＞に登録する。
     *
     * @param
     * @return
     */
    void dataCopyMdDispDeptCost();

    /**
     * テーブル＜操業度管理＞に登録する。
     *
     * @param
     * @return
     */
    void dataCopyMdDispOperation(@Param("currentFiscalYear") String currentFiscalYear,
            @Param("currentFiscalMonth") String currentFiscalMonth, @Param("targetFiscalYear") String targetFiscalYear,
            @Param("targetFiscalMonth") String targetFiscalMonth);

    /**
     * テーブル＜金額＞に(実績データ)削除する。
     *
     * @param ym1 当月
     * @param ym2 前月・指定月
     *
     * @return
     */
    void deletePerformance(@Param("ym1") String ym1, @Param("ym2") String ym2);

    /**
     * テーブル＜金額＞に(積算データ)削除する。
     *
     * @param ym3 当月
     * @param ym4 前月
     *
     * @return
     */
    void deleteIntegration(@Param("ym3") String ym3, @Param("ym4") String ym4);

    /**
     * テーブル＜金額＞に(初回積算)削除する。
     *
     * @param ym3 当月
     * @param ym4 前月
     *
     * @return
     */
    void deleteInitialIntegration(@Param("ym3") String ym3, @Param("ym4") String ym4);
}
