package jp.co.aeroasahi.tpkt.batch.fwb0108;

/**
 * テーブル＜【TEMP】SAP受注＞に操作
 */
public interface FWB0108Repository {

    /**
     * テーブル＜【TEMP】SAP受注＞に登録する。
     *
     * @param output FWB0108Output
     * @return
     */
    void create(FWB0108Output output);

    /**
     * テーブル＜【TEMP】SAP受注＞に更新する。
     *
     * @param output FWB0108Output
     * @return
     */
    void delete(FWB0108Output output);


}
