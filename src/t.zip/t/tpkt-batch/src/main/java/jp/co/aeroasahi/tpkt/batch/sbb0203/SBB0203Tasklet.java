package jp.co.aeroasahi.tpkt.batch.sbb0203;

import java.util.List;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.fw.CommonLog;

@Component
@Scope("step")
public class SBB0203Tasklet implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(SBB0203Tasklet.class);

    @Inject
    SBB0203Repository sbb0203Repository;

    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        // 発生原価更新
        updateOccuredCost();

        return RepeatStatus.FINISHED;
    }

    /**
     * 発生原価更新処理
     */
    private void updateOccuredCost() {
        // 発生原価を取得
        List<SBB0203SapCost> occuredCostList = sbb0203Repository.findSAPCost();

        if (occuredCostList != null && occuredCostList.size() > 0) {
            // 発生原価、積算原価率を算出し、［積算基本情報］を更新する
            for (SBB0203SapCost entry : occuredCostList) {
                sbb0203Repository.updateSBBaseInfo(entry);
            }
            CommonLog.setUpdateRecordeCountLog(logger, "積算基本情報", occuredCostList.size());

        }
    }

}
