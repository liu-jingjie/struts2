package jp.co.aeroasahi.tpkt.batch.mdb0205;

import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜SAP仕入先マスタ＞のInputBean。
 */
@Setter
@Getter
public class MDB0205Input {

    /** 仕入先または債権者の勘定コード */
    private String lifnr;

    /** 名称１ */
    private String name1;

    /** 名称２ */
    private String name2;

    /** 名称３ */
    private String name3;

    /** 市区町村の郵便番号 */
    private String postCode1;

    /** 地名 */
    private String street;

    /** 市区町村 */
    private String city1;

    /** 所在地 */
    private String city2;

    /** 地名２ */
    private String strSuppl1;

    /** 地名３ */
    private String strSuppl2;

    /** 電話番号: コード + 番号をダイアル */
    private String telNumber;

    /** フラグ:源泉税課税対象 */
    private String wtSubjct; ;

    /** 国コード */
    private String country;

    /** 検索語句 1 */
    private String sort1B;

    /** 銀行手数料負担コード */
    private String dtaws;

    /** 共通転記ブロック */
    private String sperr;

    /** 検索語句 2 */
    private String sort2c;

    /** 取引先の会社 ID */
    private String vbund;

}
