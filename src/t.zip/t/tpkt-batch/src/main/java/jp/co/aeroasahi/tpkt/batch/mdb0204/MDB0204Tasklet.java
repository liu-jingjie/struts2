package jp.co.aeroasahi.tpkt.batch.mdb0204;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.fw.CommonLog;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

@Component
@Scope("step")
public class MDB0204Tasklet implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0204Tasklet.class);

    @Inject
    MDB0204Repository mdb0204Repository;

    @Inject
    DateFactory dateFactory;

    /** DateTimeFormatterのパターン yyyy-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        // SAP得意先マスタのデータを取得する
        List<MDB0204Input> inputList = mdb0204Repository.findAll();

        // 【TEMP】顧客マスタに登録する前に、データを編集する。
        List<MDB0204Output> outItems = setItemOutput(inputList);

        // 【TEMP】顧客マスタのデータを削除する
        mdb0204Repository.delete();

        // 【TEMP】顧客マスタのデータを登録する
        if(outItems.size() > 0) {
            for (MDB0204Output mdb0204Output : outItems) {
                mdb0204Repository.create(mdb0204Output);
            }
        }

        CommonLog.setInsertRecordeCountLog(logger, "【TEMP】顧客マスタ(temp_md_ma_customer)", outItems.size());
        outItems.clear();

        return RepeatStatus.FINISHED;

    }

    private List<MDB0204Output> setItemOutput(List<MDB0204Input> inputList) {

        List<MDB0204Output> outputItems = new ArrayList<>();

        MDB0204Output item = new MDB0204Output();

        String systemDateTime = dateFactory.newDateTime().format(dtf);

        for (MDB0204Input mdb0204Input : inputList) {
            item = new MDB0204Output();

            // 顧客CD
            item.setCustomerCd(mdb0204Input.getKUNNR());

            // 顧客略称
            item.setCustomerShortName(mdb0204Input.getNAME2());

            // 顧客名称
            item.setCustomerName(mdb0204Input.getNAME1());

            // 顧客分類CD
            item.setCustomerCategoryCd(mdb0204Input.getBRAN1());

            // 作成日
            item.setCreatedAt(systemDateTime);

            // 更新日
            item.setUpdatedAt(systemDateTime);

            outputItems.add(item);
        }

        return outputItems;
    }
}
