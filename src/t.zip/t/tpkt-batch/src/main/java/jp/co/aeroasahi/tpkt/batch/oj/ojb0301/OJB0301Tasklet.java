package jp.co.aeroasahi.tpkt.batch.oj.ojb0301;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.inject.Inject;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import jp.co.aeroasahi.tpkt.batch.fw.CommonLog;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;
import jp.co.aeroasahi.tpkt.common.fw.mail.MailRequestSharedService;
import jp.co.aeroasahi.tpkt.common.fw.template.TemplateService;
import jp.co.aeroasahi.tpkt.common.model.fw.MailManagement;

/**
 * 支払処理日反映処理クラス.
 * <p>
 * 発注ステータスを更新して申請者と承認者を送信。
 * </p>
 */
@Component
@Scope("step")
public class OJB0301Tasklet implements Tasklet {


    private static final Logger logger = LoggerFactory.getLogger(OJB0301Tasklet.class);

    @Inject
    DateFactory dateFactory;

    @Inject
    MailRequestSharedService mailRequestSharedService;

    @Inject
    OJB0301Repository ojb0301Repository;

    @Inject
    TemplateService templateService;

    @Inject
    MessageSource messageSource;
    @Value("${baseUrl}")
    String baseUrl;

    /** 処理区分 */
    @Value("#{jobParameters['kbn']}")
    private String kbn;

    /** 処理年月 */
    @Value("#{jobParameters['date']}")
    private String date;

    /** システム日時 */
    @Value("#{jobParameters['dateTime']}")
    private String dateTime;

    /** フォーマット */
    private SimpleDateFormat sdfs = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS");

    /** SAP申請番号 */
    private static final String ABLAD = "ablad";

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
        Date dateTm = new Date(sdfs.parse(dateTime).getTime());

        // 発注ステータスを更新前、現承認者CDを更新し、申請者と承認者を送信
        // 現承認者CDを更新
        int approve = ojb0301Repository.updateApprove(kbn, date, dateTm);
        CommonLog.setUpdateRecordeCountLog(logger, "応受援承認(oj_approve)", approve);

        // 申請者と承認者全員情報を取得
        List<MailInforOutput> mailList = ojb0301Repository.findMailInfor(kbn, date, dateTm);

        // 申請者と承認者全員を送信
        mailList.forEach(mail ->
        {
            // 全てのユーザとメールを取得
            mail.convertMailInfor();
            sendMail(mail);
        });
        // 変更先の［応受援基本情報］のデータを取得し、［申請ステータス］を「99」（削除済み）にする
        int baseInforCount = ojb0301Repository.updateBaseInfor(kbn, date, dateTm);
        CommonLog.setUpdateRecordeCountLog(logger, "応受援基本情報(oj_base_info)", baseInforCount);

        logger.info("変更申請中の削除対応（委託先枝番情報）を開始します。");
        // 変更元の［応受援委託先枝番情報．発注ステータス］に変更先の［応受援委託先枝番情報．発注ステータス］で更新する
        int resultsEn = ojb0301Repository.updateEntrustStatus(kbn, date, dateTm);
        CommonLog.setUpdateRecordeCountLog(logger, "応受援委託先枝番情報(oj_entrust_branch_info)", resultsEn);
        logger.info("変更申請中の削除対応（委託先枝番情報）を終了します。");

        logger.info("支払処理日等の更新処理を開始します。");
        // ［応受援委託先枝番情報］の「支払い処理日」、「支払日」、「発注ステータス」、「支払伝票番号」を更新する
        resultsEn = ojb0301Repository.updateEntrustBranch(kbn, date, dateTm);
        CommonLog.setUpdateRecordeCountLog(logger, "応受援委託先枝番情報(oj_entrust_branch_info)", resultsEn);
        logger.info("支払処理日等の更新処理を終了します。");

        logger.info("支払取消処理を開始します。");
        // 申請番号を取得
        List<Map<String, String>> appliedNumMap = ojb0301Repository.findAppliedNum(kbn, date, dateTm);

        // リストに申請番号を追加
        List<String> appliedNumList =
                appliedNumMap.stream().map(apply -> apply.get(ABLAD)).filter(ablad -> StringUtils.isNotEmpty(ablad))
                        .collect(Collectors.toList());
        // 勘定明細に同一の申請番号のデータが存在する場合
        // ［勘定明細．金額］を加算して０になる場合、［応受援委託先枝番情報］の
        // 「支払い処理日」、「支払日」、「発注ステータス」、「支払伝票番号」を更新する
        int totalCount = 0;
        for (String appliedNum : appliedNumList) {
            totalCount = ojb0301Repository.updateEntrustBranchByList(kbn, date, appliedNum, dateTm) + totalCount;
        }

        CommonLog.setUpdateRecordeCountLog(logger, "応受援委託先枝番情報(oj_entrust_branch_info)", totalCount);
        logger.info("支払取消処理を終了します。");

        return RepeatStatus.FINISHED;
    }

    /**
     * 送信機能.
     * <p>
     * ユーザーへ送信する
     * </p>
     *
     * @param mailInforOutput
     */
    private void sendMail(MailInforOutput mailInforOutput) {
        // メール本文作成
        Map<String, String> mailBodyParameter = new HashMap<String, String>();

        String applyWay = mailInforOutput.getApplyWay();
        String pjId = mailInforOutput.getPjId();

        String applyNum = mailInforOutput.getApplyNum();
        String resourcePath = "";
        // 一般・G間
        if (ApplyWayEnum.GENERAL_GKAN.getOjuenApplyWay().equals(applyWay)) {
            resourcePath = "/oj/apply/approve/" + applyNum + "/" + pjId;
            // 上記以外の場合
        } else {
            resourcePath = "/oj/asahi/approve/" + applyNum;
        }
        mailBodyParameter.put("userName", mailInforOutput.getUsersList());
        mailBodyParameter.put("urlParam", baseUrl + resourcePath);
        String approveRequestMailBody = templateService.create("t_oj_006", mailBodyParameter);
        // メール送信機能呼び出し
        MailManagement approveRequestMailManagement = new MailManagement();
        approveRequestMailManagement.setMailAddressTo(mailInforOutput.getMailsList());
        approveRequestMailManagement.setMailAddressCc("");
        approveRequestMailManagement.setSubject("支払処理日反映");
        approveRequestMailManagement.setBody(approveRequestMailBody);
        mailRequestSharedService.requestNoAttachmentMail(approveRequestMailManagement);
    }

    /**
     * 申請方法
     * <p>
     * 応受援申請方法の定数を設定する。
     * </p>
     */
    public enum ApplyWayEnum {
        // 一般・G間
        GENERAL_GKAN("1"),
        // 朝日航空等
        ASAHI_AIR_ETC("2");

        private String ojuenApplyWay = "";

        private ApplyWayEnum(String ojuenApplyWay) {
            this.ojuenApplyWay = ojuenApplyWay;
        }

        public String getOjuenApplyWay() {
            return this.ojuenApplyWay;
        }
    }

}
