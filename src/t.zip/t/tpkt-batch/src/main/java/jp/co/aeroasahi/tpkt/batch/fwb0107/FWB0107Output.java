package jp.co.aeroasahi.tpkt.batch.fwb0107;

import java.math.BigDecimal;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.batch.item.ItemCountAware;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】SAP仕掛原価＞のOutputBean。
 */
@Setter
@Getter
public class FWB0107Output implements ItemCountAware {

    private int count;

    /** 会社コード */
    @NotBlank
    @Size(min = 1, max = 2)
    private String RBUKRS;

    /** 会計年度 */
    @NotBlank
    @Size(min = 1, max = 4)
    private String GJAHR;

    /** 会計期間 */
    @NotBlank
    @Size(min = 1, max = 2)
    private String MONAT;

    /** プロジェクトID */
    @NotBlank
    @Size(min = 1, max = 12)
    private String PROJK;

    /** 期首仕掛金額 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal INPROCESS_COST;

    /** 期首仕掛原価差異金額 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal INPROCESS_COST_BALANCE;

    /** 今期原価差異金額 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal CURRENT_COST_BALANCE;

    /** 大型機材期首仕掛原価差異金額 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal L_MACHINE_INPROCESS_COST_BALANCE;

    /** 大型機材今期原価差異金額 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal L_MACHINE_CURRENT_COST_BALANCE;

    /** 作成日 */
    @Size(min = 23, max = 23)
    private String INS_DT;

    /** 更新日 */
    @Size(min = 23, max = 23)
    private String UPD_DT;

    @Override
    public void setItemCount(int count) {
        this.count = count;
    }

    /**
     * 会社コードと会計年度と会計期間とプロジェクトIDを結合する
     * @return
     */
    public String concat() {
        return RBUKRS + "," + GJAHR + "," + MONAT + "," + PROJK;
    }
}
