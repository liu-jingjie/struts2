package jp.co.aeroasahi.tpkt.batch.mdb0101;

import java.math.BigDecimal;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.batch.item.ItemCountAware;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】工数金額＞のOutputBean。
 */
@Setter
@Getter
public class MDB0101KosuCostOutput implements ItemCountAware {

    private int count;

    /** プロジェクトID */
    @NotBlank
    @Size(min = 1, max = 12)
    private String pjId;

    /** 年月 */
    @NotBlank
    @Size(min = 1, max = 6)
    private String ym;

    /** 部門CD */
    @Size(min = 0, max = 6)
    private String deptCd;

    /** 工程CD */
    @NotBlank
    @Size(min = 1, max = 5)
    private String koteiCd;

    /** 費目CD */
    @NotBlank
    @Size(min = 1, max = 2)
    private String himokuCd;

    /** 実績積算区分 */
    @NotBlank
    @Size(min = 1, max = 1)
    private String resultPlanedKbn;

    /** 給与等級 */
    @Size(min = 0, max = 5)
    private String tokyu;

    /** 代表リソースCD */
    @Size(min = 0, max = 4)
    private String distResourceCd;

    /** リソースCD */
    @Size(min = 0, max = 4)
    private String resourceCd;

    /** 単価 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal unitCost;

    /** 直接単価 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal directUnitCost;

    /** 直接部門間接単価 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal directDeptIndirectUnitCost;

    /** 間接部門間接単価 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal indirectDeptIndirectUnitCost;

    /** 製造間接単価 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal indirectUnitCost;

    /** 大型機材単価 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal largeMachineIndirectCost;

    /** 工数 */
    @DecimalMin("-922337203685477")
    @DecimalMax("922337203685477")
    private BigDecimal kosu;

    /** 作成日 */
    @Size(min = 23, max = 23)
    private String createdAt;

    /** 更新日 */
    @Size(min = 23, max = 23)
    private String updatedAt;

    /**
     * プロジェクトIDと年月と工程CDと費目CDを結合する
     * @return
     */
    public String concat() {
        return pjId + "," + ym + "," + koteiCd + "," + himokuCd;
    }

    @Override
    public void setItemCount(int count) {
        this.count = count;
    }
}
