package jp.co.aeroasahi.tpkt.batch.oj.ojb0401;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.SocketException;
import java.nio.charset.Charset;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * 発注転送処理クラス.
 */
@Component
@Scope("step")
public class OJB0401Tasklet implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(OJB0401Tasklet.class);

    @Value("${ftp.port}")
    int ftpPort;

    @Value("${ftp.username}")
    String ftpUserName;

    @Value("${ftp.password}")
    String ftpPassword;

    @Value("${ftp.host}")
    String ftpHost;

    @Value("${ftp.path}")
    String ftpPath;

    @Value("${local.send.path}")
    String writeTempFielPath;

    @Value("${ftp.File}")
    String ftpFile;

    @Value("${cmd.backup}")
    String cmdBak;

    @Value("${cmd.move}")
    String cmdReady;

    private static FTPClient ftpClient = null;

    private static final String checkStr1 = "1 個のファイルを移動しました。";
    private static final String checkStr2 = "ファイルが存在しない";
    private static final String checkStr3 = "ファイルが存在する";
    private static final String charset = "SHIFT-JIS";
    private static final String UTF8 = "UTF-8";

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        boolean rtnCheck = true;

        boolean fileExistCheck = true;

        String sapFileMoveCheck = getExecuteResult(cmdReady);

        if (sapFileMoveCheck.equals(checkStr1)) {
            logger.info("ファイル転送準備：移動先フォルダへ発注ファイルを移動しました。");
        } else if (sapFileMoveCheck.equals(checkStr2)) {
            logger.info("ファイル転送準備：移動元フォルダ内に発注ファイルが存在しません。");
            fileExistCheck = false;
        } else if (sapFileMoveCheck.equals(checkStr3)) {
            logger.info("ファイル転送準備：移動先フォルダ内に未転送の発注ファイルが存在するため、ファイル転送準備処理はスキップします。");
        }

        // 移動先フォルダ内にファイルが存在するどうか、
        boolean fileExistFlag = isFileExist(writeTempFielPath, ftpFile);

        if (!fileExistCheck && fileExistFlag) {
            fileExistCheck = true;
        }

        if (fileExistCheck) {

            boolean uploadFileCheck = false;

            // Upload前、ファイルが存在するかどうかのチェック
            boolean isExist = false;

            // Upload後、ファイルが存在するかどうかのチェック
            boolean isExist2 = false;

            // ファイル転送処理はスキップ後、チェックフラグ
            boolean skipFlag = false;

            if (fileExistFlag) {

                // FTPを接続
                ftpClient = getFTPClient(ftpHost, ftpPassword, ftpUserName, ftpPort);

                if (null != ftpClient) {

                    ftpClient.changeWorkingDirectory(ftpPath);
                    ftpClient.setFileType(FTPClient.BINARY_FILE_TYPE);
                    FTPFile[] fs = ftpClient.listFiles();
                    for (FTPFile ff : fs) {

                        String fileName = ff.getName().substring(0, ff.getName().indexOf(".")) + ff.getName()
                                .substring(ff.getName().indexOf("."), ff.getName().length()).toUpperCase();

                        if (ftpFile.equals(fileName)) {
                            isExist = true;
                            break;
                        }
                    }

                    if (!isExist) {
                        uploadFileCheck = uploadFile(ftpFile, ftpClient, ftpPath, writeTempFielPath);

                        ftpClient.changeWorkingDirectory(ftpPath);
                        ftpClient.setFileType(FTPClient.BINARY_FILE_TYPE);
                        FTPFile[] fs2 = ftpClient.listFiles();
                        for (FTPFile ff : fs2) {

                            if (ftpFile.equals(ff.getName())) {
                                isExist2 = true;
                                break;
                            }
                        }

                    } else {
                        skipFlag = true;
                        logger.info("ファイル転送：転送先フォルダ内に発注ファイルが存在するため、ファイル転送処理はスキップします。");
                    }
                }
            } else {
                logger.info("ファイル転送：転送元フォルダ内に発注ファイルが存在しません。");
            }


            if (uploadFileCheck && isExist2) {
                logger.info("ファイル転送：発注ファイルの転送完了");

                sapFileMoveCheck = getExecuteResult(cmdBak);

                if (sapFileMoveCheck.equals(checkStr1)) {
                    logger.info("ファイルのバックアップ：ファイルのバックアップ完了。");
                } else {
                    logger.error("ファイルのバックアップ：ファイルのバックアップでエラーが発生しました。");
                    rtnCheck = false;
                }
            } else {
                if (!skipFlag) {
                    logger.error("ファイル転送：ファイル転送でエラーが発生しました。");
                    rtnCheck = false;
                } else {
                    rtnCheck = true;
                }
            }
        }

        if (rtnCheck) {
            logger.info("処理結果:正常終了");
        } else {
            logger.error("処理結果:異常終了");
        }

        return RepeatStatus.FINISHED;
    }

    private String getExecuteResult(String cmd) {

        String rtn = checkStr2;

        try {

            Runtime rt = Runtime.getRuntime();
            Process proc = rt.exec(cmd);
            InputStream stderr = proc.getInputStream();
            InputStreamReader isr = new InputStreamReader(stderr, Charset.forName(charset));
            BufferedReader br = new BufferedReader(isr);
            String line = null;

            while ((line = br.readLine()) != null) {
                // checkStr(完了メッセージ)が出力されているかを判定している
                if (line.indexOf(checkStr1) > -1) {
                    rtn = checkStr1;
                    break;
                }
                if (line.indexOf(checkStr3) > -1) {
                    rtn = checkStr3;
                    break;
                }
            }

        } catch (IOException t) {
            /*
             * 基本的には来ない想定
             * falseを返し、エラーメッセージを出力する
             */
            rtn = "";
        }

        return rtn;
    }

    /**
     * FTPにUPloadする
     *
     * @param targetFname 作成ファイル名
     * @return true||false
     */
    private boolean uploadFile(String targetFname, FTPClient ftpClient, String ftpPath, String writeTempFielPath) {

        boolean flag = false;
        if (ftpClient != null) {
            File srcFile = new File(writeTempFielPath + "/" + targetFname);
            try (FileInputStream fis = new FileInputStream(srcFile)) {
                // UPLoadフォルダを設定
                ftpClient.changeWorkingDirectory(ftpPath);
                ftpClient.setBufferSize(1024);
                ftpClient.setControlEncoding(UTF8);
                // ファイルTYPEを設定
                ftpClient.setFileType(FTPClient.BINARY_FILE_TYPE);
                // UPLoad
                flag = ftpClient.storeFile(targetFname, fis);
            } catch (Exception e) {
                logger.error("stacktrace:" + e);
                closeCon();
            }
        }
        return flag;
    }

    private FTPClient getFTPClient(String ftpHost, String ftpPassword,
            String ftpUserName, int ftpPort) {

        FTPClient ftpClient = null;
        try {
            ftpClient = new FTPClient();
            ftpClient.connect(ftpHost, ftpPort);
            ftpClient.login(ftpUserName, ftpPassword);
            if (!FTPReply.isPositiveCompletion(ftpClient.getReplyCode())) {
                logger.info("未接続、FTPのユーザーとパスワードはもう一度確認してください。");
                ftpClient.disconnect();
            }
        } catch (SocketException e) {
            e.printStackTrace();
            logger.info("FTPのIPアドレスはミスの可能性があります。もう一度確認してください。");
        } catch (IOException e) {
            e.printStackTrace();
            logger.info("ftpPortはミスの可能性があります。もう一度確認してください。");
        }
        return ftpClient;
    }

    /**
     * CloseFTP接続
     */
    private void closeCon() {
        if (ftpClient != null) {
            if (ftpClient.isConnected()) {
                try {
                    ftpClient.logout();
                    ftpClient.disconnect();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private boolean isFileExist(String path, String file) {

        boolean rtn = false;

        File fileExist = new File(path + file);
        if (fileExist.exists()) {
            rtn = true;
        }
        return rtn;
    }

}
