package jp.co.aeroasahi.tpkt.batch.mdb0003.job2;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.fw.CommonLog;
import jp.co.aeroasahi.tpkt.batch.mdb0003.BatchDataHolder;
import jp.co.aeroasahi.tpkt.batch.mdb0003.MDB0003DataCopyRepository;

/**
 * tempの情報を本体に反映させるTasklet
 */
@Component
@Scope("step")
public class MDB0003Tasklet133 implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0003Tasklet133.class);

    @Autowired
    private BatchDataHolder batchDataHolder;

    @Inject
    MDB0003DataCopyRepository mainDataCopyRepository;

    // 日次処理の場合は「D」、月次確定処理の場合は「M」
    @Value("#{jobParameters['shorikbn']}")
    public String shorikbn;

    // 処理年月：日次処理の場合は空白を設定、バッチ実行画面の指定した月次確定対象年月を「YYYYMM」形式
    @Value("#{jobParameters['ym']}")
    public String ym;

    /** DateTimeFormatterのパターン uuuuMM */
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("uuuuMM");

    /** DateTimeFormatterのパターン uuuu-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf4 = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.SSS");

    /**
     *
     * マインバッチ処理
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return 一括で各ジョブを実行した状態
     */
    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

        try {
            LocalDateTime jobStartDateTime = LocalDateTime.parse(batchDataHolder.getJobStartDateTime(), dtf4);

            // システム日付の3か月前の会計年月を取得する
            String condition = getCondition(jobStartDateTime.format(dtf4).substring(0, 7).replace("-", ""));

            // TEMPテーブルデータ反映
            logger.info("tempテーブルから本体テーブルへの書き込みを実施します。");

            // 指定月の会計年月
            String specifiedMonthCondition = "";

            // 月次確定時、指定月がバッチ実行月の3か月前より過去日付の場合
            if (shorikbn.equals("M")) {

                // 実施月
                LocalDateTime systemDateTime = LocalDateTime.of(jobStartDateTime.getYear(), jobStartDateTime.getMonthValue(), 1, 0, 0);

                // 指定月
                LocalDateTime specifiedMonth = LocalDateTime.of(Integer.parseInt(ym.substring(0, 4)), Integer.parseInt(ym.substring(4, 6)), 1, 0, 0);

                if (specifiedMonth.isBefore(systemDateTime.minusMonths(3))) {

                    // 指定月の会計年月を設定する
                    specifiedMonthCondition = getSpecifiedMonthCondition(ym);
                }
            }

            // テーブル＜工数金額＞に登録する。
            mainDataCopyRepository.dataCopy6("temp_md_kosu_cost", "md_kosu_cost", condition,
                    getCurrentMonth(jobStartDateTime), getPreviousMonth(jobStartDateTime), specifiedMonthCondition);

            // テーブル＜部門別社員工数＞に登録する。
            mainDataCopyRepository.dataCopyMdDeptPersonalKosu();

            // テーブル＜受注＞に登録する。
            mainDataCopyRepository.dataCopyMdReceive();

            // テーブル＜売上＞に登録する。
            mainDataCopyRepository.dataCopyMdSoldAmount();

            // テーブル＜プロジェクト属性＞に登録する。
            mainDataCopyRepository.dataCopyProjectAttribute();

            // テーブル＜プロジェクト＞に登録する。
            mainDataCopyRepository.dataCopyProject();

            // テーブル＜顧客マスタ＞に登録する。
            mainDataCopyRepository.dataCopyMdMaCustomer();

            // テーブル＜委託先マスタ＞に登録する。
            mainDataCopyRepository.dataCopyOjMaVendor();

            // テーブル＜外注情報＞に登録する。
            mainDataCopyRepository.dataCopy5("temp_md_outsourcing", "md_outsourcing");

            // テーブル＜部門別経費＞に登録する。
            if(specifiedMonthCondition.isEmpty()) {
                mainDataCopyRepository.dataCopyMdDeptCost(condition);
            } else {
                mainDataCopyRepository.dataCopyMdDeptCostBySpecifiedMonth(condition, specifiedMonthCondition);
            }

            // テーブル＜金額＞に登録する前にデータを削除する
            // 当月の年月
            String ym1 = getCurrentMonth2(jobStartDateTime);

            // 前月或は指定した月の年月
            String ym2 = "";

            // 日次処理の場合
            if (shorikbn.equals("D")) {
                ym2 = getPreviousMonth2(jobStartDateTime);

            // 月次確定処理の場合
            } else if (shorikbn.equals("M")) {
                LocalDateTime yyyymmP = LocalDateTime.of(Integer.parseInt(ym.substring(0, 4)), Integer.parseInt(ym.substring(4, 6)), 1, 1, 1);
                ym2 = getCurrentMonth2(yyyymmP);
            }

            // 当月
            String inputYm1 = (getFormatedYearMonth(ym1));

            // 前月或は指定した月の年月
            String inputYm2 = (getFormatedYearMonth(ym2));

            // 前月
            String inputYm4 = (getFormatedYearMonth2(ym1));

            // 実績データ削除
            mainDataCopyRepository.deletePerformance(inputYm1, inputYm2);

            // 積算データ削除
            mainDataCopyRepository.deleteIntegration(inputYm1, inputYm4);

            // 初回積算データ削除
            mainDataCopyRepository.deleteInitialIntegration(inputYm1, inputYm4);

            // テーブル＜金額＞に登録する。
            mainDataCopyRepository.dataCopy6("temp_md_cost", "md_cost", condition, getCurrentMonth(jobStartDateTime),
                    getPreviousMonth(jobStartDateTime), specifiedMonthCondition);

            logger.info("tempテーブルから本体テーブルへの書き込みが完了しました。");

        } catch (Exception e) {
            // 後続処理の実行は不要なため、ログを出力し、例外をスローすることで終了させる
            CommonLog.setBatchErrorLog(logger, "tempテーブルから、本体テーブルに更新");
            throw new RuntimeException(e);
        }
        return RepeatStatus.FINISHED;
    }

    private String getCondition(String ym) {

        int year = Integer.parseInt(ym.substring(0, 4));
        int month = Integer.parseInt(ym.substring(4, 6));
        return LocalDate.of(year, month, 1).minusMonths(6).format(dtf);
    }

    private String getSpecifiedMonthCondition(String ym) {

        int year = Integer.parseInt(ym.substring(0, 4));
        int month = Integer.parseInt(ym.substring(4, 6));
        return LocalDate.of(year, month, 1).minusMonths(3).format(dtf);
    }

    private String getCurrentMonth(LocalDateTime systemDateTime) {
        return systemDateTime.format(dtf);
    }

    private String getPreviousMonth(LocalDateTime systemDateTime) {
        return systemDateTime.minusMonths(1).format(dtf);
    }

    private String getCurrentMonth2(LocalDateTime systemDateTime) {

        return systemDateTime.plusMonths(-3).format(dtf);
    }

    private String getPreviousMonth2(LocalDateTime systemDateTime) {

        return systemDateTime.plusMonths(-4).format(dtf);
    }

    private String getFormatedYearMonth(String input) {
        LocalDate ld = LocalDate.of(Integer.parseInt(input.substring(0, 4)), Integer.parseInt(input.substring(4, 6)), 1) ;
        return ld.plusMonths(3).format(dtf);
    }

    private String getFormatedYearMonth2(String input) {
        LocalDate ld = LocalDate.of(Integer.parseInt(input.substring(0, 4)), Integer.parseInt(input.substring(4, 6)), 1) ;
        return ld.plusMonths(2).format(dtf);
    }

}
