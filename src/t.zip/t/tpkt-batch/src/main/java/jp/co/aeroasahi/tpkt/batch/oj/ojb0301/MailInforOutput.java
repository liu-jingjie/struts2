package jp.co.aeroasahi.tpkt.batch.oj.ojb0301;

import java.util.Set;
import java.util.stream.Collectors;
import org.apache.commons.lang3.StringUtils;
import com.google.common.collect.Sets;
import lombok.Getter;
import lombok.Setter;


/**
 * 送信情報のOutputBean.
 * <p>
 * 送信情報のOutputBean.
 * </p>
 */

@Getter
@Setter
public class MailInforOutput {
    /** 申請番号 */
    private String applyNum;
    /** プロジェクトID */
    private String pjId;
    /** 申請方法 */
    private String applyWay;
    /** 社員名(申請者) */
    private String empName;
    /** メールアドレス (申請者) */
    private String mailAddress;
    /** 社員名(代理申請者) */
    private String proxyEmpName;
    /** メールアドレス (代理申請者) */
    private String proxyMailAddress;
    /** 社員名(一次承認者) */
    private String firstApprovedBy;
    /** メールアドレス (一次承認者) */
    private String firstApprovedByMail;
    /** 社員名(二次承認者) */
    private String secondApprovedBy;
    /** メールアドレス (二次承認者) */
    private String secondApprovedByMail;
    /** 社員名(三次承認者) */
    private String thirdApprovedBy;
    /** メールアドレス (三次承認者) */
    private String thirdApprovedByMail;
    /** 社員名(四次承認者) */
    private String fourthApprovedBy;
    /** メールアドレス (四次承認者) */
    private String fourthApprovedByMail;
    /** 社員名(五次承認者) */
    private String fifthApprovedBy;
    /** メールアドレス (五次承認者) */
    private String fifthApprovedByMail;
    /** 社員名(最終承認者) */
    private String lastApprovedBy;
    /** メールアドレス (最終承認者) */
    private String lastApprovedByMail;
    /** 全て社員名 */
    private String usersList;
    /** 全てメールアドレス */
    private String mailsList;

    /**
     * すべて送信者の名称とメールを取得
     *
     * @return
     */
    public void convertMailInfor() {
        Set<String> users = Sets.newHashSet();

        Set<String> mails = Sets.newHashSet();

        users.add(this.getEmpName());
        mails.add(this.getMailAddress());

        users.add(this.getProxyEmpName());
        mails.add(this.getProxyMailAddress());

        users.add(this.getFirstApprovedBy());
        mails.add(this.getFirstApprovedByMail());

        users.add(this.getSecondApprovedBy());
        mails.add(this.getSecondApprovedByMail());

        users.add(this.getThirdApprovedBy());
        mails.add(this.getThirdApprovedByMail());

        users.add(this.getFourthApprovedBy());
        mails.add(this.getFourthApprovedByMail());

        users.add(this.getFifthApprovedBy());
        mails.add(this.getFifthApprovedByMail());

        users.add(this.getLastApprovedBy());
        mails.add(this.getLastApprovedByMail());
        usersList = String.join("、",
                users.stream().filter(user -> StringUtils.isNotEmpty(user)).collect(Collectors.toList()));
        mailsList = String.join(",",
                mails.stream().filter(mail -> StringUtils.isNotEmpty(mail)).collect(Collectors.toList()));
    }
}
