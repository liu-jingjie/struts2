package jp.co.aeroasahi.tpkt.batch.kn.knb0101;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;
import jp.co.aeroasahi.tpkt.common.kn.KosuValidateSharedService;
import jp.co.aeroasahi.tpkt.common.kn.check.CheckTargetPesonal;
import jp.co.aeroasahi.tpkt.common.model.fw.BatchJobRequest;
import jp.co.aeroasahi.tpkt.common.model.kn.CheckList;
import jp.co.aeroasahi.tpkt.common.repository.fw.BatchJobRequestRepository;
import jp.co.aeroasahi.tpkt.common.util.DateUtil;

/**
 *
 * 工数入力手動チェックバッチ
 * <p>
 * 指定された年月の工数データと勤怠データをチェックし、結果を洗い替えする。
 * </p>
 *
 */
@Component
@Transactional
@Scope("step")
public class KNB0101Tasklet implements Tasklet {

    private static final String FLAG_ON = "1";

    /** ジョブID */
    private static final String JOB_ID = "knb0101";

    /** ロガー */
    private static final Logger logger = LoggerFactory.getLogger(KNB0101Tasklet.class);

    /** 手動フラグ */
    @Value("#{jobParameters['isManual']}")
    public boolean isManual;

    /** 年月 */
    @Value("#{jobParameters['yearMonth']}")
    public String yearMonth;

    /** 部門CD */
    @Value("#{jobParameters['deptCd']}")
    public String deptCd;

    /** リトライフラグ */
    @Value("#{jobParameters['isRetry']}")
    public boolean isRetry;

    @Inject
    DateFactory dateFactory;

    @Inject
    MessageSource messageSource;

    @Inject
    KosuValidateSharedService kosuValidateService;

    @Inject
    KNB0101Repository repository;

    @Inject
    BatchJobRequestRepository batchJobRequestRepository;

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        String executeKbn = isManual ? "手動チェック" : "夜間チェック";
        Object[] messageArgs = {JOB_ID, executeKbn};

        logger.info(messageSource.getMessage("i.bat.kn.001", messageArgs, Locale.getDefault()));

        LocalDateTime sysDateTime = dateFactory.newDateTime();
        LocalDate sysDate = LocalDate.of(sysDateTime.getYear(), sysDateTime.getMonth(), sysDateTime.getDayOfMonth());

        LocalDate startDate = getStartDate(sysDate);
        if(startDate == null) {
            logger.info(messageSource.getMessage("i.bat.kn.003", messageArgs, Locale.getDefault()));
            return RepeatStatus.FINISHED;
        }
        LocalDate lastDate = getLastDate(sysDate);

        try {
            // 期間内の日付単位にチェック対象の社員情報を取得
            List<CheckTargetPesonal> target =
                    repository.findAllByDateRangeAndDeptCd(startDate, lastDate, deptCd);

            logger.debug("工数チェック実行開始");

            // チェック処理実施
            List<CheckList> errorList =
                    kosuValidateService.executeBatchCheck(target, sysDateTime, startDate, lastDate, isManual);
            logger.debug("工数チェック実行終了");

            logger.debug("target：" + target.size() + "件");
            logger.debug("errorList：" + errorList.size() + "件");

            // チェック一覧テーブルの対象レコ―ドを削除
            repository.deleteCheckListByDateRange(startDate, lastDate, isManual, deptCd);

            // 結果をチェック一覧テーブルに登録
            for (int i = 0; i < errorList.size(); i++) {
                CheckList error = errorList.get(i);
                repository.createCheckList(error);
            }
        } catch (Exception e) {
            if (isRetry) {
                // リトライでシステム例外が発生した場合は例外をスローし直して処理を終了
                logger.error("stackTrace：",e);
                throw new RuntimeException(messageSource.getMessage("e.bat.kn.002", messageArgs, Locale.getDefault()));
            }
            // リトライではない場合、リトライ要求

            BatchJobRequest batchJobRequest = setBatchJobRequest(sysDateTime);
            batchJobRequestRepository.create(batchJobRequest);
            logger.info(messageSource.getMessage("i.bat.kn.004", messageArgs, Locale.getDefault()));

        }
        return RepeatStatus.FINISHED;
    }

    /*
     * チェック対象の開始日を取得する
     * ・確定されている年月はチェック対象外である
     * ・手動バッチはバッチ引数の年月がチェック対象である
     * ・夜間バッチのチェック対象は2ヶ月間であり、開始日はシステム日付が1日かどうかで変わる
     * ・ 1日の場合は、システム日付-2ヶ月が開始日である(例えば、12/1の場合、10/1～11/30が対象である)
     * ・ 1日以外の場合は、システム日付-1ヶ月の1日が開始日である(例えば、12/2の場合、11/1～12/31が対象である)
     */
    private LocalDate getStartDate(LocalDate sysDate) {

        List<String> conditionYmList = new ArrayList<>();
        List<String> confirmedYmList = new ArrayList<>();
        LocalDate tempDate = DateUtil.parseNoSeparateDate(yearMonth + "01");

        // パラメータの年月が確定されていれば、チェックを実施しない
        if (isManual) {
            conditionYmList.add(yearMonth);
            confirmedYmList = repository.findConfirmedYmByTargetYm(conditionYmList);
            if (confirmedYmList != null && confirmedYmList.size() != 0) {
                // チェック対象の年月が確定されている場合、チェック処理を終了する
                return null;
            } else {
                return tempDate;
            }
        } else {
            List<String> yearMonthList = new ArrayList<>();
            // 日付が1日の場合、パラメータで指定した年月の2月前をチェック開始日とする
            if (sysDate.getDayOfMonth() == 1) {
                yearMonthList.add(DateUtil.getYearMonth(tempDate.minusMonths(1)));
                yearMonthList.add(DateUtil.getYearMonth(tempDate.minusMonths(2)));
                confirmedYmList = repository.findConfirmedYmByTargetYm(yearMonthList);
                if (confirmedYmList == null || confirmedYmList.size() == 0) {
                    return tempDate.minusMonths(2);
                } else if (confirmedYmList.size() == 1) {
                    return tempDate.minusMonths(1);
                }
                // 全て確定されている場合は、チェック処理を終了する
                return null;
            } else {
                // 夜間バッチは前月～当月が範囲
                yearMonthList.add(DateUtil.getYearMonth(tempDate));
                yearMonthList.add(DateUtil.getYearMonth(tempDate.minusMonths(1)));
                confirmedYmList = repository.findConfirmedYmByTargetYm(yearMonthList);
                if (confirmedYmList == null || confirmedYmList.size() == 0) {
                    return tempDate.minusMonths(1);
                } else if (confirmedYmList.size() == 1) {
                    return tempDate;
                }
                return null;
            }
        }
    }

    private LocalDate getLastDate(LocalDate sysDate) {

        // 手動チェックの場合、指定した年月の末日を返却する
        if (isManual) {
            return DateUtil.parseNoSeparateDate(yearMonth + "01").plusMonths(1).minusDays(1);
        } else {
            // 夜間バッチの場合かつ、システム日付が1日の場合、月を -1 する
            if (sysDate.getDayOfMonth() == 1) {
                return sysDate.minusDays(1);
            }
            return DateUtil.getLastLocalDate(sysDate);
        }
    }

    private BatchJobRequest setBatchJobRequest(LocalDateTime sysDateTime) {
        BatchJobRequest batchJobRequest = new BatchJobRequest();
        batchJobRequest.setJobName(JOB_ID + "Job");
        batchJobRequest.setJobParameter(getJobParamater());
        batchJobRequest.setCreateDate(sysDateTime);

        return batchJobRequest;
    }

    private String getJobParamater() {

        String isManualParam = "isManual=" + isManual;
        String yearMonthParam = "yearMonth=" + yearMonth;
        String isRetryParam = "isRetry=" + FLAG_ON;
        if(deptCd != null) {
            String deptCdParam = "deptCd=" + deptCd;
            return isManualParam + "," + yearMonthParam + "," + deptCdParam + "," + isRetryParam;
        }
        return isManualParam + "," + yearMonthParam + "," + isRetryParam;
    }
}
