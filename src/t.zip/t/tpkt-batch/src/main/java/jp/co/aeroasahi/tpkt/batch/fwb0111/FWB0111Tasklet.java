package jp.co.aeroasahi.tpkt.batch.fwb0111;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import javax.inject.Inject;
import javax.inject.Named;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ItemStreamReader;
import org.springframework.batch.item.validator.ValidationException;
import org.springframework.batch.item.validator.Validator;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.fw.CommonLog;
import jp.co.aeroasahi.tpkt.batch.util.CommonUtils;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

@Component
@Scope("step")
public class FWB0111Tasklet implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(FWB0111Tasklet.class);
    /** DateTimeFormatterのパターン uuuuMMdd_HHmmssSSS_ */
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("uuuuMMdd_HHmmssSSS_");
    /** DateTimeFormatterのパターン uuuu-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf4 = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.SSS");

    /** 仕入先(差分)マスタのパス */
    private static final String DIRECTORY_PATH = "Vendor/";
    /** 仕入先(差分)マスタのファイル */
    private static final String FILE_NAME = "SATP0012.txt";

    /** ファイルバックアップ先（取込が正常に行われた場合） */
    @Value("${sap.output.dirpath}")
    String outputDirPath;

    /** ファイルバックアップ先（取込で異常が発生した場合） */
    @Value("${sap.error.dirpath}")
    String errorDirPath;

    @Value("#{jobParameters['inputFile']}")
    public String inputFile;

    @Value("#{jobParameters['systemDateTime']}")
    public String systemDateTime;

    @Inject
    @Named("reader")
    ItemStreamReader<FWB0111Input> reader;

    @Inject
    FWB0111Repository mdb0111Repository;

    @Inject
    DateFactory dateFactory;

    @Inject
    Validator<FWB0111Output> validator;

    boolean isErrFlag = false;

    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        String fileSystemDateTime = LocalDateTime.parse(systemDateTime, dtf4).format(dtf);

        String[] tableItemKeys = new String[] {"KBN", "SPERR", "LIFNR", "BUKRS", "KTOKK", "NAME1", "NAME2", "NAME3",
                "NAME4", "SORT1", "SORT2", "REGION", "STREET", "POST_CODE1", "CITY1", "CITY2", "STR_SUPPL1",
                "STR_SUPPL2", "COUNTRY", "TEL_NUMBER", "TEL_EXTENS", "FAX_NUMBER", "SMTP_ADDR", "DEFLT_COMM", "REMARK",
                "NAME1_B", "NAME2_B", "NAME3_B", "NAME4_B", "SORT1_B", "SORT2_B", "REGION_B", "STREET_B", "CITY1_B",
                "CITY2_B", "STR_SUPPL1_B", "STR_SUPPL2_B", "ROOMNUMBER_B", "REMARK_B", "NAME1_C", "NAME2_C", "NAME3_C",
                "NAME4_C", "SORT1_C", "SORT2_C", "REGION_C", "STREET_C", "CITY1_C", "CITY2_C", "STR_SUPPL1_C",
                "STR_SUPPL2_C", "ROOMNUMBER_C", "REMARK_C", "KUNNR", "VBUND", "KONZS", "SCACD", "GBORT", "BANKS",
                "BANKL", "BANKN", "KOINH", "BKONT", "DTAWS", "AKONT", "LNRZE", "FDGRV", "ALTKN", "MINDK", "PERNR",
                "ZTERM", "ZWELS", "XVERR", "MGRUP", "BUSAB", "INTAD", "KVERM", "QLAND", "WITHT", "WT_WITHCD",
                "WT_SUBJCT", "STATUS", "MSG_TEXT", "INS_DT", "UPD_DT"};
        String[] tableItemNames = new String[] {"処理区分", "共通転記ブロック", "仕入先または債権者の勘定コード", "会社コード", "勘定グループ", "名称１", "名称２",
                "名称３", "名称４", "検索用語1", "検索用語2", "地域（都道府県）", "地名", "市区町村の郵便番号", "市区町村", "所在地", "地名２", "地名３", "国コード",
                "電話番号: コード + 番号をダイアル", "電話番号: 内線", "FAX 番号: 局番 + 番号", "電子メールアドレス", "通信方法 (キー) (ビジネスアドレスサービス)", "住所注記",
                "名称１", "名称２", "名称３", "名称４", "検索語句 1", "検索語句 2", "地域（都道府県）", "地名", "市区町村", "所在地", "地名２", "地名３",
                "部屋/アパート番号", "住所注記", "名称１", "名称２", "名称３", "名称４", "検索語句 1", "検索語句 2", "地域（都道府県）", "地名", "市区町村", "所在地",
                "地名２", "地名３", "部屋/アパート番号", "住所注記", "得意先コード", "取引先の会社 ID", "グループキー", "標準キャリアコード", "源泉徴収税対象者の出生地",
                "銀行国コード", "銀行コード", "口座番号", "口座名義人名", "預金種別", "銀行手数料負担コード", "総勘定元帳の統制勘定", "本店勘定コード", "計画グループ",
                "旧マスタレコードのコード", "少数コード", "従業員番号", "支払条件キー", "考慮される支払方法一覧", "フラグ: 得意先と仕入先間の相殺決済", "下請法対象候補区分", "記帳担当者",
                "関係会社担当者のインターネットアドレス", "コメント", "源泉徴収税国コード", "源泉徴収税タイプコード", "源泉徴収税コード", "フラグ:源泉税課税対象", "処理ステータス",
                "メッセージテキスト", "作成日", "更新日"};
        Map<String, String> tableItemInfo = new HashMap<String, String>();
        for (int i = 0; i < tableItemKeys.length; i++) {
            tableItemInfo.put(tableItemKeys[i], tableItemNames[i]);
        }

        List<FWB0111Output> outItems = setItemOutput(chunkContext);

        if (!isErrFlag) {
            for (int i = 0; i < outItems.size(); i++) {
                try {
                    validator.validate(outItems.get(i));
                } catch (ValidationException e) {
                    isErrFlag = true;
                    CommonLog.setFromFileErrorLog(logger, e, tableItemInfo, inputFile, i);
                }
            }

            if (!isErrFlag) {

                // テーブル＜【TEMP】SAP仕入先マスタ＞情報を取得する。
                List<FWB0111Output> existentList = mdb0111Repository.findAll();
                Map<String, FWB0111Output> existentListMap =
                        existentList.stream().collect(Collectors.toMap(FWB0111Output::getLIFNR, Function.identity()));

                List<FWB0111Output> insertRecordList = new ArrayList<FWB0111Output>();
                List<FWB0111Output> updateRecordList = new ArrayList<FWB0111Output>();

                for (FWB0111Output mdb0111Output : outItems) {
                    // 更新
                    if (existentListMap.containsKey(mdb0111Output.getLIFNR())) {

                        updateRecordList.add(mdb0111Output);
                        // 登録
                    } else {

                        insertRecordList.add(mdb0111Output);
                    }

                }

                // 【TEMP】SAP仕入先マスタのデータを更新する
                if (updateRecordList.size() > 0) {
                    for (FWB0111Output output : updateRecordList) {
                        mdb0111Repository.update(output);
                    }
                }

                // 【TEMP】SAP仕入先マスタのデータを登録する
                if (insertRecordList.size() > 0) {
                    for (FWB0111Output output : insertRecordList) {
                        mdb0111Repository.create(output);
                    }
                }
                CommonLog.setInsertRecordeCountLog(logger, "【TEMP】SAP仕入先マスタ(temp_sap_ma_vendor)",
                        insertRecordList.size());
                CommonLog.setUpdateRecordeCountLog(logger, "【TEMP】SAP仕入先マスタ(temp_sap_ma_vendor)",
                        updateRecordList.size());

                if (outItems.size() > 0) {

                    List<FWB0111TpktOutput> outTpktItems = setTpktItemOutput(outItems);

                    // テーブル＜【TEMP】委託先マスタ＞情報を取得する。
                    List<FWB0111TpktOutput> existentTpktList = mdb0111Repository.findAllTpkt();
                    Map<String, FWB0111TpktOutput> existentTpktListMap =
                            existentTpktList.stream()
                                    .collect(Collectors.toMap(FWB0111TpktOutput::getVendorCd, Function.identity()));

                    List<FWB0111TpktOutput> insertTpktRecordList = new ArrayList<FWB0111TpktOutput>();
                    List<FWB0111TpktOutput> updateTpktRecordList = new ArrayList<FWB0111TpktOutput>();
                    for (FWB0111TpktOutput mdb0111TpktOutput : outTpktItems) {
                        // 更新
                        if (existentTpktListMap.containsKey(mdb0111TpktOutput.getVendorCd())) {

                            updateTpktRecordList.add(mdb0111TpktOutput);
                            // 登録
                        } else {

                            insertTpktRecordList.add(mdb0111TpktOutput);
                        }
                    }

                    // 【TEMP】委託先マスタのデータを更新する
                    if (updateTpktRecordList.size() > 0) {
                        for (FWB0111TpktOutput output : updateTpktRecordList) {
                            mdb0111Repository.tpktUpdate(output);
                        }
                    }

                    // 【TEMP】委託先マスタのデータを登録する
                    if (insertTpktRecordList.size() > 0) {
                        for (FWB0111TpktOutput output : insertTpktRecordList) {
                            mdb0111Repository.tpktCreate(output);
                        }
                    }

                    CommonLog.setInsertRecordeCountLog(logger, "【TEMP】委託先マスタ(temp_oj_ma_vendor)",
                            insertTpktRecordList.size());
                    CommonLog.setUpdateRecordeCountLog(logger, "【TEMP】委託先マスタ(temp_oj_ma_vendor)",
                            updateTpktRecordList.size());
                }

            } else {
                logger.error("入力データでエラーが発生しました。");
            }
            outItems.clear();
        }
        System.gc();
        if (isErrFlag) {
            try {
                // 正常に取り込めなかった場合はtempフォルダに格納されているファイルをerrorフォルダへ移動させる
                CommonUtils.fileMove(inputFile, errorDirPath + fileSystemDateTime + FILE_NAME);
            } catch (IOException e) {
                logger.error(FILE_NAME + "のtempフォルダからerrorフォルダへのファイル移動に失敗しました。");
                logger.error("stackTrace：", e);
            }
            throw new RuntimeException("fwb0111仕入先マスタデータ取込（一定時間間隔）実行に異常が発生しました。");
        }

        // 正常に取り込めた場合はtempフォルダに格納されているファイルをoutputフォルダへ移動させる
        CommonUtils.fileMove(inputFile, outputDirPath + DIRECTORY_PATH + fileSystemDateTime + FILE_NAME);

        return RepeatStatus.FINISHED;
    }

    private List<FWB0111TpktOutput> setTpktItemOutput(List<FWB0111Output> FWB0111OutputList) {

        List<FWB0111TpktOutput> outputItems = new ArrayList<FWB0111TpktOutput>();
        FWB0111TpktOutput fwb0111TpktOutput = new FWB0111TpktOutput();

        for (FWB0111Output fwb0111Output : FWB0111OutputList) {

            if (fwb0111Output.getBUKRS().equals("11")
                    || fwb0111Output.getBUKRS().equals("1S")
                    || fwb0111Output.getBUKRS().equals("21")
                    || fwb0111Output.getBUKRS().equals("22")
                    || fwb0111Output.getBUKRS().equals("23")
                    || fwb0111Output.getBUKRS().equals("24")
                    || fwb0111Output.getBUKRS().equals("25")
                    || fwb0111Output.getBUKRS().equals("26")
                    || fwb0111Output.getBUKRS().equals("27")
                    || fwb0111Output.getBUKRS().equals("28")
                    ) {

            fwb0111TpktOutput = new FWB0111TpktOutput();

            // 委託先CD
            fwb0111TpktOutput.setVendorCd(fwb0111Output.getLIFNR().replaceAll("^(0+)", ""));

            // 業者CD
            fwb0111TpktOutput.setVendorSortCd(
                    "000" + fwb0111Output.getLIFNR().substring(0, fwb0111Output.getLIFNR().length() - 3));

            // 委託先名称
            fwb0111TpktOutput.setVendorName(fwb0111Output.getNAME1());

            // ヨミガナ
            fwb0111TpktOutput.setVendorNameKana(fwb0111Output.getNAME2());

            // 所在地
            fwb0111TpktOutput.setAddress(fwb0111Output.getNAME3());

            // 取引先フラグ
            fwb0111TpktOutput.setSupplier("0");

            // 郵便番号
            fwb0111TpktOutput.setPostalCode(
                    (fwb0111Output.getPOST_CODE1().indexOf("-") != -1 && fwb0111Output.getPOST_CODE1().length() == 8)
                            ? fwb0111Output.getPOST_CODE1()
                            : fwb0111Output.getPOST_CODE1().length() == 7
                                    ? fwb0111Output.getPOST_CODE1().substring(0, 3) + "-"
                                            + fwb0111Output.getPOST_CODE1().substring(3, 7)
                                    : fwb0111Output.getPOST_CODE1());

            // 都道府県
            fwb0111TpktOutput.setPrefectures(fwb0111Output.getSTREET());

            // 市区町村
            fwb0111TpktOutput.setMunicipality(fwb0111Output.getCITY1());

            // 地名 1
            fwb0111TpktOutput.setStreet1(fwb0111Output.getCITY2());

            // 地名 2
            fwb0111TpktOutput.setStreet2(fwb0111Output.getSTR_SUPPL1());

            // 地名 3
            fwb0111TpktOutput.setStreet3(fwb0111Output.getSTR_SUPPL2());

            // 電話番号
            fwb0111TpktOutput.setTelNum(fwb0111Output.getTEL_NUMBER());

            // 源泉対象有無
            fwb0111TpktOutput.setWithholding(fwb0111Output.getWT_SUBJCT().equals("X") ? "1" : "0");

            // 国CD
            fwb0111TpktOutput.setCountryCd(fwb0111Output.getCOUNTRY());

            // 支払期日
            fwb0111TpktOutput.setPaymantLimit(fwb0111Output.getSORT1());

            // 通貨
            fwb0111TpktOutput.setCurrency(null == fwb0111Output.getSORT2() ? "JPY"
                    : fwb0111Output.getSORT2().length() == 3 && !haveFullStr(fwb0111Output.getSORT2())
                            ? fwb0111Output.getSORT2()
                            : "JPY");

            // 支払方法
            fwb0111TpktOutput.setPaymantMethod(fwb0111Output.getDTAWS().equals("01") ? "発注者負担"
                    : fwb0111Output.getDTAWS().equals("02") ? "請負者負担" : "");

            // 取引先の会社 ID
            String vbund = "  ";

            // それ以外の場合は空白埋め（半角スペース2桁）を格納
            if(null == fwb0111Output.getVBUND()) {
                vbund = "  ";

            // 半角2桁の場合はそのままの値を格納、
            }else if(fwb0111Output.getVBUND().length() == 2 && !haveFullStr(fwb0111Output.getVBUND())) {
                vbund = fwb0111Output.getVBUND();

            // 半角かつ2桁以外の場合は値の下2桁の値を格納、
            }else if(fwb0111Output.getVBUND().length() > 2 && !haveFullStr(fwb0111Output.getVBUND())) {
                vbund = fwb0111Output.getVBUND().substring(fwb0111Output.getVBUND().length() - 2, fwb0111Output.getVBUND().length());
            }
            fwb0111TpktOutput.setSupplierCorpId(vbund);

            // 仕入先ブロック
            fwb0111TpktOutput.setSupplierBlock(fwb0111Output.getSPERR().equals("X") ? "1" : "0");

            // 作成者
            fwb0111TpktOutput.setCreatedBy("SAP  ");

            // 作成日
            fwb0111TpktOutput.setCreatedAt(fwb0111Output.getINS_DT());

            // 更新者
            fwb0111TpktOutput.setUpdatedBy("SAP  ");

            // 更新日
            fwb0111TpktOutput.setUpdatedAt(fwb0111Output.getUPD_DT());

            // 削除フラグ
            fwb0111TpktOutput.setDeleted("1");

            outputItems.add(fwb0111TpktOutput);

            }
        }

        return outputItems;
    }

    private List<FWB0111Output> setItemOutput(ChunkContext chunkContext) {

        List<FWB0111Output> outputItems = new ArrayList<>();

        FWB0111Input itemInput = null;
        FWB0111Output itemOutput = null;
        boolean firstFlag = true;

        try {
            reader.open(chunkContext.getStepContext().getStepExecution().getExecutionContext());
            do {
                itemInput = reader.read();

                // 1行目(ヘッダ行)の場合は、ヘッダ判定用のフラグを降ろして次の行へ
                if (firstFlag) {
                    firstFlag = false;
                    continue;
                }

                // 行が読み込めなかったらファイルの読込処理を終了する
                if (itemInput == null) {
                    break;
                }
                itemOutput = new FWB0111Output();
                // 処理区分-KBN
                itemOutput.setKBN(itemInput.getKBN());

                // 共通転記ブロック-SPERR
                itemOutput.setSPERR(itemInput.getSPERR());

                // 仕入先または債権者の勘定コード-LIFNR
                itemOutput.setLIFNR(itemInput.getLIFNR());

                // 会社コード-BUKRS
                itemOutput.setBUKRS(itemInput.getBUKRS());

                // 勘定グループ-KTOKK
                itemOutput.setKTOKK(itemInput.getKTOKK());

                // 名称１-NAME1
                itemOutput.setNAME1(itemInput.getNAME1());

                // 名称２-NAME2
                itemOutput.setNAME2(itemInput.getNAME2());

                // 名称３-NAME3
                itemOutput.setNAME3(itemInput.getNAME3());

                // 名称４-NAME4
                itemOutput.setNAME4(itemInput.getNAME4());

                // 検索用語1-SORT1
                itemOutput.setSORT1(itemInput.getSORT1());

                // 検索用語2-SORT2
                itemOutput.setSORT2(itemInput.getSORT2());

                // 地域（都道府県）-REGION
                itemOutput.setREGION(itemInput.getREGION());

                // 地名-STREET
                itemOutput.setSTREET(itemInput.getSTREET());

                // 市区町村の郵便番号-POST_CODE1
                itemOutput.setPOST_CODE1(itemInput.getPOST_CODE1());

                // 市区町村-CITY1
                itemOutput.setCITY1(itemInput.getCITY1());

                // 所在地-CITY2
                itemOutput.setCITY2(itemInput.getCITY2());

                // 地名２-STR_SUPPL1
                itemOutput.setSTR_SUPPL1(itemInput.getSTR_SUPPL1());

                // 地名３-STR_SUPPL2
                itemOutput.setSTR_SUPPL2(itemInput.getSTR_SUPPL2());

                // 国コード-COUNTRY
                itemOutput.setCOUNTRY(itemInput.getCOUNTRY());

                // 電話番号: コード + 番号をダイアル-TEL_NUMBER
                itemOutput.setTEL_NUMBER(itemInput.getTEL_NUMBER());

                // 電話番号: 内線-TEL_EXTENS
                itemOutput.setTEL_EXTENS(itemInput.getTEL_EXTENS());

                // FAX 番号: 局番 + 番号-FAX_NUMBER
                itemOutput.setFAX_NUMBER(itemInput.getFAX_NUMBER());

                // 電子メールアドレス-SMTP_ADDR
                itemOutput.setSMTP_ADDR(itemInput.getSMTP_ADDR());

                // 通信方法 (キー) (ビジネスアドレスサービス)-DEFLT_COMM
                itemOutput.setDEFLT_COMM(itemInput.getDEFLT_COMM());

                // 住所注記-REMARK
                itemOutput.setREMARK(itemInput.getREMARK());

                // 名称１-NAME1_B
                itemOutput.setNAME1_B(itemInput.getNAME1_B());

                // 名称２-NAME2_B
                itemOutput.setNAME2_B(itemInput.getNAME2_B());

                // 名称３-NAME3_B
                itemOutput.setNAME3_B(itemInput.getNAME3_B());

                // 名称４-NAME4_B
                itemOutput.setNAME4_B(itemInput.getNAME4_B());

                // 検索語句 1-SORT1_B
                itemOutput.setSORT1_B(itemInput.getSORT1_B());

                // 検索語句 2-SORT2_B
                itemOutput.setSORT2_B(itemInput.getSORT2_B());

                // 地域（都道府県）-REGION_B
                itemOutput.setREGION_B(itemInput.getREGION_B());

                // 地名-STREET_B
                itemOutput.setSTREET_B(itemInput.getSTREET_B());

                // 市区町村-CITY1_B
                itemOutput.setCITY1_B(itemInput.getCITY1_B());

                // 所在地-CITY2_B
                itemOutput.setCITY2_B(itemInput.getCITY2_B());

                // 地名２-STR_SUPPL1_B
                itemOutput.setSTR_SUPPL1_B(itemInput.getSTR_SUPPL1_B());

                // 地名３-STR_SUPPL2_B
                itemOutput.setSTR_SUPPL2_B(itemInput.getSTR_SUPPL2_B());

                // 部屋/アパート番号-ROOMNUMBER_B
                itemOutput.setROOMNUMBER_B(itemInput.getROOMNUMBER_B());

                // 住所注記-REMARK_B
                itemOutput.setREMARK_B(itemInput.getREMARK_B());

                // 名称１-NAME1_C
                itemOutput.setNAME1_C(itemInput.getNAME1_C());

                // 名称２-NAME2_C
                itemOutput.setNAME2_C(itemInput.getNAME2_C());

                // 名称３-NAME3_C
                itemOutput.setNAME3_C(itemInput.getNAME3_C());

                // 名称４-NAME4_C
                itemOutput.setNAME4_C(itemInput.getNAME4_C());

                // 検索語句 1-SORT1_C
                itemOutput.setSORT1_C(itemInput.getSORT1_C());

                // 検索語句 2-SORT2_C
                itemOutput.setSORT2_C(itemInput.getSORT2_C());

                // 地域（都道府県）-REGION_C
                itemOutput.setREGION_C(itemInput.getREGION_C());

                // 地名-STREET_C
                itemOutput.setSTREET_C(itemInput.getSTREET_C());

                // 市区町村-CITY1_C
                itemOutput.setCITY1_C(itemInput.getCITY1_C());

                // 所在地-CITY2_C
                itemOutput.setCITY2_C(itemInput.getCITY2_C());

                // 地名２-STR_SUPPL1_C
                itemOutput.setSTR_SUPPL1_C(itemInput.getSTR_SUPPL1_C());

                // 地名３-STR_SUPPL2_C
                itemOutput.setSTR_SUPPL2_C(itemInput.getSTR_SUPPL2_C());

                // 部屋/アパート番号-ROOMNUMBER_C
                itemOutput.setROOMNUMBER_C(itemInput.getROOMNUMBER_C());

                // 住所注記-REMARK_C
                itemOutput.setREMARK_C(itemInput.getREMARK_C());

                // 得意先コード-KUNNR
                itemOutput.setKUNNR(itemInput.getKUNNR());

                // 取引先の会社 ID-VBUND
                itemOutput.setVBUND(itemInput.getVBUND());

                // グループキー-KONZS
                itemOutput.setKONZS(itemInput.getKONZS());

                // 標準キャリアコード-SCACD
                itemOutput.setSCACD(itemInput.getSCACD());

                // 源泉徴収税対象者の出生地-GBORT
                itemOutput.setGBORT(itemInput.getGBORT());

                // 銀行国コード-BANKS
                itemOutput.setBANKS(itemInput.getBANKS());

                // 銀行コード-BANKL
                itemOutput.setBANKL(itemInput.getBANKL());

                // 口座番号-BANKN
                itemOutput.setBANKN(itemInput.getBANKN());

                // 口座名義人名-KOINH
                itemOutput.setKOINH(itemInput.getKOINH());

                // 預金種別-BKONT
                itemOutput.setBKONT(itemInput.getBKONT());

                // 銀行手数料負担コード-DTAWS
                itemOutput.setDTAWS(itemInput.getDTAWS());

                // 総勘定元帳の統制勘定-AKONT
                itemOutput.setAKONT(itemInput.getAKONT());

                // 本店勘定コード-LNRZE
                itemOutput.setLNRZE(itemInput.getLNRZE());

                // 計画グループ-FDGRV
                itemOutput.setFDGRV(itemInput.getFDGRV());

                // 旧マスタレコードのコード-ALTKN
                itemOutput.setALTKN(itemInput.getALTKN());

                // 少数コード-MINDK
                itemOutput.setMINDK(itemInput.getMINDK());

                // 従業員番号-PERNR
                itemOutput.setPERNR(itemInput.getPERNR());

                // 支払条件キー-ZTERM
                itemOutput.setZTERM(itemInput.getZTERM());

                // 考慮される支払方法一覧-ZWELS
                itemOutput.setZWELS(itemInput.getZWELS());

                // フラグ: 得意先と仕入先間の相殺決済-XVERR
                itemOutput.setXVERR(itemInput.getXVERR());

                // 下請法対象候補区分-MGRUP
                itemOutput.setMGRUP(itemInput.getMGRUP());

                // 記帳担当者-BUSAB
                itemOutput.setBUSAB(itemInput.getBUSAB());

                // 関係会社担当者のインターネットアドレス-INTAD
                itemOutput.setINTAD(itemInput.getINTAD());

                // コメント-KVERM
                itemOutput.setKVERM(itemInput.getKVERM());

                // 源泉徴収税国コード-QLAND
                itemOutput.setQLAND(itemInput.getQLAND());

                // 源泉徴収税タイプコード-WITHT
                itemOutput.setWITHT(itemInput.getWITHT());

                // 源泉徴収税コード-WT_WITHCD
                itemOutput.setWT_WITHCD(itemInput.getWT_WITHCD());

                // フラグ:源泉税課税対象-WT_SUBJCT
                itemOutput.setWT_SUBJCT(itemInput.getWT_SUBJCT());

                // 処理ステータス-STATUS
                itemOutput.setSTATUS(itemInput.getSTATUS());

                // メッセージテキスト-MSG_TEXT
                itemOutput.setMSG_TEXT(itemInput.getMSG_TEXT());

                // 作成日-INS_DT
                itemOutput.setINS_DT(systemDateTime);

                // 更新日-UPD_DT
                itemOutput.setUPD_DT(systemDateTime);

                outputItems.add(itemOutput);
            } while (itemInput != null);

        } catch (Exception e) {
            isErrFlag = true;
            logger.error("stackTrace：", e);
        } finally {
            try {
                reader.close();
            } catch (Exception e) {
                isErrFlag = true;
                logger.error("stackTrace：", e);
            }
        }
        return outputItems;
    }

    private boolean haveFullStr(String s) {

        byte[] bytes = s.getBytes();

        if (s.length() != bytes.length) {
            return true;

        } else {
            return false;
        }
    }
}
