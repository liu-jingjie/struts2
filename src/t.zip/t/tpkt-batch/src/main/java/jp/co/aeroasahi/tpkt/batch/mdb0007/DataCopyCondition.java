package jp.co.aeroasahi.tpkt.batch.mdb0007;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DataCopyCondition {

    /** 開始会計年度 */
    private int fromFisicalYear;

    /** 開始会計月 */
    private int fromFisicalMonth;
}
