package jp.co.aeroasahi.tpkt.batch.mdb0201;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.validator.ValidationException;
import org.springframework.batch.item.validator.Validator;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.fw.CommonLog;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

@Component
@Scope("step")
public class MDB0201Tasklet implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0201Tasklet.class);

    @Inject
    MDB0201Repository mdb0201Repository;

    @Inject
    DateFactory dateFactory;

    @Inject
    Validator<MDB0201OrderOutput> validatorOrder;

    @Inject
    Validator<MDB0201SaleOutput> validatorSale;

    @Value("#{jobParameters['kbn']}")
    public String kbn;

    @Value("#{jobParameters['yyyymm']}")
    public String yyyymm;

    boolean isErrFlag = false;

    /** DateTimeFormatterのパターン yyyy-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    /** DateTimeFormatterのパターン yyyy-MM-dd */
    private static final DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    /** DateTimeFormatterのパターン uuuuMM */
    private static final DateTimeFormatter dtfUUUUMM = DateTimeFormatter.ofPattern("uuuuMM");

    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        LocalDateTime systemDateTime = dateFactory.newDateTime();
        String systemYearMonth = systemDateTime.format(dtf);

        // 年(当月の年)
        String year1 = getCurrentMonth(systemDateTime).substring(0, 4);
        String year1Delete = getCurrentMonthDelete(systemDateTime).substring(0, 4);

        // 月(当月)
        String month1 = getCurrentMonth(systemDateTime).substring(4, 6);
        String month1Delete = getCurrentMonthDelete(systemDateTime).substring(4, 6);

        // 年(前月或は指定した月の年)
        String year2 = "";
        String year2Delete = "";

        // 月(前月或は指定した月)
        String month2 = "";
        String month2Delete = "";

        // 日次処理の場合
        if (kbn.equals("D")) {
            year2 = getPreviousMonth(systemDateTime).substring(0, 4);
            month2 = getPreviousMonth(systemDateTime).substring(4, 6);

            year2Delete = getPreviousMonthDelete(systemDateTime).substring(0, 4);
            month2Delete = getPreviousMonthDelete(systemDateTime).substring(4, 6);

        // 月次確定処理の場合
        } else if (kbn.equals("M")) {
            LocalDateTime yyyymmP = LocalDateTime.of(Integer.parseInt(yyyymm.substring(0, 4)), Integer.parseInt(yyyymm.substring(4, 6)), 1, 1, 1);
            year2 = getCurrentMonth(yyyymmP).substring(0, 4);
            month2 = getCurrentMonth(yyyymmP).substring(4, 6);

            year2Delete = getCurrentMonthDelete(yyyymmP).substring(0, 4);
            month2Delete = getCurrentMonthDelete(yyyymmP).substring(4, 6);
        }

        // 検索する用日付
        String systemYMD = systemDateTime.format(dtf2);

        // SAP受注から、Max更新日を取得する
        String maxUpdDt = mdb0201Repository.findAllByMaxUpdDt();

        // 一番最新の日付とシステム日付は違い場合、一番最新の日付をシステム日付に設定する。
        if(null != maxUpdDt) {

            String maxUpdDtStr = LocalDateTime.parse(maxUpdDt, dtf).format(dtf2);
            if(!maxUpdDtStr.equals(systemYMD)) {
                systemYMD = maxUpdDtStr;
            }
        }

        // ＜【TEMP】受注＞に登録する予定データを設定
        List<MDB0201OrderOutput> outOrderItems = setItemOrderOutput(systemYearMonth, systemYMD);

        MDB0201SaleInput itemSaleInput = new MDB0201SaleInput();
        itemSaleInput.setGJAHR1(year1);
        itemSaleInput.setMONAT1(month1);
        itemSaleInput.setGJAHR2(year2);
        itemSaleInput.setMONAT2(month2);

        // ＜【TEMP】売上＞に登録する予定データを設定
        List<MDB0201SaleOutput> outSaleItems = setItemSaleOutput(itemSaleInput, systemYearMonth);

        if (!isErrFlag) {

            // ＜【TEMP】受注＞に登録する予定データをチェックする
            for (int i = 0; i < outOrderItems.size(); i++) {
                try {
                    validatorOrder.validate(outOrderItems.get(i));
                } catch (ValidationException e) {
                    isErrFlag = true;
                    CommonLog.setFromDbErrorLog(logger, e, "【TEMP】受注(temp_md_receive)");
                }
            }

            // ＜【TEMP】売上＞に登録する予定データをチェックする
            if (!isErrFlag) {
                for (int i = 0; i < outSaleItems.size(); i++) {
                    try {
                        validatorSale.validate(outSaleItems.get(i));
                    } catch (ValidationException e) {
                        isErrFlag = true;
                        CommonLog.setFromDbErrorLog(logger, e, "【TEMP】売上(temp_md_sold_amount)");
                    }
                }
            }

            if (!isErrFlag) {

                // ＜【TEMP】受注＞
                if (outOrderItems.size() > 0) {

                    // データを削除
                    mdb0201Repository.deleteOrder(systemYMD);

                    // データを登録
                    for (MDB0201OrderOutput output : outOrderItems) {
                        mdb0201Repository.createOrder(output);
                    }

                    CommonLog.setInsertRecordeCountLog(logger, "【TEMP】受注(temp_md_receive)", outOrderItems.size());
                }

                // ＜【TEMP】売上＞
                if (outSaleItems.size() > 0) {

                    MDB0201SaleInput itemSaleInputdel = new MDB0201SaleInput();
                    itemSaleInputdel.setGJAHR1(year1Delete);
                    itemSaleInputdel.setMONAT1(month1Delete);
                    itemSaleInputdel.setGJAHR2(year2Delete);
                    itemSaleInputdel.setMONAT2(month2Delete);

                    // データを削除
                    mdb0201Repository.deleteSale(itemSaleInputdel);

                    // データを登録
                    for (MDB0201SaleOutput output : outSaleItems) {
                        mdb0201Repository.createSale(output);
                    }

                    CommonLog.setInsertRecordeCountLog(logger, "【TEMP】売上(temp_md_sold_amount)", outSaleItems.size());

                    // 対象プロジェクトIDを取得する
                    List<String> salePjIdList = getSalePjIdList(outSaleItems);

                    // 【TEMP】売上の更新対象を取得する
                    List<MDB0201SaleOutput> updateList = new ArrayList<MDB0201SaleOutput>();
                    Map<Integer, List<String>> inMap = getInStr(salePjIdList);
                    for (List<String> value : inMap.values()) {
                        updateList.addAll(mdb0201Repository.findAllByPjIds(value));
                    }

                    // 対象プロジェクトIDの「キャンセルフラグ」を全て「0」にする
                    for (MDB0201SaleOutput mdb0201SaleOutput : updateList) {
                        mdb0201SaleOutput.setCanceled("0");
                    }

                    // 売上のキャンセルフラグのを設定する
                    List<MDB0201SaleOutput> editedSaleUpdateList = getEditedSaleUpdateList(updateList, systemYearMonth);

                    // 【TEMP】売上にデータを更新
                    for (MDB0201SaleOutput output : editedSaleUpdateList) {
                        mdb0201Repository.updateSale(output);
                    }

                    if (outOrderItems.size() > 0) {

                        // 対象のプロジェクトIDリストの文字列を取得する
                        String pjidListStr = getPjIdListStr(outOrderItems);

                        // 【TEMP】受注の更新対象を取得する
                        List<MDB0201OrderOutput> updateOrderList = mdb0201Repository.findAllByOrderUpdate(pjidListStr);

                        // 受注のキャンセルフラグを設定する
                        List<MDB0201OrderOutput> editedOrderUpdateList = getEditedOrderUpdateList(updateOrderList, systemYearMonth);

                        // 【TEMP】受注にデータを更新
                        for (MDB0201OrderOutput output : editedOrderUpdateList) {
                            mdb0201Repository.updateOrder(output);
                        }
                        // 対象プロジェクトIDを取得する
                        List<String> orderPjIdList = getOrderPjIdList(outOrderItems);

                        // 【TEMP】受注の売上日を設定する
                        List<MDB0201OrderOutput> editedOrderSoldOnUpdateList = getEditedOrderSoldOnUpdateList(orderPjIdList, systemYearMonth);

                        // 【TEMP】受注にデータ(売上日を設定しました)を更新
                        if (editedOrderSoldOnUpdateList.size() > 0) {

                            for (MDB0201OrderOutput output : editedOrderSoldOnUpdateList) {
                                mdb0201Repository.updateOrderSoldOn(output);
                            }
                        }
                    }
                }

            } else {
                logger.error("登録データでエラーが発生しました。");
            }
            outOrderItems.clear();
        }

        if (isErrFlag) {
            throw new RuntimeException("mdb0201受注・売上額取込の処理実行に異常が発生しました。");
        }

        return RepeatStatus.FINISHED;
    }

    private ArrayList<String> getPjIdStr(List<String> inputList) {

        ArrayList<String> rtn = new ArrayList<String>();

        String rtnPjIdStr = "";

        for (int i = 0; i < inputList.size(); i++) {
            rtnPjIdStr += "'";
            rtnPjIdStr += inputList.get(i).toString();
            rtnPjIdStr += "'";

            if(i != 0 && i%29999 == 0 && i != inputList.size() -1) {
                rtn.add(rtnPjIdStr);
                rtnPjIdStr = "";
            }else {
                rtnPjIdStr += ",";
                if(i == inputList.size() -1) {
                    rtn.add(rtnPjIdStr.substring(0, rtnPjIdStr.length() -1));
                }
            }
        }

        return rtn;
    }

    private List<MDB0201OrderOutput> getEditedOrderSoldOnUpdateList(List<String> orderPjIdList, String systemYearMonth){

        List<MDB0201OrderOutput> rtn = new ArrayList<MDB0201OrderOutput>();

        //（事前処理）で、［【TEMP】受注．売上日］を全てNULLに設定する
        mdb0201Repository.updateBySoldOn();

        // 【TEMP】受注の更新対象を取得する
        List<MDB0201OrderOutput> updateOrderList = mdb0201Repository.findAllByOrderCompar();

        // 【TEMP】売上の更新対象を取得する
        List<MDB0201SaleOutput> updateSaleList = new ArrayList<MDB0201SaleOutput>();
        ArrayList<String> pjidList = getPjIdStr(orderPjIdList);
        for (String pjIds : pjidList) {
            updateSaleList.addAll(mdb0201Repository.findAllBySaleCompar(pjIds));
        }

        for (MDB0201OrderOutput mdb0201OrderOutput : updateOrderList) {

            for (MDB0201SaleOutput mdb0201SaleOutput : updateSaleList) {

                if (mdb0201OrderOutput.getPjId().equals(mdb0201SaleOutput.getPjId())
                        && mdb0201OrderOutput.getReceivedAmount().compareTo(mdb0201SaleOutput.getSoldAmount()) == 0
                        && mdb0201SaleOutput.getDeleteFlag().equals("false")) {

                    mdb0201OrderOutput.setSoldOn(mdb0201SaleOutput.getSoldOn());
                    mdb0201OrderOutput.setUpdatedAt(systemYearMonth);
                    mdb0201SaleOutput.setDeleteFlag("true");
                    rtn.add(mdb0201OrderOutput);
                    break;
                }
            }
        }

        return rtn;
    }

    private List<MDB0201OrderOutput> getEditedOrderUpdateList(List<MDB0201OrderOutput> updateList, String systemYearMonth){

        String oldPjId = "";
        String newPjId = "";
        BigDecimal countReceivedAmount = null;
        BigDecimal newReceivedAmount = null;
        int updateListCount = updateList.size();
        int count = 0;
        BigDecimal zero = new BigDecimal(0);

        List<MDB0201OrderOutput> tempUpdateList = new ArrayList<MDB0201OrderOutput>();
        List<MDB0201OrderOutput> editedUpdateList = new ArrayList<MDB0201OrderOutput>();

        // 対象プロジェクトIDの「キャンセルフラグ」を全て「0」にする
        for (MDB0201OrderOutput mdb0201OrderOutput : updateList) {
            mdb0201OrderOutput.setCanceled("0");
        }

        for (MDB0201OrderOutput mdb0201OrderOutput : updateList) {

            newPjId = mdb0201OrderOutput.getPjId();
            newReceivedAmount = mdb0201OrderOutput.getReceivedAmount();

            // 新プロジェクトIDの場合
            if (!oldPjId.equals(newPjId)) {

                oldPjId = newPjId;

                // 前回プロジェクトIDによって、追加した内容があれば、編集後リストの中に、追加する
                if (tempUpdateList.size() > 0) {
                    editedUpdateList.addAll(tempUpdateList);
                    tempUpdateList = new ArrayList<MDB0201OrderOutput>();
                }

                // 最初の行が0円
                if (newReceivedAmount.compareTo(zero) == 0) {

                    mdb0201OrderOutput.setCanceled("1");

                    // 編集後リストの中に、追加する。
                    editedUpdateList.add(mdb0201OrderOutput);

                    // 最初の行が0円以外
                } else {

                    countReceivedAmount = newReceivedAmount;
                    // 一時リストの中に、追加する。
                    tempUpdateList.add(mdb0201OrderOutput);
                }
                // 同じプロジェクトIDの場合
            } else {

                if (null == countReceivedAmount) {

                    // 最初の行が0円
                    if (newReceivedAmount.compareTo(zero) == 0) {

                        mdb0201OrderOutput.setCanceled("1");

                        // 編集後リストの中に、追加する。
                        editedUpdateList.add(mdb0201OrderOutput);

                        // 最初の行が0円以外
                    } else {

                        countReceivedAmount = newReceivedAmount;
                        // 一時リストの中に、追加する。
                        tempUpdateList.add(mdb0201OrderOutput);
                    }

                } else {

                    // 売上額を加算する
                    countReceivedAmount = addBD(countReceivedAmount, newReceivedAmount);

                    // 加算した売上額はO円の場合
                    if (countReceivedAmount.compareTo(zero) == 0) {

                        // 一時リストの中に、追加する。
                        tempUpdateList.add(mdb0201OrderOutput);

                        for (MDB0201OrderOutput tempMdb0201SaleOutput : tempUpdateList) {
                            tempMdb0201SaleOutput.setCanceled("1");
                            editedUpdateList.add(tempMdb0201SaleOutput);
                        }

                        tempUpdateList = new ArrayList<MDB0201OrderOutput>();
                        countReceivedAmount = null;
                    } else {
                        tempUpdateList.add(mdb0201OrderOutput);
                    }
                }

                // 今回プロジェクトIDによって、追加した内容があれば、編集後リストの中に、追加する
                if (count == updateListCount - 1) {
                    if (tempUpdateList.size() > 0) {
                        editedUpdateList.addAll(tempUpdateList);
                        tempUpdateList = new ArrayList<MDB0201OrderOutput>();
                    }
                }
            }
            count++;
        }

        for (MDB0201OrderOutput editedUpdateListOutput : editedUpdateList) {
            editedUpdateListOutput.setUpdatedAt(systemYearMonth);
        }

        return editedUpdateList;
    }

    private List<MDB0201SaleOutput> getEditedSaleUpdateList(List<MDB0201SaleOutput> updateList, String systemYearMonth){

        String oldPjId = "";
        String newPjId = "";
        BigDecimal countSoldAmount = null;
        BigDecimal newSoldAmount = null;
        int updateListCount = updateList.size();
        int count = 0;
        BigDecimal zero = new BigDecimal(0);

        List<MDB0201SaleOutput> tempUpdateList = new ArrayList<MDB0201SaleOutput>();
        List<MDB0201SaleOutput> editedUpdateList = new ArrayList<MDB0201SaleOutput>();

        for (MDB0201SaleOutput mdb0201SaleOutput : updateList) {

            newPjId = mdb0201SaleOutput.getPjId();
            newSoldAmount = mdb0201SaleOutput.getSoldAmount();

            // 新プロジェクトIDの場合
            if (!oldPjId.equals(newPjId)) {

                oldPjId = newPjId;

                // 前回プロジェクトIDによって、追加した内容があれば、編集後リストの中に、追加する
                if (tempUpdateList.size() > 0) {
                    editedUpdateList.addAll(tempUpdateList);
                    tempUpdateList = new ArrayList<MDB0201SaleOutput>();
                }

                // 最初の行が0円
                if (newSoldAmount.compareTo(zero) == 0) {

                    mdb0201SaleOutput.setCanceled("1");

                    // 編集後リストの中に、追加する。
                    editedUpdateList.add(mdb0201SaleOutput);

                    // 最初の行が0円以外
                } else {

                    countSoldAmount = newSoldAmount;
                    // 一時リストの中に、追加する。
                    tempUpdateList.add(mdb0201SaleOutput);
                }
                // 同じプロジェクトIDの場合
            } else {

                if (null == countSoldAmount) {

                    // 最初の行が0円
                    if (newSoldAmount.compareTo(zero) == 0) {

                        mdb0201SaleOutput.setCanceled("1");

                        // 編集後リストの中に、追加する。
                        editedUpdateList.add(mdb0201SaleOutput);

                        // 最初の行が0円以外
                    } else {

                        countSoldAmount = newSoldAmount;
                        // 一時リストの中に、追加する。
                        tempUpdateList.add(mdb0201SaleOutput);
                    }

                } else {

                    // 売上額を加算する
                    countSoldAmount = addBD(countSoldAmount, newSoldAmount);

                    // 加算した売上額はO円の場合
                    if (countSoldAmount.compareTo(zero) == 0) {

                        // 一時リストの中に、追加する。
                        tempUpdateList.add(mdb0201SaleOutput);

                        for (MDB0201SaleOutput tempMdb0201SaleOutput : tempUpdateList) {
                            tempMdb0201SaleOutput.setCanceled("1");
                            editedUpdateList.add(tempMdb0201SaleOutput);
                        }

                        tempUpdateList = new ArrayList<MDB0201SaleOutput>();
                        countSoldAmount = null;
                    } else {
                        tempUpdateList.add(mdb0201SaleOutput);
                    }
                }

                // 今回プロジェクトIDによって、追加した内容があれば、編集後リストの中に、追加する
                if (count == updateListCount - 1) {
                    if (tempUpdateList.size() > 0) {
                        editedUpdateList.addAll(tempUpdateList);
                        tempUpdateList = new ArrayList<MDB0201SaleOutput>();
                    }
                }
            }
            count++;
        }

        for (MDB0201SaleOutput editedUpdateListOutput : editedUpdateList) {
            editedUpdateListOutput.setUpdatedAt(systemYearMonth);
        }

        return editedUpdateList;
    }

    private List<MDB0201SaleOutput> setItemSaleOutput(MDB0201SaleInput itemSaleInput, String systemYearMonth) {

        Map<String, MDB0201SaleOutput> rtn = new LinkedHashMap<String, MDB0201SaleOutput>();
        MDB0201SaleOutput itemOutput = null;
        MDB0201SaleInput mdb0201Input = null;
        String checkKey = "";

        // 【TEMP】売上
        List<MDB0201SaleInput> detailList = mdb0201Repository.findAllSale(itemSaleInput);

        for (int i = 0; i < detailList.size(); i++) {

            mdb0201Input = detailList.get(i);
            String voucherNum = mdb0201Input.getRBUKRS().replaceFirst("1S", "10");
            String pjId = mdb0201Input.getPROJK();
            String ym = getFormatedYearMonth(mdb0201Input.getGJAHR(), mdb0201Input.getMONAT());
            checkKey = voucherNum + "," + pjId + "," + ym;

            if (rtn.containsKey(checkKey)) {

                itemOutput = rtn.get(checkKey);
                BigDecimal fromMapBELNR = new BigDecimal(itemOutput.getBELNR());
                BigDecimal fromListBELNR = new BigDecimal(mdb0201Input.getBELNR());

                if(fromListBELNR.compareTo(fromMapBELNR) > 0) {

                    // ビジネスユニット
                    itemOutput.setBu(mdb0201Input.getBu());

                    // 費目CD
                    itemOutput.setHimokuCd(mdb0201Input.getHKONT().equals("41210001") ? "51" : "52");

                    // 売上日
                    itemOutput.setSoldOn(mdb0201Input.getBUDAT());

                    // 売上額
                    itemOutput.setSoldAmount(mdb0201Input.getDMBTR().multiply(new BigDecimal(-1)));

                    // 部門CD
                    itemOutput.setDeptCd(mdb0201Input.getPRCTR());

                    // 伝票番号
                    itemOutput.setBELNR(mdb0201Input.getBELNR());

                    rtn.put(checkKey, itemOutput);
                }

            } else {

                itemOutput = new MDB0201SaleOutput();

                // ビジネスユニット
                itemOutput.setBu(mdb0201Input.getBu());

                // 請求書伝票番号
                itemOutput.setVoucherNum(voucherNum);

                // プロジェクト属性ID
                itemOutput.setPjAttId(pjId.substring(2, 10));

                // プロジェクトID
                itemOutput.setPjId(pjId);

                // 費目CD
                itemOutput.setHimokuCd(mdb0201Input.getHKONT().equals("41210001") ? "51" : "52");

                // 年月
                itemOutput.setYm(ym);

                // 売上日
                itemOutput.setSoldOn(mdb0201Input.getBUDAT());

                // 売上額
                itemOutput.setSoldAmount(mdb0201Input.getDMBTR().multiply(new BigDecimal(-1)));

                // 部門CD
                itemOutput.setDeptCd(mdb0201Input.getPRCTR());

                // キャンセルフラグ
                itemOutput.setCanceled("0");

                // 作成日
                itemOutput.setCreatedAt(systemYearMonth);

                // 更新日
                itemOutput.setUpdatedAt(systemYearMonth);

                // 伝票番号
                itemOutput.setBELNR(mdb0201Input.getBELNR());

                rtn.put(checkKey, itemOutput);
            }
        }

        return new ArrayList<MDB0201SaleOutput>(rtn.values());
    }


    private List<MDB0201OrderOutput> setItemOrderOutput(String systemYearMonth, String systemYMD) {

        List<MDB0201OrderOutput> outputItems = new ArrayList<>();
        MDB0201OrderOutput itemOutput = null;

        // 【TEMP】受注
        List<MDB0201OrderInput> detailList = mdb0201Repository.findAllOrder(systemYMD);
        for (MDB0201OrderInput mdb0201Input : detailList) {

            itemOutput = new MDB0201OrderOutput();

            // ビジネスユニット
            itemOutput.setBu(mdb0201Input.getBu());

            // 受注番号
            itemOutput.setReceiveNum(mdb0201Input.getVbeln());

            // 受注明細番号
            itemOutput.setReceiveDtlNum(new BigDecimal(mdb0201Input.getPosnr()));

            // プロジェクト属性ID
            itemOutput.setPjAttId(mdb0201Input.getPsPspPnr().substring(2, 10));

            // プロジェクトID
            itemOutput.setPjId(mdb0201Input.getPsPspPnr());

            // 受注日
            itemOutput.setReceivedOn(mdb0201Input.getAudat());

            // 受注金額
            itemOutput.setReceivedAmount(mdb0201Input.getNetwr());

            // 売上予定日
            itemOutput.setPlanedSellingOn(mdb0201Input.getFkdat());

            // 売上日
            itemOutput.setSoldOn(null);

            // 応札積算額
            itemOutput.setOsatsuPlanedAmount(mdb0201Input.getZsekisana3());

            // 高原価・政策受注フラグ
            itemOutput.setHighCostReceive(
                    mdb0201Input.getZkouflag() == null ? "0" : mdb0201Input.getZkouflag().equals("X") ? "1" : "0");

            // 受注申請時積算原価率
            itemOutput.setReceivedPlanedRate(mdb0201Input.getZsekisanr3());

            // キャンセルフラグ
            itemOutput.setCanceled("0");

            // 作成日
            itemOutput.setCreatedAt(systemYearMonth);

            // 更新日
            itemOutput.setUpdatedAt(systemYearMonth);

            outputItems.add(itemOutput);
        }

        return outputItems;
    }

    private String getCurrentMonth(LocalDateTime systemDateTime) {

        return systemDateTime.plusMonths(-3).format(dtfUUUUMM);
    }

    private String getPreviousMonth(LocalDateTime systemDateTime) {

        return systemDateTime.plusMonths(-4).format(dtfUUUUMM);
    }

    private String getCurrentMonthDelete(LocalDateTime systemDateTime) {

        return systemDateTime.format(dtfUUUUMM);
    }

    private String getPreviousMonthDelete(LocalDateTime systemDateTime) {

        return systemDateTime.plusMonths(-1).format(dtfUUUUMM);
    }

    private String getFormatedYearMonth(String year, String month) {
        LocalDate ld = LocalDate.of(Integer.parseInt(year), Integer.parseInt(month), 1).plusMonths(3) ;
        return ld.format(dtfUUUUMM);
    }

    private List<String> getSalePjIdList(List<MDB0201SaleOutput> outSaleItems) {

        List<String> rtnPjIdList = new ArrayList<String>();
        String oldPjId = "";
        String newPjId = "";

        for (MDB0201SaleOutput mdb0201SaleOutput : outSaleItems) {
            newPjId = mdb0201SaleOutput.getPjId();

            if(!oldPjId.equals(newPjId)) {
                rtnPjIdList.add(newPjId);
            }
        }
        return rtnPjIdList;
    }

    private List<String> getOrderPjIdList(List<MDB0201OrderOutput> outOrderItems) {

        List<String> rtnPjIdList = new ArrayList<String>();
        String oldPjId = "";
        String newPjId = "";

        for (MDB0201OrderOutput mdb0201OrderOutput : outOrderItems) {
            newPjId = mdb0201OrderOutput.getPjId();

            if(!oldPjId.equals(newPjId)) {
                rtnPjIdList.add(newPjId);
            }
        }
        return rtnPjIdList;
    }

    private BigDecimal addBD(BigDecimal input1, BigDecimal input2) {

        BigDecimal rtn = null;

        if (input1 != null && input2 != null) {
            rtn = input1.add(input2);
        } else {

            if (input1 == null && input2 == null) {
                rtn = null;
            } else if (input1 == null) {
                rtn = input2;
            } else {
                rtn = input1;
            }
        }

        return rtn;
    }

    private Map<Integer, List<String>> getInStr(List<String> salePjIdList){

        List<String> salePjIdlst = new ArrayList<String>();
        Map<Integer, List<String>> inMap = new HashMap<Integer, List<String>>();
        int count = 0;

        for (int i = 0; i < salePjIdList.size(); i++) {

            if(i % 1500 != 0 || i == 0) {
                salePjIdlst.add(salePjIdList.get(i));
            }else {
                count++;
                inMap.put(count,salePjIdlst);

                salePjIdlst = new ArrayList<String>();
                salePjIdlst.add(salePjIdList.get(i));
            }

            if(i == salePjIdList.size()-1 && salePjIdlst.size() > 0) {
                inMap.put(count,salePjIdlst);
            }
        }

        return inMap;

    }

    private String getPjIdListStr(List<MDB0201OrderOutput> inputList) {

        String rtnPjIdStr = "";

        for (int i = 0; i < inputList.size(); i++) {
            rtnPjIdStr += "'";
            rtnPjIdStr += inputList.get(i).getPjId();
            rtnPjIdStr += "',";

            if(i == inputList.size() -1) {
                rtnPjIdStr = rtnPjIdStr.substring(0, rtnPjIdStr.length() -1);
            }
        }

        return rtnPjIdStr.equals("")?"''" : rtnPjIdStr;
    }
}
