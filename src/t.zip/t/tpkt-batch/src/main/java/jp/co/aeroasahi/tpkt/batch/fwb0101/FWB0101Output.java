package jp.co.aeroasahi.tpkt.batch.fwb0101;

import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.batch.item.ItemCountAware;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】SAP得意先マスタ＞のOutputBean。
 */
@Setter
@Getter
public class FWB0101Output implements ItemCountAware {

    private int count;

    /** 顧客ID */
    @NotBlank
    @Size(min = 1, max = 10)
    private String KUNNR;

    /** 顧客名 */
    @Size(min = 0, max = 40)
    private String NAME1;

    /** 顧客名（カナ） */
    @Size(min = 0, max = 40)
    private String NAME2;

    /** 国コード */
    @Size(min = 0, max = 3)
    private String COUNTRY;

    /** 顧客郵便番号 */
    @Size(min = 0, max = 10)
    private String POST_CODE1;

    /** 顧客住所（都道府県） */
    @Size(min = 0, max = 60)
    private String STREET;

    /** 顧客住所（市区町村） */
    @Size(min = 0, max = 40)
    private String CITY1;

    /** 顧客住所（所在地） */
    @Size(min = 0, max = 40)
    private String CITY2;

    /** 顧客住所（建物） */
    @Size(min = 0, max = 40)
    private String STR_SUPPL1;

    /** 顧客住所（建物2） */
    @Size(min = 0, max = 40)
    private String STR_SUPPL2;

    /** 顧客電話番号 */
    @Size(min = 0, max = 30)
    private String TEL_NUMBER;

    /** 顧客FAX番号 */
    @Size(min = 0, max = 30)
    private String FAX_NUMBER;

    /** 顧客タイプ */
    @Size(min = 0, max = 4)
    private String BRSCH;

    /** 支払条件ID */
    @Size(min = 0, max = 4)
    private String ZTERM_B;

    /** 顧客通貨コード */
    @Size(min = 0, max = 5)
    private String WAERS;

    /** 消費税取引タイプ */
    @Size(min = 0, max = 1)
    private String STCD1;

    /** 顧客小分類コード */
    @Size(min = 0, max = 6)
    private String BRAN1;

    /** 顧客ステータス */
    @Size(min = 0, max = 1)
    private String SPERR;

    /** 作成日 */
    @Size(min = 0, max = 23)
    private String INS_DT;

    /** 更新日 */
    @Size(min = 0, max = 23)
    private String UPD_DT;

    @Override
    public void setItemCount(int count) {
        this.count = count;
    }
}
