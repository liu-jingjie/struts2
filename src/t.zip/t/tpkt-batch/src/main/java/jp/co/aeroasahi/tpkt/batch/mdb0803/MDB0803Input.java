package jp.co.aeroasahi.tpkt.batch.mdb0803;

import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜部門別経費＞＜部門マスタ＞＜勘定科目マスタ＞＜部門表示順マスタ＞のInputBean。
 */
@Setter
@Getter
public class MDB0803Input {

    /** 部門別経費の部門CD */
    private String deptCd;

    /** 部門マスタの部門名称 */
    private String deptName;

    /** 勘定科目マスタの費目CD */
    private String himokuCd;

    /** 勘定科目マスタの費目名称 */
    private String himokuName;

    /** 部門別経費の勘定科目CD */
    private String kamokuCd;

    /** 勘定科目マスタの勘定科目名称 */
    private String kamokuName;

    /** 部門マスタの支社コード */
    private String branchCd;

    /** 部門マスタの支社名 */
    private String branchName;

    /** 部門マスタの中部門CD */
    private String deptMCd;

    /** 部門マスタの中部門名称 */
    private String deptMName;

    /** 部門マスタの小部門CD */
    private String deptSCd;

    /** 部門マスタの小部門名称 */
    private String deptSName;

    /** 部門マスタの部門種別 */
    private String deptType;

    /** 部門別経費の会計年度 */
    private BigDecimal fiscalYear;

    /** 部門別経費の会計期間 */
    private BigDecimal fiscalMonth;

    /** 部門別経費の実績積算区分 */
    private String resultPlanedKbn;

    /** 部門別経費の原価 */
    private BigDecimal cost;

    /** 部門表示順マスタの表示順 */
    private BigDecimal dispOrder;

    /** 会計年度 検索用(当月)*/
    private String GJAHR1;

    /** 会計期間 検索用(当月)*/
    private String MONAT1;

    /** 会計年度 検索用(前月或は指定した月)*/
    private String GJAHR2;

    /** 会計期間 検索用(前月或は指定した月)*/
    private String MONAT2;

    /** システム日付（YYYY-MM-DD）*/
    private String systemDate;

    /** システム日付（YYYY-MM-DD）指定月の末日 */
    private String specifiedMonth;

}
