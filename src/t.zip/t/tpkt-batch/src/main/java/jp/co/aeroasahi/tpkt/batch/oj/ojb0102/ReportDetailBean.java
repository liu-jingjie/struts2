package jp.co.aeroasahi.tpkt.batch.oj.ojb0102;

import lombok.Getter;
import lombok.Setter;

/**
 * 帳票詳細のOutputBean.
 * <p>
 * 帳票詳細のOutputBean.
 * </p>
 */

@Getter
@Setter
public class ReportDetailBean {
    /**
     * 申請番号.
     */
    private String applyNum;
    /**
     * 委託先枝番.
     */
    private int entrustBranchNum;
    /**
     * 発注番号.
     */
    private String orderNum;
    /**
     * 算定注文番号.
     */
    private String calculatedNum;
}
