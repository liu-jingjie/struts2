package jp.co.aeroasahi.tpkt.batch.oj.ojb0102;

import lombok.Getter;
import lombok.Setter;

/**
 * 応受援帳票基本情報のOutputBean.
 * <p>
 * 応受援帳票基本情報のOutputBean.
 * </p>
 */

@Getter
@Setter
public class OjDocBaseOutPut {
    /**
     * 申請番号.
     */
    private String applyNum;
    /**
     * 委託先枝番.
     */
    private int entrustBranchNum;
    /**
     * 応受援帳票種別.
     */
    private String ojuenDocType;
    /**
     * 発注番号.
     */
    private String orderNum;
    /**
     * 算定注文番号.
     */
    private String calculatedNum;
    /**
     * 応受援帳票登録状況.
     */
    private String ojuenDocRegStatus;
    /**
     * 作成日.
     */
    private String createdAt;
    /**
     * 更新日.
     */
    private String updatedAt;


}
