package jp.co.aeroasahi.tpkt.batch.mdb0202;

import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜SAPプロジェクト属性＞＜SAP受注＞＜汎用マスタ＞＜ビジネスユニットコード変換＞のInputBean。
 */
@Setter
@Getter
public class MDB0202Input {

    /** SAPプロジェクト属性のプロジェクト属性ID */
    private String ZPSPID;

    /** SAPプロジェクト属性のプロジェクト属性名称 */
    private String ZPSPNAME;

    /** SAPプロジェクト属性の営業主管部門 */
    private String ZEIGYOSHUKANBUMON;

    /** SAPプロジェクト属性の営業主管担当者 */
    private String ZEIGYOTANTO;

    /** SAPプロジェクト属性の生産主管部門 */
    private String ZSEISANSHUKANBUMON;

    /** SAPプロジェクト属性の生産プロデューサー */
    private String ZPRODUCER;

    /** SAPプロジェクト属性の物件管理責任者部門 */
    private String ZBUKKENTANTO;

    /** SAPプロジェクト属性の物件管理責任者 */
    private String ZBUKKENTANTOBUMON;

    /** SAPプロジェクト属性の顧客 */
    private String ZTOKUISAKI;

    /** SAPプロジェクト属性の分野コード */
    private String ZBUNYACD;

    /** SAPプロジェクト属性の業務コード */
    private String ZGYOUMUCD;

    /** 汎用マスタの値 */
    private String VALUE;

    /** SAPプロジェクト属性の今期仕掛中フラグ */
    private String DATEFLG;

    /** SAPプロジェクト属性の賃貸PJ区分 */
    private String ZLEASEFLAG;

    /** SAPプロジェクト属性の契約件名 */
    private String ZKEIYAKUMEI;

    /** ビジネスユニットコード変換のビジネスユニット */
    private String BU;

    /** SAPプロジェクト属性の契約工期（FROM） */
    private String ZKEYAKUKOKIB;

    /** SAPプロジェクト属性の契約工期(TO） */
    private String ZKEYAKUKOKIE;

    /** SAP受注の個人情報 */
    private String ZKOJIN;

}
