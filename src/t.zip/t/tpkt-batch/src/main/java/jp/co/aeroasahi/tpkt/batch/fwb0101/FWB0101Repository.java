package jp.co.aeroasahi.tpkt.batch.fwb0101;

/**
 * テーブル＜【TEMP】SAP得意先マスタ＞に操作
 */
public interface FWB0101Repository {

    /**
     * テーブル＜【TEMP】SAP得意先マスタ＞に登録する。
     *
     * @param output FWB0101Output
     * @return
     */
    void create(FWB0101Output output);

    /**
     * テーブル＜【TEMP】SAP得意先マスタ＞に削除する。
     *
     * @param output FWB0101Output
     * @return
     */
    void delete(FWB0101Output output);
}