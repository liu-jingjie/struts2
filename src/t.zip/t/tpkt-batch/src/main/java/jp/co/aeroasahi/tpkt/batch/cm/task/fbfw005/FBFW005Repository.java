package jp.co.aeroasahi.tpkt.batch.cm.task.fbfw005;

/**
 * テーブル＜テーブル＜バッチ管理＞に操作
 */
public interface FBFW005Repository {

    /**
     * テーブル＜バッチ管理＞に更新する。
     *
     * @param output FBFW005Output output
     * @return
     */
    void update(FBFW005Output output);

    /**
     * テーブル＜バッチ管理＞に更新する。
     *
     * @param output FBFW005Output output
     * @return
     */
    void updateD(FBFW005Output output);

}
