package jp.co.aeroasahi.tpkt.batch.mdb0301;

import java.time.format.DateTimeFormatter;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.validator.ValidationException;
import org.springframework.batch.item.validator.Validator;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.fw.CommonLog;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

@Component
@Scope("step")
public class MDB0301Tasklet implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0301Tasklet.class);

    @Inject
    MDB0301Repository mdb0301Repository;

    @Inject
    DateFactory dateFactory;

    @Inject
    Validator<MDB0301Output> validator;

    @Value("#{jobParameters['kbn']}")
    public String kbn;

    @Value("#{jobParameters['yyyymm']}")
    public String yyyymm;

    boolean isErrFlag = false;

    /** DateTimeFormatterのパターン uuuuMM */
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("uuuuMM");

    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        MDB0301Output outItem = setItemOutput();

        if (!isErrFlag) {

            try {
                validator.validate(outItem);
            } catch (ValidationException e) {
                isErrFlag = true;
                CommonLog.setFromDbErrorLog(logger, e, "【TEMP】金額(temp_md_cost)");
            }

            if (!isErrFlag) {
                try {
                    mdb0301Repository.delete(outItem);
                    mdb0301Repository.deletePerformance(outItem);
                    CommonLog.setDeleteRecordeCountLog(logger, "【TEMP】金額(temp_md_cost)");
                } catch (Exception e) {
                    isErrFlag = true;
                }
            } else {
                logger.error("削除データでエラーが発生しました。");
            }
        }

        if (isErrFlag) {
            throw new RuntimeException("mdb0301金額情報取込準備の処理実行に異常が発生しました。");
        }

        return RepeatStatus.FINISHED;
    }

    private MDB0301Output setItemOutput() {

        MDB0301Output itemOutput = new MDB0301Output();

        String systemYearMonth = dateFactory.newDateTime().format(dtf);
        String systemYearBeforeMonth = dateFactory.newDateTime().plusMonths(-1).format(dtf);

        itemOutput.setYm1(systemYearMonth);

        if (kbn.equals("D")) {
            itemOutput.setYm2(systemYearBeforeMonth);
        } else if (kbn.equals("M")) {
            itemOutput.setYm2(yyyymm);
        }

        return itemOutput;
    }
}
