package jp.co.aeroasahi.tpkt.batch.sbb0202;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 * 積算実績登録
 */
public interface SBB0202Repository {

    /**
     * 積算データを取得
     *
     * @param ym 会計年度の年月
     * @param today システム日付
     * @return 積算データリスト
     */
    List<SBB0202TankaUpdate> getSekisanData(@Param("ym") String ym, @Param("today") LocalDate today);

    /**
     * 金額を取得
     *
     * @param ym 会計年度の年月
     * @param today システム日付
     * @return 積算データ金額リスト
     */
    List<SBB0202TankaUpdate> getKingaku(@Param("ym") String ym, @Param("today") LocalDate today);

    /**
     * 積算データを更新
     *
     * @param item 更新データ
     */
    void updateSbData(@Param("item") SBB0202TankaUpdate item);

    /**
     * 積算月別データを更新
     *
     * @param item 更新データ
     * @param today システム日時
     */

    void updateSbMonthData(@Param("item") SBB0202TankaUpdate item, @Param("today") LocalDateTime today);


}
