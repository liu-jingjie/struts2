package jp.co.aeroasahi.tpkt.batch.fwb0109;

import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】SAP発注番号＞のInputBean。
 */
@Setter
@Getter
public class FWB0109Input {

    /** 申請番号 */
    private String ABLAD;

    /** 委託先枝番 */
    private String WEMPF;

    /** 発注番号 */
    private String EBELN;

    /** 注文日 */
    private String BEDAT;

    /** 作成日 */
    private String INS_DT;

    /** 更新日 */
    private String UPD_DT;

}
