package jp.co.aeroasahi.tpkt.batch.fwb0101;

import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】SAP得意先マスタ＞のInputBean。
 */
@Setter
@Getter
public class FWB0101Input {

    /** 顧客ID */
    private String KUNNR;

    /** 顧客名 */
    private String NAME1;

    /** 顧客名（カナ） */
    private String NAME2;

    /** 国コード */
    private String COUNTRY;

    /** 顧客郵便番号 */
    private String POST_CODE1;

    /** 顧客住所（都道府県） */
    private String STREET;

    /** 顧客住所（市区町村） */
    private String CITY1;

    /** 顧客住所（所在地） */
    private String CITY2;

    /** 顧客住所（建物） */
    private String STR_SUPPL1;

    /** 顧客住所（建物2） */
    private String STR_SUPPL2;

    /** 顧客電話番号 */
    private String TEL_NUMBER;

    /** 顧客FAX番号 */
    private String FAX_NUMBER;

    /** 顧客タイプ */
    private String BRSCH;

    /** 支払条件ID */
    private String ZTERM_B;

    /** 顧客通貨コード */
    private String WAERS;

    /** 消費税取引タイプ */
    private String STCD1;

    /** 顧客小分類コード */
    private String BRAN1;

    /** 顧客ステータス */
    private String SPERR;

    /** 作成日 */
    private String INS_DT;

    /** 更新日 */
    private String UPD_DT;

}
