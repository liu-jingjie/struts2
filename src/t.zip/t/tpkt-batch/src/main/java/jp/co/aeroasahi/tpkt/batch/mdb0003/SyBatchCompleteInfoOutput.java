package jp.co.aeroasahi.tpkt.batch.mdb0003;

import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜バッチ完了情報＞のOutputBean。
 */
@Setter
@Getter
public class SyBatchCompleteInfoOutput {

    /**  前回日次処理完了日時 */
    private String lastDailyBatchCompleteDateTime;

    /**  前回月次確定処理完了日時 */
    private String lastMonthlyConfirmCompleteDateTime;

    /**  前回月次確定処理年月 */
    private String lastMonthlyConfirmYm;

    /**  前回監視完了日時 */
    private String lastMonitoringCompleteDateTime;

    /**  更新日 */
    private String updatedAt;

}
