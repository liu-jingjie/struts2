package jp.co.aeroasahi.tpkt.batch.mdb0013;

import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 * ジョブについてテーブルに操作
 */
public interface MDB0013Repository {

    /**
     * テーブル＜ジョブ要求テーブル＞に登録する。
     *
     * @param input BatchJobRequestInput
     * @return
     */
    void create(BatchJobRequestInput batchJobRequestInput);

     /**
      * ジョブ名を指定し、指定時間以内に更新されておりまだ終了していないjobの件数を取得する
      *
      * @param jobName 検索対象のジョブ名
      * @param dateTimeStr 指定時間
      *
      * @return ジョブ要求リスト
      */
     int countNotExecuted(@Param("jobName") String jobName, @Param("targetDateTimeStr") String targetDateTimeStr);

     /**
      * ジョブ名を指定し、指定時間以内に更新されておりまだ終了していないjobの件数を取得する
      *
      * @param jobNames 検索対象のジョブ名のリスト
      * @param dateTimeStr 指定時間
      *
      * @return ジョブ要求リスト
      */
     int countAllNotExecuted(@Param("jobNames") List<String> jobNames,
             @Param("targetDateTimeStr") String targetDateTimeStr);

     /**
      * ジョブ名を指定し、作製日時がメインジョブの開始時間であり、ジョブが完了していないjobの件数を取得する
      * (対象ジョブが終了していることが前提)
      *
      * @param jobName 検索対象のジョブ名
      * @param jobStartDateTimeStr システム時間
      *
      * @return ジョブ要求リスト
      */
     int countNotCompleted(@Param("jobName") String jobName, @Param("jobStartDateTimeStr") String jobStartDateTimeStr);

     /**
      * ジョブ名を指定し、作製日時がメインジョブの開始時間であり、ジョブが完了していないjobの件数を取得する
      * (対象ジョブが終了していることが前提)
      *
      * @param jobName 検索対象のジョブ名
      * @param jobStartDateTimeStr システム時間
      *
      * @return ジョブ要求リスト
      */
     int countNotAllCompleted(@Param("jobNames") List<String> jobNames,
             @Param("jobStartDateTimeStr") String jobStartDateTimeStr);
}
