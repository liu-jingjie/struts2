package jp.co.aeroasahi.tpkt.batch.kn.knb0102;

/**
 * 勤怠データ取込バッチのリポジトリ
 */
public interface KNB0102Repository {

    /**
     * テーブル＜ジョブ要求テーブル＞に登録する。
     *
     * @param input BatchJobRequestInput
     * @return
     */
    void jobInsert(BatchJobRequestInput batchJobRequestInput);

    /**
     * テーブル＜勤怠データ＞に登録する。
     *
     * @param output KNB0102Output
     * @return
     */
    void create(KNB0102Output output);

    /**
     * テーブル＜勤怠データ＞に削除する。
     *
     * @param output KNB0102Output
     * @return
     */
    void delete(KNB0102Output output);
}
