package jp.co.aeroasahi.tpkt.batch.mdb0007;

import java.io.File;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;

/**
 * SAP連携のtmepテーブルと本体テーブルのミラーリングを実施するTasklet
 */
@Component
@Scope("step")
public class MDB0007Tasklet12 implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0007Tasklet12.class);

    /** DateTimeFormatterのパターン uuuuMMdd */
    private static final DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("uuuuMMdd");
    /** DateTimeFormatterのパターン uuuu-MM-dd HH:mm:ss.SSS */
    private static final DateTimeFormatter dtf4 = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.SSS");

    private static final String CUSTMER_JOB_NAME = "fwb0101Job";
    private static final String VENDOR_JOB_NAME = "fwb0102Job";
    private static final String PROJECT_ATTRIBUTE_JOB_NAME = "fwb0103Job";
    private static final String PROJECT_JOB_NAME = "fwb0104Job";
    private static final String ACCOUNT_DETAIL_JOB_NAME = "fwb0105Job";
    private static final String ACCOUNT_BALANCE_JOB_NAME = "fwb0106Job";
    private static final String INPROCESS_COST_JOB_NAME = "fwb0107Job";
    private static final String RECEIVE_ORDER_JOB_NAME = "fwb0108Job";
    private static final String ORDER_NO_JOB_NAME = "fwb0109Job";

    private static final boolean TEMP_TO_MAIN = true;
    private static final boolean MAIN_TO_TEMP = false;

    /** 勘定明細、勘定残高の取り込む期間(3ヶ月) */
    private static final int RETRIEVE_ACCOUNT_FILE_TERM = 3;

    /** ■ファイルバックアップ先（取込で異常が発生した場合） */
    @Value("${sap.error.dirpath}")
    String errorDirPath;

    /** ファイル監視終了_時間 */
    @Value("${sap.endTime.hour}")
    int endTimeHour;

    /** ファイル監視終了_分 */
    @Value("${sap.endTime.minute}")
    int endTimeMinute;

    @Autowired
    private BatchDataHolder batchDataHolder;

    @Inject
    DateFactory dateFactory;

    @Inject
    MDB0007Repository mdb0007Repository;

    @Inject
    MDB0007DataCopyRepository mainDataCopyRepository;

    /**
     * ミラーリング処理
     * <p>
     * ファイル連携期間終了後かつ、ファイル連携が全て終了した後にtempと本体のミラーリング処理を実施する
     * ・ファイル連携でエラー無: temp -> 本体
     * ・ファイル連携でエラー有: 本体 -> temp
     * </p>
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return 一括で各ジョブを実行した状態
     */
    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        LocalTime sysTime = dateFactory.newTime();
        LocalTime endTime = LocalTime.of(endTimeHour, endTimeMinute);
        LocalDateTime jobStartDateTime = batchDataHolder.getStartDateTime();
        String jobStartDateTimeStr = jobStartDateTime.format(dtf4);
        String systemYMD = jobStartDateTime.format(dtf2);

        // 現在日時がファイル監視期間の場合は処理を終了する
        if (sysTime.isBefore(endTime)) {
            return RepeatStatus.FINISHED;
        }

        // 当日NGファイル存在チェック
        ArrayList<String> errFileNameList = getNgFilesList(getFileName(errorDirPath), systemYMD);

        // errorフォルダにファイルが存在した場合、本体 -> tempへミラーリング処理
        if (errFileNameList.size() > 0) {
            // 本体の情報をTEMPに書き込む
            dataCopy(MAIN_TO_TEMP, jobStartDateTime);
            logger.error("SAPファイルの取込に失敗しました");
            return RepeatStatus.FINISHED;
        }

        // SAP取込処理が全て終了している場合
        if (checkAllSapJobExecuted(jobStartDateTimeStr)) {

            // 再度当日NGファイル存在チェック
            errFileNameList = getNgFilesList(getFileName(errorDirPath), systemYMD);

            if (errFileNameList.size() == 0) {
                // TEMPの情報を本体に書き込む
                dataCopy(TEMP_TO_MAIN, jobStartDateTime);
                return RepeatStatus.FINISHED;
            }
        }

        /*
         * 以下に当てはまる場合は本体の情報をTEMPに書き込む
         * ・なんらかのシステムエラーが発生した場合
         * ・NGファイルが存在した場合
         * ・時間内にSAP取込が終わらなかった場合
         */
        dataCopy(MAIN_TO_TEMP, batchDataHolder.getStartDateTime());
        logger.error("SAPファイルの取込に失敗しました");
        return RepeatStatus.FINISHED;
    }

    private void dataCopy(boolean isTempToMain, LocalDateTime jobStartDateTime) {
        /*
         * 以下の条件でtempテーブルと本体テーブルのミラーリング処理を実施する
         * ・明細と残高：ジョブ開始月の3ヶ月前以降に連携されたものを対象とする
         * ・明細と残高以外：全件を対象とする
         */
        DataCopyCondition condition = createCondition(jobStartDateTime);

        // 連携jobが全て完了した場合は、tempテーブルの内容を本体テーブルへミラーリングする
        if (isTempToMain) {
            logger.info("TEMPテーブルの情報を本体テーブルへ書き込みます。");
            // FWB0101 SAP得意先マスタ
            mainDataCopyRepository.dataCopy("temp_sap_ma_customer", "SAPCustomer");
            // FWB0102 SAP仕入先マスタ
            mainDataCopyRepository.dataCopy("temp_sap_ma_vendor", "SAPVendor");
            // FWB0103 SAPプロジェクト属性
            mainDataCopyRepository.dataCopy("temp_sap_project_attribute", "SAPProjectAttribute");
            // FWB0104 SAPプロジェクト
            mainDataCopyRepository.dataCopy("temp_sap_project", "SAPProject");
            // FWB0105 SAP勘定明細
            mainDataCopyRepository.dataCopy2("temp_sap_account_detail", "SAPAccountDetail", condition);
            // FWB0106 SAP勘定残高
            mainDataCopyRepository.dataCopy2("temp_sap_account_balance", "SAPAccountBalance", condition);
            // FWB0107 SAP仕掛原価
            mainDataCopyRepository.dataCopy("temp_sap_in_process_cost", "SAPInProcessCost");
            // FWB0108 SAP受注
            mainDataCopyRepository.dataCopy("temp_sap_receive_order", "SAPReceiveOrder");
            // FWB0109 SAP発注番号
            mainDataCopyRepository.dataCopy("temp_sap_order_number", "SAPOrderNO");
        } else {
            logger.info("本体テーブルの情報をTEMPテーブルへ書き込みます。");
            // FWB0101 SAP得意先マスタ
            mainDataCopyRepository.dataCopy("SAPCustomer", "temp_sap_ma_customer");
            // FWB0102 SAP仕入先マスタ
            mainDataCopyRepository.dataCopy("SAPVendor", "temp_sap_ma_vendor");
            // FWB0103 SAPプロジェクト
            mainDataCopyRepository.dataCopy("SAPProjectAttribute", "temp_sap_project_attribute");
            // FWB0104 SAPプロジェクト属性
            mainDataCopyRepository.dataCopy("SAPProject", "temp_sap_project");
            // FWB0105 SAP勘定明細
            mainDataCopyRepository.dataCopy2("SAPAccountDetail", "temp_sap_account_detail", condition);
            // FWB0106 SAP勘定残高
            mainDataCopyRepository.dataCopy2("SAPAccountBalance", "temp_sap_account_balance", condition);
            // FWB0107 SAP仕掛原価
            mainDataCopyRepository.dataCopy("SAPInProcessCost", "temp_sap_in_process_cost");
            // FWB0108 SAP受注
            mainDataCopyRepository.dataCopy("SAPReceiveOrder", "temp_sap_receive_order");
            // FWB0109 SAP発注番号
            mainDataCopyRepository.dataCopy("SAPOrderNO", "temp_sap_order_number");
        }
    }

    /**
     * SAP取込終了確認
     *
     * @param jobStartDateTimeStr job開始日時
     *
     * @return true:全てが終了している、false:1時間経過しても終了していないjobがある
     * @throws InterruptedException threadに割り込みがあった場合等
     */
    private boolean checkAllSapJobExecuted(String jobStartDateTimeStr) throws InterruptedException {
        // SAPファイル取込のjobIDのリストを生成
        List<String> jobIds = setJobNames();
        while (true) {
            // 10秒待機
            Thread.sleep(10000);

            // 全SAP取込のjobの終了確認のために、このjobの起動から1時間以内に更新され、まだ終了していないjobの件数を取得する
            int notExecutedJobCount = mdb0007Repository.countAllNotExecuted(jobIds, jobStartDateTimeStr);
            if (notExecutedJobCount == 0) {
                return true;
            }

            LocalDateTime systemDateTime = dateFactory.newDateTime();
            LocalDateTime jobStartDateTime = LocalDateTime.parse(jobStartDateTimeStr, dtf4);
            if (systemDateTime.isAfter(jobStartDateTime.plusHours(1))) {
                // 現在日時がこのjobの起動から1時間以上経過している場合はエラーとする
                return false;
            }
            // 現在日時がこのjobの起動から1時間経過していない場合は10秒待機し、再度SAP取込の終了確認を実施する
            logger.info("まだ全てのSAP取込処理が終了していないため、10秒間待機します。");
        }
    }

    private String[] getFileName(String path) {
        File file = new File(path);
        String[] fileName = file.list();
        return fileName;
    }

    private ArrayList<String> getNgFilesList(String[] fileNames, String systemYMD) {

        ArrayList<String> rtn = new ArrayList<String>();

        if (fileNames == null || fileNames.length == 0) {
            return rtn;
        }

        for (String name : fileNames) {
            if (name.length() >= 12 && name.substring(0, 8).equals(systemYMD)) {
                rtn.add(name.substring(name.length() - 12, name.length() - 4));
            }
        }
        logger.info("errorフォルダにファイルが存在します。");
        return rtn;
    }

    private List<String> setJobNames() {
        List<String> resultList = new ArrayList<>();

        resultList.add(CUSTMER_JOB_NAME);
        resultList.add(VENDOR_JOB_NAME);
        resultList.add(PROJECT_ATTRIBUTE_JOB_NAME);
        resultList.add(PROJECT_JOB_NAME);
        resultList.add(ACCOUNT_DETAIL_JOB_NAME);
        resultList.add(ACCOUNT_BALANCE_JOB_NAME);
        resultList.add(INPROCESS_COST_JOB_NAME);
        resultList.add(RECEIVE_ORDER_JOB_NAME);
        resultList.add(ORDER_NO_JOB_NAME);

        return resultList;
    }

    private DataCopyCondition createCondition(LocalDateTime jobStartDateTime) {
        // 会計年月取得
        LocalDateTime fromFisicalDateTime = jobStartDateTime.minusMonths(3);
        // ジョブ開始月の3ヶ月前以降に連携されたものを対象とする
        LocalDateTime fromDateTime = fromFisicalDateTime.minusMonths(RETRIEVE_ACCOUNT_FILE_TERM);

        DataCopyCondition condition = new DataCopyCondition();

        condition.setFromFisicalYear(fromDateTime.getYear());
        condition.setFromFisicalMonth(fromDateTime.getMonthValue());

        return condition;
    }
}
