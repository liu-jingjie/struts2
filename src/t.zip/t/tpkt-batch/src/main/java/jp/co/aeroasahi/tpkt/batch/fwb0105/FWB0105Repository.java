package jp.co.aeroasahi.tpkt.batch.fwb0105;

/**
 * テーブル＜【TEMP】SAP勘定明細＞に操作
 */
public interface FWB0105Repository {

    /**
     * テーブル＜【TEMP】SAP勘定明細＞に登録する。
     *
     * @param output FWB0105Output
     * @return
     */
    void create(FWB0105Output output);

    /**
     * テーブル＜【TEMP】SAP勘定明細＞に更新する。
     *
     * @param output FWB0105Output
     * @return
     */
    void delete(FWB0105Output output);

}
