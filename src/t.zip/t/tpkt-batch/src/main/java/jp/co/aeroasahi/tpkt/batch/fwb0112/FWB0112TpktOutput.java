package jp.co.aeroasahi.tpkt.batch.fwb0112;

import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜【TEMP】プロジェクト属性＞のOutputBean。
 */
@Setter
@Getter
public class FWB0112TpktOutput {

    /** プロジェクト属性ID */
    private String pjAttId;

    /** プロジェクト属性名称 */
    private String pjAttName;

    /** 営業主管部門CD */
    private String salesMainDeptCd;

    /** 営業主管担当者CD */
    private String salesMainDeptEmpCd;

    /** 生産主管部門CD */
    private String productDeptCd;

    /** 生産プロデューサーCD */
    private String productEmpCd;

    /** 物件管理責任者部門CD */
    private String pjManageRespDeptCd;

    /** 物件管理責任者CD */
    private String pjManageRespEmpCd;

    /** 顧客CD */
    private String customerCd;

    /** 分野CD */
    private String fieldCd;

    /** 業務CD */
    private String businessCd;

    /** PJステータス */
    private String pjStatus;

    /** 今期仕掛中区分 */
    private String workingKbn;

    /** リースフラグ */
    private String lease;

    /** 契約件名 */
    private String contractName;

    /** 契約工期(FROM) */
    private String contractFrom;

    /** 契約工期(TO) */
    private String contractTo;

    /** 作成日 */
    private String createdAt;

    /** 更新日 */
    private String updatedAt;
}
