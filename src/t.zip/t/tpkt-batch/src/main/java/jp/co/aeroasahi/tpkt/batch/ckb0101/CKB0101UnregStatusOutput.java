package jp.co.aeroasahi.tpkt.batch.ckb0101;

import org.springframework.batch.item.ItemCountAware;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜未登録状況＞のOutputBean。
 */
@Setter
@Getter
public class CKB0101UnregStatusOutput implements ItemCountAware {

    private int count;

    /** プロジェクトID */
    private String pjId;

    /** 帳票種別 */
    private String docType;

    /** メッセージ */
    private String message;

    /** 作成日 */
    private String createdAt;

    @Override
    public void setItemCount(int count) {
        this.count = count;
    }
}
