package jp.co.aeroasahi.tpkt.batch.oj.ojb0102;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;
import javax.inject.Inject;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import com.google.common.collect.Lists;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;
import jp.co.aeroasahi.tpkt.common.util.CommonUtils;

/**
 *
 * 応受援帳票登録状況一覧の作成
 *
 */
@Component
@Scope("step")
public class OJB0102Tasklet implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(OJB0102Tasklet.class);

    @Inject
    DateFactory dateFactory;

    @Inject
    OJB0102Repository ojb0102Repository;

    @Inject
    MessageSource messageSource;

    @Value("${ojb0102.filter}")
    String fileFilter;

    @Value("${ojb0102.filepath}")
    String filePath;

    @Value("${file.serverpath}")
    String serverPath;

    @Value("${file.disk}")
    String disk;

    /** ジョブID */
    private static final String JOB_ID = "ojb0102";

    private static final String FILE_NAME = "fileName";

    private static final String APPLY_NUM = "applyNum";

    private static final String SHEET_NAME = "受入検査";

    /** DateFormatterのパターン yyyy-MM-dd */
    private static final DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    /** DateFormatterのパターン yyyy-MM-dd */
    private static final DateTimeFormatter dateTimeFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    @Transactional
    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
        // システム日を作成
        String sysdate = dateFactory.newDate().format(dateFormat);

        // システム日時を作成
        String systime = dateFactory.newDateTime().format(dateTimeFormat);

        logger.info("応受援帳票登録情報のレコードを全件削除します。");
        // 応受援帳票登録情報を削除
        ojb0102Repository.truncateTable("oj_doc_reg_info");
        logger.info("応受援帳票登録情報のレコードを全件削除しました。");
        // 帳票名を取得
        List<ReportBean> reportNames = ojb0102Repository.findReportName();

        // ファイル対象を取得
        List<File> resultFiles = FileUtils.getServerFileList(filePath, fileFilter);

        Map<String, String> fileMap = resultFiles.stream().collect(Collectors.toMap(File::getPath, File::getName));
        logger.info("対象フォルダ内のファイル件数(拡張子チェック実施済み、ファイル名チェック未実施)：" + Integer.toString(fileMap.size()) + "件");

        // 帳票詳細を取得
        List<ReportDetailBean> reportDetailBeanList = ojb0102Repository.findReportDetailInfo();
        // 帳票用マップ
        Map<String, String> namesAndType = reportNames.stream()
                .collect(Collectors.toConcurrentMap(ReportBean::getOjuenDocName, ReportBean::getOjuenDocType));

        // 発注番号用マップ
        Map<String, ReportDetailBean> orderNums =
                reportDetailBeanList.stream().filter(detailBean -> StringUtils.isNotEmpty(detailBean.getOrderNum()))
                        .collect(Collectors.toMap(ReportDetailBean::getOrderNum, Function.identity(),
                                (entity1, entity2) -> entity2));

        // 算定注文番号用マップ
        Map<String, ReportDetailBean> calculatedNums =
                reportDetailBeanList.stream()
                        .filter(detailBean -> StringUtils.isNotEmpty(detailBean.getCalculatedNum()))
                        .collect(Collectors.toMap(ReportDetailBean::getCalculatedNum, Function.identity(),
                                (entity1, entity2) -> entity2));

        // 外部委託受入検査記録表用リスト
        List<OjDocRegInfoOutput> ojDocRegInfoOutputList = Lists.newArrayList();

        for (Map.Entry<String, String> fileInfo : fileMap.entrySet()) {

            String fileName = fileInfo.getValue();
            String filePath = fileInfo.getKey();

            // 重複可能性があるので、パスで判定する
            int index = filePath.lastIndexOf(File.separator);
            // パスの最後部分はファイル名称
            String fileNameTemp = filePath.substring(index + 1);
            // 「-」で分割して番号と帳票名を取得
            String[] fileComponent = fileNameTemp.split("_");
            // 「-」前の部分は番号
            int indexStart = fileNameTemp.indexOf("_");
            // 「-」以降から拡張子「.」までファイル名
            int indexEnd = fileNameTemp.lastIndexOf(".");
            // 存在するかどうか
            if (indexStart == -1 || indexEnd == -1 || indexEnd < indexStart) {
                continue;
            }
            // 「[10桁]_[帳票名][自由文字列].[拡張子]」を判定
            if (fileComponent.length > 1) {
                String file = fileNameTemp.substring(indexStart + 1, indexEnd);

                for (Map.Entry<String, String> reportName : namesAndType.entrySet()) {
                    // 帳票名で始めるのファイル かつ算定注文番号と発注番号を含めた場合
                    if (file.startsWith(reportName.getKey())
                            && (orderNums.containsKey(fileComponent[0])
                                    || calculatedNums.containsKey(fileComponent[0]))) {
                        OjDocRegInfoOutput ojr = new OjDocRegInfoOutput();

                        ReportDetailBean rdbOrders = orderNums.get(fileComponent[0]);
                        if (rdbOrders != null) {
                            // 申請番号
                            ojr.setApplyNum(rdbOrders.getApplyNum());
                            // 委託先枝番
                            ojr.setEntrustBranchNum(rdbOrders.getEntrustBranchNum());
                        }
                        ReportDetailBean rdbCal = calculatedNums.get(fileComponent[0]);
                        if (rdbCal != null) {
                            // 申請番号
                            ojr.setApplyNum(rdbCal.getApplyNum());
                            // 委託先枝番
                            ojr.setEntrustBranchNum(rdbCal.getEntrustBranchNum());
                        }
                        // 応受援帳票種別
                        ojr.setOjuenDocType(reportName.getValue());
                        ojr.setFilePathTemp(filePath);
                        // ファイルパス
                        ojr.setFilePath(filePath.replace(disk, serverPath));
                        // ファイル名
                        ojr.setFileName(fileName);
                        // 登録日
                        ojr.setCreatedAt(systime);
                        // 更新日
                        ojr.setUpdatedAt(systime);

                        ojb0102Repository.createOjDocRegInfo(ojr);

                        if ("11".equals(reportName.getValue())) {
                            ojDocRegInfoOutputList.add(ojr);
                        }

                        Map<String, Integer> isExistFile = ojb0102Repository.findOjDocRegDateInfoByFileName(fileName);

                        if (isExistFile.get(FILE_NAME) == 0) {
                            OjDocRegDateOutPut ord = new OjDocRegDateOutPut();
                            // ファイル名称
                            ord.setFileName(fileName);
                            // 登録日
                            ord.setRegedOn(sysdate);
                            // 作成日
                            ord.setCreatedAt(systime);
                            // 更新日
                            ord.setUpdatedAt(systime);

                            ojb0102Repository.createOjDocRegDateInfo(ord);
                        }
                    }
                }
            }
        }
        logger.info("対象ファイルの情報を応受援帳票登録情報テーブルと応受援帳票登録日情報テーブルに登録完了");

        logger.info("応受援帳票基本情報をtruncate開始");
        ojb0102Repository.truncateTable("oj_doc_base");
        logger.info("応受援帳票基本情報をtruncate完了");

        logger.info("応受援帳票基本情報を登録開始");
        ojb0102Repository.createOjDocBaseInfo(sysdate);
        logger.info("応受援帳票基本情報を登録完了");

        // 外部委託受入検査記録表の特定のシート（受入検査）の特定のセルの値（A1）をテーブル委託履歴に格納
        if (ojDocRegInfoOutputList.size() > 0) {
            for (OjDocRegInfoOutput ojDocRegInfoOutput : ojDocRegInfoOutputList) {
                // ファイル情報を取得
                getExcelInfor(ojDocRegInfoOutput);
            }
        }
        return RepeatStatus.FINISHED;
    }

    /**
     * 外部委託受入検査記録表の特定のシート（受入検査）の特定のセルの値（A1）をテーブル委託履歴に格納
     *
     * @param ojDocRegInfoOutput
     */
    private void getExcelInfor(OjDocRegInfoOutput ojDocRegInfoOutput) {
        logger.info(messageSource.getMessage("i.bat.fw.001",
                CommonUtils.getMessageArgs(JOB_ID, "Excelファイル読込"),
                Locale.getDefault()));

        FileInputStream inputStream = null;
        Workbook workbook = null;
        try {
            String fileName = ojDocRegInfoOutput.getFileName();
            if (!fileName.endsWith(".xlsx") && !fileName.endsWith(".xls")) {
                return;
            }
            // 特定のファイルを取得
            File excelfile = new File(ojDocRegInfoOutput.getFilePathTemp());
            if (excelfile.exists()) {

                inputStream = new FileInputStream(excelfile);

                workbook = WorkbookFactory.create(inputStream);

                // Sheet[0]の値を取得
                Sheet firstSheet = workbook.getSheet(SHEET_NAME);

                if (firstSheet == null || firstSheet.getRow(0) == null || firstSheet.getRow(0).getCell(0) == null) {
                    return;
                }
                // 固定のCell(0,0)の値を取得
                Cell cell = firstSheet.getRow(0).getCell(0);

                String cellData = "";
                switch (cell.getCellType()) {
                    case Cell.CELL_TYPE_STRING:
                        cellData = cell.getStringCellValue();
                        break;
                    case Cell.CELL_TYPE_NUMERIC:
                        cellData = cell.getNumericCellValue() + "";
                        break;
                }
                // 外部委託受入検査記録表の場合、委託履歴を更新
                getOjEntrustHistoryInfor(ojDocRegInfoOutput, cellData);

            }
            logger.info(messageSource.getMessage("i.bat.fw.002",
                    CommonUtils.getMessageArgs(JOB_ID, "Excelファイル読込"),
                    Locale.getDefault()));

        } catch (Exception e) {
            logger.error(messageSource.getMessage("e.bat.ck.001",
                    CommonUtils.getMessageArgs(JOB_ID, "Excelファイル読込"),
                    Locale.getDefault()) + e.getMessage());

            throw new RuntimeException(messageSource.getMessage("e.bat.ck.002",
                    CommonUtils.getMessageArgs(JOB_ID, "Excelファイル読込"),
                    Locale.getDefault()));

        } finally {
            try {
                if (!Objects.isNull(workbook)) {
                    workbook.close();
                }
            } catch (IOException e) {
                logger.error(messageSource.getMessage("e.bat.ck.001",
                        CommonUtils.getMessageArgs(JOB_ID, "Excelファイルクローズ"),
                        Locale.getDefault()) + e.getMessage());
                throw new RuntimeException(messageSource.getMessage("e.bat.ck.002",
                        CommonUtils.getMessageArgs(JOB_ID, "Excelファイルクローズ"),
                        Locale.getDefault()));
            }
        }

    }

    /**
     * 外部委託受入検査記録表の場合、委託履歴を更新
     *
     * @param ori
     * @param vendorEvaluatePoints
     */
    private void getOjEntrustHistoryInfor(OjDocRegInfoOutput ori, String vendorEvaluatePoints) {
        OjEntrustHistoryOutput ohi = new OjEntrustHistoryOutput();
        // 申請番号
        ohi.setApplyNum(ori.getApplyNum());
        // 委託先枝番
        ohi.setEntrustBranchNum(ori.getEntrustBranchNum());
        // 委託先の評価点数
        ohi.setVendorEvaluatePoints(new BigDecimal(vendorEvaluatePoints));
        // 存在するかどうか
        Map<String, Integer> ohiResult = ojb0102Repository.findOjEntrustHistory(ohi);
        // 更新または登録
        insertOrUpdate(ohiResult, ohi);
    }

    /**
     *
     * @param ohiResult
     * @param ohi
     */
    private void insertOrUpdate(Map<String, Integer> ohiResult, OjEntrustHistoryOutput ohi) {
        // 存在しない場合
        if (ohiResult.get(APPLY_NUM) == 0) {
            ojb0102Repository.createOjEntrustHistory(ohi);
            // 存在する場合
        } else {
            ojb0102Repository.updateOjEntrustHistory(ohi);
        }
    }


}

