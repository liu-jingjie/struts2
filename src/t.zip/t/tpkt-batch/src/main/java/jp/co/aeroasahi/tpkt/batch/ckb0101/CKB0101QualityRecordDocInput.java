package jp.co.aeroasahi.tpkt.batch.ckb0101;

import org.springframework.batch.item.ItemCountAware;
import lombok.Getter;
import lombok.Setter;

/**
 * テーブル＜プロジェクト＞のOutputBean。
 */
@Setter
@Getter
public class CKB0101QualityRecordDocInput implements ItemCountAware {

    private int count;

    /** 帳票種別 */
    private String docType;

    /** 帳票名称 */
    private String docName;

    /** 未登録対象 */
    private String unregTarget;

    /** 未登録対象確認日 */
    private String unregTargetDate;

    /** 並び順 */
    private String sortNum;

    /** 作成者 */
    private String createdBy;

    /** 作成日 */
    private String createdAt;

    /** 更新者 */
    private String updatedBy;

    /** 更新日 */
    private String updatedAt;

    @Override
    public void setItemCount(int count) {
        this.count = count;
    }
}
