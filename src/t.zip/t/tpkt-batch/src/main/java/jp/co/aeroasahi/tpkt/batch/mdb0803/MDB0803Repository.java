package jp.co.aeroasahi.tpkt.batch.mdb0803;

import java.util.List;

/**
 * テーブル＜部門別経費＞＜部門マスタ＞＜勘定科目マスタ＞＜部門表示順マスタ＞＜部門経費管理＞に操作
 */
public interface MDB0803Repository {

    /**
     * 条件によって、テーブル＜部門別経費＞＜部門マスタ＞＜勘定科目マスタ＞＜部門表示順マスタ＞の情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0803Input> findAllByFiscalYearMonth(MDB0803Input input);

    /**
     * 条件によって、テーブル＜部門別経費マスタ＞の情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0803Output> findAllByKind();

    /**
     * 条件によって、テーブル＜部門表示順マスタ＞の情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0803Output> findAllByFiscalYear(MDB0803Input input);

    /**
     * テーブル＜部門経費管理＞に削除する。
     *
     * @return
     */
    void delete();

    /**
     * テーブル＜部門経費管理＞に登録する。
     *
     * @param output MDB0803Output
     * @return
     */
    void create(MDB0803Output output);
}