package jp.co.aeroasahi.tpkt.batch.fwb0104;

/**
 * テーブル＜【TEMP】SAPプロジェクト＞に操作
 */
public interface FWB0104Repository {

    /**
     * テーブル＜【TEMP】SAPプロジェクト＞に登録する。
     *
     * @param output FWB0104Output
     * @return
     */
    void create(FWB0104Output output);

    /**
     * テーブル＜【TEMP】SAPプロジェクト＞に削除する。
     *
     * @param output FWB0104Output
     * @return
     */
    void delete(FWB0104Output output);
}
