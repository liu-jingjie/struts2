package jp.co.aeroasahi.tpkt.batch.mdb0003.job4;

import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.batch.fw.CommonLog;
import jp.co.aeroasahi.tpkt.batch.mdb0003.MDB0003DataCopyRepository;

/**
 * 表示用テーブルのtempの内容を本体へ反映させるTasklet
 */
@Component
@Scope("step")
public class MDB0003Tasklet153 implements Tasklet {

    private static final Logger logger = LoggerFactory.getLogger(MDB0003Tasklet153.class);

    // 日次処理の場合は「D」、月次確定処理の場合は「M」
    @Value("#{jobParameters['shorikbn']}")
    public String shorikbn;

    // 処理年月：日次処理の場合は空白を設定、バッチ実行画面の指定した月次確定対象年月を「YYYYMM」形式
    @Value("#{jobParameters['ym']}")
    public String ym;

    @Inject
    MDB0003DataCopyRepository mainDataCopyRepository;

    /**
     *
     * 表示用テーブルのtempの内容を本体へ反映させる
     *
     * @param contribution StepContribution
     * @param chunkContext ChunkContext
     *
     * @return ステータス
     */
    @Override
    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

        try {
            logger.info("tempテーブルから本体テーブルへの書き込みを実施します。");

            // テーブル＜物件管理＞に登録する。
            mainDataCopyRepository.dataCopy("temp_md_disp_property", "md_disp_property");
            // テーブル＜外注管理＞に登録する。
            mainDataCopyRepository.dataCopy4("temp_md_disp_outsourcing", "md_disp_outsourcing");
            // テーブル＜部門経費管理＞に登録する。
            mainDataCopyRepository.dataCopy("temp_md_disp_dept_cost", "md_disp_dept_cost");
            // テーブル＜操業度管理＞に登録する。
            mainDataCopyRepository.dataCopy("temp_md_disp_operation", "md_disp_operation");

            logger.info("tempテーブルから本体テーブルへの書き込みが完了しました。");

        } catch (Exception e) {
            CommonLog.setBatchErrorLog(logger, "tempテーブルから、本体テーブルに更新");
            throw new RuntimeException(e);
        }

        return RepeatStatus.FINISHED;
    }

}
