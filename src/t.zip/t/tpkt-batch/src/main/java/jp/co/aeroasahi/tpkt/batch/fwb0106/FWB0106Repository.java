package jp.co.aeroasahi.tpkt.batch.fwb0106;

/**
 * テーブル＜【TEMP】SAP勘定残高＞に操作
 */
public interface FWB0106Repository {

    /**
     * テーブル＜【TEMP】SAP勘定残高＞に登録する。
     *
     * @param output FWB0106Output
     * @return
     */
    void create(FWB0106Output output);

    /**
     * テーブル＜【TEMP】SAP勘定残高＞に更新する。
     *
     * @param output FWB0106Output
     * @return
     */
    void delete(FWB0106Output output);
}
