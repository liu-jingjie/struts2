package jp.co.aeroasahi.tpkt.batch.mdb0501;

import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 * テーブル＜【TEMP】金額＞＜【TEMP】工数金額＞に操作
 */
public interface MDB0501Repository {

    /**
     * 条件によって、テーブル＜SAP勘定残高＞の件数情報を取得する。
     *
     * @param input MDB0501Input
     * @return 件数情報
     */
    int findCountBySAPAccountBalance(@Param("GJAHR") String GJAHR, @Param("MONAT") String MONAT);

    /**
     * (当月のみのデータを抽出し)条件によって、テーブル＜【TEMP】工数金額＞の情報を取得する。
     *
     * @param input MDB0501Input
     * @return データ情報
     */
    List<MDB0501Input> findAllCurrentMonthOnly(MDB0501Input input);

    /**
     * 条件によって、テーブル＜【TEMP】工数金額＞の情報を取得する。
     *
     * @param input MDB0501Input
     * @return データ情報
     */
    List<MDB0501Input> findAll(MDB0501Input input);

    /**
     * 条件によって、テーブル＜【TEMP】金額＞の情報を取得する。
     *
     * @return データ情報
     */
    List<MDB0501Output> findAllByKey();

    /**
     * テーブル＜【TEMP】金額＞に更新する。
     *
     * @param output List<MDB0501Output>
     * @return
     */
    void update(MDB0501Output output);

    /**
     * テーブル＜【TEMP】金額＞に登録する。
     *
     * @param output List<MDB0501Output>
     * @return
     */
    void create(MDB0501Output output);

    /**
     * テーブル＜【TEMP】金額＞に(実績データ)削除する。
     *
     * @param input MDB0501Input
     * @return
     */
    void deletePerformance(MDB0501Input input);

    /**
     * テーブル＜【TEMP】金額＞に(積算データ)削除する。
     *
     * @param input MDB0501Input
     * @return
     */
    void deleteIntegration(MDB0501Input input);

    /**
     * テーブル＜【TEMP】金額＞に(初回積算)削除する。
     *
     * @param input MDB0501Input
     * @return
     */
    void deleteInitialIntegration(MDB0501Input input);
}