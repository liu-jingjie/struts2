package jp.co.aeroasahi.tpkt.common.kn.check;

import jp.co.aeroasahi.tpkt.common.model.kn.KosuData;

/**
 * 工程CDが利用可能であるか判定するCheck.
 */
public class KoteiStatusCheck implements FlgCheck {


    /**
     * 工程ステータスチェックのコンストラクタ
     *
     * @param koteiCdList 利用不可な工程CDのリスト
     */
    public KoteiStatusCheck() {
    }

    /**
     * 対象の工程CDが利用不可であればtrueを返却する
     *
     * @param kosuData 工数データ
     * @return true:対象の工程CDが利用不可である場合
     */
    @Override
    public boolean matches(KosuData kosuData) {

        // 本システムでは工程マスタのステータス列が削除されたため、チェックする必要がなくなった。
        return false;
    }


}
