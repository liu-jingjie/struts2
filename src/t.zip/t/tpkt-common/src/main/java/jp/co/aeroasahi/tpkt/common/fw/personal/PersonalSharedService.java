package jp.co.aeroasahi.tpkt.common.fw.personal;

import java.time.LocalDate;

public interface PersonalSharedService {

    /**
     *
     * @param empCd
     * @param date
     * @return
     */
    String findNameByEmpCd(String empCd, LocalDate date);

    /**
     *
     * @param empCd
     * @return
     */
    String findNameByEmpCd(String empCd);

}
