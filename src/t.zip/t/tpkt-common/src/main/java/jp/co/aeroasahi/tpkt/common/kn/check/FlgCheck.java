package jp.co.aeroasahi.tpkt.common.kn.check;

import jp.co.aeroasahi.tpkt.common.model.kn.KosuData;

/**
 * 工数詳細単位のチェック
 *
 * @see WholeCheck
 */
public interface FlgCheck {

    /**
     * 指定した工数詳細が条件に合致するときにtrueを返す。
     *
     * @param companyData 勤怠データ
     * @param kosu 工数詳細
     * @return 合致するときにtrue
     */
    boolean matches(KosuData kosuData);

}
