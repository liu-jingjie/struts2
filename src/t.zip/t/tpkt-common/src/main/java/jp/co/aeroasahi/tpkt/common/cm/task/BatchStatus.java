package jp.co.aeroasahi.tpkt.common.cm.task;

import java.util.Arrays;
import java.util.NoSuchElementException;

/**
 * タスクのステータス
 */
public enum BatchStatus {
    /** タスク登録前:1 */
    BEFORE_REGIST("1"),
    /** タスク登録成功:2 */
    SUCCESS_REGIST("2"),
    /** タスク登録失敗:3 */
    FAIL_REGIST("3"),
    /** タスク削除前:4 */
    BEFORE_DELETE("4"),
    /** タスク削除成功:5 */
    SUCCESS_DELETE("5"),
    /** タスク削除失敗;6 */
    FAIL_DELETE("6");

    /**
     * 符号をあらわすコード
     */
    private String code;

    /**
     *
     * @param code
     */
    private BatchStatus(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    /**
     * コードを指定してStatusを取得する。
     * 指定したコードのStatusがない場合は実行時エラー
     *
     * @param code コード
     * @return Status タスクのステータス
     * @throws NoSuchElementException 該当するSignがない場合。
     */
    public static BatchStatus fromCode(String code) {
        return Arrays.stream(values()).filter(sign -> sign.code.equals(code)).findAny().get();
    }
}
