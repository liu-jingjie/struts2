package jp.co.aeroasahi.tpkt.common.kn.check;

import java.util.Arrays;
import java.util.NoSuchElementException;

/**
 * チェックに使用する符号。
 * チェックの種類により、使用できる符号が異なる。
 */
public enum Sign {
    /** > */
    GREATER("1"),
    /** < */
    LESS("2"),
    /** >= */
    GREATER_OR_EQUAL("3"),
    /** <= */
    LESS_OR_EQUAL("4"),
    /** <> */
    NOT_EQUAL("5"),
    /** = */
    EQUAL("6"),
    /** <<>> */
    NOT_EQUAL2("7"),
    /** >+ */
    GREATER_PLUS("8"),
    /** <+ */
    LESS_PLUS("9"),
    /** >=+ */
    GREATER_OR_EQUAL_PLUS("10"),
    /** <= */
    LESS_OR_EQUAL_PLUS("11"),
    /** <>+ */
    NOT_EQUAL_PLUS("12"),
    /** =+ */
    EQUAL_PLUS("13");

    /**
     * 符号をあらわすコード
     */
    private String code;

    /**
     *
     * @param code
     */
    private Sign(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    /**
     * コードを指定してSignを取得する。
     * 指定したコードのSignがない場合は実行時エラー
     *
     * @param code コード
     * @return Sign
     * @throws NoSuchElementException 該当するSignがない場合。
     */
    public static Sign fromCode(String code) {
        return Arrays.stream(values()).filter(sign -> sign.code.equals(code)).findAny().get();
    }
}
