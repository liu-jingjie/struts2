package jp.co.aeroasahi.tpkt.common.kn.check;

import java.util.List;
import jp.co.aeroasahi.tpkt.common.model.fw.Personal;
import jp.co.aeroasahi.tpkt.common.model.kn.CompanyData;
import jp.co.aeroasahi.tpkt.common.model.kn.KosuData;

/**
 * 社員CDチェック
 */
public class EmpCdCheck implements WholeCheck {

    /** 社員CD */
    private String empCd;

    /**
     * 社員CDを指定して、チェックを実施する
     *
     * @param calendarType カレンダー種別
     */
    public EmpCdCheck(String empCd) {
        this.empCd = empCd;
    }

    /**
     * 社員CDチェック
     * <p>
     * 社員CDが一致するか判定する
     * </p>
     *
     * @param emp 社員情報
     * @param companyData 勤怠情報
     * @param kosuData 工数データリスト
     * @return true:一致、false:不一致
     */
    @Override
    public boolean matches(Personal emp, CompanyData companyData, List<KosuData> kosuData) {
        return empCd.equals(emp.getEmpCd());
        // 現行踏襲でよいとのことなので、現行通り*を用いた正規表現チェックは実装しない
    }

}
