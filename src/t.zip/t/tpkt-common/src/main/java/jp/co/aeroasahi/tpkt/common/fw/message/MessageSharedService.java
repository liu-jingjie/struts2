package jp.co.aeroasahi.tpkt.common.fw.message;

public interface MessageSharedService {

    /**
     * fs_cm_062
     * コードと引数に紐づくメッセージ文字列を取得する
     *
     * @param code コード
     * @param args 引数
     * @return メッセージ文字列
     */
    String getMessage(String code, Object... args);

}
