package jp.co.aeroasahi.tpkt.common.fw.template;

/**
 * テンプレートをもとにテキストを生成するサービス。
 * 主にメール本文の生成用。
 */
public interface TemplateService {

    /**
     * テキストを生成する。
     * 
     * @param templateId テンプレートID
     * @param param パラメータ
     * @return テキスト
     */
    String create(String templateId, Object param);
}
