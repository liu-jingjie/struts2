package jp.co.aeroasahi.tpkt.common.kn.check;

import java.math.BigDecimal;
import java.util.List;
import jp.co.aeroasahi.tpkt.common.model.fw.Personal;
import jp.co.aeroasahi.tpkt.common.model.kn.CompanyData;
import jp.co.aeroasahi.tpkt.common.model.kn.KosuData;

/**
 * 休暇工数チェック
 */
public class KosuOffTimeCheck implements WholeCheck {

    /** 工数チェックマスタの工数休暇工数 */
    private BigDecimal offTime;

    /** 比較演算子 */
    private Sign sign;

    /**
     * 比較演算子を指定して工数の休暇工数をチェックする
     *
     * @param offTime 工数チェックマスタの工数休暇工数
     * @param sign 比較演算子
     */
    public KosuOffTimeCheck(BigDecimal offTime, Sign sign) {
        this.offTime = offTime;
        this.sign = sign;
    }

    /**
     * 工数データの休暇工数チェック
     *
     * @param emp 社員情報
     * @param companyData 勤怠情報
     * @param kosuData 工数データリスト
     * @return true:チェックマスタの休暇稼働と比較演算子と、工数データの休暇工数を比較した結果がtrueだった場合
     */
    @Override
    public boolean matches(Personal emp, CompanyData companyData, List<KosuData> kosuData) {
        // 休暇工数の合計値
        BigDecimal total = calcTotalKosu(kosuData);

        switch (sign) {
            case GREATER:
                if (kosuData.size() == 0) {
                    return false;
                }
                return offTime.compareTo(total) > 0;
            case LESS:
                if (kosuData.size() == 0) {
                    return false;
                }
                return offTime.compareTo(total) < 0;
            case GREATER_OR_EQUAL:
                if (kosuData.size() == 0) {
                    return false;
                }
                return offTime.compareTo(total) >= 0;
            case LESS_OR_EQUAL:
                if (kosuData.size() == 0) {
                    return false;
                }
                return offTime.compareTo(total) <= 0;
            case NOT_EQUAL:
                if (offTime == null) {
                    return kosuData.size() > 0 ? true : false;
                } else {
                    if (kosuData.size() == 0) {
                        return false;
                    }
                    return offTime.compareTo(total) != 0;
                }
            case EQUAL:
                if (offTime == null) {
                    return kosuData.size() == 0 ? true : false;
                } else {
                    if (kosuData.size() == 0) {
                        return false;
                    }
                }
                return offTime.compareTo(total) == 0;
            default:
                throw new IllegalArgumentException("記号：" + sign + "はサポートされていません。");
        }
    }

    private BigDecimal calcTotalKosu(List<KosuData> kosuData) {
        // 休暇工数の合計値
        return kosuData.stream()
                .filter(kosu -> kosu.getKoteiCd().equals("ZCZ10"))
                .map(KosuData::getKosu)
                .reduce(BigDecimal.ZERO, (prev, current) -> prev.add(current));
    }
}
