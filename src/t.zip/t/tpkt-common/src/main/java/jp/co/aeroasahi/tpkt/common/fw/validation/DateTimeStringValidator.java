package jp.co.aeroasahi.tpkt.common.fw.validation;

import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.springframework.util.StringUtils;

/**
 * 日付形式の文字列であることをチェックするためのValidator
 */
public class DateTimeStringValidator implements ConstraintValidator<DateTimeString, String> {

    @Override
    public void initialize(DateTimeString constraintAnnotation) {
        // nothing to do
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (!StringUtils.hasLength(value)) {
            return true;
        }
        try {
            LocalDateTime.parse(value);
            return true;
        } catch (DateTimeParseException e) {
            return false;
        }
    }
}
