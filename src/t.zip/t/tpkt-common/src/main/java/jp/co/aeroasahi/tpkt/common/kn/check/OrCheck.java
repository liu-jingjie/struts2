package jp.co.aeroasahi.tpkt.common.kn.check;

import jp.co.aeroasahi.tpkt.common.model.fw.Personal;
import jp.co.aeroasahi.tpkt.common.model.kn.KosuData;

/**
 * 2つのチェックのうち、いずれかが満たされていることを確認するチェック。
 *
 * 現行システムで、工程CDがZまたはWで始まるときにエラーとするチェックがあり、それに対応する目的のもの。<br>
 * (チェックを2つに分ければよいのではないかと思うが、現行踏襲しておく。)
 */
public class OrCheck implements RowCheck {

    /**
     * チェック1
     */
    private RowCheck firstCheck;

    /**
     * チェック2
     */
    private RowCheck secondCheck;

    public OrCheck(RowCheck firstCheck, RowCheck secondCheck) {
        this.firstCheck = firstCheck;
        this.secondCheck = secondCheck;
    }

    /**
     * 指定した工数詳細情報がいずれかのチェックに合致するか判定する。
     */
    @Override
    public boolean matches(Personal personal, KosuData kosu) {
        return firstCheck.matches(personal, kosu) || secondCheck.matches(personal, kosu);
    }

}
