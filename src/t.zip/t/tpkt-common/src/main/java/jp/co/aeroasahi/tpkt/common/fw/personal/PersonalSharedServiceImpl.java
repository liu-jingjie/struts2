package jp.co.aeroasahi.tpkt.common.fw.personal;

import java.time.LocalDate;
import javax.inject.Inject;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;
import jp.co.aeroasahi.tpkt.common.model.fw.Personal;
import jp.co.aeroasahi.tpkt.common.repository.fw.PersonalRepository;

@Service
@Transactional
public class PersonalSharedServiceImpl implements PersonalSharedService {

    @Inject
    PersonalRepository personalRepository;

    @Inject
    DateFactory dateFactory;

    @Override
    public String findNameByEmpCd(String employeeCd, LocalDate date) {
        Personal personal = personalRepository.findOneByCd(employeeCd, date);
        if (personal == null) {
            return null;
        }
        return personal.getEmpName();
    }

    @Override
    public String findNameByEmpCd(String empCd) {
        return personalRepository.findLatestNameByCd(empCd, dateFactory.newDate());
    }

}
