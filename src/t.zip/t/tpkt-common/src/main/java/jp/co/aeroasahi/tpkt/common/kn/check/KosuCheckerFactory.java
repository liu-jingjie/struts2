package jp.co.aeroasahi.tpkt.common.kn.check;

import java.util.ArrayList;
import java.util.List;
import jp.co.aeroasahi.tpkt.common.model.fw.PublicHoliday;
import jp.co.aeroasahi.tpkt.common.model.kn.KosuCheck;
import jp.co.aeroasahi.tpkt.common.util.CommonUtils;

/**
 * KosuCheckerのfactory
 */
public class KosuCheckerFactory {

    /**
     * マスタを元に工数チェッカーを作成する。
     *
     * @param kosuCheck 工数チェック情報
     * @param publicHolidays 休日リスト
     * @param openPjIdList オープンプロジェクトリスト
     * @param koteiCdList 工程CDリスト
     * @param unusableKoteiCdList 利用不可工程CDリスト
     * @return KosuChecker 工数チェッカ―
     */
    public static KosuChecker create(KosuCheck kosuCheck, List<PublicHoliday> publicHolidays, List<String> openPjIdList,
            List<String> koteiCdList) {

        KosuChecker kosuChecker = new KosuChecker();

        // 工数データテーブルのレコード単位ではない判定を行うためのチェック処理をリストに追加する
        kosuChecker.setWholeChecks(createWholeCheck(kosuCheck));

        // 工数データテーブルのレコード単位かつ、DBから取得したものと比較するチェック処理をリストに追加する
        kosuChecker.setFlgChecks(createFlgCheck(kosuCheck, openPjIdList, koteiCdList));

        // 上記以外のチェック処理をリストに追加する
        kosuChecker.setRowChecks(createRowCheck(kosuCheck, publicHolidays));

        kosuChecker.setCheckNo(kosuCheck.getCheckNo());

        // 処理制御
        kosuChecker.setChkFlg(kosuCheck.getChkFlg());
        kosuChecker.setFurikaeChkFlg(kosuCheck.getFurikaeChkFlg());

        // 登録押下時の画面表示用
        kosuChecker.setErrorDisp(kosuCheck.getErrorDisp());
        kosuChecker.setErrorExp(kosuCheck.getErrorExp());

        // バッチの実行結果登録用
        kosuChecker.setRegisterChkFlg(kosuCheck.getRegisterChkFlg());
        kosuChecker.setNightChkFlg(kosuCheck.getNightChkFlg());
        kosuChecker.setManualChkFlg(kosuCheck.getManualChkFlg());

        return kosuChecker;
    }

    public static KosuChecker createProjectCheck(KosuCheck kosuCheck) {
        KosuChecker kosuChecker = new KosuChecker();

        kosuChecker.setCheckNo(kosuCheck.getCheckNo());

        // バッチの実行結果登録用
        kosuChecker.setChkFlg(kosuCheck.getChkFlg());
        kosuChecker.setRegisterChkFlg(kosuCheck.getRegisterChkFlg());
        kosuChecker.setNightChkFlg(kosuCheck.getNightChkFlg());
        kosuChecker.setManualChkFlg(kosuCheck.getManualChkFlg());

        return kosuChecker;
    }


    private static List<WholeCheck> createWholeCheck(KosuCheck kosuCheck) {
        List<WholeCheck> wholeChecks = new ArrayList<>();

        // 社員CDチェック
        if (kosuCheck.getEmpCd() != null) {
            wholeChecks.add(new EmpCdCheck(kosuCheck.getEmpCd()));
        }
        // 社員区分チェック
        if (kosuCheck.getEmpKbn() != null) {
            wholeChecks.add(new EmpKbnCheck(kosuCheck.getEmpKbn()));
        }
        // 部門CDチェック
        if (kosuCheck.getDeptCd() != null) {
            wholeChecks.add(new DeptCheck(kosuCheck.getDeptCd()));
        }
        // 勤務種別チェック
        if (kosuCheck.getKinmuKbn() != null) {
            wholeChecks.add(new KinmuKbnCheck(kosuCheck.getKinmuKbn()));
        }
        // 勤怠CDチェック
        if (kosuCheck.getKintaiCd() != null) {
            wholeChecks.add(new KintaiCdCheck(kosuCheck.getKintaiCd()));
        }

        // 始業時間チェック
        if (kosuCheck.getOpeningTimeSign() != null) {
            wholeChecks.add(new KintaiOpeningTimeCheck(CommonUtils.getTime(kosuCheck.getOpeningTime()),
                    Sign.fromCode(kosuCheck.getOpeningTimeSign())));
        }
        // 終業時間チェック
        if (kosuCheck.getEndingTimeSign() != null) {
            wholeChecks.add(new KintaiEndingTimeCheck(CommonUtils.getTime(kosuCheck.getEndingTime()),
                    Sign.fromCode(kosuCheck.getEndingTimeSign())));
        }
        // 休憩時間チェック
        if (kosuCheck.getOffTimeSign() != null) {
            wholeChecks
                    .add(new KintaiOffTimeCheck(kosuCheck.getOffTime(), Sign.fromCode(kosuCheck.getOffTimeSign())));
        }
        // 勤怠稼働時間チェック
        if (kosuCheck.getInputTimeSign() != null) {
            wholeChecks.add(
                    new KintaiInputTimeCheck(kosuCheck.getInputTime(), Sign.fromCode(kosuCheck.getInputTimeSign())));
        }

        // 工数チェック
        if (kosuCheck.getKosuTimeSign() != null) {
            wholeChecks.add(new KosuTimeCheck(kosuCheck.getKosuTime(), Sign.fromCode(kosuCheck.getKosuTimeSign())));
        }
        // 休暇工数チェック
        if (kosuCheck.getKosuOffTimeSign() != null) {
            wholeChecks.add(
                    new KosuOffTimeCheck(kosuCheck.getKosuOffTime(), Sign.fromCode(kosuCheck.getKosuOffTimeSign())));
        }

        return wholeChecks;
    }

    private static List<FlgCheck> createFlgCheck(KosuCheck kosuCheck, List<String> openPjIdList,
            List<String> koteiCdList) {
        List<FlgCheck> flgChecks = new ArrayList<>();
        // プロジェクトステータスチェック
        if (kosuCheck.getPrjOpFlg() != null) {
            flgChecks.add(new PjStatusCheck(openPjIdList));
        }
        // 工程存在チェック
        if (kosuCheck.getKoteiDelFlg() != null) {
            flgChecks.add(new KoteiDelCheck(koteiCdList));
        }
        // 工程ステータスチェック(本システムでは工程マスタからステータス列が削除されたため、無意味なチェック)
        if (kosuCheck.getKoteiUseFlg() != null) {
            flgChecks.add(new KoteiStatusCheck());
        }

        return flgChecks;
    }


    private static List<RowCheck> createRowCheck(KosuCheck kosuCheck, List<PublicHoliday> publicHolidays) {
        List<RowCheck> rowChecks = new ArrayList<>();

        // カレンダー種別、祝日チェック
        if (kosuCheck.getCalendarType() != null) {
            rowChecks.add(new CalendarTypeCheck(kosuCheck.getCalendarType(), publicHolidays));
        }
        // PJIDチェック
        if (kosuCheck.getPjid() != null) {
            rowChecks.add(new PjIdCheck(kosuCheck.getPjid(), Sign.fromCode(kosuCheck.getPjidSign())));
        }
        // 工程チェック
        if (kosuCheck.getKotei1() != null) {
            RowCheck check1 = new KoteiCdCheck(kosuCheck.getKotei1(), Sign.fromCode(kosuCheck.getKoteiSign1()));
            if (kosuCheck.getKotei2() == null) {
                rowChecks.add(check1);
            } else {
                RowCheck check2 = new KoteiCdCheck(kosuCheck.getKotei2(), Sign.fromCode(kosuCheck.getKoteiSign2()));
                rowChecks.add(new OrCheck(check1, check2));
            }
        }
        return rowChecks;
    }


}
