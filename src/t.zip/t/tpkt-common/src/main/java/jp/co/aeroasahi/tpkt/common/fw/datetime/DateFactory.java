package jp.co.aeroasahi.tpkt.common.fw.datetime;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Date;
import javax.inject.Inject;
import org.terasoluna.gfw.common.date.jodatime.JodaTimeDateFactory;

/**
 * Date and Time APIのLocalDateTimeなどを返す。DateFactory。
 * TerasolunaのJodaTimeDateFactoryのラップ。
 */
public class DateFactory {

    /** jodaTimeDateFactory */
    @Inject
    JodaTimeDateFactory jodaTimeDateFactory;

    /**
     * fs_cm_002
     * システム日時を返却する。
     *
     * @return システム日時
     */
    public LocalDateTime newDateTime() {
        Date date = jodaTimeDateFactory.newDate();
        return LocalDateTime.ofInstant(Instant.ofEpochMilli(date.getTime()), ZoneId.systemDefault());
    }

    /**
     * fs_cm_003
     * システム日付を返却する。
     *
     * @return システム日付
     */
    public LocalDate newDate() {
        return newDateTime().toLocalDate();
    }

    /**
     * fs_cm_004
     * システム時間を返却する。
     *
     * @return システム時間
     */
    public LocalTime newTime() {
        return newDateTime().toLocalTime();
    }
}
