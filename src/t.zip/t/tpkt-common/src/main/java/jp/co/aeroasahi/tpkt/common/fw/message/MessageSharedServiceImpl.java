package jp.co.aeroasahi.tpkt.common.fw.message;

import java.util.Locale;
import javax.inject.Inject;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

@Service
public class MessageSharedServiceImpl implements MessageSharedService {

    @Inject
    MessageSource messageSource;

    @Override
    public String getMessage(String code, Object... args) {

        return messageSource.getMessage(code, args, Locale.getDefault());
    }

}
