package jp.co.aeroasahi.tpkt.common.kn.check;

import java.util.List;
import javax.inject.Inject;
import org.springframework.context.MessageSource;
import jp.co.aeroasahi.tpkt.common.model.fw.Personal;
import jp.co.aeroasahi.tpkt.common.model.kn.CompanyData;
import jp.co.aeroasahi.tpkt.common.model.kn.KosuData;

/**
 * 勤怠CDチェック
 */
public class KintaiCdCheck implements WholeCheck {

    /** 勤怠CD */
    private String kintaiCd;

    /** メッセージ */
    @Inject
    MessageSource messageSource;
    /**
     * 勤怠CDのチェックを行う。
     *
     * @param kintaiCd 勤怠CD
     */
    public KintaiCdCheck(String kintaiCd) {
        this.kintaiCd = kintaiCd;
    }

    /**
     * 勤怠CDチェック
     * <p>
     * 勤怠CDがマスタ値と合致するか判定する。
     * </p>
     *
     * @param emp 社員情報
     * @param companyData 勤怠情報
     * @param kosuData 工数データリスト
     * @return true:チェックマスタの勤怠CDと勤怠情報の勤怠CDが一致した場合
     */
    @Override
    public boolean matches(Personal emp, CompanyData companyData, List<KosuData> kosuData) {
        // 勤怠CDがnullの場合はチェックをしない (マスタがnullの場合はこの処理が呼ばれることはないため、考慮不要)
        if (companyData.getKintaiCd() == null) {
            return false;
        }
        return companyData.getKintaiCd().equals(kintaiCd);
    }

}
