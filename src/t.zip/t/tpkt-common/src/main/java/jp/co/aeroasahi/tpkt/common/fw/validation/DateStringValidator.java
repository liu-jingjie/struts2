package jp.co.aeroasahi.tpkt.common.fw.validation;

import java.time.format.DateTimeParseException;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.springframework.util.StringUtils;
import jp.co.aeroasahi.tpkt.common.util.DateUtil;

/**
 * 日付形式の文字列であることをチェックするためのValidator
 */
public class DateStringValidator implements ConstraintValidator<DateString, String> {

    @Override
    public void initialize(DateString constraintAnnotation) {
        // nothing to do
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (!StringUtils.hasLength(value)) {
            return true;
        }
        try {
            DateUtil.parseDate(value);
            return true;
        } catch (DateTimeParseException e) {
            return false;
        }
    }
}
