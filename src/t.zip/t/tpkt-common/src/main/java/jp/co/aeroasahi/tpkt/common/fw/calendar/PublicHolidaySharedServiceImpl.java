package jp.co.aeroasahi.tpkt.common.fw.calendar;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;
import javax.inject.Inject;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import jp.co.aeroasahi.tpkt.common.model.fw.PublicHoliday;
import jp.co.aeroasahi.tpkt.common.repository.fw.PublicHolidayRepository;

@Service
@Transactional
public class PublicHolidaySharedServiceImpl implements PublicHolidaySharedService {

    @Inject
    PublicHolidayRepository publicHolidayRepository;

    @Override
    public List<LocalDate> findOffDays(String calendarType) {
        return publicHolidayRepository.findAllByType(calendarType).stream().map(PublicHoliday::getPublicHoliday)
                .collect(Collectors.toList());
    }
}
