package jp.co.aeroasahi.tpkt.common.kn.check;

import jp.co.aeroasahi.tpkt.common.model.fw.Personal;
import jp.co.aeroasahi.tpkt.common.model.kn.KosuData;

/**
 * プロジェクトIDが指定した条件に合致するか判定するCheck.
 */
public class PjIdCheck implements RowCheck {

    /** プロジェクトIDのパターン */
    private String pattern;

    /** 符号 */
    private Sign sign;

    public PjIdCheck(String pattern, Sign sign) {
        this.pattern = pattern.replaceAll("\\*", ".");
        this.sign = sign;
    }

    /**
     * プロジェクトIDが指定した条件に合致するか判定する。
     * <p>
     * 不等号による数値比較が必要な場合、現行と同じ判定をする(以下の要件が実装されていること)<br>
     * ・数値比較の対象は末尾二桁のみである。<br>
     * ・ワイルドカードが入るのは先頭～末尾2桁以外であり、末尾二桁はワイルドカードが入らない<br>
     * ・マスタの末尾二桁の文字列の数値以外の場合、0として扱う(マスタの設定ミスを想定している？)<br>
     * </p>
     */
    @Override
    public boolean matches(Personal personal, KosuData kosu) {
        // PJIDがnull即ち、バッチの場合かつ工数入力がされていない場合はチェック不要
        if (kosu.getPjId() == null) {
            return false;
        }

        String projectId = kosu.getPjId();
        switch (sign) {
            case EQUAL:
                return projectId.matches(pattern);
            case NOT_EQUAL:
                return !projectId.matches(pattern);
            case GREATER:
                if (isPatternMatch(projectId)) {
                    String suffix = getSuffix();
                    return suffix.compareTo(projectId.substring(10)) > 0;
                }
                return false;
            case LESS:
                if (isPatternMatch(projectId)) {
                    String suffix = getSuffix();
                    return suffix.compareTo(projectId.substring(10)) < 0;
                }
                return false;
            case GREATER_OR_EQUAL:
                if (isPatternMatch(projectId)) {
                    String suffix = getSuffix();
                    return suffix.compareTo(projectId.substring(10)) >= 0;
                }
                return false;
            case LESS_OR_EQUAL:
                if (isPatternMatch(projectId)) {
                    String suffix = getSuffix();
                    return suffix.compareTo(projectId.substring(10)) <= 0;
                }
                return false;

            default:
                throw new IllegalArgumentException("sign is " + sign);
        }

    }

    private boolean isPatternMatch(String projectId) {
        if (pattern.length() == 12) {
            String prefix = pattern.substring(0, 10);
            if (projectId.matches(prefix + "..")) {
                return true;
            }
            return false;
        }
        // マスタ異常なため、チェック対象外
        return false;
    }

    private String getSuffix() {
        String returnStr = pattern.substring(10);
        if (returnStr.matches("\\d{2}")) {
            return returnStr;
        } else {
            // 1文字目が数値 -> 2文字目が異常なので、2文字目を0にして返却する
            if (returnStr.substring(0, 1).matches("\\d")) {
                return returnStr.substring(0, 1) + "0";
            } else {
                // 1文字目のみが異常なので、1文字目を0にして返却する
                if (returnStr.substring(1).matches("\\d")) {
                    return "0" + returnStr.substring(1);
                } else {
                    // 両方が異常なので、00を返却する
                    return "00";
                }
            }
        }
    }

}
