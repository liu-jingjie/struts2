package jp.co.aeroasahi.tpkt.common.kn.check;

import java.util.List;
import jp.co.aeroasahi.tpkt.common.model.fw.Personal;
import jp.co.aeroasahi.tpkt.common.model.kn.CompanyData;
import jp.co.aeroasahi.tpkt.common.model.kn.KosuData;

/**
 * 社員区分チェック
 */
public class EmpKbnCheck implements WholeCheck {

    /**
     * 社員区分
     */
    private String empKbn;

    /**
     * 社員区分を指定して、チェックを実施する
     *
     * @param empKbn
     */
    public EmpKbnCheck(String empKbn) {
        this.empKbn = empKbn;
    }

    /**
     * 社員区分チェック
     * <p>
     * 社員区分が一致した場合、trueを返却する
     * </p>
     *
     * @param emp 社員情報
     * @param companyData 勤怠情報
     * @param kosuData 工数データリスト
     * @return true:チェックマスタの社員区分と社員情報の社員区分が一致した場合
     */
    @Override
    public boolean matches(Personal emp, CompanyData companyData, List<KosuData> kosuData) {
        return empKbn.equals(emp.getEmpKbn());
    }

}
