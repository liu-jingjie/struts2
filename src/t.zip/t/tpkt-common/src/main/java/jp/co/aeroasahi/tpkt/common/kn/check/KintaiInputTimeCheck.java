package jp.co.aeroasahi.tpkt.common.kn.check;

import java.math.BigDecimal;
import java.util.List;
import jp.co.aeroasahi.tpkt.common.model.fw.Personal;
import jp.co.aeroasahi.tpkt.common.model.kn.CompanyData;
import jp.co.aeroasahi.tpkt.common.model.kn.KosuData;

/**
 * 勤怠稼働チェック
 */
public class KintaiInputTimeCheck implements WholeCheck {

    /** チェックマスタの勤怠稼動時間 */
    private BigDecimal inputTime;

    /** 比較演算子 */
    private Sign sign;

    /** 休暇工数の工程CD */
    private static final String OFF_TIME = "ZCZ10";

    /**
     * 比較演算子を指定して勤怠の稼働時間をチェックする
     *
     * @param inputTime 稼働時間
     * @param sign 比較演算子
     */
    public KintaiInputTimeCheck(BigDecimal inputTime, Sign sign) {
        this.inputTime = inputTime;
        this.sign = sign;
    }

    /**
     * 勤怠稼働チェック
     * <p>
     * チェックマスタの勤怠稼働時間と比較演算子を用いて、勤怠データの稼働時間をチェックする
     * </p>
     *
     * @param emp 社員情報
     * @param companyData 勤怠情報
     * @param kosuData 工数データリスト
     * @return true:チェックマスタの勤怠稼働時間と比較演算子と勤怠データの稼働時間を比較した結果がtrueだった場合
     */
    @Override
    public boolean matches(Personal emp, CompanyData companyData, List<KosuData> kosuData) {

        BigDecimal kintaiInputTime = companyData.getInputTime();
        // nullの場合は0として扱う
        BigDecimal ChikokuSoutaitime = companyData.getCikokuSoutaiTime();

        switch (sign) {
            case GREATER:
                if (kintaiInputTime == null) {
                    return false;
                }
                return inputTime.compareTo(kintaiInputTime) > 0;
            case LESS:
                if (kintaiInputTime == null) {
                    return false;
                }
                return inputTime.compareTo(kintaiInputTime) < 0;
            case GREATER_OR_EQUAL:
                if (kintaiInputTime == null) {
                    return false;
                }
                return inputTime.compareTo(kintaiInputTime) >= 0;
            case LESS_OR_EQUAL:
                if (kintaiInputTime == null) {
                    return false;
                }
                return inputTime.compareTo(kintaiInputTime) <= 0;

            case NOT_EQUAL:
                if (inputTime == null) {
                    return companyData.getInputTime() != null ? true : false;
                } else {
                    if (kintaiInputTime == null) {
                        return true;
                    }
                    return inputTime.compareTo(kintaiInputTime) != 0;
                }
            case EQUAL:
                if (inputTime == null) {
                    return companyData.getInputTime() == null ? true : false;
                } else {
                    if (kintaiInputTime == null) {
                        return false;
                    }
                    return inputTime.compareTo(kintaiInputTime) == 0;
                }
            case NOT_EQUAL2:
                if (kintaiInputTime == null) {
                    return kosuData.size() > 0 ? true : false;
                }

                // 休暇工数(工程CD ZCZ10)を除いた工数データの工数の合算値を取得する
                BigDecimal kosuTotal = kosuData.stream()
                        .filter(kosu -> !kosu.getKoteiCd().equals(OFF_TIME))
                        .map(KosuData::getKosu)
                        .reduce(BigDecimal.ZERO, (prev, current) -> prev.add(current));

                return kosuTotal.compareTo(kintaiInputTime) != 0;
            case GREATER_PLUS:
                if (kintaiInputTime == null || companyData.getCikokuSoutaiTime() == null) {
                    return false;
                }
                return inputTime.compareTo(kintaiInputTime.add(ChikokuSoutaitime)) > 0;
            case LESS_PLUS:
                if (kintaiInputTime == null || companyData.getCikokuSoutaiTime() == null) {
                    return false;
                }
                return inputTime.compareTo(kintaiInputTime.add(ChikokuSoutaitime)) < 0;
            case GREATER_OR_EQUAL_PLUS:
                if (kintaiInputTime == null || companyData.getCikokuSoutaiTime() == null) {
                    return false;
                }
                return inputTime.compareTo(kintaiInputTime.add(ChikokuSoutaitime)) >= 0;
            case LESS_OR_EQUAL_PLUS:
                if (kintaiInputTime == null || companyData.getCikokuSoutaiTime() == null) {
                    return false;
                }
                return inputTime.compareTo(kintaiInputTime.add(ChikokuSoutaitime)) <= 0;
            case NOT_EQUAL_PLUS:
                // マスタ値がnullの場合、勤怠入力と遅刻の両方がnullだった場合のみ一致しているとみなしてfalseを返却
                if (inputTime == null) {
                    return kintaiInputTime == null && companyData.getCikokuSoutaiTime() == null ? false : true;
                }

                if (kintaiInputTime == null || companyData.getCikokuSoutaiTime() == null) {
                    return true;
                }
                return inputTime.compareTo(kintaiInputTime.add(ChikokuSoutaitime)) != 0;
            case EQUAL_PLUS:
                // マスタ値がnullの場合、勤怠入力と遅刻の両方がnullだった場合のみ一致しているとみなしてfalseを返却
                if (inputTime == null) {
                    return kintaiInputTime == null && companyData.getCikokuSoutaiTime() == null ? true : false;
                }
                if (kintaiInputTime == null || companyData.getCikokuSoutaiTime() == null) {
                    return false;
                }
                return inputTime.compareTo(kintaiInputTime.add(ChikokuSoutaitime)) == 0;
            default:
                throw new IllegalArgumentException("記号：" + sign + "はサポートされていません。");
        }
    }
}
