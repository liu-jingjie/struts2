package jp.co.aeroasahi.tpkt.common.kn.check;

import java.math.BigDecimal;
import java.util.List;
import jp.co.aeroasahi.tpkt.common.model.fw.Personal;
import jp.co.aeroasahi.tpkt.common.model.kn.CompanyData;
import jp.co.aeroasahi.tpkt.common.model.kn.KosuData;
import jp.co.aeroasahi.tpkt.common.util.CommonUtils;

/**
 * 始業チェック
 */
public class KintaiOpeningTimeCheck implements WholeCheck {

    /** チェックマスタの始業 */
    private BigDecimal openingTime;

    /** 比較演算子 */
    private Sign sign;

    /**
     * 比較演算子を指定して勤怠の始業時間をチェックする
     *
     * @param openingTime 始業時間
     * @param sign 比較演算子
     */
    public KintaiOpeningTimeCheck(BigDecimal openingTime, Sign sign) {
        this.openingTime = openingTime == null ? BigDecimal.ZERO : openingTime;
        this.sign = sign;
    }

    /**
     * 始業チェック
     * <p>
     * チェックマスタの始業と時間と比較演算子を用いて、勤怠データの始業時間をチェックする
     * </p>
     *
     * @param emp 社員情報
     * @param companyData 勤怠情報
     * @param kosuData 工数データリスト
     * @return true:チェックマスタの終業と比較演算子と勤怠データの始業時間を比較した結果がtrueだった場合
     */
    @Override
    public boolean matches(Personal emp, CompanyData companyData, List<KosuData> kosuData) {
        /*
         * null -> 0
         * 変換不可 -> null
         * 変換可能 -> BigDecimal
         */
        BigDecimal kintaiOpeningTime = CommonUtils.timeStringToBigDecimal(companyData.getOpeningTime());

        // 数値変換できない値が入力されていた場合はtrueを返却する
        if (kintaiOpeningTime == null) {
            return true;
        }

        switch (sign) {
            case GREATER:
                return openingTime.compareTo(kintaiOpeningTime) > 0;
            case LESS:
                return openingTime.compareTo(kintaiOpeningTime) < 0;
            case GREATER_OR_EQUAL:
                return openingTime.compareTo(kintaiOpeningTime) >= 0;
            case LESS_OR_EQUAL:
                return openingTime.compareTo(kintaiOpeningTime) <= 0;
            case NOT_EQUAL:
                return openingTime.compareTo(kintaiOpeningTime) != 0;
            case EQUAL:
                return openingTime.compareTo(kintaiOpeningTime) == 0;
            default:
                throw new IllegalArgumentException("記号：" + sign + "はサポートされていません。");
        }
    }
}
