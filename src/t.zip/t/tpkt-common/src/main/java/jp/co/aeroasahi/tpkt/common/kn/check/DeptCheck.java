package jp.co.aeroasahi.tpkt.common.kn.check;

import java.util.List;
import jp.co.aeroasahi.tpkt.common.model.fw.Personal;
import jp.co.aeroasahi.tpkt.common.model.kn.CompanyData;
import jp.co.aeroasahi.tpkt.common.model.kn.KosuData;

/**
 * 部門チェック
 */
public class DeptCheck implements WholeCheck {

    /** 部門CDパターン */
    private String pattern;

    /**
     * 部門CDのパターンを指定して部門チェックを行う。
     *
     * @param pattern 部門CDのパターン("11***"など)
     */
    public DeptCheck(String pattern) {
        this.pattern = pattern.replaceAll("\\*", ".");
    }

    /**
     * 部門チェック
     * <p>
     * 社員の部門がパターンに合致するか判定する。
     * </p>
     *
     * @param 社員情報
     * @param companyData 勤怠情報
     * @param kosuData 工数データリスト
     * @return true:チェックマスタの部門CDのパターンと社員情報の部門CDが一致した場合
     */
    @Override
    public boolean matches(Personal emp, CompanyData companyData, List<KosuData> kosuData) {
        return emp.getDeptCd().matches(pattern);
    }

}
