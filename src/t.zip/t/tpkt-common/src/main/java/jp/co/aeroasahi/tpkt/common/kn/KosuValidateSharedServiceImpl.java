package jp.co.aeroasahi.tpkt.common.kn;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import jp.co.aeroasahi.tpkt.common.fw.datetime.DateFactory;
import jp.co.aeroasahi.tpkt.common.fw.project.ProjectId;
import jp.co.aeroasahi.tpkt.common.kn.check.CheckTargetPesonal;
import jp.co.aeroasahi.tpkt.common.kn.check.KosuChecker;
import jp.co.aeroasahi.tpkt.common.kn.check.KosuCheckerFactory;
import jp.co.aeroasahi.tpkt.common.kn.check.Sign;
import jp.co.aeroasahi.tpkt.common.model.fw.Personal;
import jp.co.aeroasahi.tpkt.common.model.fw.Project;
import jp.co.aeroasahi.tpkt.common.model.fw.PublicHoliday;
import jp.co.aeroasahi.tpkt.common.model.kn.CheckList;
import jp.co.aeroasahi.tpkt.common.model.kn.CompanyData;
import jp.co.aeroasahi.tpkt.common.model.kn.Exclusion;
import jp.co.aeroasahi.tpkt.common.model.kn.KosuCheck;
import jp.co.aeroasahi.tpkt.common.model.kn.KosuData;
import jp.co.aeroasahi.tpkt.common.model.kn.OpenPjInfo;
import jp.co.aeroasahi.tpkt.common.model.kn.TransferData;
import jp.co.aeroasahi.tpkt.common.repository.fw.CommonProjectRepository;
import jp.co.aeroasahi.tpkt.common.repository.fw.DeptRepository;
import jp.co.aeroasahi.tpkt.common.repository.fw.KoteiRepository;
import jp.co.aeroasahi.tpkt.common.repository.fw.OPjKoteiRepository;
import jp.co.aeroasahi.tpkt.common.repository.fw.PublicHolidayRepository;
import jp.co.aeroasahi.tpkt.common.repository.fw.SalesKoteiRepository;
import jp.co.aeroasahi.tpkt.common.repository.kn.CheckListRepository;
import jp.co.aeroasahi.tpkt.common.repository.kn.CommonOpenPjInfoRepository;
import jp.co.aeroasahi.tpkt.common.repository.kn.CompanyDataRepository;
import jp.co.aeroasahi.tpkt.common.repository.kn.ExclusionRepository;
import jp.co.aeroasahi.tpkt.common.repository.kn.KosuCheckRepository;
import jp.co.aeroasahi.tpkt.common.repository.kn.KosuDataRepository;
import jp.co.aeroasahi.tpkt.common.repository.kn.TransferDataRepository;
import jp.co.aeroasahi.tpkt.common.repository.sb.DataRepository;
import jp.co.aeroasahi.tpkt.common.util.CommonUtils;
import jp.co.aeroasahi.tpkt.common.util.DateUtil;

@Service
public class KosuValidateSharedServiceImpl implements KosuValidateSharedService {

    private static final Logger logger = LoggerFactory.getLogger(KosuValidateSharedServiceImpl.class);
    /** 休暇工数の工程CD */
    private static final String OFF_TIME = "ZCZ10";
    /** フラグON */
    private static final String FLAG_ON = "1";
    /** フラグOFF */
    private static final String FLAG_OFF = "0";

    /** プロジェクトチェックのCheckNo */
    private static final int PJ_CHECK_NO = 1000;
    /** 工程チェックのCheckNo */
    private static final int KOTEI_CHECK_NO = 1001;

    /** 祝日 */
    @Inject
    PublicHolidayRepository publicHolidayRepository;
    /** 工数チェックマスタ */
    @Inject
    KosuCheckRepository kosuCheckRepository;
    /** プロジェクト */
    @Inject
    CommonProjectRepository projectRepository;
    /** 工程 */
    @Inject
    KoteiRepository koteiRepository;
    /** プロジェクト公開 */
    @Inject
    CommonOpenPjInfoRepository openPjInfoRepository;
    /** 勤怠データ */
    @Inject
    CompanyDataRepository companyDataRepository;
    /** 工数データ */
    @Inject
    KosuDataRepository kosuDataRepository;
    /** 部門 */
    @Inject
    DeptRepository deptRepository;
    /** 積算データ */
    @Inject
    DataRepository sekisanDataRepository;
    /** Oプロジェクト工程 */
    @Inject
    OPjKoteiRepository oPjKoteiRepository;
    /** 営業プロジェクト工程 */
    @Inject
    SalesKoteiRepository salesKoteiRepository;
    /** 工数除外 */
    @Inject
    ExclusionRepository exclusionRepository;
    /** 振替 */
    @Inject
    TransferDataRepository transferDataRepository;
    /** チェック一覧 */
    @Inject
    CheckListRepository checkListRepository;

    /** メッセージ */
    @Inject
    MessageSource messageSource;

    @Inject
    DateFactory dateFactory;

    private enum transactionKbn {
        /** 振替以外 */
        NORMAL("0"),
        /** 振替元 */
        BEFORE("1"),
        /** 振替先 */
        AFTER("2");
        private String value;

        private transactionKbn(String value) {
            this.value = value;
        }
    }

    @Override
    public List<ValidateError> executeRegisterCheck(Personal emp, LocalDate date, List<KosuData> kosuDataList,
            String loginEmpCd) {

        // 祝日のリストを取得する
        List<PublicHoliday> publicHolidayList = publicHolidayRepository.findByDateRange(date, date);

        // オープンなプロジェクトIDのリストを取得する
        List<String> openPjIdList = projectRepository.findAllOpenPjId();

        // チェックマスタから登録フラグが立っていて削除フラグが立っていないものを全て取得する
        List<KosuCheck> kosuCheckList = kosuCheckRepository.findAllRegisterCheck();

        // マスタの内容を検証し、問題があればシステム例外をスロー
        validateKosuCheckMaster(kosuCheckList);

        // 公開チェック用に会社CDを取得
        String corpCd = deptRepository.findOneCorpCdBydeptCdDate(emp.getDeptCd(), date);

        // 社員CD、日付と登録フラグが立っていることを条件にチェック一覧テーブルからデリート
        checkListRepository.deleteCheckListByCdAndDate(emp.getEmpCd(), date);

        List<KosuChecker> kosuCheckers = new ArrayList<>();
        for (KosuCheck check : kosuCheckList) {
            kosuCheckers
                    .add(KosuCheckerFactory.create(check, publicHolidayList, openPjIdList, null));
        }

        // 画面に表示するメッセージを格納するオブジェクト
        List<ValidateError> errors = new ArrayList<>();
        // 除外情報を登録するためのオブジェクト
        List<CheckList> exclusionList = new ArrayList<>();

        for (KosuData each : kosuDataList) {
            for (KosuChecker checker : kosuCheckers) {
                // チェックNoが1000の場合プロジェクトチェック
                if (checker.getCheckNo() == PJ_CHECK_NO) {
                    if (matchProject(each, emp, corpCd)) {
                        // 除外チェックをし、除外対象だった場合、リストにセットされる
                        checkExclusion(exclusionList, checker, emp, kosuDataList, each, loginEmpCd);
                        // チェックの全ての条件に合致するときにエラーとなる
                        ValidateError error = new ValidateError();
                        error.setErrorMessage(checker.getErrorExp());
                        errors.add(error);

                        continue;
                    }
                }
                // 登録押下時でのチェックNo1001の工程チェックは事前にチェックしているため、実装しない
                if (checker.getCheckNo() == KOTEI_CHECK_NO) {
                    continue;
                }

                // チェック処理が空の場合、次のチェックへ
                if (isNoChecker(checker)) {
                    continue;
                }

                // 作成したチェッカーを用いて工数チェック
                if (checker.match(emp, new CompanyData(), kosuDataList, each)) {
                    // チェックの全ての条件に合致するときにエラーとなる
                    if (checkExclusion(exclusionList, checker, emp, kosuDataList, each, loginEmpCd)) {
                        // 除外チェックをし、除外対象だった場合、リストにセットされる

                        // 社員CD日付に紐づく連番の最大値を取得(0件だった場合は0を取得)
                        int maxSerial = checkListRepository.findMaxSerialByCdAndDate(emp.getEmpCd(), date);
                        for (int i = 0; i < exclusionList.size(); i++) {
                            CheckList checkList = exclusionList.get(i);
                            // 取得した最大値とインクリメント変数を加算したものを連番にセット
                            checkList.setSerial(maxSerial + i + 1);
                            checkListRepository.createExclusionkList(checkList);
                        }
                    } else {

                        ValidateError error = new ValidateError();
                        error.setErrorMessage(checker.getErrorExp());
                        errors.add(error);
                    }
                }
            }
        }


        return errors;

    }

    @Override
    public List<CheckList> executeBatchCheck(List<CheckTargetPesonal> target, LocalDateTime sysDateTime,
            LocalDate startDate, LocalDate lastDate, boolean isManual) {

        LocalDate sysDate = sysDateTime.toLocalDate();

        // 勤怠情報を取得
        List<CompanyData> companyDataList = companyDataRepository.findAllByDateRange(startDate, lastDate);

        // 工数情報を取得
        List<KosuData> wholeKosuDataList = kosuDataRepository.findAllByDateRange(startDate, lastDate);

        // 祝日を取得する
        List<PublicHoliday> publicHolidayList = publicHolidayRepository.findByDateRange(startDate, lastDate);

        // オープンなプロジェクトIDのリストを取得する
        List<String> openPjIdList = projectRepository.findAllOpenPjId();

        // 削除されていない全ての工程CDを取得する
        List<String> koteiCdList = koteiRepository.findAllCd();

        // Oプロジェクト工程CDを全て取得(工程マスタは参照していないため、存在チェックやステータスチェックはしていない)
        List<String> oPjKoteiCdList = oPjKoteiRepository.findAll();
        // 営業工程CDを全て取得(工程マスタは参照していないため、存在チェックやステータスチェックはしていない)
        List<String> salesKoteiCdList = salesKoteiRepository.findAll();

        // 年月を指定して除外情報を取得する
        List<Exclusion> exclusionList =
                exclusionRepository.findAllByYm(DateUtil.getYearMonth(lastDate), isManual);

        // 年月を指定して振替情報を取得する
        List<TransferData> transferDataList =
                transferDataRepository.findAllByYearMonth(DateUtil.getYearMonth(lastDate), isManual);

        // チェックマスタから登録フラグが立っていて削除フラグが立っていないものを全て取得する
        List<KosuCheck> kosuCheckList = kosuCheckRepository.findAllBatchCheck(isManual);

        // マスタの内容を検証し、問題があればシステム例外をスロー
        validateKosuCheckMaster(kosuCheckList);

        List<CheckList> errors = new ArrayList<>();

        List<KosuChecker> checkerList = new ArrayList<>();

        logger.debug("チェックリスト作成開始");
        // マスタから取得した件数分ループ
        for (KosuCheck check : kosuCheckList) {
            // マスタを元に工数チェッカーを作成する
            KosuChecker checker = KosuCheckerFactory.create(check, publicHolidayList, openPjIdList, koteiCdList);

            checkerList.add(checker);
        }
        logger.debug("チェックリスト作成終了");

        logger.debug("工数チェック開始");
        // 社員CD、日付単位で工数チェックを行う
        for (CheckTargetPesonal checkTarget : target) {
            // 通番の初期値をセット
            int i = 1;

            Personal personal = getPersonal(checkTarget);
            // DBから取得した勤怠リストから社員CDと日付を条件にチェック対象の勤怠情報を取得(取得できなかった場合、空オブジェクトを生成)
            CompanyData companyData =
                    getCompanyCheckTarget(companyDataList, checkTarget.getEmpCd(), checkTarget.getDate());

            // DBから取得した工数情報からチェック対象の工数情報を取得
            List<KosuData> kosuDataList = getKosuData(wholeKosuDataList, checkTarget);


            /*
             * ■作成したチェッカー(チェックマスタ)に対してチェックを実施する
             * 〇工数データが存在しない場合
             * ・チェッカーを用いたチェック
             *
             * 〇工数データが存在する場合
             * ・プロジェクトチェック
             * ・工程チェック
             * ・チェッカーを用いたチェック
             */
            for (KosuChecker checker : checkerList) {

                // 工数入力されていない場合、工数データオブジェクトを生成してチェックを実施する
                if (kosuDataList.size() == 0) {
                    // チェック処理が空の場合(マスタ不整合対策)、あるいはチェックする必要が無い場合は次のチェックへ
                    if (isNoChecker(checker) || !needsCheck(checker.getChkFlg(), checkTarget.getDate(), sysDate)) {
                        continue;
                    }

                    if (checker.match(personal, companyData, kosuDataList, new KosuData())) {
                        // チェック対象の情報とマスタの情報、作成日、更新日をセットし、登録レコードを完成させる
                        errors.add(createCheckList(checkTarget, checker, exclusionList, companyData, null, sysDateTime,
                                i, transactionKbn.NORMAL));
                        i++;
                    }
                } else {
                    for (KosuData each : kosuDataList) {
                        // チェックNoが1000の場合はプロジェクトチェックを実施する
                        if (checker.getCheckNo() == PJ_CHECK_NO) {
                            // プロジェクトチェック
                            if (matchProject(each, personal, checkTarget.getCorpCd())) {
                                errors.add(createCheckList(checkTarget, checker, exclusionList, companyData, each,
                                        sysDateTime, i, transactionKbn.NORMAL));

                                i++;
                            }
                            continue;
                        }
                        // チェックNoが1001の場合は工程チェックを実施する
                        if (checker.getCheckNo() == KOTEI_CHECK_NO) {
                            // 工程チェック
                            if (matchKotei(each, oPjKoteiCdList, salesKoteiCdList)) {
                                errors.add(createCheckList(checkTarget, checker, exclusionList, companyData, each,
                                        sysDateTime, i, transactionKbn.NORMAL));
                                i++;
                            }
                            continue;
                        }

                        // チェック処理が空の場合(マスタ不整合対策)、あるいはチェックする必要が無い場合は次のチェックへ
                        if (!needsCheck(checker.getChkFlg(), checkTarget.getDate(), sysDate)) {
                            continue;
                        }

                        // チェック対象の情報とマスタの情報、作成日、更新日をセットし、登録レコードを完成させる
                        if (checker.match(personal, companyData, kosuDataList, each)) {

                            // 返却された情報に対してマスタの情報と作成日、更新日をセットし、登録レコードを完成させる
                            errors.add(createCheckList(checkTarget, checker, exclusionList, companyData, each,
                                    sysDateTime, i, transactionKbn.NORMAL));

                            i++;
                        }
                    }
                }
            }
        }

        logger.debug("工数チェック終了");

        logger.debug("振替チェック開始");
        // 振替工数データに対してチェックを行う
        for (TransferData transferData : transferDataList) {

            CheckTargetPesonal targetTransfer = getCheckTarget(transferData);
            Personal personal = getPersonal(targetTransfer);

            int i = 1;

            for (KosuChecker checker : checkerList) {

                // 振替フラグが立っているもののみチェックを実施する
                if (checker.getFurikaeChkFlg().equals(FLAG_ON)) {
                    // 数値関連のチェックは無い想定(日付が固定値のため、日付単位の合計値は出せない)
                    if (checker.match(personal, new CompanyData(), null, getKosuData(transferData))) {
                        // 除外チェックと登録レコードの追加
                        errors.add(createCheckList(targetTransfer, checker, exclusionList, null, null, sysDateTime,
                                i, transactionKbn.valueOf(transferData.getTransactionKbn())));
                    }
                }
            }
            i++;
        }
        logger.debug("振替チェック終了");
        return errors;

    }

    private void validateKosuCheckMaster(List<KosuCheck> kosuChecks) {

        for (KosuCheck each : kosuChecks) {
            // マスタの値がhh:mm形式であることをチェックする
            if (each.getOpeningTime() != null && !CommonUtils.isTimeStr(each.getOpeningTime())) {
                throw new IllegalArgumentException(messageSource.getMessage("e.com.kn.001",
                        CommonUtils.getMessageArgs(Integer.toString(each.getCheckNo()), "始業時刻"),
                        Locale.getDefault()));
            }
            if (each.getEndingTime() != null && !CommonUtils.isTimeStr(each.getEndingTime())) {
                throw new IllegalArgumentException(messageSource.getMessage("e.com.kn.001",
                        CommonUtils.getMessageArgs(Integer.toString(each.getCheckNo()), "終業時刻"),
                        Locale.getDefault()));
            }

            // マスタの記号値がこちらが実装した値のいずれかであることをチェックする
            try {
                // 始業時刻
                if (each.getOpeningTimeSign() != null) {
                    Sign.fromCode(each.getOpeningTimeSign());
                }
                // 終業時刻
                if (each.getEndingTimeSign() != null) {
                    Sign.fromCode(each.getEndingTimeSign());
                }
                // 休憩時間
                if (each.getOffTimeSign() != null) {
                    Sign.fromCode(each.getOffTimeSign());
                }
                // 勤怠稼働時間
                if (each.getInputTimeSign() != null) {
                    Sign.fromCode(each.getInputTimeSign());
                }
                // 工数稼働時間
                if (each.getKosuTimeSign() != null) {
                    Sign.fromCode(each.getKosuTimeSign());
                }
                // 工数休暇工数
                if (each.getKosuOffTimeSign() != null) {
                    Sign.fromCode(each.getKosuOffTimeSign());
                }
                // プロジェクトID
                if (each.getPjidSign() != null) {
                    Sign.fromCode(each.getPjidSign());
                }
                // 工程CD1
                if (each.getKoteiSign1() != null) {
                    Sign.fromCode(each.getKoteiSign1());
                }
                // 工程CD2
                if (each.getKoteiSign2() != null) {
                    Sign.fromCode(each.getKoteiSign2());
                }

            } catch (NoSuchElementException e) {
                throw new IllegalArgumentException(messageSource.getMessage("e.com.kn.002",
                        CommonUtils.getMessageArgs(Integer.toString(each.getCheckNo())), Locale.getDefault()));
            }
        }
    }

    private boolean isNoChecker(KosuChecker kosuChecker) {

        // チェックNoが1000と1001の場合は例外とする(固定チェックは例外とする)
        if (kosuChecker.getCheckNo() == PJ_CHECK_NO || kosuChecker.getCheckNo() == KOTEI_CHECK_NO) {
            return true;
        }

        // 全てのサイズが0だった場合は、チェックをしない
        if (kosuChecker.getWholeChecks().size() == 0
                && kosuChecker.getFlgChecks().size() == 0
                && kosuChecker.getRowChecks().size() == 0) {
            return true;
        }
        return false;
    }



    private Personal getPersonal(CheckTargetPesonal checkTarget) {
        Personal personal = new Personal();
        personal.setEmpCd(checkTarget.getEmpCd());
        personal.setEmpKbn(checkTarget.getEmpKbn());
        personal.setDeptCd(checkTarget.getDeptCd());
        // 振替のnull対策
        personal.setCalendarType(checkTarget.getCalendarType() == null ? null : checkTarget.getCalendarType());

        return personal;

    }

    private List<KosuData> getKosuData(List<KosuData> wholeKosuDataList, CheckTargetPesonal checkTarget) {

        // DBから取得した工数データリスト(全社員,対象期間全日付)に対して、社員CDと日付でフィルタリングしたものを返却する
        return wholeKosuDataList.stream().filter(kosuData1 -> kosuData1.getEmpCd().equals(checkTarget.getEmpCd()))
                .filter(kosuData2 -> kosuData2.getDate().isEqual(checkTarget.getDate()))
                .collect(Collectors.toList());

    }

    private CompanyData getCompanyCheckTarget(List<CompanyData> companyDataList, String empCd, LocalDate targetDate) {
        // 勤怠データリストから社員CDと日付を条件にチェック対象の勤怠データを取得(取得できなかった場合、オブジェクトを生成)
        return companyDataList.stream()
                .filter(data -> data.getEmpCd().equals(empCd) && data.getDate().isEqual(targetDate))
                .findFirst().orElse(new CompanyData());
    }

    private CheckList createCheckList(CheckTargetPesonal target, KosuChecker checker, List<Exclusion> exclusionList,
            CompanyData companyData, KosuData kosuData, LocalDateTime sysDateTime, int serial, transactionKbn kbn) {

        CheckList checkList = new CheckList();

        checkList.setEmpCd(target.getEmpCd());
        checkList.setErroredOn(target.getDate());
        checkList.setSerial(serial);
        checkList.setCheckNum(checker.getCheckNo());
        checkList.setInputYm(DateUtil.getYearMonth(target.getDate()));

        // 勤怠
        if (companyData != null) {
            checkList.setKintaiCd(companyData.getKintaiCd());
            checkList.setOpeningTime(companyData.getOpeningTime());
            checkList.setEndingTime(companyData.getEndingTime());
            checkList.setOffTime(companyData.getOffTime());
            checkList.setInputTime(companyData.getInputTime());
        }

        // 工数
        if (kosuData != null) {
            checkList.setKosuTime(getKosu(kosuData));
            checkList.setKosuOffTime(getOffKosu(kosuData));
            checkList.setKoteiCd(kosuData.getKoteiCd());
            checkList.setPjId(kosuData.getPjId());
        }

        // 振替に対しては管理者表示フラグを立てる
        switch (kbn) {
            case BEFORE:
                checkList.setAdminDisping(FLAG_ON);
                checkList.setTransactionKbn(transactionKbn.BEFORE.value);
                break;
            case AFTER:
                checkList.setAdminDisping(FLAG_ON);
                checkList.setTransactionKbn(transactionKbn.AFTER.value);
                break;
            default:
                checkList.setAdminDisping(FLAG_OFF);
                checkList.setTransactionKbn(transactionKbn.NORMAL.value);
                break;
        }

        checkList.setRegChecking(checker.getRegisterChkFlg());
        checkList.setNightChecking(checker.getNightChkFlg());
        checkList.setManualChecking(checker.getManualChkFlg());

        // 作成日、更新日
        checkList.setCreatedAt(sysDateTime);
        checkList.setUpdatedAt(sysDateTime);

        // 除外チェックをし、該当する場合はメッセージをセット
        checkExclusion(checkList, exclusionList, target, checker.getCheckNo());

        return checkList;
    }


    private BigDecimal getKosu(KosuData kosuData) {
        if (!kosuData.getKoteiCd().equals(OFF_TIME)) {
            return kosuData.getKosu();
        }
        return BigDecimal.ZERO;
    }

    private BigDecimal getOffKosu(KosuData kosuData) {
        if (kosuData.getKoteiCd().equals(OFF_TIME)) {
            return kosuData.getKosu();
        }
        return BigDecimal.ZERO;
    }

    private boolean needsCheck(String checkFlg, LocalDate targetDate, LocalDate sydDate) {
        // チェックフラグが立っている場合、システム日付の前日までをチェック対象とする
        if (checkFlg != null && checkFlg.equals(FLAG_ON) && targetDate.isAfter(sydDate)) {
            return false;
        }

        return true;
    }

    private boolean matchProject(KosuData kosuData, Personal personal, String corpCd) {
        String pjId = kosuData.getPjId();
        // PJIDがnull即ち、バッチの場合かつ工数入力がされていない場合はチェック不要
        if (pjId == null) {
            return false;
        }
        // 対象のプロジェクトの生産営業担当部門と所属部門が一致しない場合は公開チェックへ
        if (isAffiliationProject(pjId, personal.getDeptCd())) {
            return false;
        }
        // 公開されていなかった場合は異常とみなしtrueを返却
        if (!isOpen(kosuData, personal, corpCd)) {
            return true;
        }
        // 異常なしであればfalseを返却
        return false;
    }

    private boolean isAffiliationProject(String pjId, String deptCd) {

        // プロジェクトIDを条件に対象のプロジェクト情報を取得
        Project project = projectRepository.findOneByPk(pjId);

        // 対象プロジェクトの生産営業担当部門が対象社員の所属部門CDと異なる場合はfalse
        if (project.getProSalesDeptCd().equals(deptCd)) {
            return true;
        }
        return false;
    }

    private boolean matchKotei(KosuData kosuData, List<String> oPjKoteiCdList, List<String> salesKoteiCdList) {
        // PJIDがnull即ち、バッチの場合かつ工数入力がされていない場合はチェック不要
        ProjectId projectId = new ProjectId(kosuData.getPjId());
        String koteiCd = kosuData.getKoteiCd();
        if (projectId.isOPj()) {
            return !oPjKoteiCdList.contains(koteiCd);
        }
        if (projectId.isSalesPj()) {
            return !salesKoteiCdList.contains(koteiCd);
        }
        if (projectId.isProductPj()) {
            // 対象の工程CDが積算されていない場合エラーとする(実績のみの積算データは考慮せず、現行通り実装しておく)
            if (sekisanDataRepository.findOneByPjIdAndKoteiCd(kosuData.getPjId(), koteiCd) == null) {
                return true;
            }
        }
        return false;
    }

    private boolean isOpen(KosuData kosuData, Personal personal, String corpCd) {

        List<OpenPjInfo> openPjInfoList =
                openPjInfoRepository.findAllByPjIdAndDate(kosuData.getPjId(), kosuData.getDate());
        for (OpenPjInfo openPjInfo : openPjInfoList) {
            // 会社CDチェック
            if (openPjInfo.getCorpCd() != null) {
                if (!openPjInfo.getCorpCd().equals(corpCd)) {
                    continue;
                }
            }
            // 部門CDチェック
            if (openPjInfo.getDeptCd() != null) {
                if (!openPjInfo.getDeptCd().equals(personal.getDeptCd())) {
                    continue;
                }
            }
            // 社員区分チェック
            if (openPjInfo.getEmpKbn() != null) {
                if (!openPjInfo.getEmpKbn().equals(personal.getEmpKbn())) {
                    continue;
                }
            }
            // 社員CDチェック
            if (openPjInfo.getEmpCd() != null) {
                if (!openPjInfo.getEmpCd().equals(personal.getEmpCd())) {
                    continue;
                }
            }
            // 全てに一致した場合 = 公開されている(全てnullの場合は存在しないこととする)
            return true;
        }
        // 一致するレコードが無かった場合 = 公開されていない
        return false;
    }

    private void checkExclusion(CheckList checkList, List<Exclusion> exclusionList, CheckTargetPesonal target,
            int checkNum) {

        List<Exclusion> filteredList = filterByCheckNum(exclusionList, checkNum);

        // 除外情報1行ずつに対して、年月と日付と社員CDと部門の一致チェックを実施する
        for (Exclusion each : filteredList) {

            // 年月チェック
            if (each.getTargetYm() != null) {
                if (!DateUtil.getYearMonth(target.getDate()).equals(each.getTargetYm())) {
                    continue;
                }
            }

            // 日付チェック
            if (each.getExcludingDate() != null) {
                if (!isEqualData(target.getDate(), each.getExcludingDate())) {
                    continue;
                }
            }

            // 社員CDチェック
            if (each.getEmpCd() != null) {
                String empCdPattern = each.getEmpCd().replaceAll("\\*", ".");
                if (!target.getEmpCd().matches(empCdPattern)) {
                    continue;
                }
            }

            // 部門チェック
            if (each.getDeptCd() != null) {
                String deptCdPattern = each.getDeptCd().replaceAll("\\*", ".");
                if (!target.getDeptCd().matches(deptCdPattern)) {
                    continue;
                }
            }

            // 全てに一致した場合は除外対象とし、フラグを立て、メッセージをセット(除外情報が全てnullの場合は考慮しない)
            checkList.setExcluding(FLAG_ON);
            checkList.setExcludingReason(each.getExcludingReason());
            return;
        }

        // 除外リストが0件の場合、もしくは、いずれにもマッチしない場合
        checkList.setExcluding(FLAG_OFF);

    }

    private boolean isEqualData(LocalDate targetDate, String excludingDate) {

        String targetDateStr = Integer.toString(targetDate.getDayOfMonth());
        if (excludingDate.equals(targetDateStr)) {
            return true;
        }
        return false;
    }

    private List<Exclusion> filterByCheckNum(List<Exclusion> exclusionList, int targetCheckNum) {
        // チェックNumでフィルタリングしたリストを返却する
        return exclusionList.stream()
                .filter(each -> each.getCheckNum() == targetCheckNum)
                .collect(Collectors.toList());

    }

    private CheckTargetPesonal getCheckTarget(TransferData transferData) {
        CheckTargetPesonal target = new CheckTargetPesonal();
        target.setEmpCd(transferData.getEmpCd());
        target.setDeptCd(transferData.getDeptCd());
        target.setDate(transferData.getDate());
        target.setCalendarType(transferData.getCalendarType());

        return target;
    }

    private KosuData getKosuData(TransferData transferData) {
        KosuData kosuData = new KosuData();
        kosuData.setPjId(transferData.getPjId());
        kosuData.setKoteiCd(transferData.getKoteiCd());
        kosuData.setKosu(transferData.getKosu());

        return kosuData;
    }

    private boolean checkExclusion(List<CheckList> checkList, KosuChecker checker, Personal emp,
            List<KosuData> kosuDataList, KosuData kosuData, String loginEmpCd) {
        LocalDate targetDate = kosuData.getDate();
        // 対象の日付と社員情報を指定し、当てはまる全ての除外情報を取得する
        String yearMonth = DateUtil.getYearMonth(targetDate);
        Exclusion exclusion = exclusionRepository.findOneByCondition(checker.getCheckNo(), yearMonth, targetDate,
                emp.getEmpCd(), emp.getDeptCd());

        if (exclusion != null) {
            checkList.add(createCheckList(checker, targetDate, kosuDataList, kosuData, emp, exclusion, loginEmpCd));
            return true;
        }
        return false;
    }

    private CheckList createCheckList(KosuChecker checker, LocalDate targetDate, List<KosuData> kosuDataList,
            KosuData kosuData, Personal emp, Exclusion exlusion, String loginEmpCd) {

        CheckList checkList = new CheckList();

        checkList.setEmpCd(emp.getEmpCd());
        checkList.setErroredOn(targetDate);
        checkList.setCheckNum(checker.getCheckNo());
        checkList.setInputYm(DateUtil.getYearMonth(targetDate));

        checkList.setKosuTime(getKosu(kosuData));
        checkList.setKosuOffTime(getOffKosu(kosuData));
        checkList.setKoteiCd(kosuData.getKoteiCd());
        checkList.setPjId(kosuData.getPjId());

        checkList.setExcluding("1");
        checkList.setExcludingReason(exlusion.getExcludingReason());

        checkList.setAdminDisping(FLAG_OFF);

        checkList.setRegChecking(checker.getRegisterChkFlg());
        checkList.setNightChecking(checker.getNightChkFlg());
        checkList.setManualChecking(checker.getManualChkFlg());

        checkList.setTransactionKbn(transactionKbn.NORMAL.value);

        LocalDateTime sysDateTime = dateFactory.newDateTime();
        // 作成者、作成日、更新者、更新日
        checkList.setCreatedBy(loginEmpCd);
        checkList.setCreatedAt(sysDateTime);
        checkList.setUpdatedBy(loginEmpCd);
        checkList.setUpdatedAt(sysDateTime);

        return checkList;
    }
}
