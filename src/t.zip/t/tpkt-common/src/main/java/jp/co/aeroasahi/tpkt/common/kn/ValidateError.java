package jp.co.aeroasahi.tpkt.common.kn;

import lombok.Getter;
import lombok.Setter;

/**
 * エラーメッセージを保持するオブジェクト
 */
@Getter
@Setter
public class ValidateError {

    /** エラーメッセージ */
    private String errorMessage;

    /**
     * @return errorMessage
     */
    public String getErrorMessage() {
        return errorMessage;
    }

    /**
     * @param errorMessage セットする errorMessage
     */
    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}
