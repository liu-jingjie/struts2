package jp.co.aeroasahi.tpkt.common.fw.project;

/**
 * プロジェクト種別
 */
public enum PjType {

    /**
     * 製造原価
     */
    P_PJ,

    /**
     * 研究
     */
    R_PJ,

    /**
     * その他
     */
    O_PJ;

    /**
     * コード(P or R or O)を返す。
     * 
     * @return コード
     */
    public String getCode() {
        return toString().substring(0, 1);
    }
}
